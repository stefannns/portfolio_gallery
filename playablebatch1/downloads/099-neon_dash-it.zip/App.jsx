// Mount game-owned markup with DOM nodes. Native hosts do not all implement
// HTML-string setters; keep mounting synchronous for the gameplay code below.
function mountPlayableMarkup(target, markup) {
  if (!target) throw new Error('Game mount target is missing');
  const source = String(markup ?? '');
  const decode = value => value.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi, (match, entity) => {
    if (entity[0] === '#') {
      const hex = entity[1].toLowerCase() === 'x';
      const code = parseInt(entity.slice(hex ? 2 : 1), hex ? 16 : 10);
      return code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : '\ufffd';
    }
    return ({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:'\u00a0'})[entity.toLowerCase()] || match;
  });
  while (target.firstChild) target.removeChild(target.firstChild);
  const stack = [{element:target, tag:'', svg:target.namespaceURI === 'http://www.w3.org/2000/svg'}];
  const voidTags = /^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)$/i;
  let position = 0;
  while (position < source.length) {
    if (source.startsWith('<!--', position)) {
      const end = source.indexOf('-->', position + 4);
      position = end < 0 ? source.length : end + 3;
      continue;
    }
    if (source[position] !== '<') {
      const next = source.indexOf('<', position);
      const end = next < 0 ? source.length : next;
      stack[stack.length - 1].element.appendChild(document.createTextNode(decode(source.slice(position, end))));
      position = end;
      continue;
    }
    let end = position + 1, quote = '';
    for (; end < source.length; end++) {
      const c = source[end];
      if (quote) { if (c === quote) quote = ''; }
      else if (c === '"' || c === "'") quote = c;
      else if (c === '>') break;
    }
    if (end >= source.length) throw new Error('Incomplete game markup');
    const token = source.slice(position + 1, end);
    position = end + 1;
    if (/^\s*!/.test(token)) continue;
    const close = /^\s*\/\s*([\w:-]+)/.exec(token);
    if (close) {
      for (let i = stack.length - 1; i > 0; i--) {
        if (stack[i].tag.toLowerCase() === close[1].toLowerCase()) { stack.length = i; break; }
      }
      continue;
    }
    const opening = /^\s*([\w:-]+)/.exec(token);
    if (!opening) throw new Error('Invalid game markup');
    const tag = opening[1], parent = stack[stack.length - 1];
    const svg = tag.toLowerCase() === 'svg' || (parent.svg && parent.tag.toLowerCase() !== 'foreignobject');
    const element = svg ? document.createElementNS('http://www.w3.org/2000/svg', tag) : document.createElement(tag);
    const attributes = token.slice(opening[0].length).replace(/\/\s*$/, '');
    const attribute = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
    let match;
    while ((match = attribute.exec(attributes))) {
      const name = match[1], value = decode(match[2] ?? match[3] ?? match[4] ?? '');
      element.setAttribute(name, value);
    }
    parent.element.appendChild(element);
    if (!voidTags.test(tag) && !/\/\s*$/.test(token)) stack.push({element, tag, svg});
  }
  return source;
}

document.documentElement.lang = 'it';
(() => {
  'use strict';
  const root = document.getElementById('root');
  const style = document.createElement('style');
  style.textContent = `
    *{box-sizing:border-box}html,body,#root{width:100%;height:100%;margin:0;overflow:hidden;background:#090b1b;color:#e8fdff;font-family:Arial,sans-serif;-webkit-tap-highlight-color:transparent}
    button{font:700 16px Arial,sans-serif;touch-action:manipulation;cursor:pointer}
    .dash{position:relative;width:100%;height:100%;overflow:hidden;touch-action:none;user-select:none}
    canvas{display:block;width:100%;height:100%}
    .hud{position:absolute;left:30px;right:30px;top:28px;pointer-events:none}
    .stats{display:flex;justify-content:space-between;align-items:baseline;font-size:13px;letter-spacing:1px;color:#9da7c5}.progress-label{font-size:20px;font-weight:800;color:#75f2ff;letter-spacing:0}
    .track{height:5px;border-radius:5px;background:#292e43;margin-top:8px;overflow:hidden}.fill{height:100%;width:0;background:#75f2ff;box-shadow:0 0 12px #39e1ff;border-radius:5px}
    .levels{position:absolute;top:93px;left:0;right:0;display:flex;justify-content:center;gap:14px}
    .levels button{position:relative;width:40px;height:40px;border:1px solid #394259;color:#bac6db;border-radius:50%;background:#15182b}
    .levels button.selected{background:#75f2ff;color:#071a23;border-color:#75f2ff;box-shadow:0 0 20px #34e9ff35}.levels button:disabled{cursor:default;opacity:.55}
    .lock{display:inline-block;width:10px;height:9px;border-radius:2px;background:#7b879e;position:relative}.lock:before{content:'';position:absolute;left:1px;top:-7px;width:8px;height:9px;border:2px solid #7b879e;border-radius:7px}
    .guide{position:absolute;top:34%;left:30px;right:30px;text-align:center;color:#e5fdff;font-size:20px;font-weight:800;line-height:1.3;text-shadow:0 2px 12px #142b42;pointer-events:none;animation:breathe 1.9s ease-in-out infinite}
    @keyframes breathe{50%{opacity:.65;transform:scale(.97)}}
    .result{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:#06081796;backdrop-filter:blur(4px);z-index:5}
    .card{width:calc(100% - 60px);max-width:320px;text-align:center;border:1px solid #485b7b;background:#0e1426ee;border-radius:20px;padding:30px 24px;box-shadow:0 15px 50px #0006}
    .card h1{margin:0 0 18px;font-size:24px;letter-spacing:-.6px}.card p{margin:0 0 25px;color:#8df5ff;font-size:46px;font-weight:800;font-variant-numeric:tabular-nums}
    .card button{border:0;border-radius:30px;padding:13px 28px;background:#75f2ff;color:#08212d;box-shadow:0 5px 22px #2be4ff24}.hidden{display:none}
    @media(max-height:520px){.hud{top:20px}.levels{top:79px}.levels button{height:34px;width:34px}}
  `;
  document.head.append(style);
  mountPlayableMarkup(root, `<div class="dash"><canvas aria-label="Campo di Scatto neon"></canvas><div class="hud"><div class="stats"><span class="best">RECORD 0%</span><span class="progress-label">0%</span></div><div class="track"><div class="fill"></div></div></div><div class="levels" aria-label="Scegli il livello"></div><div class="guide">Tocca per saltare</div><div class="result hidden"><div class="card"><h1>Riprova</h1><p>0%</p><button>Riprova</button></div></div></div>`);
  const game = root.querySelector('.dash'), canvas = root.querySelector('canvas'), ctx = canvas.getContext('2d');
  const progressEl = root.querySelector('.progress-label'), bestEl = root.querySelector('.best'), fill = root.querySelector('.fill');
  const guide = root.querySelector('.guide'), levelsEl = root.querySelector('.levels'), result = root.querySelector('.result');
  // Three progressively denser rhythm courses; speed and jump physics stay fixed.
  const courses = [{"speed":285,"length":8600,"spacing":1,"loopFrom":8,"patterns":["single","double","short-pair","platforms","tall","low-ceiling","saw","double","platforms","high-saw","triple","jump-duck","spike-ledge","saw-platform","duck-jump","short-pair","stairs-up","low-ceiling"]},{"speed":320,"length":10300,"spacing":0.97,"loopFrom":6,"patterns":["double","saw-spike","platforms","triple","duck-jump","spike-ledge","saw-ceiling","stairs-up","high-saw","quad","jump-duck","steps-down","high-ledge","saw-platform","duck-jump","tall","spike-ledge","stairs-up"]},{"speed":355,"length":12000,"spacing":0.94,"loopFrom":4,"patterns":["triple","spike-ledge","saw-ceiling","quad","jump-duck","stairs-up","duck-jump","high-ledge","saw-spike","steps-down","quad","jump-duck","platforms","saw-platform","high-saw","high-ledge","stairs-up","duck-jump"]}];
  const obstaclePatterns = {"single":{"advance":280,"objects":[{"x":0,"w":28,"h":40,"kind":"spike"}]},"double":{"advance":300,"objects":[{"x":0,"w":28,"h":40,"kind":"spike"},{"x":29,"w":28,"h":40,"kind":"spike"}]},"triple":{"advance":330,"objects":[{"x":0,"w":28,"h":40,"kind":"spike"},{"x":29,"w":28,"h":40,"kind":"spike"},{"x":58,"w":28,"h":40,"kind":"spike"}]},"quad":{"advance":360,"objects":[{"x":0,"w":28,"h":40,"kind":"spike"},{"x":29,"w":28,"h":40,"kind":"spike"},{"x":58,"w":28,"h":40,"kind":"spike"},{"x":87,"w":28,"h":40,"kind":"spike"}]},"short-pair":{"advance":280,"objects":[{"x":0,"w":26,"h":24,"kind":"spike"},{"x":68,"w":26,"h":24,"kind":"spike"}]},"tall":{"advance":300,"objects":[{"x":0,"w":30,"h":58,"kind":"spike"}]},"saw":{"advance":315,"objects":[{"x":0,"w":48,"r":24,"lift":24,"kind":"saw"}]},"high-saw":{"advance":300,"objects":[{"x":0,"w":48,"r":24,"lift":78,"kind":"saw"}]},"platforms":{"advance":480,"objects":[{"x":0,"w":90,"h":28,"kind":"block"},{"x":130,"w":100,"h":52,"kind":"block"}]},"stairs-up":{"advance":580,"objects":[{"x":0,"w":76,"h":24,"kind":"block"},{"x":112,"w":86,"h":48,"kind":"block"},{"x":242,"w":96,"h":72,"kind":"block"}]},"steps-down":{"advance":500,"objects":[{"x":0,"w":112,"h":60,"kind":"block"},{"x":160,"w":106,"h":30,"kind":"block"}]},"low-ceiling":{"advance":320,"objects":[{"x":0,"w":152,"h":76,"lift":146,"kind":"ceiling"}]},"saw-ceiling":{"advance":510,"objects":[{"x":0,"w":48,"r":24,"lift":24,"kind":"saw"},{"x":210,"w":150,"h":76,"lift":146,"kind":"ceiling"}]},"saw-platform":{"advance":440,"objects":[{"x":0,"w":48,"r":24,"lift":24,"kind":"saw"},{"x":155,"w":112,"h":44,"kind":"block"}]},"spike-ledge":{"advance":430,"objects":[{"x":0,"w":190,"h":34,"kind":"block"},{"x":90,"w":26,"h":26,"kind":"spike","lift":34}]},"high-ledge":{"advance":490,"objects":[{"x":0,"w":192,"h":52,"kind":"block"},{"x":86,"w":26,"h":24,"kind":"spike","lift":52}]},"jump-duck":{"advance":490,"objects":[{"x":0,"w":28,"h":40,"kind":"spike"},{"x":29,"w":28,"h":40,"kind":"spike"},{"x":58,"w":28,"h":40,"kind":"spike"},{"x":226,"w":138,"h":74,"lift":140,"kind":"ceiling"}]},"duck-jump":{"advance":500,"objects":[{"x":0,"w":128,"h":78,"lift":160,"kind":"ceiling"},{"x":224,"w":28,"h":40,"kind":"spike"},{"x":253,"w":28,"h":40,"kind":"spike"}]},"saw-spike":{"advance":390,"objects":[{"x":0,"w":48,"r":24,"lift":24,"kind":"saw"},{"x":112,"w":28,"h":28,"kind":"spike"}]}};
  const key = 'neon-dash-progress-v1';
  let saved = {best:courses.map(()=>0),unlocked:1};
  try {
    const data=JSON.parse(localStorage.getItem(key)||'null');
    if(data&&Array.isArray(data.best)){
      saved.best=courses.map((_,i)=>Math.max(0,Math.min(100,Number(data.best[i])||0)));
      saved.unlocked=Math.max(1,Math.min(courses.length,Math.floor(Number(data.unlocked)||1)));
      // Retain the first three best scores and clamp any former extra-stage unlocks.
      for(let i=0;i<courses.length-1;i++)if(saved.best[i]===100)saved.unlocked=Math.max(saved.unlocked,i+2);
    }
  }catch(_){}
  // Normalize any saved six-stage campaign back to the retained three courses.
  persist();
  let W=390,H=598,ground=450,level=0,phase='ready',active=true,offset=0,vy=0,y=0,angle=0,grounded=true,held=false,jumpBuffer=0,freeze=0,last=0,particles=[],trail=[],lastHud=-1,shake=0,beat=0;
  const cube = {x:112,size:29};
  let obstacles=[],length=9000,speed=285,attempts=1;
  let audio=null,music=null,musicTimer=null,musicNext=0,musicStep=0;
  function getAudio(){
    if(!audio)audio=new (window.AudioContext||window.webkitAudioContext)();
    if(audio.state==='suspended')audio.resume().catch(()=>{});
    return audio;
  }
  function sound(type){
    try {
      getAudio();
      const at=audio.currentTime,o=audio.createOscillator(),g=audio.createGain();o.connect(g);g.connect(audio.destination);
      const start=type==='jump'?410:type==='crash'?160:660,end=type==='jump'?590:type==='crash'?48:990,duration=type==='crash'?.19:.1;
      o.type=type==='crash'?'triangle':'sine';o.frequency.setValueAtTime(start,at);o.frequency.exponentialRampToValueAtTime(end,at+duration);g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(type==='jump'?.09:.15,at+.008);g.gain.exponentialRampToValueAtTime(.0001,at+duration);o.start(at);o.stop(at+duration+.02);
      o.onended=()=>{o.disconnect();g.disconnect();};
    }catch(_){}
  }
  // Original 128 BPM synth loop: kick, backbeat, hats, syncopated bass and arpeggio.
  // Schedule a short window ahead so note timing stays independent of rendering.
  const beatLength=60/128,sixteenth=beatLength/4;
  const frequency=note=>440*Math.pow(2,(note-69)/12);
  function musicVoice(freq,at,duration,volume,type='triangle',cutoff=2200,endFrequency=0,attack=.006){
    const o=audio.createOscillator(),g=audio.createGain(),filter=audio.createBiquadFilter();
    o.type=type;o.frequency.setValueAtTime(freq,at);
    if(endFrequency)o.frequency.exponentialRampToValueAtTime(endFrequency,at+duration*.8);
    filter.type='lowpass';filter.frequency.value=cutoff;filter.Q.value=.6;
    g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(volume,at+attack);g.gain.exponentialRampToValueAtTime(.0001,at+duration);
    o.connect(filter);filter.connect(g);g.connect(music.bus);music.voices.add(o);
    o.onended=()=>{music.voices.delete(o);o.disconnect();filter.disconnect();g.disconnect();};
    o.start(at);o.stop(at+duration+.02);
  }
  function musicNoise(at,duration,volume,cutoff){
    const n=audio.createBufferSource(),g=audio.createGain(),filter=audio.createBiquadFilter();n.buffer=music.noise;
    filter.type='highpass';filter.frequency.value=cutoff;
    g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(volume,at+.002);g.gain.exponentialRampToValueAtTime(.0001,at+duration);
    n.connect(filter);filter.connect(g);g.connect(music.bus);music.voices.add(n);
    n.onended=()=>{music.voices.delete(n);n.disconnect();filter.disconnect();g.disconnect();};
    n.start(at);n.stop(at+duration+.01);
  }
  function scheduleMusic(){
    if(!active||document.hidden||phase!=='playing'){stopMusic();return;}
    while(musicNext<audio.currentTime+.13){
      const step=musicStep%16,bar=Math.floor(musicStep/16)%4;
      const base=[45,41,48,43][bar],chord=bar===0?[0,3,7,12]:[0,4,7,12];
      if(step%4===0)musicVoice(145,musicNext,.19,.36,'sine',1200,44);
      if(step===4||step===12){musicNoise(musicNext,.12,.12,1300);musicVoice(180,musicNext,.085,.075,'triangle',1600,105);}
      if(step%2===0)musicNoise(musicNext,step===14?.10:.037,step%4===2?.047:.029,6500);
      if(step%4===0||step===7||step===14)musicVoice(frequency(base),musicNext,.20,.13,'sawtooth',650);
      if(step%2===0){const note=[0,2,1,3,2,1,2,0][step/2];musicVoice(frequency(base+24+chord[note]),musicNext,.18,.09,'sawtooth',2100);}
      if(step===0)for(const interval of chord.slice(0,3))musicVoice(frequency(base+12+interval),musicNext,beatLength*3.8,.018,'triangle',1100,0,.06);
      musicStep++;musicNext+=sixteenth;
    }
  }
  function startMusic(){
    if(!active||document.hidden||phase!=='playing'||musicTimer)return;
    try{
      getAudio();
      if(!music){
        const bus=audio.createGain();bus.gain.value=0;bus.connect(audio.destination);
        const noise=audio.createBuffer(1,Math.ceil(audio.sampleRate*.25),audio.sampleRate),samples=noise.getChannelData(0);
        for(let i=0;i<samples.length;i++)samples[i]=Math.random()*2-1;
        music={bus,noise,voices:new Set()};
      }
      const now=audio.currentTime;music.bus.gain.cancelScheduledValues(now);music.bus.gain.setValueAtTime(0,now);music.bus.gain.linearRampToValueAtTime(.36,now+.16);
      musicStep=0;musicNext=now+.025;musicTimer=setInterval(scheduleMusic,25);scheduleMusic();game.dataset.music='playing';
    }catch(_){stopMusic();}
  }
  function stopMusic(){
    if(musicTimer){clearInterval(musicTimer);musicTimer=null;}
    if(music&&audio){
      const at=audio.currentTime;music.bus.gain.cancelScheduledValues(at);music.bus.gain.setValueAtTime(music.bus.gain.value,at);music.bus.gain.linearRampToValueAtTime(0,at+.045);
      for(const voice of music.voices){try{voice.stop(at+.05);}catch(_){}}
    }
    game.dataset.music='stopped';
  }
  function persist(){try{localStorage.setItem(key,JSON.stringify(saved))}catch(_){}}
  function progress(){return Math.min(100,Math.floor(offset/length*100))}
  function hud(){const p=progress();if(p!==lastHud){progressEl.textContent=p+'%';fill.style.width=p+'%';lastHud=p;}bestEl.textContent='RECORD '+(saved.best[level]||0)+'%';game.dataset.progress=String(p);game.dataset.phase=phase;}
  function levels(){mountPlayableMarkup(levelsEl, courses.map((_,i)=>`<button aria-label="Livello ${i+1}${i>=saved.unlocked?' bloccato':''}" ${i>=saved.unlocked?'disabled':''} class="${i===level?'selected':''}" data-level="${i}">${i<saved.unlocked?i+1:'<span class="lock" aria-hidden="true"></span>'}</button>`).join(''))}
  function makeLevel(){
    const course=courses[level];
    obstacles=[];speed=course.speed;length=course.length;
    let x=600;
    for(let i=0;x<length-500;i++){
      // Intro motifs appear once; later repeats keep the stronger closing rhythm.
      const loopFrom=course.loopFrom||0;
      const index=i<course.patterns.length?i:loopFrom+(i-loopFrom)%(course.patterns.length-loopFrom);
      const pattern=obstaclePatterns[course.patterns[index]];
      for(const object of pattern.objects)obstacles.push({...object,x:x+object.x});
      x+=Math.round(pattern.advance*course.spacing);
    }
    game.dataset.level=String(level+1);game.dataset.levelCount=String(courses.length);
  }
  function reset(start=false){offset=0;y=0;vy=0;angle=0;grounded=true;held=false;jumpBuffer=0;particles=[];trail=[];freeze=0;lastHud=-1;phase=start?'playing':'ready';result.classList.add('hidden');guide.classList.toggle('hidden',start);makeLevel();hud();if(start)startMusic();else stopMusic();draw();}
  function burst(x,yy,color,n=18){for(let i=0;i<n;i++){const a=i/n*Math.PI*2,s=65+Math.random()*180;particles.push({x,y:yy,vx:Math.cos(a)*s,vy:Math.sin(a)*s,color,life:.55+Math.random()*.25,size:2+Math.random()*5})}}
  function jump(){if(!grounded)return;vy=-625;grounded=false;jumpBuffer=0;sound('jump');burst(cube.x,ground+y,'#64dce8',5)}
  function press(){if(!active||phase==='crashed'||phase==='complete')return;if(phase==='ready'){phase='playing';guide.classList.add('hidden');hud();startMusic();}jumpBuffer=.13;held=true;if(grounded)jump()}
  function release(){held=false}
  function end(won){
    if(phase!=='playing')return;phase=won?'complete':'crashed';held=false;freeze=won?.2:.45;stopMusic();
    saved.best[level]=Math.max(saved.best[level]||0,won?100:progress());if(won)saved.unlocked=Math.max(saved.unlocked,Math.min(courses.length,level+2));persist();hud();levels();sound(won?'win':'crash');
    if(!won){shake=.2;burst(cube.x+cube.size/2,ground+y-cube.size/2,'#75f2ff',28)}
  }
  function showResult(){result.classList.remove('hidden');result.querySelector('h1').textContent=phase==='complete'?'Livello completato':'Riprova';result.querySelector('p').textContent=phase==='complete'?'100%':progress()+'%';result.querySelector('button').textContent=phase==='complete'&&level<courses.length-1?'Livello successivo':'Riprova';}
  function resize(){const r=canvas.getBoundingClientRect(),d=Math.min(devicePixelRatio||1,2);canvas.width=Math.max(1,Math.round(r.width*d));canvas.height=Math.max(1,Math.round(r.height*d));H=W*(r.height/Math.max(1,r.width));ground=H*.76;ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);draw()}
  // A slightly inset player box and triangular spike test make visible contact fair.
  function hitsSpike(ob){
    const left=cube.x+4,right=cube.x+cube.size-4,top=ground+y-cube.size+4,bottom=ground+y-3;
    const x=ob.x-offset,base=ground-(ob.lift||0);
    if(right<=x||left>=x+ob.w||bottom<=base-ob.h)return false;
    const sample=Math.max(x+2,Math.min(x+ob.w-2,(left+right)/2));
    const surface=base-ob.h*(1-Math.abs((sample-(x+ob.w/2))/(ob.w/2)));
    return bottom>surface&&top<base;
  }
  function update(dt){
    if(phase==='playing'){
      const beforeY=y;offset+=speed*dt;jumpBuffer=Math.max(0,jumpBuffer-dt);
      vy+=2000*dt;y+=vy*dt;grounded=false;
      if(y>=0){if(vy>0&&beforeY<0)burst(cube.x,ground,'#75f2ff',5);y=0;vy=0;grounded=true;angle=Math.round(angle/(Math.PI/2))*Math.PI/2;}
      for(const ob of obstacles){
        const x=ob.x-offset;if(x>W+100||x+ob.w<cube.x-100)continue;
        const left=cube.x+4,right=cube.x+cube.size-4,top=y-cube.size+4,bottom=y-3;
        if(ob.kind==='spike'){
          if(hitsSpike(ob))end(false);
        }else if(ob.kind==='saw'){
          const cx=x+ob.r,cy=-ob.lift,nearX=Math.max(left,Math.min(right,cx)),nearY=Math.max(top,Math.min(bottom,cy));
          if(Math.hypot(cx-nearX,cy-nearY)<ob.r-1)end(false);
        }else if(ob.kind==='ceiling'){
          if(right>x+2&&left<x+ob.w-2&&bottom>-ob.lift+2&&top<-ob.lift+ob.h-2)end(false);
        }else if(right>x&&left<x+ob.w){
          if(beforeY<=-ob.h+2&&y>=-ob.h&&vy>=0){y=-ob.h;vy=0;grounded=true;angle=Math.round(angle/(Math.PI/2))*Math.PI/2;}
          else if(bottom>-ob.h&&top<0)end(false);
        }
      }
      if(grounded&&(held||jumpBuffer>0)&&phase==='playing')jump();
      if(!grounded)angle+=dt*5.5;
      beat+=dt;if(beat>.025){beat=0;trail.push({x:cube.x+2,y:ground+y-cube.size/2,life:.25});}
      if(offset>=length)end(true);hud();
    }else if((phase==='crashed'||phase==='complete')&&result.classList.contains('hidden')){freeze-=dt;if(freeze<=0)showResult()}
    for(const p of particles){p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=350*dt}particles=particles.filter(p=>p.life>0);
    for(const p of trail){p.life-=dt;p.x-=speed*dt}trail=trail.filter(p=>p.life>0);shake=Math.max(0,shake-dt);
  }
  function rounded(x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r)}
  function draw(){
    const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#0a1226');sky.addColorStop(1,'#17102a');
    ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);ctx.save();if(shake)ctx.translate((Math.random()-.5)*shake*22,(Math.random()-.5)*shake*22);
    // Even square cells replace the drifting decorative shapes.
    const grid=40,shift=offset*.12%grid;
    ctx.strokeStyle='#4d8aaf';ctx.lineWidth=1;ctx.globalAlpha=.27;ctx.beginPath();
    for(let x=-shift;x<W;x+=grid){ctx.moveTo(x,0);ctx.lineTo(x,ground);}
    for(let yy=0;yy<ground;yy+=grid){ctx.moveTo(0,yy);ctx.lineTo(W,yy);}ctx.stroke();
    ctx.strokeStyle='#78b2cf';ctx.globalAlpha=.10;ctx.beginPath();
    for(let x=-(offset*.12%(grid*4));x<W;x+=grid*4){ctx.moveTo(x,0);ctx.lineTo(x,ground);}
    for(let yy=0;yy<ground;yy+=grid*4){ctx.moveTo(0,yy);ctx.lineTo(W,yy);}ctx.stroke();
    ctx.globalAlpha=1;ctx.fillStyle='#0b1525';ctx.fillRect(0,ground,W,H-ground);
    ctx.strokeStyle='#346b83';ctx.globalAlpha=.35;ctx.lineWidth=1;ctx.beginPath();
    for(let x=-(offset%grid);x<W;x+=grid){ctx.moveTo(x,ground);ctx.lineTo(x,H);}
    for(let yy=ground+32;yy<H;yy+=32){ctx.moveTo(0,yy);ctx.lineTo(W,yy);}ctx.stroke();
    ctx.globalAlpha=1;ctx.strokeStyle='#75f2ff';ctx.lineWidth=2;ctx.shadowColor='#35d8eb';ctx.shadowBlur=7;ctx.beginPath();ctx.moveTo(0,ground);ctx.lineTo(W,ground);ctx.stroke();ctx.shadowBlur=0;
    for(const ob of obstacles){
      const x=ob.x-offset;if(x+ob.w< -50||x>W+80)continue;
      ctx.save();ctx.lineWidth=2.5;
      if(ob.kind==='saw'){
        ctx.translate(x+ob.r,ground-ob.lift);ctx.rotate(offset*.018);
        ctx.strokeStyle='#ffa766';ctx.fillStyle='#49253c';ctx.shadowColor='#f69858';ctx.shadowBlur=7;
        ctx.beginPath();
        for(let i=0;i<24;i++){const a=i*Math.PI/12,r=i%2?ob.r*.72:ob.r;const xx=Math.cos(a)*r,yy=Math.sin(a)*r;if(i)ctx.lineTo(xx,yy);else ctx.moveTo(xx,yy);}
        ctx.closePath();ctx.fill();ctx.stroke();ctx.shadowBlur=0;
        ctx.beginPath();ctx.arc(0,0,7,0,Math.PI*2);ctx.fillStyle='#111b30';ctx.fill();ctx.stroke();
      }else if(ob.kind==='ceiling'){
        const top=ground-ob.lift,bottom=top+ob.h;
        ctx.strokeStyle='#ffad79';ctx.fillStyle='#3d2340';ctx.shadowColor='#f08b76';ctx.shadowBlur=6;
        ctx.fillRect(x,top,ob.w,ob.h);ctx.strokeRect(x,top,ob.w,ob.h);ctx.shadowBlur=0;
        // Downward chevrons distinguish the low passage from landable cyan platforms.
        ctx.strokeStyle='#f6b38b';ctx.lineWidth=2;
        for(let xx=x+23;xx<x+ob.w-10;xx+=35){ctx.beginPath();ctx.moveTo(xx-7,bottom-20);ctx.lineTo(xx,bottom-13);ctx.lineTo(xx+7,bottom-20);ctx.stroke();}
      }else{
        ctx.strokeStyle=ob.kind==='spike'?'#f478ee':'#6addeb';ctx.fillStyle=ob.kind==='spike'?'#401b4b':'#163644';ctx.shadowColor=ctx.strokeStyle;ctx.shadowBlur=7;
        ctx.beginPath();
        if(ob.kind==='spike'){const base=ground-(ob.lift||0);ctx.moveTo(x,base);ctx.lineTo(x+ob.w/2,base-ob.h);ctx.lineTo(x+ob.w,base);ctx.closePath();}
        else ctx.rect(x,ground-ob.h,ob.w,ob.h);
        ctx.fill();ctx.stroke();ctx.shadowBlur=0;
        if(ob.kind==='block'){ctx.strokeStyle='#c2fbff';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x+3,ground-ob.h);ctx.lineTo(x+ob.w-3,ground-ob.h);ctx.stroke();}
      }
      ctx.restore();
    }
    if(length-offset<W){const xx=length-offset;ctx.strokeStyle='#80ffd0';ctx.setLineDash([7,5]);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(xx,ground-145);ctx.lineTo(xx,ground);ctx.stroke();ctx.setLineDash([])}
    for(const p of trail){ctx.globalAlpha=p.life*1.6;ctx.fillStyle='#75f2ff';ctx.fillRect(p.x,p.y,4,4)}ctx.globalAlpha=1;
    if(phase!=='crashed'){
      ctx.save();ctx.translate(cube.x+cube.size/2,ground+y-cube.size/2);ctx.rotate(angle);ctx.shadowColor='#50f3ff';ctx.shadowBlur=18;ctx.fillStyle='#32c6d8';rounded(-cube.size/2,-cube.size/2,cube.size,cube.size,5);ctx.fill();ctx.strokeStyle='#9cffff';ctx.lineWidth=2;ctx.stroke();ctx.shadowBlur=0;ctx.strokeStyle='#e5ffff';ctx.lineWidth=2;rounded(-8,-8,16,16,2);ctx.stroke();ctx.fillStyle='#b3ffff';ctx.fillRect(-3,-3,6,6);ctx.restore();
    }
    for(const p of particles){ctx.globalAlpha=Math.min(1,p.life*2);ctx.fillStyle=p.color;ctx.fillRect(p.x,p.y,p.size,p.size)}ctx.globalAlpha=1;ctx.restore();
  }
  game.addEventListener('pointerdown',e=>{if(e.target.closest('button,.result,.levels'))return;e.preventDefault();game.setPointerCapture(e.pointerId);press()});
  game.addEventListener('pointerup',release);game.addEventListener('pointercancel',release);game.addEventListener('lostpointercapture',release);
  window.addEventListener('keydown',e=>{if(e.code==='Space'||e.code==='ArrowUp'){e.preventDefault();if(!e.repeat)press()}});window.addEventListener('keyup',e=>{if(e.code==='Space'||e.code==='ArrowUp')release()});
  levelsEl.addEventListener('click',e=>{const b=e.target.closest('[data-level]');if(!b||b.disabled)return;level=Number(b.dataset.level);attempts=1;levels();reset()});
  result.querySelector('button').addEventListener('click',()=>{if(phase==='complete'&&level<courses.length-1){level++;attempts=1;levels()}else attempts++;reset(true)});
  window.addEventListener('message',e=>{if(e.source===parent&&e.data?.type==='playable-active'){active=!!e.data.active;if(!active){held=false;stopMusic();}else if(phase==='playing'&&audio)startMusic();last=0}});
  document.addEventListener('visibilitychange',()=>{last=0;held=false;if(document.hidden)stopMusic();else if(active&&phase==='playing'&&audio)startMusic();});window.addEventListener('pagehide',stopMusic);window.addEventListener('resize',resize);
  function frame(now){const dt=last?Math.min((now-last)/1000,.035):0;last=now;if(active&&!document.hidden){let remaining=dt;while(remaining>0){const step=Math.min(remaining,1/120);update(step);remaining-=step}draw()}requestAnimationFrame(frame)}
  levels();reset();resize();requestAnimationFrame(frame);
})();

// Batch 3 UI refinement — 2026-11-16
// Local fonts and explicit per-game layout rules; no gameplay or host mutations.
(() => {
  const uiStyle=document.createElement('style');
  uiStyle.dataset.batch3Ui='20261116';
  uiStyle.textContent="\n@font-face{font-family:UIBody;src:url('./assets/ui/Poppins-Regular.woff2') format('woff2');font-weight:400;font-style:normal;font-display:swap}\n@font-face{font-family:UIBody;src:url('./assets/ui/Poppins-Bold.woff2') format('woff2');font-weight:600 900;font-style:normal;font-display:swap}\nhtml,body,#root{font-family:UIBody,system-ui,sans-serif;-webkit-text-size-adjust:100%}\nbutton{font-family:UIBody,system-ui,sans-serif;font-size:16px;font-weight:700;line-height:1.3;min-height:44px}\nbutton:focus-visible{outline:3px solid currentColor;outline-offset:4px}\nbutton:disabled{opacity:.55}\n[hidden]{display:none!important}\n.guide{font-size:18px;line-height:1.4;text-wrap:balance}\n.hud{top:30px;left:30px;right:30px;font-size:28px;line-height:1.2;font-variant-numeric:tabular-nums}\n.hud.center{justify-content:center}\n.bottom{bottom:50px;left:30px;right:30px;gap:10px}\n.bottom .capability{min-height:44px;padding:10px 14px;font-size:14px;line-height:1.25;white-space:normal}\n.status{font-size:13px;line-height:1.4;bottom:108px;text-wrap:balance}\n.pill{font-size:16px;line-height:1.3;min-height:44px;padding:11px 22px}\n.modal{padding:30px 30px 50px}\n.result{max-height:100%;overflow-y:auto;padding:28px 22px}\n.result h2{font-family:Playful,UIBody,sans-serif;font-size:24px;line-height:1.25;text-wrap:balance;overflow-wrap:anywhere}\n.result p{font-size:15px;line-height:1.6;overflow-wrap:anywhere}\n.result .value{line-height:1.2;overflow-wrap:anywhere}\n.smallcaps{font-size:12px;letter-spacing:1.4px;line-height:1.4}\n\n@font-face{font-family:UIArcade;src:url('./assets/ui/Audiowide-Regular.woff2') format('woff2');font-display:swap}\nhtml,body,#root,button{font-family:UIArcade,UIBody,sans-serif}\n.stats{font-family:UIBody,system-ui,sans-serif;font-size:14px;line-height:1.3;letter-spacing:.5px;align-items:center;color:#bec9dd}\n.progress-label{font-family:UIArcade,UIBody,sans-serif;font-size:28px}\n.levels{top:105px;left:30px;right:30px;display:flex;justify-content:center;gap:16px}.levels button{width:44px;height:44px;min-height:44px}\n.guide{font:400 18px/1.4 UIArcade,UIBody,sans-serif}\n.card h1{font:400 24px/1.3 UIArcade,UIBody,sans-serif;letter-spacing:0}\n.card p{font-family:UIArcade,UIBody,sans-serif;font-size:44px}\n.card button{font:700 16px/1.3 UIBody,system-ui,sans-serif;min-height:48px}\n";
  document.head.append(uiStyle);
})();
