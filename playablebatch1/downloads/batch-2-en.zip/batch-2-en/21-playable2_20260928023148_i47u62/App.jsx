(() => {
  if (new URLSearchParams(location.search).get("feedReview") !== "1") return;
  let active = false, alive = true;
  const waiting = /* @__PURE__ */ new Set(), contexts = /* @__PURE__ */ new Set(), media = /* @__PURE__ */ new Set(), streams = /* @__PURE__ */ new Set();
  const wait = () => alive ? new Promise((resolve, reject) => waiting.add({ resolve, reject })) : Promise.reject(new DOMException("Feed closed", "AbortError"));
  if (navigator.mediaDevices?.getUserMedia) {
    const native = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async (constraints) => {
      if (!active) await wait();
      if (!alive) throw new DOMException("Feed closed", "AbortError");
      const stream = await native(constraints);
      if (!alive || !active) {
        stream.getTracks().forEach((track) => track.stop());
        throw new DOMException("Feed inactive", "AbortError");
      }
      streams.add(stream);
      return stream;
    };
  }
  for (const key of ["AudioContext", "webkitAudioContext"]) {
    const Native = window[key];
    if (!Native) continue;
    window[key] = class FeedAudioContext extends Native {
      constructor(...args) {
        super(...args);
        contexts.add(this);
        if (!active) super.suspend().catch(() => {
        });
      }
      async resume() {
        if (!active) await wait();
        if (alive) return super.resume();
      }
    };
  }
  const nativePlay = HTMLMediaElement.prototype.play;
  HTMLMediaElement.prototype.play = async function(...args) {
    media.add(this);
    if (!active) await wait();
    if (alive) return nativePlay.apply(this, args);
  };
  addEventListener("message", (event) => {
    if (event.source !== parent || event.origin !== location.origin || event.data?.type !== "playable-active") return;
    active = alive && event.data.active === true;
    if (active) {
      for (const job of waiting) job.resolve();
      waiting.clear();
      for (const context of contexts) if (context.state !== "closed") context.resume().catch(() => {
      });
    } else {
      for (const context of contexts) if (context.state !== "closed") context.suspend().catch(() => {
      });
      for (const item of media) item.pause();
      for (const stream of streams) stream.getTracks().forEach((track) => track.stop());
      streams.clear();
    }
  });
  addEventListener("pagehide", () => {
    alive = false;
    active = false;
    for (const job of waiting) job.reject(new DOMException("Feed closed", "AbortError"));
    waiting.clear();
    for (const context of contexts) if (context.state !== "closed") context.close().catch(() => {
    });
    for (const item of media) item.pause();
    for (const stream of streams) stream.getTracks().forEach((track) => track.stop());
  }, { once: true });
})();
(() => {
  if (window.location.protocol !== "file:" || !window.fetch) return;
  const configNode = document.getElementById("playable-inline-config");
  if (!configNode) return;
  let inlineConfig;
  try {
    inlineConfig = JSON.parse(configNode.textContent);
  } catch (_) {
    return;
  }
  const nativeFetch = window.fetch.bind(window);
  window.fetch = (input, init) => {
    const url = typeof input === "string" ? input : input && input.url;
    if (url === "./game.config.json" || url === "game.config.json") {
      return Promise.resolve(new Response(JSON.stringify(inlineConfig), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      }));
    }
    return nativeFetch(input, init);
  };
})();
(() => {
  var IE = Object.create;
  var iy = Object.defineProperty;
  var LE = Object.getOwnPropertyDescriptor;
  var BE = Object.getOwnPropertyNames;
  var jE = Object.getPrototypeOf, qE = Object.prototype.hasOwnProperty;
  var sy = ((t) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(t, { get: (e, r) => (typeof require < "u" ? require : e)[r] }) : t)(function(t) {
    if (typeof require < "u") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + t + '" is not supported');
  });
  var $e = (t, e) => () => (e || t((e = { exports: {} }).exports, e), e.exports);
  var zE = (t, e, r, n) => {
    if (e && typeof e == "object" || typeof e == "function") for (let o of BE(e)) !qE.call(t, o) && o !== r && iy(t, o, { get: () => e[o], enumerable: !(n = LE(e, o)) || n.enumerable });
    return t;
  };
  var se = (t, e, r) => (r = t != null ? IE(jE(t)) : {}, zE(e || !t || !t.__esModule ? iy(r, "default", { value: t, enumerable: true }) : r, t));
  var yy = $e((ae) => {
    "use strict";
    var Na = Symbol.for("react.element"), WE = Symbol.for("react.portal"), UE = Symbol.for("react.fragment"), GE = Symbol.for("react.strict_mode"), HE = Symbol.for("react.profiler"), $E = Symbol.for("react.provider"), XE = Symbol.for("react.context"), YE = Symbol.for("react.forward_ref"), QE = Symbol.for("react.suspense"), KE = Symbol.for("react.memo"), ZE = Symbol.for("react.lazy"), ay = Symbol.iterator;
    function JE(t) {
      return t === null || typeof t != "object" ? null : (t = ay && t[ay] || t["@@iterator"], typeof t == "function" ? t : null);
    }
    var cy = { isMounted: function() {
      return false;
    }, enqueueForceUpdate: function() {
    }, enqueueReplaceState: function() {
    }, enqueueSetState: function() {
    } }, py = Object.assign, hy = {};
    function $i(t, e, r) {
      this.props = t, this.context = e, this.refs = hy, this.updater = r || cy;
    }
    $i.prototype.isReactComponent = {};
    $i.prototype.setState = function(t, e) {
      if (typeof t != "object" && typeof t != "function" && t != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, t, e, "setState");
    };
    $i.prototype.forceUpdate = function(t) {
      this.updater.enqueueForceUpdate(this, t, "forceUpdate");
    };
    function fy() {
    }
    fy.prototype = $i.prototype;
    function Ef(t, e, r) {
      this.props = t, this.context = e, this.refs = hy, this.updater = r || cy;
    }
    var bf = Ef.prototype = new fy();
    bf.constructor = Ef;
    py(bf, $i.prototype);
    bf.isPureReactComponent = true;
    var ly = Array.isArray, my = Object.prototype.hasOwnProperty, Nf = { current: null }, dy = { key: true, ref: true, __self: true, __source: true };
    function gy(t, e, r) {
      var n, o = {}, i = null, s = null;
      if (e != null) for (n in e.ref !== void 0 && (s = e.ref), e.key !== void 0 && (i = "" + e.key), e) my.call(e, n) && !dy.hasOwnProperty(n) && (o[n] = e[n]);
      var a = arguments.length - 2;
      if (a === 1) o.children = r;
      else if (1 < a) {
        for (var l = Array(a), u = 0; u < a; u++) l[u] = arguments[u + 2];
        o.children = l;
      }
      if (t && t.defaultProps) for (n in a = t.defaultProps, a) o[n] === void 0 && (o[n] = a[n]);
      return { $$typeof: Na, type: t, key: i, ref: s, props: o, _owner: Nf.current };
    }
    function eb(t, e) {
      return { $$typeof: Na, type: t.type, key: e, ref: t.ref, props: t.props, _owner: t._owner };
    }
    function Of(t) {
      return typeof t == "object" && t !== null && t.$$typeof === Na;
    }
    function tb(t) {
      var e = { "=": "=0", ":": "=2" };
      return "$" + t.replace(/[=:]/g, function(r) {
        return e[r];
      });
    }
    var uy = /\/+/g;
    function kf(t, e) {
      return typeof t == "object" && t !== null && t.key != null ? tb("" + t.key) : e.toString(36);
    }
    function Uu(t, e, r, n, o) {
      var i = typeof t;
      (i === "undefined" || i === "boolean") && (t = null);
      var s = false;
      if (t === null) s = true;
      else switch (i) {
        case "string":
        case "number":
          s = true;
          break;
        case "object":
          switch (t.$$typeof) {
            case Na:
            case WE:
              s = true;
          }
      }
      if (s) return s = t, o = o(s), t = n === "" ? "." + kf(s, 0) : n, ly(o) ? (r = "", t != null && (r = t.replace(uy, "$&/") + "/"), Uu(o, e, r, "", function(u) {
        return u;
      })) : o != null && (Of(o) && (o = eb(o, r + (!o.key || s && s.key === o.key ? "" : ("" + o.key).replace(uy, "$&/") + "/") + t)), e.push(o)), 1;
      if (s = 0, n = n === "" ? "." : n + ":", ly(t)) for (var a = 0; a < t.length; a++) {
        i = t[a];
        var l = n + kf(i, a);
        s += Uu(i, e, r, l, o);
      }
      else if (l = JE(t), typeof l == "function") for (t = l.call(t), a = 0; !(i = t.next()).done; ) i = i.value, l = n + kf(i, a++), s += Uu(i, e, r, l, o);
      else if (i === "object") throw e = String(t), Error("Objects are not valid as a React child (found: " + (e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e) + "). If you meant to render a collection of children, use an array instead.");
      return s;
    }
    function Wu(t, e, r) {
      if (t == null) return t;
      var n = [], o = 0;
      return Uu(t, n, "", "", function(i) {
        return e.call(r, i, o++);
      }), n;
    }
    function rb(t) {
      if (t._status === -1) {
        var e = t._result;
        e = e(), e.then(function(r) {
          (t._status === 0 || t._status === -1) && (t._status = 1, t._result = r);
        }, function(r) {
          (t._status === 0 || t._status === -1) && (t._status = 2, t._result = r);
        }), t._status === -1 && (t._status = 0, t._result = e);
      }
      if (t._status === 1) return t._result.default;
      throw t._result;
    }
    var Vt = { current: null }, Gu = { transition: null }, nb = { ReactCurrentDispatcher: Vt, ReactCurrentBatchConfig: Gu, ReactCurrentOwner: Nf };
    function xy() {
      throw Error("act(...) is not supported in production builds of React.");
    }
    ae.Children = { map: Wu, forEach: function(t, e, r) {
      Wu(t, function() {
        e.apply(this, arguments);
      }, r);
    }, count: function(t) {
      var e = 0;
      return Wu(t, function() {
        e++;
      }), e;
    }, toArray: function(t) {
      return Wu(t, function(e) {
        return e;
      }) || [];
    }, only: function(t) {
      if (!Of(t)) throw Error("React.Children.only expected to receive a single React element child.");
      return t;
    } };
    ae.Component = $i;
    ae.Fragment = UE;
    ae.Profiler = HE;
    ae.PureComponent = Ef;
    ae.StrictMode = GE;
    ae.Suspense = QE;
    ae.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = nb;
    ae.act = xy;
    ae.cloneElement = function(t, e, r) {
      if (t == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + t + ".");
      var n = py({}, t.props), o = t.key, i = t.ref, s = t._owner;
      if (e != null) {
        if (e.ref !== void 0 && (i = e.ref, s = Nf.current), e.key !== void 0 && (o = "" + e.key), t.type && t.type.defaultProps) var a = t.type.defaultProps;
        for (l in e) my.call(e, l) && !dy.hasOwnProperty(l) && (n[l] = e[l] === void 0 && a !== void 0 ? a[l] : e[l]);
      }
      var l = arguments.length - 2;
      if (l === 1) n.children = r;
      else if (1 < l) {
        a = Array(l);
        for (var u = 0; u < l; u++) a[u] = arguments[u + 2];
        n.children = a;
      }
      return { $$typeof: Na, type: t.type, key: o, ref: i, props: n, _owner: s };
    };
    ae.createContext = function(t) {
      return t = { $$typeof: XE, _currentValue: t, _currentValue2: t, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, t.Provider = { $$typeof: $E, _context: t }, t.Consumer = t;
    };
    ae.createElement = gy;
    ae.createFactory = function(t) {
      var e = gy.bind(null, t);
      return e.type = t, e;
    };
    ae.createRef = function() {
      return { current: null };
    };
    ae.forwardRef = function(t) {
      return { $$typeof: YE, render: t };
    };
    ae.isValidElement = Of;
    ae.lazy = function(t) {
      return { $$typeof: ZE, _payload: { _status: -1, _result: t }, _init: rb };
    };
    ae.memo = function(t, e) {
      return { $$typeof: KE, type: t, compare: e === void 0 ? null : e };
    };
    ae.startTransition = function(t) {
      var e = Gu.transition;
      Gu.transition = {};
      try {
        t();
      } finally {
        Gu.transition = e;
      }
    };
    ae.unstable_act = xy;
    ae.useCallback = function(t, e) {
      return Vt.current.useCallback(t, e);
    };
    ae.useContext = function(t) {
      return Vt.current.useContext(t);
    };
    ae.useDebugValue = function() {
    };
    ae.useDeferredValue = function(t) {
      return Vt.current.useDeferredValue(t);
    };
    ae.useEffect = function(t, e) {
      return Vt.current.useEffect(t, e);
    };
    ae.useId = function() {
      return Vt.current.useId();
    };
    ae.useImperativeHandle = function(t, e, r) {
      return Vt.current.useImperativeHandle(t, e, r);
    };
    ae.useInsertionEffect = function(t, e) {
      return Vt.current.useInsertionEffect(t, e);
    };
    ae.useLayoutEffect = function(t, e) {
      return Vt.current.useLayoutEffect(t, e);
    };
    ae.useMemo = function(t, e) {
      return Vt.current.useMemo(t, e);
    };
    ae.useReducer = function(t, e, r) {
      return Vt.current.useReducer(t, e, r);
    };
    ae.useRef = function(t) {
      return Vt.current.useRef(t);
    };
    ae.useState = function(t) {
      return Vt.current.useState(t);
    };
    ae.useSyncExternalStore = function(t, e, r) {
      return Vt.current.useSyncExternalStore(t, e, r);
    };
    ae.useTransition = function() {
      return Vt.current.useTransition();
    };
    ae.version = "18.3.1";
  });
  var xe = $e((kV, _y) => {
    "use strict";
    _y.exports = yy();
  });
  var Ny = $e((Te) => {
    "use strict";
    function Rf(t, e) {
      var r = t.length;
      t.push(e);
      e: for (; 0 < r; ) {
        var n = r - 1 >>> 1, o = t[n];
        if (0 < Hu(o, e)) t[n] = e, t[r] = o, r = n;
        else break e;
      }
    }
    function jr(t) {
      return t.length === 0 ? null : t[0];
    }
    function Xu(t) {
      if (t.length === 0) return null;
      var e = t[0], r = t.pop();
      if (r !== e) {
        t[0] = r;
        e: for (var n = 0, o = t.length, i = o >>> 1; n < i; ) {
          var s = 2 * (n + 1) - 1, a = t[s], l = s + 1, u = t[l];
          if (0 > Hu(a, r)) l < o && 0 > Hu(u, a) ? (t[n] = u, t[l] = r, n = l) : (t[n] = a, t[s] = r, n = s);
          else if (l < o && 0 > Hu(u, r)) t[n] = u, t[l] = r, n = l;
          else break e;
        }
      }
      return e;
    }
    function Hu(t, e) {
      var r = t.sortIndex - e.sortIndex;
      return r !== 0 ? r : t.id - e.id;
    }
    typeof performance == "object" && typeof performance.now == "function" ? (vy = performance, Te.unstable_now = function() {
      return vy.now();
    }) : (Df = Date, wy = Df.now(), Te.unstable_now = function() {
      return Df.now() - wy;
    });
    var vy, Df, wy, cn = [], io = [], ob = 1, _r = null, Ct = 3, Yu = false, ei = false, Da = false, Ay = typeof setTimeout == "function" ? setTimeout : null, Cy = typeof clearTimeout == "function" ? clearTimeout : null, Sy = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function Vf(t) {
      for (var e = jr(io); e !== null; ) {
        if (e.callback === null) Xu(io);
        else if (e.startTime <= t) Xu(io), e.sortIndex = e.expirationTime, Rf(cn, e);
        else break;
        e = jr(io);
      }
    }
    function Ff(t) {
      if (Da = false, Vf(t), !ei) if (jr(cn) !== null) ei = true, Lf(If);
      else {
        var e = jr(io);
        e !== null && Bf(Ff, e.startTime - t);
      }
    }
    function If(t, e) {
      ei = false, Da && (Da = false, Cy(Ma), Ma = -1), Yu = true;
      var r = Ct;
      try {
        for (Vf(e), _r = jr(cn); _r !== null && (!(_r.expirationTime > e) || t && !by()); ) {
          var n = _r.callback;
          if (typeof n == "function") {
            _r.callback = null, Ct = _r.priorityLevel;
            var o = n(_r.expirationTime <= e);
            e = Te.unstable_now(), typeof o == "function" ? _r.callback = o : _r === jr(cn) && Xu(cn), Vf(e);
          } else Xu(cn);
          _r = jr(cn);
        }
        if (_r !== null) var i = true;
        else {
          var s = jr(io);
          s !== null && Bf(Ff, s.startTime - e), i = false;
        }
        return i;
      } finally {
        _r = null, Ct = r, Yu = false;
      }
    }
    var Qu = false, $u = null, Ma = -1, ky = 5, Ey = -1;
    function by() {
      return !(Te.unstable_now() - Ey < ky);
    }
    function Mf() {
      if ($u !== null) {
        var t = Te.unstable_now();
        Ey = t;
        var e = true;
        try {
          e = $u(true, t);
        } finally {
          e ? Oa() : (Qu = false, $u = null);
        }
      } else Qu = false;
    }
    var Oa;
    typeof Sy == "function" ? Oa = function() {
      Sy(Mf);
    } : typeof MessageChannel < "u" ? (Pf = new MessageChannel(), Ty = Pf.port2, Pf.port1.onmessage = Mf, Oa = function() {
      Ty.postMessage(null);
    }) : Oa = function() {
      Ay(Mf, 0);
    };
    var Pf, Ty;
    function Lf(t) {
      $u = t, Qu || (Qu = true, Oa());
    }
    function Bf(t, e) {
      Ma = Ay(function() {
        t(Te.unstable_now());
      }, e);
    }
    Te.unstable_IdlePriority = 5;
    Te.unstable_ImmediatePriority = 1;
    Te.unstable_LowPriority = 4;
    Te.unstable_NormalPriority = 3;
    Te.unstable_Profiling = null;
    Te.unstable_UserBlockingPriority = 2;
    Te.unstable_cancelCallback = function(t) {
      t.callback = null;
    };
    Te.unstable_continueExecution = function() {
      ei || Yu || (ei = true, Lf(If));
    };
    Te.unstable_forceFrameRate = function(t) {
      0 > t || 125 < t ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : ky = 0 < t ? Math.floor(1e3 / t) : 5;
    };
    Te.unstable_getCurrentPriorityLevel = function() {
      return Ct;
    };
    Te.unstable_getFirstCallbackNode = function() {
      return jr(cn);
    };
    Te.unstable_next = function(t) {
      switch (Ct) {
        case 1:
        case 2:
        case 3:
          var e = 3;
          break;
        default:
          e = Ct;
      }
      var r = Ct;
      Ct = e;
      try {
        return t();
      } finally {
        Ct = r;
      }
    };
    Te.unstable_pauseExecution = function() {
    };
    Te.unstable_requestPaint = function() {
    };
    Te.unstable_runWithPriority = function(t, e) {
      switch (t) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          t = 3;
      }
      var r = Ct;
      Ct = t;
      try {
        return e();
      } finally {
        Ct = r;
      }
    };
    Te.unstable_scheduleCallback = function(t, e, r) {
      var n = Te.unstable_now();
      switch (typeof r == "object" && r !== null ? (r = r.delay, r = typeof r == "number" && 0 < r ? n + r : n) : r = n, t) {
        case 1:
          var o = -1;
          break;
        case 2:
          o = 250;
          break;
        case 5:
          o = 1073741823;
          break;
        case 4:
          o = 1e4;
          break;
        default:
          o = 5e3;
      }
      return o = r + o, t = { id: ob++, callback: e, priorityLevel: t, startTime: r, expirationTime: o, sortIndex: -1 }, r > n ? (t.sortIndex = r, Rf(io, t), jr(cn) === null && t === jr(io) && (Da ? (Cy(Ma), Ma = -1) : Da = true, Bf(Ff, r - n))) : (t.sortIndex = o, Rf(cn, t), ei || Yu || (ei = true, Lf(If))), t;
    };
    Te.unstable_shouldYield = by;
    Te.unstable_wrapCallback = function(t) {
      var e = Ct;
      return function() {
        var r = Ct;
        Ct = e;
        try {
          return t.apply(this, arguments);
        } finally {
          Ct = r;
        }
      };
    };
  });
  var Dy = $e((bV, Oy) => {
    "use strict";
    Oy.exports = Ny();
  });
  var V0 = $e((ur) => {
    "use strict";
    var ib = xe(), ar = Dy();
    function F(t) {
      for (var e = "https://reactjs.org/docs/error-decoder.html?invariant=" + t, r = 1; r < arguments.length; r++) e += "&args[]=" + encodeURIComponent(arguments[r]);
      return "Minified React error #" + t + "; visit " + e + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    var L_ = /* @__PURE__ */ new Set(), el = {};
    function fi(t, e) {
      ms(t, e), ms(t + "Capture", e);
    }
    function ms(t, e) {
      for (el[t] = e, t = 0; t < e.length; t++) L_.add(e[t]);
    }
    var In = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), lm = Object.prototype.hasOwnProperty, sb = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/, My = {}, Py = {};
    function ab(t) {
      return lm.call(Py, t) ? true : lm.call(My, t) ? false : sb.test(t) ? Py[t] = true : (My[t] = true, false);
    }
    function lb(t, e, r, n) {
      if (r !== null && r.type === 0) return false;
      switch (typeof e) {
        case "function":
        case "symbol":
          return true;
        case "boolean":
          return n ? false : r !== null ? !r.acceptsBooleans : (t = t.toLowerCase().slice(0, 5), t !== "data-" && t !== "aria-");
        default:
          return false;
      }
    }
    function ub(t, e, r, n) {
      if (e === null || typeof e > "u" || lb(t, e, r, n)) return true;
      if (n) return false;
      if (r !== null) switch (r.type) {
        case 3:
          return !e;
        case 4:
          return e === false;
        case 5:
          return isNaN(e);
        case 6:
          return isNaN(e) || 1 > e;
      }
      return false;
    }
    function Lt(t, e, r, n, o, i, s) {
      this.acceptsBooleans = e === 2 || e === 3 || e === 4, this.attributeName = n, this.attributeNamespace = o, this.mustUseProperty = r, this.propertyName = t, this.type = e, this.sanitizeURL = i, this.removeEmptyString = s;
    }
    var St = {};
    "children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(t) {
      St[t] = new Lt(t, 0, false, t, null, false, false);
    });
    [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(t) {
      var e = t[0];
      St[e] = new Lt(e, 1, false, t[1], null, false, false);
    });
    ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(t) {
      St[t] = new Lt(t, 2, false, t.toLowerCase(), null, false, false);
    });
    ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(t) {
      St[t] = new Lt(t, 2, false, t, null, false, false);
    });
    "allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(t) {
      St[t] = new Lt(t, 3, false, t.toLowerCase(), null, false, false);
    });
    ["checked", "multiple", "muted", "selected"].forEach(function(t) {
      St[t] = new Lt(t, 3, true, t, null, false, false);
    });
    ["capture", "download"].forEach(function(t) {
      St[t] = new Lt(t, 4, false, t, null, false, false);
    });
    ["cols", "rows", "size", "span"].forEach(function(t) {
      St[t] = new Lt(t, 6, false, t, null, false, false);
    });
    ["rowSpan", "start"].forEach(function(t) {
      St[t] = new Lt(t, 5, false, t.toLowerCase(), null, false, false);
    });
    var ed = /[\-:]([a-z])/g;
    function td(t) {
      return t[1].toUpperCase();
    }
    "accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(t) {
      var e = t.replace(ed, td);
      St[e] = new Lt(e, 1, false, t, null, false, false);
    });
    "xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(t) {
      var e = t.replace(ed, td);
      St[e] = new Lt(e, 1, false, t, "http://www.w3.org/1999/xlink", false, false);
    });
    ["xml:base", "xml:lang", "xml:space"].forEach(function(t) {
      var e = t.replace(ed, td);
      St[e] = new Lt(e, 1, false, t, "http://www.w3.org/XML/1998/namespace", false, false);
    });
    ["tabIndex", "crossOrigin"].forEach(function(t) {
      St[t] = new Lt(t, 1, false, t.toLowerCase(), null, false, false);
    });
    St.xlinkHref = new Lt("xlinkHref", 1, false, "xlink:href", "http://www.w3.org/1999/xlink", true, false);
    ["src", "href", "action", "formAction"].forEach(function(t) {
      St[t] = new Lt(t, 1, false, t.toLowerCase(), null, true, true);
    });
    function rd(t, e, r, n) {
      var o = St.hasOwnProperty(e) ? St[e] : null;
      (o !== null ? o.type !== 0 : n || !(2 < e.length) || e[0] !== "o" && e[0] !== "O" || e[1] !== "n" && e[1] !== "N") && (ub(e, r, o, n) && (r = null), n || o === null ? ab(e) && (r === null ? t.removeAttribute(e) : t.setAttribute(e, "" + r)) : o.mustUseProperty ? t[o.propertyName] = r === null ? o.type === 3 ? false : "" : r : (e = o.attributeName, n = o.attributeNamespace, r === null ? t.removeAttribute(e) : (o = o.type, r = o === 3 || o === 4 && r === true ? "" : "" + r, n ? t.setAttributeNS(n, e, r) : t.setAttribute(e, r))));
    }
    var qn = ib.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, Ku = Symbol.for("react.element"), Qi = Symbol.for("react.portal"), Ki = Symbol.for("react.fragment"), nd = Symbol.for("react.strict_mode"), um = Symbol.for("react.profiler"), B_ = Symbol.for("react.provider"), j_ = Symbol.for("react.context"), od = Symbol.for("react.forward_ref"), cm = Symbol.for("react.suspense"), pm = Symbol.for("react.suspense_list"), id = Symbol.for("react.memo"), ao = Symbol.for("react.lazy");
    Symbol.for("react.scope");
    Symbol.for("react.debug_trace_mode");
    var q_ = Symbol.for("react.offscreen");
    Symbol.for("react.legacy_hidden");
    Symbol.for("react.cache");
    Symbol.for("react.tracing_marker");
    var Ry = Symbol.iterator;
    function Pa(t) {
      return t === null || typeof t != "object" ? null : (t = Ry && t[Ry] || t["@@iterator"], typeof t == "function" ? t : null);
    }
    var Ve = Object.assign, jf;
    function qa(t) {
      if (jf === void 0) try {
        throw Error();
      } catch (r) {
        var e = r.stack.trim().match(/\n( *(at )?)/);
        jf = e && e[1] || "";
      }
      return `
` + jf + t;
    }
    var qf = false;
    function zf(t, e) {
      if (!t || qf) return "";
      qf = true;
      var r = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        if (e) if (e = function() {
          throw Error();
        }, Object.defineProperty(e.prototype, "props", { set: function() {
          throw Error();
        } }), typeof Reflect == "object" && Reflect.construct) {
          try {
            Reflect.construct(e, []);
          } catch (u) {
            var n = u;
          }
          Reflect.construct(t, [], e);
        } else {
          try {
            e.call();
          } catch (u) {
            n = u;
          }
          t.call(e.prototype);
        }
        else {
          try {
            throw Error();
          } catch (u) {
            n = u;
          }
          t();
        }
      } catch (u) {
        if (u && n && typeof u.stack == "string") {
          for (var o = u.stack.split(`
`), i = n.stack.split(`
`), s = o.length - 1, a = i.length - 1; 1 <= s && 0 <= a && o[s] !== i[a]; ) a--;
          for (; 1 <= s && 0 <= a; s--, a--) if (o[s] !== i[a]) {
            if (s !== 1 || a !== 1) do
              if (s--, a--, 0 > a || o[s] !== i[a]) {
                var l = `
` + o[s].replace(" at new ", " at ");
                return t.displayName && l.includes("<anonymous>") && (l = l.replace("<anonymous>", t.displayName)), l;
              }
            while (1 <= s && 0 <= a);
            break;
          }
        }
      } finally {
        qf = false, Error.prepareStackTrace = r;
      }
      return (t = t ? t.displayName || t.name : "") ? qa(t) : "";
    }
    function cb(t) {
      switch (t.tag) {
        case 5:
          return qa(t.type);
        case 16:
          return qa("Lazy");
        case 13:
          return qa("Suspense");
        case 19:
          return qa("SuspenseList");
        case 0:
        case 2:
        case 15:
          return t = zf(t.type, false), t;
        case 11:
          return t = zf(t.type.render, false), t;
        case 1:
          return t = zf(t.type, true), t;
        default:
          return "";
      }
    }
    function hm(t) {
      if (t == null) return null;
      if (typeof t == "function") return t.displayName || t.name || null;
      if (typeof t == "string") return t;
      switch (t) {
        case Ki:
          return "Fragment";
        case Qi:
          return "Portal";
        case um:
          return "Profiler";
        case nd:
          return "StrictMode";
        case cm:
          return "Suspense";
        case pm:
          return "SuspenseList";
      }
      if (typeof t == "object") switch (t.$$typeof) {
        case j_:
          return (t.displayName || "Context") + ".Consumer";
        case B_:
          return (t._context.displayName || "Context") + ".Provider";
        case od:
          var e = t.render;
          return t = t.displayName, t || (t = e.displayName || e.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
        case id:
          return e = t.displayName || null, e !== null ? e : hm(t.type) || "Memo";
        case ao:
          e = t._payload, t = t._init;
          try {
            return hm(t(e));
          } catch {
          }
      }
      return null;
    }
    function pb(t) {
      var e = t.type;
      switch (t.tag) {
        case 24:
          return "Cache";
        case 9:
          return (e.displayName || "Context") + ".Consumer";
        case 10:
          return (e._context.displayName || "Context") + ".Provider";
        case 18:
          return "DehydratedFragment";
        case 11:
          return t = e.render, t = t.displayName || t.name || "", e.displayName || (t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef");
        case 7:
          return "Fragment";
        case 5:
          return e;
        case 4:
          return "Portal";
        case 3:
          return "Root";
        case 6:
          return "Text";
        case 16:
          return hm(e);
        case 8:
          return e === nd ? "StrictMode" : "Mode";
        case 22:
          return "Offscreen";
        case 12:
          return "Profiler";
        case 21:
          return "Scope";
        case 13:
          return "Suspense";
        case 19:
          return "SuspenseList";
        case 25:
          return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
          if (typeof e == "function") return e.displayName || e.name || null;
          if (typeof e == "string") return e;
      }
      return null;
    }
    function So(t) {
      switch (typeof t) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return t;
        case "object":
          return t;
        default:
          return "";
      }
    }
    function z_(t) {
      var e = t.type;
      return (t = t.nodeName) && t.toLowerCase() === "input" && (e === "checkbox" || e === "radio");
    }
    function hb(t) {
      var e = z_(t) ? "checked" : "value", r = Object.getOwnPropertyDescriptor(t.constructor.prototype, e), n = "" + t[e];
      if (!t.hasOwnProperty(e) && typeof r < "u" && typeof r.get == "function" && typeof r.set == "function") {
        var o = r.get, i = r.set;
        return Object.defineProperty(t, e, { configurable: true, get: function() {
          return o.call(this);
        }, set: function(s) {
          n = "" + s, i.call(this, s);
        } }), Object.defineProperty(t, e, { enumerable: r.enumerable }), { getValue: function() {
          return n;
        }, setValue: function(s) {
          n = "" + s;
        }, stopTracking: function() {
          t._valueTracker = null, delete t[e];
        } };
      }
    }
    function Zu(t) {
      t._valueTracker || (t._valueTracker = hb(t));
    }
    function W_(t) {
      if (!t) return false;
      var e = t._valueTracker;
      if (!e) return true;
      var r = e.getValue(), n = "";
      return t && (n = z_(t) ? t.checked ? "true" : "false" : t.value), t = n, t !== r ? (e.setValue(t), true) : false;
    }
    function kc(t) {
      if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
      try {
        return t.activeElement || t.body;
      } catch {
        return t.body;
      }
    }
    function fm(t, e) {
      var r = e.checked;
      return Ve({}, e, { defaultChecked: void 0, defaultValue: void 0, value: void 0, checked: r ?? t._wrapperState.initialChecked });
    }
    function Vy(t, e) {
      var r = e.defaultValue == null ? "" : e.defaultValue, n = e.checked != null ? e.checked : e.defaultChecked;
      r = So(e.value != null ? e.value : r), t._wrapperState = { initialChecked: n, initialValue: r, controlled: e.type === "checkbox" || e.type === "radio" ? e.checked != null : e.value != null };
    }
    function U_(t, e) {
      e = e.checked, e != null && rd(t, "checked", e, false);
    }
    function mm(t, e) {
      U_(t, e);
      var r = So(e.value), n = e.type;
      if (r != null) n === "number" ? (r === 0 && t.value === "" || t.value != r) && (t.value = "" + r) : t.value !== "" + r && (t.value = "" + r);
      else if (n === "submit" || n === "reset") {
        t.removeAttribute("value");
        return;
      }
      e.hasOwnProperty("value") ? dm(t, e.type, r) : e.hasOwnProperty("defaultValue") && dm(t, e.type, So(e.defaultValue)), e.checked == null && e.defaultChecked != null && (t.defaultChecked = !!e.defaultChecked);
    }
    function Fy(t, e, r) {
      if (e.hasOwnProperty("value") || e.hasOwnProperty("defaultValue")) {
        var n = e.type;
        if (!(n !== "submit" && n !== "reset" || e.value !== void 0 && e.value !== null)) return;
        e = "" + t._wrapperState.initialValue, r || e === t.value || (t.value = e), t.defaultValue = e;
      }
      r = t.name, r !== "" && (t.name = ""), t.defaultChecked = !!t._wrapperState.initialChecked, r !== "" && (t.name = r);
    }
    function dm(t, e, r) {
      (e !== "number" || kc(t.ownerDocument) !== t) && (r == null ? t.defaultValue = "" + t._wrapperState.initialValue : t.defaultValue !== "" + r && (t.defaultValue = "" + r));
    }
    var za = Array.isArray;
    function ls(t, e, r, n) {
      if (t = t.options, e) {
        e = {};
        for (var o = 0; o < r.length; o++) e["$" + r[o]] = true;
        for (r = 0; r < t.length; r++) o = e.hasOwnProperty("$" + t[r].value), t[r].selected !== o && (t[r].selected = o), o && n && (t[r].defaultSelected = true);
      } else {
        for (r = "" + So(r), e = null, o = 0; o < t.length; o++) {
          if (t[o].value === r) {
            t[o].selected = true, n && (t[o].defaultSelected = true);
            return;
          }
          e !== null || t[o].disabled || (e = t[o]);
        }
        e !== null && (e.selected = true);
      }
    }
    function gm(t, e) {
      if (e.dangerouslySetInnerHTML != null) throw Error(F(91));
      return Ve({}, e, { value: void 0, defaultValue: void 0, children: "" + t._wrapperState.initialValue });
    }
    function Iy(t, e) {
      var r = e.value;
      if (r == null) {
        if (r = e.children, e = e.defaultValue, r != null) {
          if (e != null) throw Error(F(92));
          if (za(r)) {
            if (1 < r.length) throw Error(F(93));
            r = r[0];
          }
          e = r;
        }
        e == null && (e = ""), r = e;
      }
      t._wrapperState = { initialValue: So(r) };
    }
    function G_(t, e) {
      var r = So(e.value), n = So(e.defaultValue);
      r != null && (r = "" + r, r !== t.value && (t.value = r), e.defaultValue == null && t.defaultValue !== r && (t.defaultValue = r)), n != null && (t.defaultValue = "" + n);
    }
    function Ly(t) {
      var e = t.textContent;
      e === t._wrapperState.initialValue && e !== "" && e !== null && (t.value = e);
    }
    function H_(t) {
      switch (t) {
        case "svg":
          return "http://www.w3.org/2000/svg";
        case "math":
          return "http://www.w3.org/1998/Math/MathML";
        default:
          return "http://www.w3.org/1999/xhtml";
      }
    }
    function xm(t, e) {
      return t == null || t === "http://www.w3.org/1999/xhtml" ? H_(e) : t === "http://www.w3.org/2000/svg" && e === "foreignObject" ? "http://www.w3.org/1999/xhtml" : t;
    }
    var Ju, $_ = (function(t) {
      return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(e, r, n, o) {
        MSApp.execUnsafeLocalFunction(function() {
          return t(e, r, n, o);
        });
      } : t;
    })(function(t, e) {
      if (t.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in t) t.innerHTML = e;
      else {
        for (Ju = Ju || document.createElement("div"), Ju.innerHTML = "<svg>" + e.valueOf().toString() + "</svg>", e = Ju.firstChild; t.firstChild; ) t.removeChild(t.firstChild);
        for (; e.firstChild; ) t.appendChild(e.firstChild);
      }
    });
    function tl(t, e) {
      if (e) {
        var r = t.firstChild;
        if (r && r === t.lastChild && r.nodeType === 3) {
          r.nodeValue = e;
          return;
        }
      }
      t.textContent = e;
    }
    var Ga = { animationIterationCount: true, aspectRatio: true, borderImageOutset: true, borderImageSlice: true, borderImageWidth: true, boxFlex: true, boxFlexGroup: true, boxOrdinalGroup: true, columnCount: true, columns: true, flex: true, flexGrow: true, flexPositive: true, flexShrink: true, flexNegative: true, flexOrder: true, gridArea: true, gridRow: true, gridRowEnd: true, gridRowSpan: true, gridRowStart: true, gridColumn: true, gridColumnEnd: true, gridColumnSpan: true, gridColumnStart: true, fontWeight: true, lineClamp: true, lineHeight: true, opacity: true, order: true, orphans: true, tabSize: true, widows: true, zIndex: true, zoom: true, fillOpacity: true, floodOpacity: true, stopOpacity: true, strokeDasharray: true, strokeDashoffset: true, strokeMiterlimit: true, strokeOpacity: true, strokeWidth: true }, fb = ["Webkit", "ms", "Moz", "O"];
    Object.keys(Ga).forEach(function(t) {
      fb.forEach(function(e) {
        e = e + t.charAt(0).toUpperCase() + t.substring(1), Ga[e] = Ga[t];
      });
    });
    function X_(t, e, r) {
      return e == null || typeof e == "boolean" || e === "" ? "" : r || typeof e != "number" || e === 0 || Ga.hasOwnProperty(t) && Ga[t] ? ("" + e).trim() : e + "px";
    }
    function Y_(t, e) {
      t = t.style;
      for (var r in e) if (e.hasOwnProperty(r)) {
        var n = r.indexOf("--") === 0, o = X_(r, e[r], n);
        r === "float" && (r = "cssFloat"), n ? t.setProperty(r, o) : t[r] = o;
      }
    }
    var mb = Ve({ menuitem: true }, { area: true, base: true, br: true, col: true, embed: true, hr: true, img: true, input: true, keygen: true, link: true, meta: true, param: true, source: true, track: true, wbr: true });
    function ym(t, e) {
      if (e) {
        if (mb[t] && (e.children != null || e.dangerouslySetInnerHTML != null)) throw Error(F(137, t));
        if (e.dangerouslySetInnerHTML != null) {
          if (e.children != null) throw Error(F(60));
          if (typeof e.dangerouslySetInnerHTML != "object" || !("__html" in e.dangerouslySetInnerHTML)) throw Error(F(61));
        }
        if (e.style != null && typeof e.style != "object") throw Error(F(62));
      }
    }
    function _m(t, e) {
      if (t.indexOf("-") === -1) return typeof e.is == "string";
      switch (t) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return false;
        default:
          return true;
      }
    }
    var vm = null;
    function sd(t) {
      return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t;
    }
    var wm = null, us = null, cs = null;
    function By(t) {
      if (t = _l(t)) {
        if (typeof wm != "function") throw Error(F(280));
        var e = t.stateNode;
        e && (e = ep(e), wm(t.stateNode, t.type, e));
      }
    }
    function Q_(t) {
      us ? cs ? cs.push(t) : cs = [t] : us = t;
    }
    function K_() {
      if (us) {
        var t = us, e = cs;
        if (cs = us = null, By(t), e) for (t = 0; t < e.length; t++) By(e[t]);
      }
    }
    function Z_(t, e) {
      return t(e);
    }
    function J_() {
    }
    var Wf = false;
    function ev(t, e, r) {
      if (Wf) return t(e, r);
      Wf = true;
      try {
        return Z_(t, e, r);
      } finally {
        Wf = false, (us !== null || cs !== null) && (J_(), K_());
      }
    }
    function rl(t, e) {
      var r = t.stateNode;
      if (r === null) return null;
      var n = ep(r);
      if (n === null) return null;
      r = n[e];
      e: switch (e) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (n = !n.disabled) || (t = t.type, n = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !n;
          break e;
        default:
          t = false;
      }
      if (t) return null;
      if (r && typeof r != "function") throw Error(F(231, e, typeof r));
      return r;
    }
    var Sm = false;
    if (In) try {
      Xi = {}, Object.defineProperty(Xi, "passive", { get: function() {
        Sm = true;
      } }), window.addEventListener("test", Xi, Xi), window.removeEventListener("test", Xi, Xi);
    } catch {
      Sm = false;
    }
    var Xi;
    function db(t, e, r, n, o, i, s, a, l) {
      var u = Array.prototype.slice.call(arguments, 3);
      try {
        e.apply(r, u);
      } catch (c) {
        this.onError(c);
      }
    }
    var Ha = false, Ec = null, bc = false, Tm = null, gb = { onError: function(t) {
      Ha = true, Ec = t;
    } };
    function xb(t, e, r, n, o, i, s, a, l) {
      Ha = false, Ec = null, db.apply(gb, arguments);
    }
    function yb(t, e, r, n, o, i, s, a, l) {
      if (xb.apply(this, arguments), Ha) {
        if (Ha) {
          var u = Ec;
          Ha = false, Ec = null;
        } else throw Error(F(198));
        bc || (bc = true, Tm = u);
      }
    }
    function mi(t) {
      var e = t, r = t;
      if (t.alternate) for (; e.return; ) e = e.return;
      else {
        t = e;
        do
          e = t, e.flags & 4098 && (r = e.return), t = e.return;
        while (t);
      }
      return e.tag === 3 ? r : null;
    }
    function tv(t) {
      if (t.tag === 13) {
        var e = t.memoizedState;
        if (e === null && (t = t.alternate, t !== null && (e = t.memoizedState)), e !== null) return e.dehydrated;
      }
      return null;
    }
    function jy(t) {
      if (mi(t) !== t) throw Error(F(188));
    }
    function _b(t) {
      var e = t.alternate;
      if (!e) {
        if (e = mi(t), e === null) throw Error(F(188));
        return e !== t ? null : t;
      }
      for (var r = t, n = e; ; ) {
        var o = r.return;
        if (o === null) break;
        var i = o.alternate;
        if (i === null) {
          if (n = o.return, n !== null) {
            r = n;
            continue;
          }
          break;
        }
        if (o.child === i.child) {
          for (i = o.child; i; ) {
            if (i === r) return jy(o), t;
            if (i === n) return jy(o), e;
            i = i.sibling;
          }
          throw Error(F(188));
        }
        if (r.return !== n.return) r = o, n = i;
        else {
          for (var s = false, a = o.child; a; ) {
            if (a === r) {
              s = true, r = o, n = i;
              break;
            }
            if (a === n) {
              s = true, n = o, r = i;
              break;
            }
            a = a.sibling;
          }
          if (!s) {
            for (a = i.child; a; ) {
              if (a === r) {
                s = true, r = i, n = o;
                break;
              }
              if (a === n) {
                s = true, n = i, r = o;
                break;
              }
              a = a.sibling;
            }
            if (!s) throw Error(F(189));
          }
        }
        if (r.alternate !== n) throw Error(F(190));
      }
      if (r.tag !== 3) throw Error(F(188));
      return r.stateNode.current === r ? t : e;
    }
    function rv(t) {
      return t = _b(t), t !== null ? nv(t) : null;
    }
    function nv(t) {
      if (t.tag === 5 || t.tag === 6) return t;
      for (t = t.child; t !== null; ) {
        var e = nv(t);
        if (e !== null) return e;
        t = t.sibling;
      }
      return null;
    }
    var ov = ar.unstable_scheduleCallback, qy = ar.unstable_cancelCallback, vb = ar.unstable_shouldYield, wb = ar.unstable_requestPaint, Xe = ar.unstable_now, Sb = ar.unstable_getCurrentPriorityLevel, ad = ar.unstable_ImmediatePriority, iv = ar.unstable_UserBlockingPriority, Nc = ar.unstable_NormalPriority, Tb = ar.unstable_LowPriority, sv = ar.unstable_IdlePriority, Qc = null, mn = null;
    function Ab(t) {
      if (mn && typeof mn.onCommitFiberRoot == "function") try {
        mn.onCommitFiberRoot(Qc, t, void 0, (t.current.flags & 128) === 128);
      } catch {
      }
    }
    var Gr = Math.clz32 ? Math.clz32 : Eb, Cb = Math.log, kb = Math.LN2;
    function Eb(t) {
      return t >>>= 0, t === 0 ? 32 : 31 - (Cb(t) / kb | 0) | 0;
    }
    var ec = 64, tc = 4194304;
    function Wa(t) {
      switch (t & -t) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return t & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          return t & 130023424;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 1073741824;
        default:
          return t;
      }
    }
    function Oc(t, e) {
      var r = t.pendingLanes;
      if (r === 0) return 0;
      var n = 0, o = t.suspendedLanes, i = t.pingedLanes, s = r & 268435455;
      if (s !== 0) {
        var a = s & ~o;
        a !== 0 ? n = Wa(a) : (i &= s, i !== 0 && (n = Wa(i)));
      } else s = r & ~o, s !== 0 ? n = Wa(s) : i !== 0 && (n = Wa(i));
      if (n === 0) return 0;
      if (e !== 0 && e !== n && !(e & o) && (o = n & -n, i = e & -e, o >= i || o === 16 && (i & 4194240) !== 0)) return e;
      if (n & 4 && (n |= r & 16), e = t.entangledLanes, e !== 0) for (t = t.entanglements, e &= n; 0 < e; ) r = 31 - Gr(e), o = 1 << r, n |= t[r], e &= ~o;
      return n;
    }
    function bb(t, e) {
      switch (t) {
        case 1:
        case 2:
        case 4:
          return e + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return e + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
          return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function Nb(t, e) {
      for (var r = t.suspendedLanes, n = t.pingedLanes, o = t.expirationTimes, i = t.pendingLanes; 0 < i; ) {
        var s = 31 - Gr(i), a = 1 << s, l = o[s];
        l === -1 ? (!(a & r) || a & n) && (o[s] = bb(a, e)) : l <= e && (t.expiredLanes |= a), i &= ~a;
      }
    }
    function Am(t) {
      return t = t.pendingLanes & -1073741825, t !== 0 ? t : t & 1073741824 ? 1073741824 : 0;
    }
    function av() {
      var t = ec;
      return ec <<= 1, !(ec & 4194240) && (ec = 64), t;
    }
    function Uf(t) {
      for (var e = [], r = 0; 31 > r; r++) e.push(t);
      return e;
    }
    function xl(t, e, r) {
      t.pendingLanes |= e, e !== 536870912 && (t.suspendedLanes = 0, t.pingedLanes = 0), t = t.eventTimes, e = 31 - Gr(e), t[e] = r;
    }
    function Ob(t, e) {
      var r = t.pendingLanes & ~e;
      t.pendingLanes = e, t.suspendedLanes = 0, t.pingedLanes = 0, t.expiredLanes &= e, t.mutableReadLanes &= e, t.entangledLanes &= e, e = t.entanglements;
      var n = t.eventTimes;
      for (t = t.expirationTimes; 0 < r; ) {
        var o = 31 - Gr(r), i = 1 << o;
        e[o] = 0, n[o] = -1, t[o] = -1, r &= ~i;
      }
    }
    function ld(t, e) {
      var r = t.entangledLanes |= e;
      for (t = t.entanglements; r; ) {
        var n = 31 - Gr(r), o = 1 << n;
        o & e | t[n] & e && (t[n] |= e), r &= ~o;
      }
    }
    var _e = 0;
    function lv(t) {
      return t &= -t, 1 < t ? 4 < t ? t & 268435455 ? 16 : 536870912 : 4 : 1;
    }
    var uv, ud, cv, pv, hv, Cm = false, rc = [], fo = null, mo = null, go = null, nl = /* @__PURE__ */ new Map(), ol = /* @__PURE__ */ new Map(), uo = [], Db = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
    function zy(t, e) {
      switch (t) {
        case "focusin":
        case "focusout":
          fo = null;
          break;
        case "dragenter":
        case "dragleave":
          mo = null;
          break;
        case "mouseover":
        case "mouseout":
          go = null;
          break;
        case "pointerover":
        case "pointerout":
          nl.delete(e.pointerId);
          break;
        case "gotpointercapture":
        case "lostpointercapture":
          ol.delete(e.pointerId);
      }
    }
    function Ra(t, e, r, n, o, i) {
      return t === null || t.nativeEvent !== i ? (t = { blockedOn: e, domEventName: r, eventSystemFlags: n, nativeEvent: i, targetContainers: [o] }, e !== null && (e = _l(e), e !== null && ud(e)), t) : (t.eventSystemFlags |= n, e = t.targetContainers, o !== null && e.indexOf(o) === -1 && e.push(o), t);
    }
    function Mb(t, e, r, n, o) {
      switch (e) {
        case "focusin":
          return fo = Ra(fo, t, e, r, n, o), true;
        case "dragenter":
          return mo = Ra(mo, t, e, r, n, o), true;
        case "mouseover":
          return go = Ra(go, t, e, r, n, o), true;
        case "pointerover":
          var i = o.pointerId;
          return nl.set(i, Ra(nl.get(i) || null, t, e, r, n, o)), true;
        case "gotpointercapture":
          return i = o.pointerId, ol.set(i, Ra(ol.get(i) || null, t, e, r, n, o)), true;
      }
      return false;
    }
    function fv(t) {
      var e = ni(t.target);
      if (e !== null) {
        var r = mi(e);
        if (r !== null) {
          if (e = r.tag, e === 13) {
            if (e = tv(r), e !== null) {
              t.blockedOn = e, hv(t.priority, function() {
                cv(r);
              });
              return;
            }
          } else if (e === 3 && r.stateNode.current.memoizedState.isDehydrated) {
            t.blockedOn = r.tag === 3 ? r.stateNode.containerInfo : null;
            return;
          }
        }
      }
      t.blockedOn = null;
    }
    function gc(t) {
      if (t.blockedOn !== null) return false;
      for (var e = t.targetContainers; 0 < e.length; ) {
        var r = km(t.domEventName, t.eventSystemFlags, e[0], t.nativeEvent);
        if (r === null) {
          r = t.nativeEvent;
          var n = new r.constructor(r.type, r);
          vm = n, r.target.dispatchEvent(n), vm = null;
        } else return e = _l(r), e !== null && ud(e), t.blockedOn = r, false;
        e.shift();
      }
      return true;
    }
    function Wy(t, e, r) {
      gc(t) && r.delete(e);
    }
    function Pb() {
      Cm = false, fo !== null && gc(fo) && (fo = null), mo !== null && gc(mo) && (mo = null), go !== null && gc(go) && (go = null), nl.forEach(Wy), ol.forEach(Wy);
    }
    function Va(t, e) {
      t.blockedOn === e && (t.blockedOn = null, Cm || (Cm = true, ar.unstable_scheduleCallback(ar.unstable_NormalPriority, Pb)));
    }
    function il(t) {
      function e(o) {
        return Va(o, t);
      }
      if (0 < rc.length) {
        Va(rc[0], t);
        for (var r = 1; r < rc.length; r++) {
          var n = rc[r];
          n.blockedOn === t && (n.blockedOn = null);
        }
      }
      for (fo !== null && Va(fo, t), mo !== null && Va(mo, t), go !== null && Va(go, t), nl.forEach(e), ol.forEach(e), r = 0; r < uo.length; r++) n = uo[r], n.blockedOn === t && (n.blockedOn = null);
      for (; 0 < uo.length && (r = uo[0], r.blockedOn === null); ) fv(r), r.blockedOn === null && uo.shift();
    }
    var ps = qn.ReactCurrentBatchConfig, Dc = true;
    function Rb(t, e, r, n) {
      var o = _e, i = ps.transition;
      ps.transition = null;
      try {
        _e = 1, cd(t, e, r, n);
      } finally {
        _e = o, ps.transition = i;
      }
    }
    function Vb(t, e, r, n) {
      var o = _e, i = ps.transition;
      ps.transition = null;
      try {
        _e = 4, cd(t, e, r, n);
      } finally {
        _e = o, ps.transition = i;
      }
    }
    function cd(t, e, r, n) {
      if (Dc) {
        var o = km(t, e, r, n);
        if (o === null) Kf(t, e, n, Mc, r), zy(t, n);
        else if (Mb(o, t, e, r, n)) n.stopPropagation();
        else if (zy(t, n), e & 4 && -1 < Db.indexOf(t)) {
          for (; o !== null; ) {
            var i = _l(o);
            if (i !== null && uv(i), i = km(t, e, r, n), i === null && Kf(t, e, n, Mc, r), i === o) break;
            o = i;
          }
          o !== null && n.stopPropagation();
        } else Kf(t, e, n, null, r);
      }
    }
    var Mc = null;
    function km(t, e, r, n) {
      if (Mc = null, t = sd(n), t = ni(t), t !== null) if (e = mi(t), e === null) t = null;
      else if (r = e.tag, r === 13) {
        if (t = tv(e), t !== null) return t;
        t = null;
      } else if (r === 3) {
        if (e.stateNode.current.memoizedState.isDehydrated) return e.tag === 3 ? e.stateNode.containerInfo : null;
        t = null;
      } else e !== t && (t = null);
      return Mc = t, null;
    }
    function mv(t) {
      switch (t) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return 4;
        case "message":
          switch (Sb()) {
            case ad:
              return 1;
            case iv:
              return 4;
            case Nc:
            case Tb:
              return 16;
            case sv:
              return 536870912;
            default:
              return 16;
          }
        default:
          return 16;
      }
    }
    var po = null, pd = null, xc = null;
    function dv() {
      if (xc) return xc;
      var t, e = pd, r = e.length, n, o = "value" in po ? po.value : po.textContent, i = o.length;
      for (t = 0; t < r && e[t] === o[t]; t++) ;
      var s = r - t;
      for (n = 1; n <= s && e[r - n] === o[i - n]; n++) ;
      return xc = o.slice(t, 1 < n ? 1 - n : void 0);
    }
    function yc(t) {
      var e = t.keyCode;
      return "charCode" in t ? (t = t.charCode, t === 0 && e === 13 && (t = 13)) : t = e, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0;
    }
    function nc() {
      return true;
    }
    function Uy() {
      return false;
    }
    function lr(t) {
      function e(r, n, o, i, s) {
        this._reactName = r, this._targetInst = o, this.type = n, this.nativeEvent = i, this.target = s, this.currentTarget = null;
        for (var a in t) t.hasOwnProperty(a) && (r = t[a], this[a] = r ? r(i) : i[a]);
        return this.isDefaultPrevented = (i.defaultPrevented != null ? i.defaultPrevented : i.returnValue === false) ? nc : Uy, this.isPropagationStopped = Uy, this;
      }
      return Ve(e.prototype, { preventDefault: function() {
        this.defaultPrevented = true;
        var r = this.nativeEvent;
        r && (r.preventDefault ? r.preventDefault() : typeof r.returnValue != "unknown" && (r.returnValue = false), this.isDefaultPrevented = nc);
      }, stopPropagation: function() {
        var r = this.nativeEvent;
        r && (r.stopPropagation ? r.stopPropagation() : typeof r.cancelBubble != "unknown" && (r.cancelBubble = true), this.isPropagationStopped = nc);
      }, persist: function() {
      }, isPersistent: nc }), e;
    }
    var ws = { eventPhase: 0, bubbles: 0, cancelable: 0, timeStamp: function(t) {
      return t.timeStamp || Date.now();
    }, defaultPrevented: 0, isTrusted: 0 }, hd = lr(ws), yl = Ve({}, ws, { view: 0, detail: 0 }), Fb = lr(yl), Gf, Hf, Fa, Kc = Ve({}, yl, { screenX: 0, screenY: 0, clientX: 0, clientY: 0, pageX: 0, pageY: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, getModifierState: fd, button: 0, buttons: 0, relatedTarget: function(t) {
      return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget;
    }, movementX: function(t) {
      return "movementX" in t ? t.movementX : (t !== Fa && (Fa && t.type === "mousemove" ? (Gf = t.screenX - Fa.screenX, Hf = t.screenY - Fa.screenY) : Hf = Gf = 0, Fa = t), Gf);
    }, movementY: function(t) {
      return "movementY" in t ? t.movementY : Hf;
    } }), Gy = lr(Kc), Ib = Ve({}, Kc, { dataTransfer: 0 }), Lb = lr(Ib), Bb = Ve({}, yl, { relatedTarget: 0 }), $f = lr(Bb), jb = Ve({}, ws, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }), qb = lr(jb), zb = Ve({}, ws, { clipboardData: function(t) {
      return "clipboardData" in t ? t.clipboardData : window.clipboardData;
    } }), Wb = lr(zb), Ub = Ve({}, ws, { data: 0 }), Hy = lr(Ub), Gb = { Esc: "Escape", Spacebar: " ", Left: "ArrowLeft", Up: "ArrowUp", Right: "ArrowRight", Down: "ArrowDown", Del: "Delete", Win: "OS", Menu: "ContextMenu", Apps: "ContextMenu", Scroll: "ScrollLock", MozPrintableKey: "Unidentified" }, Hb = { 8: "Backspace", 9: "Tab", 12: "Clear", 13: "Enter", 16: "Shift", 17: "Control", 18: "Alt", 19: "Pause", 20: "CapsLock", 27: "Escape", 32: " ", 33: "PageUp", 34: "PageDown", 35: "End", 36: "Home", 37: "ArrowLeft", 38: "ArrowUp", 39: "ArrowRight", 40: "ArrowDown", 45: "Insert", 46: "Delete", 112: "F1", 113: "F2", 114: "F3", 115: "F4", 116: "F5", 117: "F6", 118: "F7", 119: "F8", 120: "F9", 121: "F10", 122: "F11", 123: "F12", 144: "NumLock", 145: "ScrollLock", 224: "Meta" }, $b = { Alt: "altKey", Control: "ctrlKey", Meta: "metaKey", Shift: "shiftKey" };
    function Xb(t) {
      var e = this.nativeEvent;
      return e.getModifierState ? e.getModifierState(t) : (t = $b[t]) ? !!e[t] : false;
    }
    function fd() {
      return Xb;
    }
    var Yb = Ve({}, yl, { key: function(t) {
      if (t.key) {
        var e = Gb[t.key] || t.key;
        if (e !== "Unidentified") return e;
      }
      return t.type === "keypress" ? (t = yc(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? Hb[t.keyCode] || "Unidentified" : "";
    }, code: 0, location: 0, ctrlKey: 0, shiftKey: 0, altKey: 0, metaKey: 0, repeat: 0, locale: 0, getModifierState: fd, charCode: function(t) {
      return t.type === "keypress" ? yc(t) : 0;
    }, keyCode: function(t) {
      return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
    }, which: function(t) {
      return t.type === "keypress" ? yc(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0;
    } }), Qb = lr(Yb), Kb = Ve({}, Kc, { pointerId: 0, width: 0, height: 0, pressure: 0, tangentialPressure: 0, tiltX: 0, tiltY: 0, twist: 0, pointerType: 0, isPrimary: 0 }), $y = lr(Kb), Zb = Ve({}, yl, { touches: 0, targetTouches: 0, changedTouches: 0, altKey: 0, metaKey: 0, ctrlKey: 0, shiftKey: 0, getModifierState: fd }), Jb = lr(Zb), eN = Ve({}, ws, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 }), tN = lr(eN), rN = Ve({}, Kc, { deltaX: function(t) {
      return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0;
    }, deltaY: function(t) {
      return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0;
    }, deltaZ: 0, deltaMode: 0 }), nN = lr(rN), oN = [9, 13, 27, 32], md = In && "CompositionEvent" in window, $a = null;
    In && "documentMode" in document && ($a = document.documentMode);
    var iN = In && "TextEvent" in window && !$a, gv = In && (!md || $a && 8 < $a && 11 >= $a), Xy = " ", Yy = false;
    function xv(t, e) {
      switch (t) {
        case "keyup":
          return oN.indexOf(e.keyCode) !== -1;
        case "keydown":
          return e.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
          return true;
        default:
          return false;
      }
    }
    function yv(t) {
      return t = t.detail, typeof t == "object" && "data" in t ? t.data : null;
    }
    var Zi = false;
    function sN(t, e) {
      switch (t) {
        case "compositionend":
          return yv(e);
        case "keypress":
          return e.which !== 32 ? null : (Yy = true, Xy);
        case "textInput":
          return t = e.data, t === Xy && Yy ? null : t;
        default:
          return null;
      }
    }
    function aN(t, e) {
      if (Zi) return t === "compositionend" || !md && xv(t, e) ? (t = dv(), xc = pd = po = null, Zi = false, t) : null;
      switch (t) {
        case "paste":
          return null;
        case "keypress":
          if (!(e.ctrlKey || e.altKey || e.metaKey) || e.ctrlKey && e.altKey) {
            if (e.char && 1 < e.char.length) return e.char;
            if (e.which) return String.fromCharCode(e.which);
          }
          return null;
        case "compositionend":
          return gv && e.locale !== "ko" ? null : e.data;
        default:
          return null;
      }
    }
    var lN = { color: true, date: true, datetime: true, "datetime-local": true, email: true, month: true, number: true, password: true, range: true, search: true, tel: true, text: true, time: true, url: true, week: true };
    function Qy(t) {
      var e = t && t.nodeName && t.nodeName.toLowerCase();
      return e === "input" ? !!lN[t.type] : e === "textarea";
    }
    function _v(t, e, r, n) {
      Q_(n), e = Pc(e, "onChange"), 0 < e.length && (r = new hd("onChange", "change", null, r, n), t.push({ event: r, listeners: e }));
    }
    var Xa = null, sl = null;
    function uN(t) {
      Ov(t, 0);
    }
    function Zc(t) {
      var e = ts(t);
      if (W_(e)) return t;
    }
    function cN(t, e) {
      if (t === "change") return e;
    }
    var vv = false;
    In && (In ? (ic = "oninput" in document, ic || (Xf = document.createElement("div"), Xf.setAttribute("oninput", "return;"), ic = typeof Xf.oninput == "function"), oc = ic) : oc = false, vv = oc && (!document.documentMode || 9 < document.documentMode));
    var oc, ic, Xf;
    function Ky() {
      Xa && (Xa.detachEvent("onpropertychange", wv), sl = Xa = null);
    }
    function wv(t) {
      if (t.propertyName === "value" && Zc(sl)) {
        var e = [];
        _v(e, sl, t, sd(t)), ev(uN, e);
      }
    }
    function pN(t, e, r) {
      t === "focusin" ? (Ky(), Xa = e, sl = r, Xa.attachEvent("onpropertychange", wv)) : t === "focusout" && Ky();
    }
    function hN(t) {
      if (t === "selectionchange" || t === "keyup" || t === "keydown") return Zc(sl);
    }
    function fN(t, e) {
      if (t === "click") return Zc(e);
    }
    function mN(t, e) {
      if (t === "input" || t === "change") return Zc(e);
    }
    function dN(t, e) {
      return t === e && (t !== 0 || 1 / t === 1 / e) || t !== t && e !== e;
    }
    var $r = typeof Object.is == "function" ? Object.is : dN;
    function al(t, e) {
      if ($r(t, e)) return true;
      if (typeof t != "object" || t === null || typeof e != "object" || e === null) return false;
      var r = Object.keys(t), n = Object.keys(e);
      if (r.length !== n.length) return false;
      for (n = 0; n < r.length; n++) {
        var o = r[n];
        if (!lm.call(e, o) || !$r(t[o], e[o])) return false;
      }
      return true;
    }
    function Zy(t) {
      for (; t && t.firstChild; ) t = t.firstChild;
      return t;
    }
    function Jy(t, e) {
      var r = Zy(t);
      t = 0;
      for (var n; r; ) {
        if (r.nodeType === 3) {
          if (n = t + r.textContent.length, t <= e && n >= e) return { node: r, offset: e - t };
          t = n;
        }
        e: {
          for (; r; ) {
            if (r.nextSibling) {
              r = r.nextSibling;
              break e;
            }
            r = r.parentNode;
          }
          r = void 0;
        }
        r = Zy(r);
      }
    }
    function Sv(t, e) {
      return t && e ? t === e ? true : t && t.nodeType === 3 ? false : e && e.nodeType === 3 ? Sv(t, e.parentNode) : "contains" in t ? t.contains(e) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(e) & 16) : false : false;
    }
    function Tv() {
      for (var t = window, e = kc(); e instanceof t.HTMLIFrameElement; ) {
        try {
          var r = typeof e.contentWindow.location.href == "string";
        } catch {
          r = false;
        }
        if (r) t = e.contentWindow;
        else break;
        e = kc(t.document);
      }
      return e;
    }
    function dd(t) {
      var e = t && t.nodeName && t.nodeName.toLowerCase();
      return e && (e === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || e === "textarea" || t.contentEditable === "true");
    }
    function gN(t) {
      var e = Tv(), r = t.focusedElem, n = t.selectionRange;
      if (e !== r && r && r.ownerDocument && Sv(r.ownerDocument.documentElement, r)) {
        if (n !== null && dd(r)) {
          if (e = n.start, t = n.end, t === void 0 && (t = e), "selectionStart" in r) r.selectionStart = e, r.selectionEnd = Math.min(t, r.value.length);
          else if (t = (e = r.ownerDocument || document) && e.defaultView || window, t.getSelection) {
            t = t.getSelection();
            var o = r.textContent.length, i = Math.min(n.start, o);
            n = n.end === void 0 ? i : Math.min(n.end, o), !t.extend && i > n && (o = n, n = i, i = o), o = Jy(r, i);
            var s = Jy(r, n);
            o && s && (t.rangeCount !== 1 || t.anchorNode !== o.node || t.anchorOffset !== o.offset || t.focusNode !== s.node || t.focusOffset !== s.offset) && (e = e.createRange(), e.setStart(o.node, o.offset), t.removeAllRanges(), i > n ? (t.addRange(e), t.extend(s.node, s.offset)) : (e.setEnd(s.node, s.offset), t.addRange(e)));
          }
        }
        for (e = [], t = r; t = t.parentNode; ) t.nodeType === 1 && e.push({ element: t, left: t.scrollLeft, top: t.scrollTop });
        for (typeof r.focus == "function" && r.focus(), r = 0; r < e.length; r++) t = e[r], t.element.scrollLeft = t.left, t.element.scrollTop = t.top;
      }
    }
    var xN = In && "documentMode" in document && 11 >= document.documentMode, Ji = null, Em = null, Ya = null, bm = false;
    function e_(t, e, r) {
      var n = r.window === r ? r.document : r.nodeType === 9 ? r : r.ownerDocument;
      bm || Ji == null || Ji !== kc(n) || (n = Ji, "selectionStart" in n && dd(n) ? n = { start: n.selectionStart, end: n.selectionEnd } : (n = (n.ownerDocument && n.ownerDocument.defaultView || window).getSelection(), n = { anchorNode: n.anchorNode, anchorOffset: n.anchorOffset, focusNode: n.focusNode, focusOffset: n.focusOffset }), Ya && al(Ya, n) || (Ya = n, n = Pc(Em, "onSelect"), 0 < n.length && (e = new hd("onSelect", "select", null, e, r), t.push({ event: e, listeners: n }), e.target = Ji)));
    }
    function sc(t, e) {
      var r = {};
      return r[t.toLowerCase()] = e.toLowerCase(), r["Webkit" + t] = "webkit" + e, r["Moz" + t] = "moz" + e, r;
    }
    var es = { animationend: sc("Animation", "AnimationEnd"), animationiteration: sc("Animation", "AnimationIteration"), animationstart: sc("Animation", "AnimationStart"), transitionend: sc("Transition", "TransitionEnd") }, Yf = {}, Av = {};
    In && (Av = document.createElement("div").style, "AnimationEvent" in window || (delete es.animationend.animation, delete es.animationiteration.animation, delete es.animationstart.animation), "TransitionEvent" in window || delete es.transitionend.transition);
    function Jc(t) {
      if (Yf[t]) return Yf[t];
      if (!es[t]) return t;
      var e = es[t], r;
      for (r in e) if (e.hasOwnProperty(r) && r in Av) return Yf[t] = e[r];
      return t;
    }
    var Cv = Jc("animationend"), kv = Jc("animationiteration"), Ev = Jc("animationstart"), bv = Jc("transitionend"), Nv = /* @__PURE__ */ new Map(), t_ = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    function Ao(t, e) {
      Nv.set(t, e), fi(e, [t]);
    }
    for (ac = 0; ac < t_.length; ac++) lc = t_[ac], r_ = lc.toLowerCase(), n_ = lc[0].toUpperCase() + lc.slice(1), Ao(r_, "on" + n_);
    var lc, r_, n_, ac;
    Ao(Cv, "onAnimationEnd");
    Ao(kv, "onAnimationIteration");
    Ao(Ev, "onAnimationStart");
    Ao("dblclick", "onDoubleClick");
    Ao("focusin", "onFocus");
    Ao("focusout", "onBlur");
    Ao(bv, "onTransitionEnd");
    ms("onMouseEnter", ["mouseout", "mouseover"]);
    ms("onMouseLeave", ["mouseout", "mouseover"]);
    ms("onPointerEnter", ["pointerout", "pointerover"]);
    ms("onPointerLeave", ["pointerout", "pointerover"]);
    fi("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
    fi("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
    fi("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
    fi("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
    fi("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
    fi("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var Ua = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), yN = new Set("cancel close invalid load scroll toggle".split(" ").concat(Ua));
    function o_(t, e, r) {
      var n = t.type || "unknown-event";
      t.currentTarget = r, yb(n, e, void 0, t), t.currentTarget = null;
    }
    function Ov(t, e) {
      e = (e & 4) !== 0;
      for (var r = 0; r < t.length; r++) {
        var n = t[r], o = n.event;
        n = n.listeners;
        e: {
          var i = void 0;
          if (e) for (var s = n.length - 1; 0 <= s; s--) {
            var a = n[s], l = a.instance, u = a.currentTarget;
            if (a = a.listener, l !== i && o.isPropagationStopped()) break e;
            o_(o, a, u), i = l;
          }
          else for (s = 0; s < n.length; s++) {
            if (a = n[s], l = a.instance, u = a.currentTarget, a = a.listener, l !== i && o.isPropagationStopped()) break e;
            o_(o, a, u), i = l;
          }
        }
      }
      if (bc) throw t = Tm, bc = false, Tm = null, t;
    }
    function ke(t, e) {
      var r = e[Pm];
      r === void 0 && (r = e[Pm] = /* @__PURE__ */ new Set());
      var n = t + "__bubble";
      r.has(n) || (Dv(e, t, 2, false), r.add(n));
    }
    function Qf(t, e, r) {
      var n = 0;
      e && (n |= 4), Dv(r, t, n, e);
    }
    var uc = "_reactListening" + Math.random().toString(36).slice(2);
    function ll(t) {
      if (!t[uc]) {
        t[uc] = true, L_.forEach(function(r) {
          r !== "selectionchange" && (yN.has(r) || Qf(r, false, t), Qf(r, true, t));
        });
        var e = t.nodeType === 9 ? t : t.ownerDocument;
        e === null || e[uc] || (e[uc] = true, Qf("selectionchange", false, e));
      }
    }
    function Dv(t, e, r, n) {
      switch (mv(e)) {
        case 1:
          var o = Rb;
          break;
        case 4:
          o = Vb;
          break;
        default:
          o = cd;
      }
      r = o.bind(null, e, r, t), o = void 0, !Sm || e !== "touchstart" && e !== "touchmove" && e !== "wheel" || (o = true), n ? o !== void 0 ? t.addEventListener(e, r, { capture: true, passive: o }) : t.addEventListener(e, r, true) : o !== void 0 ? t.addEventListener(e, r, { passive: o }) : t.addEventListener(e, r, false);
    }
    function Kf(t, e, r, n, o) {
      var i = n;
      if (!(e & 1) && !(e & 2) && n !== null) e: for (; ; ) {
        if (n === null) return;
        var s = n.tag;
        if (s === 3 || s === 4) {
          var a = n.stateNode.containerInfo;
          if (a === o || a.nodeType === 8 && a.parentNode === o) break;
          if (s === 4) for (s = n.return; s !== null; ) {
            var l = s.tag;
            if ((l === 3 || l === 4) && (l = s.stateNode.containerInfo, l === o || l.nodeType === 8 && l.parentNode === o)) return;
            s = s.return;
          }
          for (; a !== null; ) {
            if (s = ni(a), s === null) return;
            if (l = s.tag, l === 5 || l === 6) {
              n = i = s;
              continue e;
            }
            a = a.parentNode;
          }
        }
        n = n.return;
      }
      ev(function() {
        var u = i, c = sd(r), p = [];
        e: {
          var h = Nv.get(t);
          if (h !== void 0) {
            var f = hd, m = t;
            switch (t) {
              case "keypress":
                if (yc(r) === 0) break e;
              case "keydown":
              case "keyup":
                f = Qb;
                break;
              case "focusin":
                m = "focus", f = $f;
                break;
              case "focusout":
                m = "blur", f = $f;
                break;
              case "beforeblur":
              case "afterblur":
                f = $f;
                break;
              case "click":
                if (r.button === 2) break e;
              case "auxclick":
              case "dblclick":
              case "mousedown":
              case "mousemove":
              case "mouseup":
              case "mouseout":
              case "mouseover":
              case "contextmenu":
                f = Gy;
                break;
              case "drag":
              case "dragend":
              case "dragenter":
              case "dragexit":
              case "dragleave":
              case "dragover":
              case "dragstart":
              case "drop":
                f = Lb;
                break;
              case "touchcancel":
              case "touchend":
              case "touchmove":
              case "touchstart":
                f = Jb;
                break;
              case Cv:
              case kv:
              case Ev:
                f = qb;
                break;
              case bv:
                f = tN;
                break;
              case "scroll":
                f = Fb;
                break;
              case "wheel":
                f = nN;
                break;
              case "copy":
              case "cut":
              case "paste":
                f = Wb;
                break;
              case "gotpointercapture":
              case "lostpointercapture":
              case "pointercancel":
              case "pointerdown":
              case "pointermove":
              case "pointerout":
              case "pointerover":
              case "pointerup":
                f = $y;
            }
            var x = (e & 4) !== 0, _ = !x && t === "scroll", d = x ? h !== null ? h + "Capture" : null : h;
            x = [];
            for (var g = u, y; g !== null; ) {
              y = g;
              var S = y.stateNode;
              if (y.tag === 5 && S !== null && (y = S, d !== null && (S = rl(g, d), S != null && x.push(ul(g, S, y)))), _) break;
              g = g.return;
            }
            0 < x.length && (h = new f(h, m, null, r, c), p.push({ event: h, listeners: x }));
          }
        }
        if (!(e & 7)) {
          e: {
            if (h = t === "mouseover" || t === "pointerover", f = t === "mouseout" || t === "pointerout", h && r !== vm && (m = r.relatedTarget || r.fromElement) && (ni(m) || m[Ln])) break e;
            if ((f || h) && (h = c.window === c ? c : (h = c.ownerDocument) ? h.defaultView || h.parentWindow : window, f ? (m = r.relatedTarget || r.toElement, f = u, m = m ? ni(m) : null, m !== null && (_ = mi(m), m !== _ || m.tag !== 5 && m.tag !== 6) && (m = null)) : (f = null, m = u), f !== m)) {
              if (x = Gy, S = "onMouseLeave", d = "onMouseEnter", g = "mouse", (t === "pointerout" || t === "pointerover") && (x = $y, S = "onPointerLeave", d = "onPointerEnter", g = "pointer"), _ = f == null ? h : ts(f), y = m == null ? h : ts(m), h = new x(S, g + "leave", f, r, c), h.target = _, h.relatedTarget = y, S = null, ni(c) === u && (x = new x(d, g + "enter", m, r, c), x.target = y, x.relatedTarget = _, S = x), _ = S, f && m) t: {
                for (x = f, d = m, g = 0, y = x; y; y = Yi(y)) g++;
                for (y = 0, S = d; S; S = Yi(S)) y++;
                for (; 0 < g - y; ) x = Yi(x), g--;
                for (; 0 < y - g; ) d = Yi(d), y--;
                for (; g--; ) {
                  if (x === d || d !== null && x === d.alternate) break t;
                  x = Yi(x), d = Yi(d);
                }
                x = null;
              }
              else x = null;
              f !== null && i_(p, h, f, x, false), m !== null && _ !== null && i_(p, _, m, x, true);
            }
          }
          e: {
            if (h = u ? ts(u) : window, f = h.nodeName && h.nodeName.toLowerCase(), f === "select" || f === "input" && h.type === "file") var v = cN;
            else if (Qy(h)) if (vv) v = mN;
            else {
              v = hN;
              var T = pN;
            }
            else (f = h.nodeName) && f.toLowerCase() === "input" && (h.type === "checkbox" || h.type === "radio") && (v = fN);
            if (v && (v = v(t, u))) {
              _v(p, v, r, c);
              break e;
            }
            T && T(t, h, u), t === "focusout" && (T = h._wrapperState) && T.controlled && h.type === "number" && dm(h, "number", h.value);
          }
          switch (T = u ? ts(u) : window, t) {
            case "focusin":
              (Qy(T) || T.contentEditable === "true") && (Ji = T, Em = u, Ya = null);
              break;
            case "focusout":
              Ya = Em = Ji = null;
              break;
            case "mousedown":
              bm = true;
              break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
              bm = false, e_(p, r, c);
              break;
            case "selectionchange":
              if (xN) break;
            case "keydown":
            case "keyup":
              e_(p, r, c);
          }
          var A;
          if (md) e: {
            switch (t) {
              case "compositionstart":
                var w = "onCompositionStart";
                break e;
              case "compositionend":
                w = "onCompositionEnd";
                break e;
              case "compositionupdate":
                w = "onCompositionUpdate";
                break e;
            }
            w = void 0;
          }
          else Zi ? xv(t, r) && (w = "onCompositionEnd") : t === "keydown" && r.keyCode === 229 && (w = "onCompositionStart");
          w && (gv && r.locale !== "ko" && (Zi || w !== "onCompositionStart" ? w === "onCompositionEnd" && Zi && (A = dv()) : (po = c, pd = "value" in po ? po.value : po.textContent, Zi = true)), T = Pc(u, w), 0 < T.length && (w = new Hy(w, t, null, r, c), p.push({ event: w, listeners: T }), A ? w.data = A : (A = yv(r), A !== null && (w.data = A)))), (A = iN ? sN(t, r) : aN(t, r)) && (u = Pc(u, "onBeforeInput"), 0 < u.length && (c = new Hy("onBeforeInput", "beforeinput", null, r, c), p.push({ event: c, listeners: u }), c.data = A));
        }
        Ov(p, e);
      });
    }
    function ul(t, e, r) {
      return { instance: t, listener: e, currentTarget: r };
    }
    function Pc(t, e) {
      for (var r = e + "Capture", n = []; t !== null; ) {
        var o = t, i = o.stateNode;
        o.tag === 5 && i !== null && (o = i, i = rl(t, r), i != null && n.unshift(ul(t, i, o)), i = rl(t, e), i != null && n.push(ul(t, i, o))), t = t.return;
      }
      return n;
    }
    function Yi(t) {
      if (t === null) return null;
      do
        t = t.return;
      while (t && t.tag !== 5);
      return t || null;
    }
    function i_(t, e, r, n, o) {
      for (var i = e._reactName, s = []; r !== null && r !== n; ) {
        var a = r, l = a.alternate, u = a.stateNode;
        if (l !== null && l === n) break;
        a.tag === 5 && u !== null && (a = u, o ? (l = rl(r, i), l != null && s.unshift(ul(r, l, a))) : o || (l = rl(r, i), l != null && s.push(ul(r, l, a)))), r = r.return;
      }
      s.length !== 0 && t.push({ event: e, listeners: s });
    }
    var _N = /\r\n?/g, vN = /\u0000|\uFFFD/g;
    function s_(t) {
      return (typeof t == "string" ? t : "" + t).replace(_N, `
`).replace(vN, "");
    }
    function cc(t, e, r) {
      if (e = s_(e), s_(t) !== e && r) throw Error(F(425));
    }
    function Rc() {
    }
    var Nm = null, Om = null;
    function Dm(t, e) {
      return t === "textarea" || t === "noscript" || typeof e.children == "string" || typeof e.children == "number" || typeof e.dangerouslySetInnerHTML == "object" && e.dangerouslySetInnerHTML !== null && e.dangerouslySetInnerHTML.__html != null;
    }
    var Mm = typeof setTimeout == "function" ? setTimeout : void 0, wN = typeof clearTimeout == "function" ? clearTimeout : void 0, a_ = typeof Promise == "function" ? Promise : void 0, SN = typeof queueMicrotask == "function" ? queueMicrotask : typeof a_ < "u" ? function(t) {
      return a_.resolve(null).then(t).catch(TN);
    } : Mm;
    function TN(t) {
      setTimeout(function() {
        throw t;
      });
    }
    function Zf(t, e) {
      var r = e, n = 0;
      do {
        var o = r.nextSibling;
        if (t.removeChild(r), o && o.nodeType === 8) if (r = o.data, r === "/$") {
          if (n === 0) {
            t.removeChild(o), il(e);
            return;
          }
          n--;
        } else r !== "$" && r !== "$?" && r !== "$!" || n++;
        r = o;
      } while (r);
      il(e);
    }
    function xo(t) {
      for (; t != null; t = t.nextSibling) {
        var e = t.nodeType;
        if (e === 1 || e === 3) break;
        if (e === 8) {
          if (e = t.data, e === "$" || e === "$!" || e === "$?") break;
          if (e === "/$") return null;
        }
      }
      return t;
    }
    function l_(t) {
      t = t.previousSibling;
      for (var e = 0; t; ) {
        if (t.nodeType === 8) {
          var r = t.data;
          if (r === "$" || r === "$!" || r === "$?") {
            if (e === 0) return t;
            e--;
          } else r === "/$" && e++;
        }
        t = t.previousSibling;
      }
      return null;
    }
    var Ss = Math.random().toString(36).slice(2), fn = "__reactFiber$" + Ss, cl = "__reactProps$" + Ss, Ln = "__reactContainer$" + Ss, Pm = "__reactEvents$" + Ss, AN = "__reactListeners$" + Ss, CN = "__reactHandles$" + Ss;
    function ni(t) {
      var e = t[fn];
      if (e) return e;
      for (var r = t.parentNode; r; ) {
        if (e = r[Ln] || r[fn]) {
          if (r = e.alternate, e.child !== null || r !== null && r.child !== null) for (t = l_(t); t !== null; ) {
            if (r = t[fn]) return r;
            t = l_(t);
          }
          return e;
        }
        t = r, r = t.parentNode;
      }
      return null;
    }
    function _l(t) {
      return t = t[fn] || t[Ln], !t || t.tag !== 5 && t.tag !== 6 && t.tag !== 13 && t.tag !== 3 ? null : t;
    }
    function ts(t) {
      if (t.tag === 5 || t.tag === 6) return t.stateNode;
      throw Error(F(33));
    }
    function ep(t) {
      return t[cl] || null;
    }
    var Rm = [], rs = -1;
    function Co(t) {
      return { current: t };
    }
    function Ee(t) {
      0 > rs || (t.current = Rm[rs], Rm[rs] = null, rs--);
    }
    function Ae(t, e) {
      rs++, Rm[rs] = t.current, t.current = e;
    }
    var To = {}, Nt = Co(To), Qt = Co(false), li = To;
    function ds(t, e) {
      var r = t.type.contextTypes;
      if (!r) return To;
      var n = t.stateNode;
      if (n && n.__reactInternalMemoizedUnmaskedChildContext === e) return n.__reactInternalMemoizedMaskedChildContext;
      var o = {}, i;
      for (i in r) o[i] = e[i];
      return n && (t = t.stateNode, t.__reactInternalMemoizedUnmaskedChildContext = e, t.__reactInternalMemoizedMaskedChildContext = o), o;
    }
    function Kt(t) {
      return t = t.childContextTypes, t != null;
    }
    function Vc() {
      Ee(Qt), Ee(Nt);
    }
    function u_(t, e, r) {
      if (Nt.current !== To) throw Error(F(168));
      Ae(Nt, e), Ae(Qt, r);
    }
    function Mv(t, e, r) {
      var n = t.stateNode;
      if (e = e.childContextTypes, typeof n.getChildContext != "function") return r;
      n = n.getChildContext();
      for (var o in n) if (!(o in e)) throw Error(F(108, pb(t) || "Unknown", o));
      return Ve({}, r, n);
    }
    function Fc(t) {
      return t = (t = t.stateNode) && t.__reactInternalMemoizedMergedChildContext || To, li = Nt.current, Ae(Nt, t), Ae(Qt, Qt.current), true;
    }
    function c_(t, e, r) {
      var n = t.stateNode;
      if (!n) throw Error(F(169));
      r ? (t = Mv(t, e, li), n.__reactInternalMemoizedMergedChildContext = t, Ee(Qt), Ee(Nt), Ae(Nt, t)) : Ee(Qt), Ae(Qt, r);
    }
    var Pn = null, tp = false, Jf = false;
    function Pv(t) {
      Pn === null ? Pn = [t] : Pn.push(t);
    }
    function kN(t) {
      tp = true, Pv(t);
    }
    function ko() {
      if (!Jf && Pn !== null) {
        Jf = true;
        var t = 0, e = _e;
        try {
          var r = Pn;
          for (_e = 1; t < r.length; t++) {
            var n = r[t];
            do
              n = n(true);
            while (n !== null);
          }
          Pn = null, tp = false;
        } catch (o) {
          throw Pn !== null && (Pn = Pn.slice(t + 1)), ov(ad, ko), o;
        } finally {
          _e = e, Jf = false;
        }
      }
      return null;
    }
    var ns = [], os = 0, Ic = null, Lc = 0, vr = [], wr = 0, ui = null, Rn = 1, Vn = "";
    function ti(t, e) {
      ns[os++] = Lc, ns[os++] = Ic, Ic = t, Lc = e;
    }
    function Rv(t, e, r) {
      vr[wr++] = Rn, vr[wr++] = Vn, vr[wr++] = ui, ui = t;
      var n = Rn;
      t = Vn;
      var o = 32 - Gr(n) - 1;
      n &= ~(1 << o), r += 1;
      var i = 32 - Gr(e) + o;
      if (30 < i) {
        var s = o - o % 5;
        i = (n & (1 << s) - 1).toString(32), n >>= s, o -= s, Rn = 1 << 32 - Gr(e) + o | r << o | n, Vn = i + t;
      } else Rn = 1 << i | r << o | n, Vn = t;
    }
    function gd(t) {
      t.return !== null && (ti(t, 1), Rv(t, 1, 0));
    }
    function xd(t) {
      for (; t === Ic; ) Ic = ns[--os], ns[os] = null, Lc = ns[--os], ns[os] = null;
      for (; t === ui; ) ui = vr[--wr], vr[wr] = null, Vn = vr[--wr], vr[wr] = null, Rn = vr[--wr], vr[wr] = null;
    }
    var sr = null, ir = null, be = false, Ur = null;
    function Vv(t, e) {
      var r = Sr(5, null, null, 0);
      r.elementType = "DELETED", r.stateNode = e, r.return = t, e = t.deletions, e === null ? (t.deletions = [r], t.flags |= 16) : e.push(r);
    }
    function p_(t, e) {
      switch (t.tag) {
        case 5:
          var r = t.type;
          return e = e.nodeType !== 1 || r.toLowerCase() !== e.nodeName.toLowerCase() ? null : e, e !== null ? (t.stateNode = e, sr = t, ir = xo(e.firstChild), true) : false;
        case 6:
          return e = t.pendingProps === "" || e.nodeType !== 3 ? null : e, e !== null ? (t.stateNode = e, sr = t, ir = null, true) : false;
        case 13:
          return e = e.nodeType !== 8 ? null : e, e !== null ? (r = ui !== null ? { id: Rn, overflow: Vn } : null, t.memoizedState = { dehydrated: e, treeContext: r, retryLane: 1073741824 }, r = Sr(18, null, null, 0), r.stateNode = e, r.return = t, t.child = r, sr = t, ir = null, true) : false;
        default:
          return false;
      }
    }
    function Vm(t) {
      return (t.mode & 1) !== 0 && (t.flags & 128) === 0;
    }
    function Fm(t) {
      if (be) {
        var e = ir;
        if (e) {
          var r = e;
          if (!p_(t, e)) {
            if (Vm(t)) throw Error(F(418));
            e = xo(r.nextSibling);
            var n = sr;
            e && p_(t, e) ? Vv(n, r) : (t.flags = t.flags & -4097 | 2, be = false, sr = t);
          }
        } else {
          if (Vm(t)) throw Error(F(418));
          t.flags = t.flags & -4097 | 2, be = false, sr = t;
        }
      }
    }
    function h_(t) {
      for (t = t.return; t !== null && t.tag !== 5 && t.tag !== 3 && t.tag !== 13; ) t = t.return;
      sr = t;
    }
    function pc(t) {
      if (t !== sr) return false;
      if (!be) return h_(t), be = true, false;
      var e;
      if ((e = t.tag !== 3) && !(e = t.tag !== 5) && (e = t.type, e = e !== "head" && e !== "body" && !Dm(t.type, t.memoizedProps)), e && (e = ir)) {
        if (Vm(t)) throw Fv(), Error(F(418));
        for (; e; ) Vv(t, e), e = xo(e.nextSibling);
      }
      if (h_(t), t.tag === 13) {
        if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(F(317));
        e: {
          for (t = t.nextSibling, e = 0; t; ) {
            if (t.nodeType === 8) {
              var r = t.data;
              if (r === "/$") {
                if (e === 0) {
                  ir = xo(t.nextSibling);
                  break e;
                }
                e--;
              } else r !== "$" && r !== "$!" && r !== "$?" || e++;
            }
            t = t.nextSibling;
          }
          ir = null;
        }
      } else ir = sr ? xo(t.stateNode.nextSibling) : null;
      return true;
    }
    function Fv() {
      for (var t = ir; t; ) t = xo(t.nextSibling);
    }
    function gs() {
      ir = sr = null, be = false;
    }
    function yd(t) {
      Ur === null ? Ur = [t] : Ur.push(t);
    }
    var EN = qn.ReactCurrentBatchConfig;
    function Ia(t, e, r) {
      if (t = r.ref, t !== null && typeof t != "function" && typeof t != "object") {
        if (r._owner) {
          if (r = r._owner, r) {
            if (r.tag !== 1) throw Error(F(309));
            var n = r.stateNode;
          }
          if (!n) throw Error(F(147, t));
          var o = n, i = "" + t;
          return e !== null && e.ref !== null && typeof e.ref == "function" && e.ref._stringRef === i ? e.ref : (e = function(s) {
            var a = o.refs;
            s === null ? delete a[i] : a[i] = s;
          }, e._stringRef = i, e);
        }
        if (typeof t != "string") throw Error(F(284));
        if (!r._owner) throw Error(F(290, t));
      }
      return t;
    }
    function hc(t, e) {
      throw t = Object.prototype.toString.call(e), Error(F(31, t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t));
    }
    function f_(t) {
      var e = t._init;
      return e(t._payload);
    }
    function Iv(t) {
      function e(d, g) {
        if (t) {
          var y = d.deletions;
          y === null ? (d.deletions = [g], d.flags |= 16) : y.push(g);
        }
      }
      function r(d, g) {
        if (!t) return null;
        for (; g !== null; ) e(d, g), g = g.sibling;
        return null;
      }
      function n(d, g) {
        for (d = /* @__PURE__ */ new Map(); g !== null; ) g.key !== null ? d.set(g.key, g) : d.set(g.index, g), g = g.sibling;
        return d;
      }
      function o(d, g) {
        return d = wo(d, g), d.index = 0, d.sibling = null, d;
      }
      function i(d, g, y) {
        return d.index = y, t ? (y = d.alternate, y !== null ? (y = y.index, y < g ? (d.flags |= 2, g) : y) : (d.flags |= 2, g)) : (d.flags |= 1048576, g);
      }
      function s(d) {
        return t && d.alternate === null && (d.flags |= 2), d;
      }
      function a(d, g, y, S) {
        return g === null || g.tag !== 6 ? (g = sm(y, d.mode, S), g.return = d, g) : (g = o(g, y), g.return = d, g);
      }
      function l(d, g, y, S) {
        var v = y.type;
        return v === Ki ? c(d, g, y.props.children, S, y.key) : g !== null && (g.elementType === v || typeof v == "object" && v !== null && v.$$typeof === ao && f_(v) === g.type) ? (S = o(g, y.props), S.ref = Ia(d, g, y), S.return = d, S) : (S = Cc(y.type, y.key, y.props, null, d.mode, S), S.ref = Ia(d, g, y), S.return = d, S);
      }
      function u(d, g, y, S) {
        return g === null || g.tag !== 4 || g.stateNode.containerInfo !== y.containerInfo || g.stateNode.implementation !== y.implementation ? (g = am(y, d.mode, S), g.return = d, g) : (g = o(g, y.children || []), g.return = d, g);
      }
      function c(d, g, y, S, v) {
        return g === null || g.tag !== 7 ? (g = ai(y, d.mode, S, v), g.return = d, g) : (g = o(g, y), g.return = d, g);
      }
      function p(d, g, y) {
        if (typeof g == "string" && g !== "" || typeof g == "number") return g = sm("" + g, d.mode, y), g.return = d, g;
        if (typeof g == "object" && g !== null) {
          switch (g.$$typeof) {
            case Ku:
              return y = Cc(g.type, g.key, g.props, null, d.mode, y), y.ref = Ia(d, null, g), y.return = d, y;
            case Qi:
              return g = am(g, d.mode, y), g.return = d, g;
            case ao:
              var S = g._init;
              return p(d, S(g._payload), y);
          }
          if (za(g) || Pa(g)) return g = ai(g, d.mode, y, null), g.return = d, g;
          hc(d, g);
        }
        return null;
      }
      function h(d, g, y, S) {
        var v = g !== null ? g.key : null;
        if (typeof y == "string" && y !== "" || typeof y == "number") return v !== null ? null : a(d, g, "" + y, S);
        if (typeof y == "object" && y !== null) {
          switch (y.$$typeof) {
            case Ku:
              return y.key === v ? l(d, g, y, S) : null;
            case Qi:
              return y.key === v ? u(d, g, y, S) : null;
            case ao:
              return v = y._init, h(d, g, v(y._payload), S);
          }
          if (za(y) || Pa(y)) return v !== null ? null : c(d, g, y, S, null);
          hc(d, y);
        }
        return null;
      }
      function f(d, g, y, S, v) {
        if (typeof S == "string" && S !== "" || typeof S == "number") return d = d.get(y) || null, a(g, d, "" + S, v);
        if (typeof S == "object" && S !== null) {
          switch (S.$$typeof) {
            case Ku:
              return d = d.get(S.key === null ? y : S.key) || null, l(g, d, S, v);
            case Qi:
              return d = d.get(S.key === null ? y : S.key) || null, u(g, d, S, v);
            case ao:
              var T = S._init;
              return f(d, g, y, T(S._payload), v);
          }
          if (za(S) || Pa(S)) return d = d.get(y) || null, c(g, d, S, v, null);
          hc(g, S);
        }
        return null;
      }
      function m(d, g, y, S) {
        for (var v = null, T = null, A = g, w = g = 0, N = null; A !== null && w < y.length; w++) {
          A.index > w ? (N = A, A = null) : N = A.sibling;
          var k = h(d, A, y[w], S);
          if (k === null) {
            A === null && (A = N);
            break;
          }
          t && A && k.alternate === null && e(d, A), g = i(k, g, w), T === null ? v = k : T.sibling = k, T = k, A = N;
        }
        if (w === y.length) return r(d, A), be && ti(d, w), v;
        if (A === null) {
          for (; w < y.length; w++) A = p(d, y[w], S), A !== null && (g = i(A, g, w), T === null ? v = A : T.sibling = A, T = A);
          return be && ti(d, w), v;
        }
        for (A = n(d, A); w < y.length; w++) N = f(A, d, w, y[w], S), N !== null && (t && N.alternate !== null && A.delete(N.key === null ? w : N.key), g = i(N, g, w), T === null ? v = N : T.sibling = N, T = N);
        return t && A.forEach(function(D) {
          return e(d, D);
        }), be && ti(d, w), v;
      }
      function x(d, g, y, S) {
        var v = Pa(y);
        if (typeof v != "function") throw Error(F(150));
        if (y = v.call(y), y == null) throw Error(F(151));
        for (var T = v = null, A = g, w = g = 0, N = null, k = y.next(); A !== null && !k.done; w++, k = y.next()) {
          A.index > w ? (N = A, A = null) : N = A.sibling;
          var D = h(d, A, k.value, S);
          if (D === null) {
            A === null && (A = N);
            break;
          }
          t && A && D.alternate === null && e(d, A), g = i(D, g, w), T === null ? v = D : T.sibling = D, T = D, A = N;
        }
        if (k.done) return r(d, A), be && ti(d, w), v;
        if (A === null) {
          for (; !k.done; w++, k = y.next()) k = p(d, k.value, S), k !== null && (g = i(k, g, w), T === null ? v = k : T.sibling = k, T = k);
          return be && ti(d, w), v;
        }
        for (A = n(d, A); !k.done; w++, k = y.next()) k = f(A, d, w, k.value, S), k !== null && (t && k.alternate !== null && A.delete(k.key === null ? w : k.key), g = i(k, g, w), T === null ? v = k : T.sibling = k, T = k);
        return t && A.forEach(function(M) {
          return e(d, M);
        }), be && ti(d, w), v;
      }
      function _(d, g, y, S) {
        if (typeof y == "object" && y !== null && y.type === Ki && y.key === null && (y = y.props.children), typeof y == "object" && y !== null) {
          switch (y.$$typeof) {
            case Ku:
              e: {
                for (var v = y.key, T = g; T !== null; ) {
                  if (T.key === v) {
                    if (v = y.type, v === Ki) {
                      if (T.tag === 7) {
                        r(d, T.sibling), g = o(T, y.props.children), g.return = d, d = g;
                        break e;
                      }
                    } else if (T.elementType === v || typeof v == "object" && v !== null && v.$$typeof === ao && f_(v) === T.type) {
                      r(d, T.sibling), g = o(T, y.props), g.ref = Ia(d, T, y), g.return = d, d = g;
                      break e;
                    }
                    r(d, T);
                    break;
                  } else e(d, T);
                  T = T.sibling;
                }
                y.type === Ki ? (g = ai(y.props.children, d.mode, S, y.key), g.return = d, d = g) : (S = Cc(y.type, y.key, y.props, null, d.mode, S), S.ref = Ia(d, g, y), S.return = d, d = S);
              }
              return s(d);
            case Qi:
              e: {
                for (T = y.key; g !== null; ) {
                  if (g.key === T) if (g.tag === 4 && g.stateNode.containerInfo === y.containerInfo && g.stateNode.implementation === y.implementation) {
                    r(d, g.sibling), g = o(g, y.children || []), g.return = d, d = g;
                    break e;
                  } else {
                    r(d, g);
                    break;
                  }
                  else e(d, g);
                  g = g.sibling;
                }
                g = am(y, d.mode, S), g.return = d, d = g;
              }
              return s(d);
            case ao:
              return T = y._init, _(d, g, T(y._payload), S);
          }
          if (za(y)) return m(d, g, y, S);
          if (Pa(y)) return x(d, g, y, S);
          hc(d, y);
        }
        return typeof y == "string" && y !== "" || typeof y == "number" ? (y = "" + y, g !== null && g.tag === 6 ? (r(d, g.sibling), g = o(g, y), g.return = d, d = g) : (r(d, g), g = sm(y, d.mode, S), g.return = d, d = g), s(d)) : r(d, g);
      }
      return _;
    }
    var xs = Iv(true), Lv = Iv(false), Bc = Co(null), jc = null, is = null, _d = null;
    function vd() {
      _d = is = jc = null;
    }
    function wd(t) {
      var e = Bc.current;
      Ee(Bc), t._currentValue = e;
    }
    function Im(t, e, r) {
      for (; t !== null; ) {
        var n = t.alternate;
        if ((t.childLanes & e) !== e ? (t.childLanes |= e, n !== null && (n.childLanes |= e)) : n !== null && (n.childLanes & e) !== e && (n.childLanes |= e), t === r) break;
        t = t.return;
      }
    }
    function hs(t, e) {
      jc = t, _d = is = null, t = t.dependencies, t !== null && t.firstContext !== null && (t.lanes & e && (Yt = true), t.firstContext = null);
    }
    function Ar(t) {
      var e = t._currentValue;
      if (_d !== t) if (t = { context: t, memoizedValue: e, next: null }, is === null) {
        if (jc === null) throw Error(F(308));
        is = t, jc.dependencies = { lanes: 0, firstContext: t };
      } else is = is.next = t;
      return e;
    }
    var oi = null;
    function Sd(t) {
      oi === null ? oi = [t] : oi.push(t);
    }
    function Bv(t, e, r, n) {
      var o = e.interleaved;
      return o === null ? (r.next = r, Sd(e)) : (r.next = o.next, o.next = r), e.interleaved = r, Bn(t, n);
    }
    function Bn(t, e) {
      t.lanes |= e;
      var r = t.alternate;
      for (r !== null && (r.lanes |= e), r = t, t = t.return; t !== null; ) t.childLanes |= e, r = t.alternate, r !== null && (r.childLanes |= e), r = t, t = t.return;
      return r.tag === 3 ? r.stateNode : null;
    }
    var lo = false;
    function Td(t) {
      t.updateQueue = { baseState: t.memoizedState, firstBaseUpdate: null, lastBaseUpdate: null, shared: { pending: null, interleaved: null, lanes: 0 }, effects: null };
    }
    function jv(t, e) {
      t = t.updateQueue, e.updateQueue === t && (e.updateQueue = { baseState: t.baseState, firstBaseUpdate: t.firstBaseUpdate, lastBaseUpdate: t.lastBaseUpdate, shared: t.shared, effects: t.effects });
    }
    function Fn(t, e) {
      return { eventTime: t, lane: e, tag: 0, payload: null, callback: null, next: null };
    }
    function yo(t, e, r) {
      var n = t.updateQueue;
      if (n === null) return null;
      if (n = n.shared, pe & 2) {
        var o = n.pending;
        return o === null ? e.next = e : (e.next = o.next, o.next = e), n.pending = e, Bn(t, r);
      }
      return o = n.interleaved, o === null ? (e.next = e, Sd(n)) : (e.next = o.next, o.next = e), n.interleaved = e, Bn(t, r);
    }
    function _c(t, e, r) {
      if (e = e.updateQueue, e !== null && (e = e.shared, (r & 4194240) !== 0)) {
        var n = e.lanes;
        n &= t.pendingLanes, r |= n, e.lanes = r, ld(t, r);
      }
    }
    function m_(t, e) {
      var r = t.updateQueue, n = t.alternate;
      if (n !== null && (n = n.updateQueue, r === n)) {
        var o = null, i = null;
        if (r = r.firstBaseUpdate, r !== null) {
          do {
            var s = { eventTime: r.eventTime, lane: r.lane, tag: r.tag, payload: r.payload, callback: r.callback, next: null };
            i === null ? o = i = s : i = i.next = s, r = r.next;
          } while (r !== null);
          i === null ? o = i = e : i = i.next = e;
        } else o = i = e;
        r = { baseState: n.baseState, firstBaseUpdate: o, lastBaseUpdate: i, shared: n.shared, effects: n.effects }, t.updateQueue = r;
        return;
      }
      t = r.lastBaseUpdate, t === null ? r.firstBaseUpdate = e : t.next = e, r.lastBaseUpdate = e;
    }
    function qc(t, e, r, n) {
      var o = t.updateQueue;
      lo = false;
      var i = o.firstBaseUpdate, s = o.lastBaseUpdate, a = o.shared.pending;
      if (a !== null) {
        o.shared.pending = null;
        var l = a, u = l.next;
        l.next = null, s === null ? i = u : s.next = u, s = l;
        var c = t.alternate;
        c !== null && (c = c.updateQueue, a = c.lastBaseUpdate, a !== s && (a === null ? c.firstBaseUpdate = u : a.next = u, c.lastBaseUpdate = l));
      }
      if (i !== null) {
        var p = o.baseState;
        s = 0, c = u = l = null, a = i;
        do {
          var h = a.lane, f = a.eventTime;
          if ((n & h) === h) {
            c !== null && (c = c.next = { eventTime: f, lane: 0, tag: a.tag, payload: a.payload, callback: a.callback, next: null });
            e: {
              var m = t, x = a;
              switch (h = e, f = r, x.tag) {
                case 1:
                  if (m = x.payload, typeof m == "function") {
                    p = m.call(f, p, h);
                    break e;
                  }
                  p = m;
                  break e;
                case 3:
                  m.flags = m.flags & -65537 | 128;
                case 0:
                  if (m = x.payload, h = typeof m == "function" ? m.call(f, p, h) : m, h == null) break e;
                  p = Ve({}, p, h);
                  break e;
                case 2:
                  lo = true;
              }
            }
            a.callback !== null && a.lane !== 0 && (t.flags |= 64, h = o.effects, h === null ? o.effects = [a] : h.push(a));
          } else f = { eventTime: f, lane: h, tag: a.tag, payload: a.payload, callback: a.callback, next: null }, c === null ? (u = c = f, l = p) : c = c.next = f, s |= h;
          if (a = a.next, a === null) {
            if (a = o.shared.pending, a === null) break;
            h = a, a = h.next, h.next = null, o.lastBaseUpdate = h, o.shared.pending = null;
          }
        } while (true);
        if (c === null && (l = p), o.baseState = l, o.firstBaseUpdate = u, o.lastBaseUpdate = c, e = o.shared.interleaved, e !== null) {
          o = e;
          do
            s |= o.lane, o = o.next;
          while (o !== e);
        } else i === null && (o.shared.lanes = 0);
        pi |= s, t.lanes = s, t.memoizedState = p;
      }
    }
    function d_(t, e, r) {
      if (t = e.effects, e.effects = null, t !== null) for (e = 0; e < t.length; e++) {
        var n = t[e], o = n.callback;
        if (o !== null) {
          if (n.callback = null, n = r, typeof o != "function") throw Error(F(191, o));
          o.call(n);
        }
      }
    }
    var vl = {}, dn = Co(vl), pl = Co(vl), hl = Co(vl);
    function ii(t) {
      if (t === vl) throw Error(F(174));
      return t;
    }
    function Ad(t, e) {
      switch (Ae(hl, e), Ae(pl, t), Ae(dn, vl), t = e.nodeType, t) {
        case 9:
        case 11:
          e = (e = e.documentElement) ? e.namespaceURI : xm(null, "");
          break;
        default:
          t = t === 8 ? e.parentNode : e, e = t.namespaceURI || null, t = t.tagName, e = xm(e, t);
      }
      Ee(dn), Ae(dn, e);
    }
    function ys() {
      Ee(dn), Ee(pl), Ee(hl);
    }
    function qv(t) {
      ii(hl.current);
      var e = ii(dn.current), r = xm(e, t.type);
      e !== r && (Ae(pl, t), Ae(dn, r));
    }
    function Cd(t) {
      pl.current === t && (Ee(dn), Ee(pl));
    }
    var Pe = Co(0);
    function zc(t) {
      for (var e = t; e !== null; ) {
        if (e.tag === 13) {
          var r = e.memoizedState;
          if (r !== null && (r = r.dehydrated, r === null || r.data === "$?" || r.data === "$!")) return e;
        } else if (e.tag === 19 && e.memoizedProps.revealOrder !== void 0) {
          if (e.flags & 128) return e;
        } else if (e.child !== null) {
          e.child.return = e, e = e.child;
          continue;
        }
        if (e === t) break;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t) return null;
          e = e.return;
        }
        e.sibling.return = e.return, e = e.sibling;
      }
      return null;
    }
    var em = [];
    function kd() {
      for (var t = 0; t < em.length; t++) em[t]._workInProgressVersionPrimary = null;
      em.length = 0;
    }
    var vc = qn.ReactCurrentDispatcher, tm = qn.ReactCurrentBatchConfig, ci = 0, Re = null, lt = null, gt = null, Wc = false, Qa = false, fl = 0, bN = 0;
    function kt() {
      throw Error(F(321));
    }
    function Ed(t, e) {
      if (e === null) return false;
      for (var r = 0; r < e.length && r < t.length; r++) if (!$r(t[r], e[r])) return false;
      return true;
    }
    function bd(t, e, r, n, o, i) {
      if (ci = i, Re = e, e.memoizedState = null, e.updateQueue = null, e.lanes = 0, vc.current = t === null || t.memoizedState === null ? MN : PN, t = r(n, o), Qa) {
        i = 0;
        do {
          if (Qa = false, fl = 0, 25 <= i) throw Error(F(301));
          i += 1, gt = lt = null, e.updateQueue = null, vc.current = RN, t = r(n, o);
        } while (Qa);
      }
      if (vc.current = Uc, e = lt !== null && lt.next !== null, ci = 0, gt = lt = Re = null, Wc = false, e) throw Error(F(300));
      return t;
    }
    function Nd() {
      var t = fl !== 0;
      return fl = 0, t;
    }
    function hn() {
      var t = { memoizedState: null, baseState: null, baseQueue: null, queue: null, next: null };
      return gt === null ? Re.memoizedState = gt = t : gt = gt.next = t, gt;
    }
    function Cr() {
      if (lt === null) {
        var t = Re.alternate;
        t = t !== null ? t.memoizedState : null;
      } else t = lt.next;
      var e = gt === null ? Re.memoizedState : gt.next;
      if (e !== null) gt = e, lt = t;
      else {
        if (t === null) throw Error(F(310));
        lt = t, t = { memoizedState: lt.memoizedState, baseState: lt.baseState, baseQueue: lt.baseQueue, queue: lt.queue, next: null }, gt === null ? Re.memoizedState = gt = t : gt = gt.next = t;
      }
      return gt;
    }
    function ml(t, e) {
      return typeof e == "function" ? e(t) : e;
    }
    function rm(t) {
      var e = Cr(), r = e.queue;
      if (r === null) throw Error(F(311));
      r.lastRenderedReducer = t;
      var n = lt, o = n.baseQueue, i = r.pending;
      if (i !== null) {
        if (o !== null) {
          var s = o.next;
          o.next = i.next, i.next = s;
        }
        n.baseQueue = o = i, r.pending = null;
      }
      if (o !== null) {
        i = o.next, n = n.baseState;
        var a = s = null, l = null, u = i;
        do {
          var c = u.lane;
          if ((ci & c) === c) l !== null && (l = l.next = { lane: 0, action: u.action, hasEagerState: u.hasEagerState, eagerState: u.eagerState, next: null }), n = u.hasEagerState ? u.eagerState : t(n, u.action);
          else {
            var p = { lane: c, action: u.action, hasEagerState: u.hasEagerState, eagerState: u.eagerState, next: null };
            l === null ? (a = l = p, s = n) : l = l.next = p, Re.lanes |= c, pi |= c;
          }
          u = u.next;
        } while (u !== null && u !== i);
        l === null ? s = n : l.next = a, $r(n, e.memoizedState) || (Yt = true), e.memoizedState = n, e.baseState = s, e.baseQueue = l, r.lastRenderedState = n;
      }
      if (t = r.interleaved, t !== null) {
        o = t;
        do
          i = o.lane, Re.lanes |= i, pi |= i, o = o.next;
        while (o !== t);
      } else o === null && (r.lanes = 0);
      return [e.memoizedState, r.dispatch];
    }
    function nm(t) {
      var e = Cr(), r = e.queue;
      if (r === null) throw Error(F(311));
      r.lastRenderedReducer = t;
      var n = r.dispatch, o = r.pending, i = e.memoizedState;
      if (o !== null) {
        r.pending = null;
        var s = o = o.next;
        do
          i = t(i, s.action), s = s.next;
        while (s !== o);
        $r(i, e.memoizedState) || (Yt = true), e.memoizedState = i, e.baseQueue === null && (e.baseState = i), r.lastRenderedState = i;
      }
      return [i, n];
    }
    function zv() {
    }
    function Wv(t, e) {
      var r = Re, n = Cr(), o = e(), i = !$r(n.memoizedState, o);
      if (i && (n.memoizedState = o, Yt = true), n = n.queue, Od(Hv.bind(null, r, n, t), [t]), n.getSnapshot !== e || i || gt !== null && gt.memoizedState.tag & 1) {
        if (r.flags |= 2048, dl(9, Gv.bind(null, r, n, o, e), void 0, null), xt === null) throw Error(F(349));
        ci & 30 || Uv(r, e, o);
      }
      return o;
    }
    function Uv(t, e, r) {
      t.flags |= 16384, t = { getSnapshot: e, value: r }, e = Re.updateQueue, e === null ? (e = { lastEffect: null, stores: null }, Re.updateQueue = e, e.stores = [t]) : (r = e.stores, r === null ? e.stores = [t] : r.push(t));
    }
    function Gv(t, e, r, n) {
      e.value = r, e.getSnapshot = n, $v(e) && Xv(t);
    }
    function Hv(t, e, r) {
      return r(function() {
        $v(e) && Xv(t);
      });
    }
    function $v(t) {
      var e = t.getSnapshot;
      t = t.value;
      try {
        var r = e();
        return !$r(t, r);
      } catch {
        return true;
      }
    }
    function Xv(t) {
      var e = Bn(t, 1);
      e !== null && Hr(e, t, 1, -1);
    }
    function g_(t) {
      var e = hn();
      return typeof t == "function" && (t = t()), e.memoizedState = e.baseState = t, t = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: ml, lastRenderedState: t }, e.queue = t, t = t.dispatch = DN.bind(null, Re, t), [e.memoizedState, t];
    }
    function dl(t, e, r, n) {
      return t = { tag: t, create: e, destroy: r, deps: n, next: null }, e = Re.updateQueue, e === null ? (e = { lastEffect: null, stores: null }, Re.updateQueue = e, e.lastEffect = t.next = t) : (r = e.lastEffect, r === null ? e.lastEffect = t.next = t : (n = r.next, r.next = t, t.next = n, e.lastEffect = t)), t;
    }
    function Yv() {
      return Cr().memoizedState;
    }
    function wc(t, e, r, n) {
      var o = hn();
      Re.flags |= t, o.memoizedState = dl(1 | e, r, void 0, n === void 0 ? null : n);
    }
    function rp(t, e, r, n) {
      var o = Cr();
      n = n === void 0 ? null : n;
      var i = void 0;
      if (lt !== null) {
        var s = lt.memoizedState;
        if (i = s.destroy, n !== null && Ed(n, s.deps)) {
          o.memoizedState = dl(e, r, i, n);
          return;
        }
      }
      Re.flags |= t, o.memoizedState = dl(1 | e, r, i, n);
    }
    function x_(t, e) {
      return wc(8390656, 8, t, e);
    }
    function Od(t, e) {
      return rp(2048, 8, t, e);
    }
    function Qv(t, e) {
      return rp(4, 2, t, e);
    }
    function Kv(t, e) {
      return rp(4, 4, t, e);
    }
    function Zv(t, e) {
      if (typeof e == "function") return t = t(), e(t), function() {
        e(null);
      };
      if (e != null) return t = t(), e.current = t, function() {
        e.current = null;
      };
    }
    function Jv(t, e, r) {
      return r = r != null ? r.concat([t]) : null, rp(4, 4, Zv.bind(null, e, t), r);
    }
    function Dd() {
    }
    function e0(t, e) {
      var r = Cr();
      e = e === void 0 ? null : e;
      var n = r.memoizedState;
      return n !== null && e !== null && Ed(e, n[1]) ? n[0] : (r.memoizedState = [t, e], t);
    }
    function t0(t, e) {
      var r = Cr();
      e = e === void 0 ? null : e;
      var n = r.memoizedState;
      return n !== null && e !== null && Ed(e, n[1]) ? n[0] : (t = t(), r.memoizedState = [t, e], t);
    }
    function r0(t, e, r) {
      return ci & 21 ? ($r(r, e) || (r = av(), Re.lanes |= r, pi |= r, t.baseState = true), e) : (t.baseState && (t.baseState = false, Yt = true), t.memoizedState = r);
    }
    function NN(t, e) {
      var r = _e;
      _e = r !== 0 && 4 > r ? r : 4, t(true);
      var n = tm.transition;
      tm.transition = {};
      try {
        t(false), e();
      } finally {
        _e = r, tm.transition = n;
      }
    }
    function n0() {
      return Cr().memoizedState;
    }
    function ON(t, e, r) {
      var n = vo(t);
      if (r = { lane: n, action: r, hasEagerState: false, eagerState: null, next: null }, o0(t)) i0(e, r);
      else if (r = Bv(t, e, r, n), r !== null) {
        var o = It();
        Hr(r, t, n, o), s0(r, e, n);
      }
    }
    function DN(t, e, r) {
      var n = vo(t), o = { lane: n, action: r, hasEagerState: false, eagerState: null, next: null };
      if (o0(t)) i0(e, o);
      else {
        var i = t.alternate;
        if (t.lanes === 0 && (i === null || i.lanes === 0) && (i = e.lastRenderedReducer, i !== null)) try {
          var s = e.lastRenderedState, a = i(s, r);
          if (o.hasEagerState = true, o.eagerState = a, $r(a, s)) {
            var l = e.interleaved;
            l === null ? (o.next = o, Sd(e)) : (o.next = l.next, l.next = o), e.interleaved = o;
            return;
          }
        } catch {
        } finally {
        }
        r = Bv(t, e, o, n), r !== null && (o = It(), Hr(r, t, n, o), s0(r, e, n));
      }
    }
    function o0(t) {
      var e = t.alternate;
      return t === Re || e !== null && e === Re;
    }
    function i0(t, e) {
      Qa = Wc = true;
      var r = t.pending;
      r === null ? e.next = e : (e.next = r.next, r.next = e), t.pending = e;
    }
    function s0(t, e, r) {
      if (r & 4194240) {
        var n = e.lanes;
        n &= t.pendingLanes, r |= n, e.lanes = r, ld(t, r);
      }
    }
    var Uc = { readContext: Ar, useCallback: kt, useContext: kt, useEffect: kt, useImperativeHandle: kt, useInsertionEffect: kt, useLayoutEffect: kt, useMemo: kt, useReducer: kt, useRef: kt, useState: kt, useDebugValue: kt, useDeferredValue: kt, useTransition: kt, useMutableSource: kt, useSyncExternalStore: kt, useId: kt, unstable_isNewReconciler: false }, MN = { readContext: Ar, useCallback: function(t, e) {
      return hn().memoizedState = [t, e === void 0 ? null : e], t;
    }, useContext: Ar, useEffect: x_, useImperativeHandle: function(t, e, r) {
      return r = r != null ? r.concat([t]) : null, wc(4194308, 4, Zv.bind(null, e, t), r);
    }, useLayoutEffect: function(t, e) {
      return wc(4194308, 4, t, e);
    }, useInsertionEffect: function(t, e) {
      return wc(4, 2, t, e);
    }, useMemo: function(t, e) {
      var r = hn();
      return e = e === void 0 ? null : e, t = t(), r.memoizedState = [t, e], t;
    }, useReducer: function(t, e, r) {
      var n = hn();
      return e = r !== void 0 ? r(e) : e, n.memoizedState = n.baseState = e, t = { pending: null, interleaved: null, lanes: 0, dispatch: null, lastRenderedReducer: t, lastRenderedState: e }, n.queue = t, t = t.dispatch = ON.bind(null, Re, t), [n.memoizedState, t];
    }, useRef: function(t) {
      var e = hn();
      return t = { current: t }, e.memoizedState = t;
    }, useState: g_, useDebugValue: Dd, useDeferredValue: function(t) {
      return hn().memoizedState = t;
    }, useTransition: function() {
      var t = g_(false), e = t[0];
      return t = NN.bind(null, t[1]), hn().memoizedState = t, [e, t];
    }, useMutableSource: function() {
    }, useSyncExternalStore: function(t, e, r) {
      var n = Re, o = hn();
      if (be) {
        if (r === void 0) throw Error(F(407));
        r = r();
      } else {
        if (r = e(), xt === null) throw Error(F(349));
        ci & 30 || Uv(n, e, r);
      }
      o.memoizedState = r;
      var i = { value: r, getSnapshot: e };
      return o.queue = i, x_(Hv.bind(null, n, i, t), [t]), n.flags |= 2048, dl(9, Gv.bind(null, n, i, r, e), void 0, null), r;
    }, useId: function() {
      var t = hn(), e = xt.identifierPrefix;
      if (be) {
        var r = Vn, n = Rn;
        r = (n & ~(1 << 32 - Gr(n) - 1)).toString(32) + r, e = ":" + e + "R" + r, r = fl++, 0 < r && (e += "H" + r.toString(32)), e += ":";
      } else r = bN++, e = ":" + e + "r" + r.toString(32) + ":";
      return t.memoizedState = e;
    }, unstable_isNewReconciler: false }, PN = { readContext: Ar, useCallback: e0, useContext: Ar, useEffect: Od, useImperativeHandle: Jv, useInsertionEffect: Qv, useLayoutEffect: Kv, useMemo: t0, useReducer: rm, useRef: Yv, useState: function() {
      return rm(ml);
    }, useDebugValue: Dd, useDeferredValue: function(t) {
      var e = Cr();
      return r0(e, lt.memoizedState, t);
    }, useTransition: function() {
      var t = rm(ml)[0], e = Cr().memoizedState;
      return [t, e];
    }, useMutableSource: zv, useSyncExternalStore: Wv, useId: n0, unstable_isNewReconciler: false }, RN = { readContext: Ar, useCallback: e0, useContext: Ar, useEffect: Od, useImperativeHandle: Jv, useInsertionEffect: Qv, useLayoutEffect: Kv, useMemo: t0, useReducer: nm, useRef: Yv, useState: function() {
      return nm(ml);
    }, useDebugValue: Dd, useDeferredValue: function(t) {
      var e = Cr();
      return lt === null ? e.memoizedState = t : r0(e, lt.memoizedState, t);
    }, useTransition: function() {
      var t = nm(ml)[0], e = Cr().memoizedState;
      return [t, e];
    }, useMutableSource: zv, useSyncExternalStore: Wv, useId: n0, unstable_isNewReconciler: false };
    function zr(t, e) {
      if (t && t.defaultProps) {
        e = Ve({}, e), t = t.defaultProps;
        for (var r in t) e[r] === void 0 && (e[r] = t[r]);
        return e;
      }
      return e;
    }
    function Lm(t, e, r, n) {
      e = t.memoizedState, r = r(n, e), r = r == null ? e : Ve({}, e, r), t.memoizedState = r, t.lanes === 0 && (t.updateQueue.baseState = r);
    }
    var np = { isMounted: function(t) {
      return (t = t._reactInternals) ? mi(t) === t : false;
    }, enqueueSetState: function(t, e, r) {
      t = t._reactInternals;
      var n = It(), o = vo(t), i = Fn(n, o);
      i.payload = e, r != null && (i.callback = r), e = yo(t, i, o), e !== null && (Hr(e, t, o, n), _c(e, t, o));
    }, enqueueReplaceState: function(t, e, r) {
      t = t._reactInternals;
      var n = It(), o = vo(t), i = Fn(n, o);
      i.tag = 1, i.payload = e, r != null && (i.callback = r), e = yo(t, i, o), e !== null && (Hr(e, t, o, n), _c(e, t, o));
    }, enqueueForceUpdate: function(t, e) {
      t = t._reactInternals;
      var r = It(), n = vo(t), o = Fn(r, n);
      o.tag = 2, e != null && (o.callback = e), e = yo(t, o, n), e !== null && (Hr(e, t, n, r), _c(e, t, n));
    } };
    function y_(t, e, r, n, o, i, s) {
      return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(n, i, s) : e.prototype && e.prototype.isPureReactComponent ? !al(r, n) || !al(o, i) : true;
    }
    function a0(t, e, r) {
      var n = false, o = To, i = e.contextType;
      return typeof i == "object" && i !== null ? i = Ar(i) : (o = Kt(e) ? li : Nt.current, n = e.contextTypes, i = (n = n != null) ? ds(t, o) : To), e = new e(r, i), t.memoizedState = e.state !== null && e.state !== void 0 ? e.state : null, e.updater = np, t.stateNode = e, e._reactInternals = t, n && (t = t.stateNode, t.__reactInternalMemoizedUnmaskedChildContext = o, t.__reactInternalMemoizedMaskedChildContext = i), e;
    }
    function __(t, e, r, n) {
      t = e.state, typeof e.componentWillReceiveProps == "function" && e.componentWillReceiveProps(r, n), typeof e.UNSAFE_componentWillReceiveProps == "function" && e.UNSAFE_componentWillReceiveProps(r, n), e.state !== t && np.enqueueReplaceState(e, e.state, null);
    }
    function Bm(t, e, r, n) {
      var o = t.stateNode;
      o.props = r, o.state = t.memoizedState, o.refs = {}, Td(t);
      var i = e.contextType;
      typeof i == "object" && i !== null ? o.context = Ar(i) : (i = Kt(e) ? li : Nt.current, o.context = ds(t, i)), o.state = t.memoizedState, i = e.getDerivedStateFromProps, typeof i == "function" && (Lm(t, e, i, r), o.state = t.memoizedState), typeof e.getDerivedStateFromProps == "function" || typeof o.getSnapshotBeforeUpdate == "function" || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (e = o.state, typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount(), e !== o.state && np.enqueueReplaceState(o, o.state, null), qc(t, r, o, n), o.state = t.memoizedState), typeof o.componentDidMount == "function" && (t.flags |= 4194308);
    }
    function _s(t, e) {
      try {
        var r = "", n = e;
        do
          r += cb(n), n = n.return;
        while (n);
        var o = r;
      } catch (i) {
        o = `
Error generating stack: ` + i.message + `
` + i.stack;
      }
      return { value: t, source: e, stack: o, digest: null };
    }
    function om(t, e, r) {
      return { value: t, source: null, stack: r ?? null, digest: e ?? null };
    }
    function jm(t, e) {
      try {
        console.error(e.value);
      } catch (r) {
        setTimeout(function() {
          throw r;
        });
      }
    }
    var VN = typeof WeakMap == "function" ? WeakMap : Map;
    function l0(t, e, r) {
      r = Fn(-1, r), r.tag = 3, r.payload = { element: null };
      var n = e.value;
      return r.callback = function() {
        Hc || (Hc = true, Qm = n), jm(t, e);
      }, r;
    }
    function u0(t, e, r) {
      r = Fn(-1, r), r.tag = 3;
      var n = t.type.getDerivedStateFromError;
      if (typeof n == "function") {
        var o = e.value;
        r.payload = function() {
          return n(o);
        }, r.callback = function() {
          jm(t, e);
        };
      }
      var i = t.stateNode;
      return i !== null && typeof i.componentDidCatch == "function" && (r.callback = function() {
        jm(t, e), typeof n != "function" && (_o === null ? _o = /* @__PURE__ */ new Set([this]) : _o.add(this));
        var s = e.stack;
        this.componentDidCatch(e.value, { componentStack: s !== null ? s : "" });
      }), r;
    }
    function v_(t, e, r) {
      var n = t.pingCache;
      if (n === null) {
        n = t.pingCache = new VN();
        var o = /* @__PURE__ */ new Set();
        n.set(e, o);
      } else o = n.get(e), o === void 0 && (o = /* @__PURE__ */ new Set(), n.set(e, o));
      o.has(r) || (o.add(r), t = YN.bind(null, t, e, r), e.then(t, t));
    }
    function w_(t) {
      do {
        var e;
        if ((e = t.tag === 13) && (e = t.memoizedState, e = e !== null ? e.dehydrated !== null : true), e) return t;
        t = t.return;
      } while (t !== null);
      return null;
    }
    function S_(t, e, r, n, o) {
      return t.mode & 1 ? (t.flags |= 65536, t.lanes = o, t) : (t === e ? t.flags |= 65536 : (t.flags |= 128, r.flags |= 131072, r.flags &= -52805, r.tag === 1 && (r.alternate === null ? r.tag = 17 : (e = Fn(-1, 1), e.tag = 2, yo(r, e, 1))), r.lanes |= 1), t);
    }
    var FN = qn.ReactCurrentOwner, Yt = false;
    function Ft(t, e, r, n) {
      e.child = t === null ? Lv(e, null, r, n) : xs(e, t.child, r, n);
    }
    function T_(t, e, r, n, o) {
      r = r.render;
      var i = e.ref;
      return hs(e, o), n = bd(t, e, r, n, i, o), r = Nd(), t !== null && !Yt ? (e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~o, jn(t, e, o)) : (be && r && gd(e), e.flags |= 1, Ft(t, e, n, o), e.child);
    }
    function A_(t, e, r, n, o) {
      if (t === null) {
        var i = r.type;
        return typeof i == "function" && !Bd(i) && i.defaultProps === void 0 && r.compare === null && r.defaultProps === void 0 ? (e.tag = 15, e.type = i, c0(t, e, i, n, o)) : (t = Cc(r.type, null, n, e, e.mode, o), t.ref = e.ref, t.return = e, e.child = t);
      }
      if (i = t.child, !(t.lanes & o)) {
        var s = i.memoizedProps;
        if (r = r.compare, r = r !== null ? r : al, r(s, n) && t.ref === e.ref) return jn(t, e, o);
      }
      return e.flags |= 1, t = wo(i, n), t.ref = e.ref, t.return = e, e.child = t;
    }
    function c0(t, e, r, n, o) {
      if (t !== null) {
        var i = t.memoizedProps;
        if (al(i, n) && t.ref === e.ref) if (Yt = false, e.pendingProps = n = i, (t.lanes & o) !== 0) t.flags & 131072 && (Yt = true);
        else return e.lanes = t.lanes, jn(t, e, o);
      }
      return qm(t, e, r, n, o);
    }
    function p0(t, e, r) {
      var n = e.pendingProps, o = n.children, i = t !== null ? t.memoizedState : null;
      if (n.mode === "hidden") if (!(e.mode & 1)) e.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, Ae(as, or), or |= r;
      else {
        if (!(r & 1073741824)) return t = i !== null ? i.baseLanes | r : r, e.lanes = e.childLanes = 1073741824, e.memoizedState = { baseLanes: t, cachePool: null, transitions: null }, e.updateQueue = null, Ae(as, or), or |= t, null;
        e.memoizedState = { baseLanes: 0, cachePool: null, transitions: null }, n = i !== null ? i.baseLanes : r, Ae(as, or), or |= n;
      }
      else i !== null ? (n = i.baseLanes | r, e.memoizedState = null) : n = r, Ae(as, or), or |= n;
      return Ft(t, e, o, r), e.child;
    }
    function h0(t, e) {
      var r = e.ref;
      (t === null && r !== null || t !== null && t.ref !== r) && (e.flags |= 512, e.flags |= 2097152);
    }
    function qm(t, e, r, n, o) {
      var i = Kt(r) ? li : Nt.current;
      return i = ds(e, i), hs(e, o), r = bd(t, e, r, n, i, o), n = Nd(), t !== null && !Yt ? (e.updateQueue = t.updateQueue, e.flags &= -2053, t.lanes &= ~o, jn(t, e, o)) : (be && n && gd(e), e.flags |= 1, Ft(t, e, r, o), e.child);
    }
    function C_(t, e, r, n, o) {
      if (Kt(r)) {
        var i = true;
        Fc(e);
      } else i = false;
      if (hs(e, o), e.stateNode === null) Sc(t, e), a0(e, r, n), Bm(e, r, n, o), n = true;
      else if (t === null) {
        var s = e.stateNode, a = e.memoizedProps;
        s.props = a;
        var l = s.context, u = r.contextType;
        typeof u == "object" && u !== null ? u = Ar(u) : (u = Kt(r) ? li : Nt.current, u = ds(e, u));
        var c = r.getDerivedStateFromProps, p = typeof c == "function" || typeof s.getSnapshotBeforeUpdate == "function";
        p || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (a !== n || l !== u) && __(e, s, n, u), lo = false;
        var h = e.memoizedState;
        s.state = h, qc(e, n, s, o), l = e.memoizedState, a !== n || h !== l || Qt.current || lo ? (typeof c == "function" && (Lm(e, r, c, n), l = e.memoizedState), (a = lo || y_(e, r, a, n, h, l, u)) ? (p || typeof s.UNSAFE_componentWillMount != "function" && typeof s.componentWillMount != "function" || (typeof s.componentWillMount == "function" && s.componentWillMount(), typeof s.UNSAFE_componentWillMount == "function" && s.UNSAFE_componentWillMount()), typeof s.componentDidMount == "function" && (e.flags |= 4194308)) : (typeof s.componentDidMount == "function" && (e.flags |= 4194308), e.memoizedProps = n, e.memoizedState = l), s.props = n, s.state = l, s.context = u, n = a) : (typeof s.componentDidMount == "function" && (e.flags |= 4194308), n = false);
      } else {
        s = e.stateNode, jv(t, e), a = e.memoizedProps, u = e.type === e.elementType ? a : zr(e.type, a), s.props = u, p = e.pendingProps, h = s.context, l = r.contextType, typeof l == "object" && l !== null ? l = Ar(l) : (l = Kt(r) ? li : Nt.current, l = ds(e, l));
        var f = r.getDerivedStateFromProps;
        (c = typeof f == "function" || typeof s.getSnapshotBeforeUpdate == "function") || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (a !== p || h !== l) && __(e, s, n, l), lo = false, h = e.memoizedState, s.state = h, qc(e, n, s, o);
        var m = e.memoizedState;
        a !== p || h !== m || Qt.current || lo ? (typeof f == "function" && (Lm(e, r, f, n), m = e.memoizedState), (u = lo || y_(e, r, u, n, h, m, l) || false) ? (c || typeof s.UNSAFE_componentWillUpdate != "function" && typeof s.componentWillUpdate != "function" || (typeof s.componentWillUpdate == "function" && s.componentWillUpdate(n, m, l), typeof s.UNSAFE_componentWillUpdate == "function" && s.UNSAFE_componentWillUpdate(n, m, l)), typeof s.componentDidUpdate == "function" && (e.flags |= 4), typeof s.getSnapshotBeforeUpdate == "function" && (e.flags |= 1024)) : (typeof s.componentDidUpdate != "function" || a === t.memoizedProps && h === t.memoizedState || (e.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || a === t.memoizedProps && h === t.memoizedState || (e.flags |= 1024), e.memoizedProps = n, e.memoizedState = m), s.props = n, s.state = m, s.context = l, n = u) : (typeof s.componentDidUpdate != "function" || a === t.memoizedProps && h === t.memoizedState || (e.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || a === t.memoizedProps && h === t.memoizedState || (e.flags |= 1024), n = false);
      }
      return zm(t, e, r, n, i, o);
    }
    function zm(t, e, r, n, o, i) {
      h0(t, e);
      var s = (e.flags & 128) !== 0;
      if (!n && !s) return o && c_(e, r, false), jn(t, e, i);
      n = e.stateNode, FN.current = e;
      var a = s && typeof r.getDerivedStateFromError != "function" ? null : n.render();
      return e.flags |= 1, t !== null && s ? (e.child = xs(e, t.child, null, i), e.child = xs(e, null, a, i)) : Ft(t, e, a, i), e.memoizedState = n.state, o && c_(e, r, true), e.child;
    }
    function f0(t) {
      var e = t.stateNode;
      e.pendingContext ? u_(t, e.pendingContext, e.pendingContext !== e.context) : e.context && u_(t, e.context, false), Ad(t, e.containerInfo);
    }
    function k_(t, e, r, n, o) {
      return gs(), yd(o), e.flags |= 256, Ft(t, e, r, n), e.child;
    }
    var Wm = { dehydrated: null, treeContext: null, retryLane: 0 };
    function Um(t) {
      return { baseLanes: t, cachePool: null, transitions: null };
    }
    function m0(t, e, r) {
      var n = e.pendingProps, o = Pe.current, i = false, s = (e.flags & 128) !== 0, a;
      if ((a = s) || (a = t !== null && t.memoizedState === null ? false : (o & 2) !== 0), a ? (i = true, e.flags &= -129) : (t === null || t.memoizedState !== null) && (o |= 1), Ae(Pe, o & 1), t === null) return Fm(e), t = e.memoizedState, t !== null && (t = t.dehydrated, t !== null) ? (e.mode & 1 ? t.data === "$!" ? e.lanes = 8 : e.lanes = 1073741824 : e.lanes = 1, null) : (s = n.children, t = n.fallback, i ? (n = e.mode, i = e.child, s = { mode: "hidden", children: s }, !(n & 1) && i !== null ? (i.childLanes = 0, i.pendingProps = s) : i = sp(s, n, 0, null), t = ai(t, n, r, null), i.return = e, t.return = e, i.sibling = t, e.child = i, e.child.memoizedState = Um(r), e.memoizedState = Wm, t) : Md(e, s));
      if (o = t.memoizedState, o !== null && (a = o.dehydrated, a !== null)) return IN(t, e, s, n, a, o, r);
      if (i) {
        i = n.fallback, s = e.mode, o = t.child, a = o.sibling;
        var l = { mode: "hidden", children: n.children };
        return !(s & 1) && e.child !== o ? (n = e.child, n.childLanes = 0, n.pendingProps = l, e.deletions = null) : (n = wo(o, l), n.subtreeFlags = o.subtreeFlags & 14680064), a !== null ? i = wo(a, i) : (i = ai(i, s, r, null), i.flags |= 2), i.return = e, n.return = e, n.sibling = i, e.child = n, n = i, i = e.child, s = t.child.memoizedState, s = s === null ? Um(r) : { baseLanes: s.baseLanes | r, cachePool: null, transitions: s.transitions }, i.memoizedState = s, i.childLanes = t.childLanes & ~r, e.memoizedState = Wm, n;
      }
      return i = t.child, t = i.sibling, n = wo(i, { mode: "visible", children: n.children }), !(e.mode & 1) && (n.lanes = r), n.return = e, n.sibling = null, t !== null && (r = e.deletions, r === null ? (e.deletions = [t], e.flags |= 16) : r.push(t)), e.child = n, e.memoizedState = null, n;
    }
    function Md(t, e) {
      return e = sp({ mode: "visible", children: e }, t.mode, 0, null), e.return = t, t.child = e;
    }
    function fc(t, e, r, n) {
      return n !== null && yd(n), xs(e, t.child, null, r), t = Md(e, e.pendingProps.children), t.flags |= 2, e.memoizedState = null, t;
    }
    function IN(t, e, r, n, o, i, s) {
      if (r) return e.flags & 256 ? (e.flags &= -257, n = om(Error(F(422))), fc(t, e, s, n)) : e.memoizedState !== null ? (e.child = t.child, e.flags |= 128, null) : (i = n.fallback, o = e.mode, n = sp({ mode: "visible", children: n.children }, o, 0, null), i = ai(i, o, s, null), i.flags |= 2, n.return = e, i.return = e, n.sibling = i, e.child = n, e.mode & 1 && xs(e, t.child, null, s), e.child.memoizedState = Um(s), e.memoizedState = Wm, i);
      if (!(e.mode & 1)) return fc(t, e, s, null);
      if (o.data === "$!") {
        if (n = o.nextSibling && o.nextSibling.dataset, n) var a = n.dgst;
        return n = a, i = Error(F(419)), n = om(i, n, void 0), fc(t, e, s, n);
      }
      if (a = (s & t.childLanes) !== 0, Yt || a) {
        if (n = xt, n !== null) {
          switch (s & -s) {
            case 4:
              o = 2;
              break;
            case 16:
              o = 8;
              break;
            case 64:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
            case 67108864:
              o = 32;
              break;
            case 536870912:
              o = 268435456;
              break;
            default:
              o = 0;
          }
          o = o & (n.suspendedLanes | s) ? 0 : o, o !== 0 && o !== i.retryLane && (i.retryLane = o, Bn(t, o), Hr(n, t, o, -1));
        }
        return Ld(), n = om(Error(F(421))), fc(t, e, s, n);
      }
      return o.data === "$?" ? (e.flags |= 128, e.child = t.child, e = QN.bind(null, t), o._reactRetry = e, null) : (t = i.treeContext, ir = xo(o.nextSibling), sr = e, be = true, Ur = null, t !== null && (vr[wr++] = Rn, vr[wr++] = Vn, vr[wr++] = ui, Rn = t.id, Vn = t.overflow, ui = e), e = Md(e, n.children), e.flags |= 4096, e);
    }
    function E_(t, e, r) {
      t.lanes |= e;
      var n = t.alternate;
      n !== null && (n.lanes |= e), Im(t.return, e, r);
    }
    function im(t, e, r, n, o) {
      var i = t.memoizedState;
      i === null ? t.memoizedState = { isBackwards: e, rendering: null, renderingStartTime: 0, last: n, tail: r, tailMode: o } : (i.isBackwards = e, i.rendering = null, i.renderingStartTime = 0, i.last = n, i.tail = r, i.tailMode = o);
    }
    function d0(t, e, r) {
      var n = e.pendingProps, o = n.revealOrder, i = n.tail;
      if (Ft(t, e, n.children, r), n = Pe.current, n & 2) n = n & 1 | 2, e.flags |= 128;
      else {
        if (t !== null && t.flags & 128) e: for (t = e.child; t !== null; ) {
          if (t.tag === 13) t.memoizedState !== null && E_(t, r, e);
          else if (t.tag === 19) E_(t, r, e);
          else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue;
          }
          if (t === e) break e;
          for (; t.sibling === null; ) {
            if (t.return === null || t.return === e) break e;
            t = t.return;
          }
          t.sibling.return = t.return, t = t.sibling;
        }
        n &= 1;
      }
      if (Ae(Pe, n), !(e.mode & 1)) e.memoizedState = null;
      else switch (o) {
        case "forwards":
          for (r = e.child, o = null; r !== null; ) t = r.alternate, t !== null && zc(t) === null && (o = r), r = r.sibling;
          r = o, r === null ? (o = e.child, e.child = null) : (o = r.sibling, r.sibling = null), im(e, false, o, r, i);
          break;
        case "backwards":
          for (r = null, o = e.child, e.child = null; o !== null; ) {
            if (t = o.alternate, t !== null && zc(t) === null) {
              e.child = o;
              break;
            }
            t = o.sibling, o.sibling = r, r = o, o = t;
          }
          im(e, true, r, null, i);
          break;
        case "together":
          im(e, false, null, null, void 0);
          break;
        default:
          e.memoizedState = null;
      }
      return e.child;
    }
    function Sc(t, e) {
      !(e.mode & 1) && t !== null && (t.alternate = null, e.alternate = null, e.flags |= 2);
    }
    function jn(t, e, r) {
      if (t !== null && (e.dependencies = t.dependencies), pi |= e.lanes, !(r & e.childLanes)) return null;
      if (t !== null && e.child !== t.child) throw Error(F(153));
      if (e.child !== null) {
        for (t = e.child, r = wo(t, t.pendingProps), e.child = r, r.return = e; t.sibling !== null; ) t = t.sibling, r = r.sibling = wo(t, t.pendingProps), r.return = e;
        r.sibling = null;
      }
      return e.child;
    }
    function LN(t, e, r) {
      switch (e.tag) {
        case 3:
          f0(e), gs();
          break;
        case 5:
          qv(e);
          break;
        case 1:
          Kt(e.type) && Fc(e);
          break;
        case 4:
          Ad(e, e.stateNode.containerInfo);
          break;
        case 10:
          var n = e.type._context, o = e.memoizedProps.value;
          Ae(Bc, n._currentValue), n._currentValue = o;
          break;
        case 13:
          if (n = e.memoizedState, n !== null) return n.dehydrated !== null ? (Ae(Pe, Pe.current & 1), e.flags |= 128, null) : r & e.child.childLanes ? m0(t, e, r) : (Ae(Pe, Pe.current & 1), t = jn(t, e, r), t !== null ? t.sibling : null);
          Ae(Pe, Pe.current & 1);
          break;
        case 19:
          if (n = (r & e.childLanes) !== 0, t.flags & 128) {
            if (n) return d0(t, e, r);
            e.flags |= 128;
          }
          if (o = e.memoizedState, o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), Ae(Pe, Pe.current), n) break;
          return null;
        case 22:
        case 23:
          return e.lanes = 0, p0(t, e, r);
      }
      return jn(t, e, r);
    }
    var g0, Gm, x0, y0;
    g0 = function(t, e) {
      for (var r = e.child; r !== null; ) {
        if (r.tag === 5 || r.tag === 6) t.appendChild(r.stateNode);
        else if (r.tag !== 4 && r.child !== null) {
          r.child.return = r, r = r.child;
          continue;
        }
        if (r === e) break;
        for (; r.sibling === null; ) {
          if (r.return === null || r.return === e) return;
          r = r.return;
        }
        r.sibling.return = r.return, r = r.sibling;
      }
    };
    Gm = function() {
    };
    x0 = function(t, e, r, n) {
      var o = t.memoizedProps;
      if (o !== n) {
        t = e.stateNode, ii(dn.current);
        var i = null;
        switch (r) {
          case "input":
            o = fm(t, o), n = fm(t, n), i = [];
            break;
          case "select":
            o = Ve({}, o, { value: void 0 }), n = Ve({}, n, { value: void 0 }), i = [];
            break;
          case "textarea":
            o = gm(t, o), n = gm(t, n), i = [];
            break;
          default:
            typeof o.onClick != "function" && typeof n.onClick == "function" && (t.onclick = Rc);
        }
        ym(r, n);
        var s;
        r = null;
        for (u in o) if (!n.hasOwnProperty(u) && o.hasOwnProperty(u) && o[u] != null) if (u === "style") {
          var a = o[u];
          for (s in a) a.hasOwnProperty(s) && (r || (r = {}), r[s] = "");
        } else u !== "dangerouslySetInnerHTML" && u !== "children" && u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && u !== "autoFocus" && (el.hasOwnProperty(u) ? i || (i = []) : (i = i || []).push(u, null));
        for (u in n) {
          var l = n[u];
          if (a = o != null ? o[u] : void 0, n.hasOwnProperty(u) && l !== a && (l != null || a != null)) if (u === "style") if (a) {
            for (s in a) !a.hasOwnProperty(s) || l && l.hasOwnProperty(s) || (r || (r = {}), r[s] = "");
            for (s in l) l.hasOwnProperty(s) && a[s] !== l[s] && (r || (r = {}), r[s] = l[s]);
          } else r || (i || (i = []), i.push(u, r)), r = l;
          else u === "dangerouslySetInnerHTML" ? (l = l ? l.__html : void 0, a = a ? a.__html : void 0, l != null && a !== l && (i = i || []).push(u, l)) : u === "children" ? typeof l != "string" && typeof l != "number" || (i = i || []).push(u, "" + l) : u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && (el.hasOwnProperty(u) ? (l != null && u === "onScroll" && ke("scroll", t), i || a === l || (i = [])) : (i = i || []).push(u, l));
        }
        r && (i = i || []).push("style", r);
        var u = i;
        (e.updateQueue = u) && (e.flags |= 4);
      }
    };
    y0 = function(t, e, r, n) {
      r !== n && (e.flags |= 4);
    };
    function La(t, e) {
      if (!be) switch (t.tailMode) {
        case "hidden":
          e = t.tail;
          for (var r = null; e !== null; ) e.alternate !== null && (r = e), e = e.sibling;
          r === null ? t.tail = null : r.sibling = null;
          break;
        case "collapsed":
          r = t.tail;
          for (var n = null; r !== null; ) r.alternate !== null && (n = r), r = r.sibling;
          n === null ? e || t.tail === null ? t.tail = null : t.tail.sibling = null : n.sibling = null;
      }
    }
    function Et(t) {
      var e = t.alternate !== null && t.alternate.child === t.child, r = 0, n = 0;
      if (e) for (var o = t.child; o !== null; ) r |= o.lanes | o.childLanes, n |= o.subtreeFlags & 14680064, n |= o.flags & 14680064, o.return = t, o = o.sibling;
      else for (o = t.child; o !== null; ) r |= o.lanes | o.childLanes, n |= o.subtreeFlags, n |= o.flags, o.return = t, o = o.sibling;
      return t.subtreeFlags |= n, t.childLanes = r, e;
    }
    function BN(t, e, r) {
      var n = e.pendingProps;
      switch (xd(e), e.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return Et(e), null;
        case 1:
          return Kt(e.type) && Vc(), Et(e), null;
        case 3:
          return n = e.stateNode, ys(), Ee(Qt), Ee(Nt), kd(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (t === null || t.child === null) && (pc(e) ? e.flags |= 4 : t === null || t.memoizedState.isDehydrated && !(e.flags & 256) || (e.flags |= 1024, Ur !== null && (Jm(Ur), Ur = null))), Gm(t, e), Et(e), null;
        case 5:
          Cd(e);
          var o = ii(hl.current);
          if (r = e.type, t !== null && e.stateNode != null) x0(t, e, r, n, o), t.ref !== e.ref && (e.flags |= 512, e.flags |= 2097152);
          else {
            if (!n) {
              if (e.stateNode === null) throw Error(F(166));
              return Et(e), null;
            }
            if (t = ii(dn.current), pc(e)) {
              n = e.stateNode, r = e.type;
              var i = e.memoizedProps;
              switch (n[fn] = e, n[cl] = i, t = (e.mode & 1) !== 0, r) {
                case "dialog":
                  ke("cancel", n), ke("close", n);
                  break;
                case "iframe":
                case "object":
                case "embed":
                  ke("load", n);
                  break;
                case "video":
                case "audio":
                  for (o = 0; o < Ua.length; o++) ke(Ua[o], n);
                  break;
                case "source":
                  ke("error", n);
                  break;
                case "img":
                case "image":
                case "link":
                  ke("error", n), ke("load", n);
                  break;
                case "details":
                  ke("toggle", n);
                  break;
                case "input":
                  Vy(n, i), ke("invalid", n);
                  break;
                case "select":
                  n._wrapperState = { wasMultiple: !!i.multiple }, ke("invalid", n);
                  break;
                case "textarea":
                  Iy(n, i), ke("invalid", n);
              }
              ym(r, i), o = null;
              for (var s in i) if (i.hasOwnProperty(s)) {
                var a = i[s];
                s === "children" ? typeof a == "string" ? n.textContent !== a && (i.suppressHydrationWarning !== true && cc(n.textContent, a, t), o = ["children", a]) : typeof a == "number" && n.textContent !== "" + a && (i.suppressHydrationWarning !== true && cc(n.textContent, a, t), o = ["children", "" + a]) : el.hasOwnProperty(s) && a != null && s === "onScroll" && ke("scroll", n);
              }
              switch (r) {
                case "input":
                  Zu(n), Fy(n, i, true);
                  break;
                case "textarea":
                  Zu(n), Ly(n);
                  break;
                case "select":
                case "option":
                  break;
                default:
                  typeof i.onClick == "function" && (n.onclick = Rc);
              }
              n = o, e.updateQueue = n, n !== null && (e.flags |= 4);
            } else {
              s = o.nodeType === 9 ? o : o.ownerDocument, t === "http://www.w3.org/1999/xhtml" && (t = H_(r)), t === "http://www.w3.org/1999/xhtml" ? r === "script" ? (t = s.createElement("div"), t.innerHTML = "<script><\/script>", t = t.removeChild(t.firstChild)) : typeof n.is == "string" ? t = s.createElement(r, { is: n.is }) : (t = s.createElement(r), r === "select" && (s = t, n.multiple ? s.multiple = true : n.size && (s.size = n.size))) : t = s.createElementNS(t, r), t[fn] = e, t[cl] = n, g0(t, e, false, false), e.stateNode = t;
              e: {
                switch (s = _m(r, n), r) {
                  case "dialog":
                    ke("cancel", t), ke("close", t), o = n;
                    break;
                  case "iframe":
                  case "object":
                  case "embed":
                    ke("load", t), o = n;
                    break;
                  case "video":
                  case "audio":
                    for (o = 0; o < Ua.length; o++) ke(Ua[o], t);
                    o = n;
                    break;
                  case "source":
                    ke("error", t), o = n;
                    break;
                  case "img":
                  case "image":
                  case "link":
                    ke("error", t), ke("load", t), o = n;
                    break;
                  case "details":
                    ke("toggle", t), o = n;
                    break;
                  case "input":
                    Vy(t, n), o = fm(t, n), ke("invalid", t);
                    break;
                  case "option":
                    o = n;
                    break;
                  case "select":
                    t._wrapperState = { wasMultiple: !!n.multiple }, o = Ve({}, n, { value: void 0 }), ke("invalid", t);
                    break;
                  case "textarea":
                    Iy(t, n), o = gm(t, n), ke("invalid", t);
                    break;
                  default:
                    o = n;
                }
                ym(r, o), a = o;
                for (i in a) if (a.hasOwnProperty(i)) {
                  var l = a[i];
                  i === "style" ? Y_(t, l) : i === "dangerouslySetInnerHTML" ? (l = l ? l.__html : void 0, l != null && $_(t, l)) : i === "children" ? typeof l == "string" ? (r !== "textarea" || l !== "") && tl(t, l) : typeof l == "number" && tl(t, "" + l) : i !== "suppressContentEditableWarning" && i !== "suppressHydrationWarning" && i !== "autoFocus" && (el.hasOwnProperty(i) ? l != null && i === "onScroll" && ke("scroll", t) : l != null && rd(t, i, l, s));
                }
                switch (r) {
                  case "input":
                    Zu(t), Fy(t, n, false);
                    break;
                  case "textarea":
                    Zu(t), Ly(t);
                    break;
                  case "option":
                    n.value != null && t.setAttribute("value", "" + So(n.value));
                    break;
                  case "select":
                    t.multiple = !!n.multiple, i = n.value, i != null ? ls(t, !!n.multiple, i, false) : n.defaultValue != null && ls(t, !!n.multiple, n.defaultValue, true);
                    break;
                  default:
                    typeof o.onClick == "function" && (t.onclick = Rc);
                }
                switch (r) {
                  case "button":
                  case "input":
                  case "select":
                  case "textarea":
                    n = !!n.autoFocus;
                    break e;
                  case "img":
                    n = true;
                    break e;
                  default:
                    n = false;
                }
              }
              n && (e.flags |= 4);
            }
            e.ref !== null && (e.flags |= 512, e.flags |= 2097152);
          }
          return Et(e), null;
        case 6:
          if (t && e.stateNode != null) y0(t, e, t.memoizedProps, n);
          else {
            if (typeof n != "string" && e.stateNode === null) throw Error(F(166));
            if (r = ii(hl.current), ii(dn.current), pc(e)) {
              if (n = e.stateNode, r = e.memoizedProps, n[fn] = e, (i = n.nodeValue !== r) && (t = sr, t !== null)) switch (t.tag) {
                case 3:
                  cc(n.nodeValue, r, (t.mode & 1) !== 0);
                  break;
                case 5:
                  t.memoizedProps.suppressHydrationWarning !== true && cc(n.nodeValue, r, (t.mode & 1) !== 0);
              }
              i && (e.flags |= 4);
            } else n = (r.nodeType === 9 ? r : r.ownerDocument).createTextNode(n), n[fn] = e, e.stateNode = n;
          }
          return Et(e), null;
        case 13:
          if (Ee(Pe), n = e.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
            if (be && ir !== null && e.mode & 1 && !(e.flags & 128)) Fv(), gs(), e.flags |= 98560, i = false;
            else if (i = pc(e), n !== null && n.dehydrated !== null) {
              if (t === null) {
                if (!i) throw Error(F(318));
                if (i = e.memoizedState, i = i !== null ? i.dehydrated : null, !i) throw Error(F(317));
                i[fn] = e;
              } else gs(), !(e.flags & 128) && (e.memoizedState = null), e.flags |= 4;
              Et(e), i = false;
            } else Ur !== null && (Jm(Ur), Ur = null), i = true;
            if (!i) return e.flags & 65536 ? e : null;
          }
          return e.flags & 128 ? (e.lanes = r, e) : (n = n !== null, n !== (t !== null && t.memoizedState !== null) && n && (e.child.flags |= 8192, e.mode & 1 && (t === null || Pe.current & 1 ? ut === 0 && (ut = 3) : Ld())), e.updateQueue !== null && (e.flags |= 4), Et(e), null);
        case 4:
          return ys(), Gm(t, e), t === null && ll(e.stateNode.containerInfo), Et(e), null;
        case 10:
          return wd(e.type._context), Et(e), null;
        case 17:
          return Kt(e.type) && Vc(), Et(e), null;
        case 19:
          if (Ee(Pe), i = e.memoizedState, i === null) return Et(e), null;
          if (n = (e.flags & 128) !== 0, s = i.rendering, s === null) if (n) La(i, false);
          else {
            if (ut !== 0 || t !== null && t.flags & 128) for (t = e.child; t !== null; ) {
              if (s = zc(t), s !== null) {
                for (e.flags |= 128, La(i, false), n = s.updateQueue, n !== null && (e.updateQueue = n, e.flags |= 4), e.subtreeFlags = 0, n = r, r = e.child; r !== null; ) i = r, t = n, i.flags &= 14680066, s = i.alternate, s === null ? (i.childLanes = 0, i.lanes = t, i.child = null, i.subtreeFlags = 0, i.memoizedProps = null, i.memoizedState = null, i.updateQueue = null, i.dependencies = null, i.stateNode = null) : (i.childLanes = s.childLanes, i.lanes = s.lanes, i.child = s.child, i.subtreeFlags = 0, i.deletions = null, i.memoizedProps = s.memoizedProps, i.memoizedState = s.memoizedState, i.updateQueue = s.updateQueue, i.type = s.type, t = s.dependencies, i.dependencies = t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }), r = r.sibling;
                return Ae(Pe, Pe.current & 1 | 2), e.child;
              }
              t = t.sibling;
            }
            i.tail !== null && Xe() > vs && (e.flags |= 128, n = true, La(i, false), e.lanes = 4194304);
          }
          else {
            if (!n) if (t = zc(s), t !== null) {
              if (e.flags |= 128, n = true, r = t.updateQueue, r !== null && (e.updateQueue = r, e.flags |= 4), La(i, true), i.tail === null && i.tailMode === "hidden" && !s.alternate && !be) return Et(e), null;
            } else 2 * Xe() - i.renderingStartTime > vs && r !== 1073741824 && (e.flags |= 128, n = true, La(i, false), e.lanes = 4194304);
            i.isBackwards ? (s.sibling = e.child, e.child = s) : (r = i.last, r !== null ? r.sibling = s : e.child = s, i.last = s);
          }
          return i.tail !== null ? (e = i.tail, i.rendering = e, i.tail = e.sibling, i.renderingStartTime = Xe(), e.sibling = null, r = Pe.current, Ae(Pe, n ? r & 1 | 2 : r & 1), e) : (Et(e), null);
        case 22:
        case 23:
          return Id(), n = e.memoizedState !== null, t !== null && t.memoizedState !== null !== n && (e.flags |= 8192), n && e.mode & 1 ? or & 1073741824 && (Et(e), e.subtreeFlags & 6 && (e.flags |= 8192)) : Et(e), null;
        case 24:
          return null;
        case 25:
          return null;
      }
      throw Error(F(156, e.tag));
    }
    function jN(t, e) {
      switch (xd(e), e.tag) {
        case 1:
          return Kt(e.type) && Vc(), t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
        case 3:
          return ys(), Ee(Qt), Ee(Nt), kd(), t = e.flags, t & 65536 && !(t & 128) ? (e.flags = t & -65537 | 128, e) : null;
        case 5:
          return Cd(e), null;
        case 13:
          if (Ee(Pe), t = e.memoizedState, t !== null && t.dehydrated !== null) {
            if (e.alternate === null) throw Error(F(340));
            gs();
          }
          return t = e.flags, t & 65536 ? (e.flags = t & -65537 | 128, e) : null;
        case 19:
          return Ee(Pe), null;
        case 4:
          return ys(), null;
        case 10:
          return wd(e.type._context), null;
        case 22:
        case 23:
          return Id(), null;
        case 24:
          return null;
        default:
          return null;
      }
    }
    var mc = false, bt = false, qN = typeof WeakSet == "function" ? WeakSet : Set, $ = null;
    function ss(t, e) {
      var r = t.ref;
      if (r !== null) if (typeof r == "function") try {
        r(null);
      } catch (n) {
        We(t, e, n);
      }
      else r.current = null;
    }
    function Hm(t, e, r) {
      try {
        r();
      } catch (n) {
        We(t, e, n);
      }
    }
    var b_ = false;
    function zN(t, e) {
      if (Nm = Dc, t = Tv(), dd(t)) {
        if ("selectionStart" in t) var r = { start: t.selectionStart, end: t.selectionEnd };
        else e: {
          r = (r = t.ownerDocument) && r.defaultView || window;
          var n = r.getSelection && r.getSelection();
          if (n && n.rangeCount !== 0) {
            r = n.anchorNode;
            var o = n.anchorOffset, i = n.focusNode;
            n = n.focusOffset;
            try {
              r.nodeType, i.nodeType;
            } catch {
              r = null;
              break e;
            }
            var s = 0, a = -1, l = -1, u = 0, c = 0, p = t, h = null;
            t: for (; ; ) {
              for (var f; p !== r || o !== 0 && p.nodeType !== 3 || (a = s + o), p !== i || n !== 0 && p.nodeType !== 3 || (l = s + n), p.nodeType === 3 && (s += p.nodeValue.length), (f = p.firstChild) !== null; ) h = p, p = f;
              for (; ; ) {
                if (p === t) break t;
                if (h === r && ++u === o && (a = s), h === i && ++c === n && (l = s), (f = p.nextSibling) !== null) break;
                p = h, h = p.parentNode;
              }
              p = f;
            }
            r = a === -1 || l === -1 ? null : { start: a, end: l };
          } else r = null;
        }
        r = r || { start: 0, end: 0 };
      } else r = null;
      for (Om = { focusedElem: t, selectionRange: r }, Dc = false, $ = e; $ !== null; ) if (e = $, t = e.child, (e.subtreeFlags & 1028) !== 0 && t !== null) t.return = e, $ = t;
      else for (; $ !== null; ) {
        e = $;
        try {
          var m = e.alternate;
          if (e.flags & 1024) switch (e.tag) {
            case 0:
            case 11:
            case 15:
              break;
            case 1:
              if (m !== null) {
                var x = m.memoizedProps, _ = m.memoizedState, d = e.stateNode, g = d.getSnapshotBeforeUpdate(e.elementType === e.type ? x : zr(e.type, x), _);
                d.__reactInternalSnapshotBeforeUpdate = g;
              }
              break;
            case 3:
              var y = e.stateNode.containerInfo;
              y.nodeType === 1 ? y.textContent = "" : y.nodeType === 9 && y.documentElement && y.removeChild(y.documentElement);
              break;
            case 5:
            case 6:
            case 4:
            case 17:
              break;
            default:
              throw Error(F(163));
          }
        } catch (S) {
          We(e, e.return, S);
        }
        if (t = e.sibling, t !== null) {
          t.return = e.return, $ = t;
          break;
        }
        $ = e.return;
      }
      return m = b_, b_ = false, m;
    }
    function Ka(t, e, r) {
      var n = e.updateQueue;
      if (n = n !== null ? n.lastEffect : null, n !== null) {
        var o = n = n.next;
        do {
          if ((o.tag & t) === t) {
            var i = o.destroy;
            o.destroy = void 0, i !== void 0 && Hm(e, r, i);
          }
          o = o.next;
        } while (o !== n);
      }
    }
    function op(t, e) {
      if (e = e.updateQueue, e = e !== null ? e.lastEffect : null, e !== null) {
        var r = e = e.next;
        do {
          if ((r.tag & t) === t) {
            var n = r.create;
            r.destroy = n();
          }
          r = r.next;
        } while (r !== e);
      }
    }
    function $m(t) {
      var e = t.ref;
      if (e !== null) {
        var r = t.stateNode;
        switch (t.tag) {
          case 5:
            t = r;
            break;
          default:
            t = r;
        }
        typeof e == "function" ? e(t) : e.current = t;
      }
    }
    function _0(t) {
      var e = t.alternate;
      e !== null && (t.alternate = null, _0(e)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (e = t.stateNode, e !== null && (delete e[fn], delete e[cl], delete e[Pm], delete e[AN], delete e[CN])), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null;
    }
    function v0(t) {
      return t.tag === 5 || t.tag === 3 || t.tag === 4;
    }
    function N_(t) {
      e: for (; ; ) {
        for (; t.sibling === null; ) {
          if (t.return === null || v0(t.return)) return null;
          t = t.return;
        }
        for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18; ) {
          if (t.flags & 2 || t.child === null || t.tag === 4) continue e;
          t.child.return = t, t = t.child;
        }
        if (!(t.flags & 2)) return t.stateNode;
      }
    }
    function Xm(t, e, r) {
      var n = t.tag;
      if (n === 5 || n === 6) t = t.stateNode, e ? r.nodeType === 8 ? r.parentNode.insertBefore(t, e) : r.insertBefore(t, e) : (r.nodeType === 8 ? (e = r.parentNode, e.insertBefore(t, r)) : (e = r, e.appendChild(t)), r = r._reactRootContainer, r != null || e.onclick !== null || (e.onclick = Rc));
      else if (n !== 4 && (t = t.child, t !== null)) for (Xm(t, e, r), t = t.sibling; t !== null; ) Xm(t, e, r), t = t.sibling;
    }
    function Ym(t, e, r) {
      var n = t.tag;
      if (n === 5 || n === 6) t = t.stateNode, e ? r.insertBefore(t, e) : r.appendChild(t);
      else if (n !== 4 && (t = t.child, t !== null)) for (Ym(t, e, r), t = t.sibling; t !== null; ) Ym(t, e, r), t = t.sibling;
    }
    var vt = null, Wr = false;
    function so(t, e, r) {
      for (r = r.child; r !== null; ) w0(t, e, r), r = r.sibling;
    }
    function w0(t, e, r) {
      if (mn && typeof mn.onCommitFiberUnmount == "function") try {
        mn.onCommitFiberUnmount(Qc, r);
      } catch {
      }
      switch (r.tag) {
        case 5:
          bt || ss(r, e);
        case 6:
          var n = vt, o = Wr;
          vt = null, so(t, e, r), vt = n, Wr = o, vt !== null && (Wr ? (t = vt, r = r.stateNode, t.nodeType === 8 ? t.parentNode.removeChild(r) : t.removeChild(r)) : vt.removeChild(r.stateNode));
          break;
        case 18:
          vt !== null && (Wr ? (t = vt, r = r.stateNode, t.nodeType === 8 ? Zf(t.parentNode, r) : t.nodeType === 1 && Zf(t, r), il(t)) : Zf(vt, r.stateNode));
          break;
        case 4:
          n = vt, o = Wr, vt = r.stateNode.containerInfo, Wr = true, so(t, e, r), vt = n, Wr = o;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          if (!bt && (n = r.updateQueue, n !== null && (n = n.lastEffect, n !== null))) {
            o = n = n.next;
            do {
              var i = o, s = i.destroy;
              i = i.tag, s !== void 0 && (i & 2 || i & 4) && Hm(r, e, s), o = o.next;
            } while (o !== n);
          }
          so(t, e, r);
          break;
        case 1:
          if (!bt && (ss(r, e), n = r.stateNode, typeof n.componentWillUnmount == "function")) try {
            n.props = r.memoizedProps, n.state = r.memoizedState, n.componentWillUnmount();
          } catch (a) {
            We(r, e, a);
          }
          so(t, e, r);
          break;
        case 21:
          so(t, e, r);
          break;
        case 22:
          r.mode & 1 ? (bt = (n = bt) || r.memoizedState !== null, so(t, e, r), bt = n) : so(t, e, r);
          break;
        default:
          so(t, e, r);
      }
    }
    function O_(t) {
      var e = t.updateQueue;
      if (e !== null) {
        t.updateQueue = null;
        var r = t.stateNode;
        r === null && (r = t.stateNode = new qN()), e.forEach(function(n) {
          var o = KN.bind(null, t, n);
          r.has(n) || (r.add(n), n.then(o, o));
        });
      }
    }
    function qr(t, e) {
      var r = e.deletions;
      if (r !== null) for (var n = 0; n < r.length; n++) {
        var o = r[n];
        try {
          var i = t, s = e, a = s;
          e: for (; a !== null; ) {
            switch (a.tag) {
              case 5:
                vt = a.stateNode, Wr = false;
                break e;
              case 3:
                vt = a.stateNode.containerInfo, Wr = true;
                break e;
              case 4:
                vt = a.stateNode.containerInfo, Wr = true;
                break e;
            }
            a = a.return;
          }
          if (vt === null) throw Error(F(160));
          w0(i, s, o), vt = null, Wr = false;
          var l = o.alternate;
          l !== null && (l.return = null), o.return = null;
        } catch (u) {
          We(o, e, u);
        }
      }
      if (e.subtreeFlags & 12854) for (e = e.child; e !== null; ) S0(e, t), e = e.sibling;
    }
    function S0(t, e) {
      var r = t.alternate, n = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          if (qr(e, t), pn(t), n & 4) {
            try {
              Ka(3, t, t.return), op(3, t);
            } catch (x) {
              We(t, t.return, x);
            }
            try {
              Ka(5, t, t.return);
            } catch (x) {
              We(t, t.return, x);
            }
          }
          break;
        case 1:
          qr(e, t), pn(t), n & 512 && r !== null && ss(r, r.return);
          break;
        case 5:
          if (qr(e, t), pn(t), n & 512 && r !== null && ss(r, r.return), t.flags & 32) {
            var o = t.stateNode;
            try {
              tl(o, "");
            } catch (x) {
              We(t, t.return, x);
            }
          }
          if (n & 4 && (o = t.stateNode, o != null)) {
            var i = t.memoizedProps, s = r !== null ? r.memoizedProps : i, a = t.type, l = t.updateQueue;
            if (t.updateQueue = null, l !== null) try {
              a === "input" && i.type === "radio" && i.name != null && U_(o, i), _m(a, s);
              var u = _m(a, i);
              for (s = 0; s < l.length; s += 2) {
                var c = l[s], p = l[s + 1];
                c === "style" ? Y_(o, p) : c === "dangerouslySetInnerHTML" ? $_(o, p) : c === "children" ? tl(o, p) : rd(o, c, p, u);
              }
              switch (a) {
                case "input":
                  mm(o, i);
                  break;
                case "textarea":
                  G_(o, i);
                  break;
                case "select":
                  var h = o._wrapperState.wasMultiple;
                  o._wrapperState.wasMultiple = !!i.multiple;
                  var f = i.value;
                  f != null ? ls(o, !!i.multiple, f, false) : h !== !!i.multiple && (i.defaultValue != null ? ls(o, !!i.multiple, i.defaultValue, true) : ls(o, !!i.multiple, i.multiple ? [] : "", false));
              }
              o[cl] = i;
            } catch (x) {
              We(t, t.return, x);
            }
          }
          break;
        case 6:
          if (qr(e, t), pn(t), n & 4) {
            if (t.stateNode === null) throw Error(F(162));
            o = t.stateNode, i = t.memoizedProps;
            try {
              o.nodeValue = i;
            } catch (x) {
              We(t, t.return, x);
            }
          }
          break;
        case 3:
          if (qr(e, t), pn(t), n & 4 && r !== null && r.memoizedState.isDehydrated) try {
            il(e.containerInfo);
          } catch (x) {
            We(t, t.return, x);
          }
          break;
        case 4:
          qr(e, t), pn(t);
          break;
        case 13:
          qr(e, t), pn(t), o = t.child, o.flags & 8192 && (i = o.memoizedState !== null, o.stateNode.isHidden = i, !i || o.alternate !== null && o.alternate.memoizedState !== null || (Vd = Xe())), n & 4 && O_(t);
          break;
        case 22:
          if (c = r !== null && r.memoizedState !== null, t.mode & 1 ? (bt = (u = bt) || c, qr(e, t), bt = u) : qr(e, t), pn(t), n & 8192) {
            if (u = t.memoizedState !== null, (t.stateNode.isHidden = u) && !c && t.mode & 1) for ($ = t, c = t.child; c !== null; ) {
              for (p = $ = c; $ !== null; ) {
                switch (h = $, f = h.child, h.tag) {
                  case 0:
                  case 11:
                  case 14:
                  case 15:
                    Ka(4, h, h.return);
                    break;
                  case 1:
                    ss(h, h.return);
                    var m = h.stateNode;
                    if (typeof m.componentWillUnmount == "function") {
                      n = h, r = h.return;
                      try {
                        e = n, m.props = e.memoizedProps, m.state = e.memoizedState, m.componentWillUnmount();
                      } catch (x) {
                        We(n, r, x);
                      }
                    }
                    break;
                  case 5:
                    ss(h, h.return);
                    break;
                  case 22:
                    if (h.memoizedState !== null) {
                      M_(p);
                      continue;
                    }
                }
                f !== null ? (f.return = h, $ = f) : M_(p);
              }
              c = c.sibling;
            }
            e: for (c = null, p = t; ; ) {
              if (p.tag === 5) {
                if (c === null) {
                  c = p;
                  try {
                    o = p.stateNode, u ? (i = o.style, typeof i.setProperty == "function" ? i.setProperty("display", "none", "important") : i.display = "none") : (a = p.stateNode, l = p.memoizedProps.style, s = l != null && l.hasOwnProperty("display") ? l.display : null, a.style.display = X_("display", s));
                  } catch (x) {
                    We(t, t.return, x);
                  }
                }
              } else if (p.tag === 6) {
                if (c === null) try {
                  p.stateNode.nodeValue = u ? "" : p.memoizedProps;
                } catch (x) {
                  We(t, t.return, x);
                }
              } else if ((p.tag !== 22 && p.tag !== 23 || p.memoizedState === null || p === t) && p.child !== null) {
                p.child.return = p, p = p.child;
                continue;
              }
              if (p === t) break e;
              for (; p.sibling === null; ) {
                if (p.return === null || p.return === t) break e;
                c === p && (c = null), p = p.return;
              }
              c === p && (c = null), p.sibling.return = p.return, p = p.sibling;
            }
          }
          break;
        case 19:
          qr(e, t), pn(t), n & 4 && O_(t);
          break;
        case 21:
          break;
        default:
          qr(e, t), pn(t);
      }
    }
    function pn(t) {
      var e = t.flags;
      if (e & 2) {
        try {
          e: {
            for (var r = t.return; r !== null; ) {
              if (v0(r)) {
                var n = r;
                break e;
              }
              r = r.return;
            }
            throw Error(F(160));
          }
          switch (n.tag) {
            case 5:
              var o = n.stateNode;
              n.flags & 32 && (tl(o, ""), n.flags &= -33);
              var i = N_(t);
              Ym(t, i, o);
              break;
            case 3:
            case 4:
              var s = n.stateNode.containerInfo, a = N_(t);
              Xm(t, a, s);
              break;
            default:
              throw Error(F(161));
          }
        } catch (l) {
          We(t, t.return, l);
        }
        t.flags &= -3;
      }
      e & 4096 && (t.flags &= -4097);
    }
    function WN(t, e, r) {
      $ = t, T0(t, e, r);
    }
    function T0(t, e, r) {
      for (var n = (t.mode & 1) !== 0; $ !== null; ) {
        var o = $, i = o.child;
        if (o.tag === 22 && n) {
          var s = o.memoizedState !== null || mc;
          if (!s) {
            var a = o.alternate, l = a !== null && a.memoizedState !== null || bt;
            a = mc;
            var u = bt;
            if (mc = s, (bt = l) && !u) for ($ = o; $ !== null; ) s = $, l = s.child, s.tag === 22 && s.memoizedState !== null ? P_(o) : l !== null ? (l.return = s, $ = l) : P_(o);
            for (; i !== null; ) $ = i, T0(i, e, r), i = i.sibling;
            $ = o, mc = a, bt = u;
          }
          D_(t, e, r);
        } else o.subtreeFlags & 8772 && i !== null ? (i.return = o, $ = i) : D_(t, e, r);
      }
    }
    function D_(t) {
      for (; $ !== null; ) {
        var e = $;
        if (e.flags & 8772) {
          var r = e.alternate;
          try {
            if (e.flags & 8772) switch (e.tag) {
              case 0:
              case 11:
              case 15:
                bt || op(5, e);
                break;
              case 1:
                var n = e.stateNode;
                if (e.flags & 4 && !bt) if (r === null) n.componentDidMount();
                else {
                  var o = e.elementType === e.type ? r.memoizedProps : zr(e.type, r.memoizedProps);
                  n.componentDidUpdate(o, r.memoizedState, n.__reactInternalSnapshotBeforeUpdate);
                }
                var i = e.updateQueue;
                i !== null && d_(e, i, n);
                break;
              case 3:
                var s = e.updateQueue;
                if (s !== null) {
                  if (r = null, e.child !== null) switch (e.child.tag) {
                    case 5:
                      r = e.child.stateNode;
                      break;
                    case 1:
                      r = e.child.stateNode;
                  }
                  d_(e, s, r);
                }
                break;
              case 5:
                var a = e.stateNode;
                if (r === null && e.flags & 4) {
                  r = a;
                  var l = e.memoizedProps;
                  switch (e.type) {
                    case "button":
                    case "input":
                    case "select":
                    case "textarea":
                      l.autoFocus && r.focus();
                      break;
                    case "img":
                      l.src && (r.src = l.src);
                  }
                }
                break;
              case 6:
                break;
              case 4:
                break;
              case 12:
                break;
              case 13:
                if (e.memoizedState === null) {
                  var u = e.alternate;
                  if (u !== null) {
                    var c = u.memoizedState;
                    if (c !== null) {
                      var p = c.dehydrated;
                      p !== null && il(p);
                    }
                  }
                }
                break;
              case 19:
              case 17:
              case 21:
              case 22:
              case 23:
              case 25:
                break;
              default:
                throw Error(F(163));
            }
            bt || e.flags & 512 && $m(e);
          } catch (h) {
            We(e, e.return, h);
          }
        }
        if (e === t) {
          $ = null;
          break;
        }
        if (r = e.sibling, r !== null) {
          r.return = e.return, $ = r;
          break;
        }
        $ = e.return;
      }
    }
    function M_(t) {
      for (; $ !== null; ) {
        var e = $;
        if (e === t) {
          $ = null;
          break;
        }
        var r = e.sibling;
        if (r !== null) {
          r.return = e.return, $ = r;
          break;
        }
        $ = e.return;
      }
    }
    function P_(t) {
      for (; $ !== null; ) {
        var e = $;
        try {
          switch (e.tag) {
            case 0:
            case 11:
            case 15:
              var r = e.return;
              try {
                op(4, e);
              } catch (l) {
                We(e, r, l);
              }
              break;
            case 1:
              var n = e.stateNode;
              if (typeof n.componentDidMount == "function") {
                var o = e.return;
                try {
                  n.componentDidMount();
                } catch (l) {
                  We(e, o, l);
                }
              }
              var i = e.return;
              try {
                $m(e);
              } catch (l) {
                We(e, i, l);
              }
              break;
            case 5:
              var s = e.return;
              try {
                $m(e);
              } catch (l) {
                We(e, s, l);
              }
          }
        } catch (l) {
          We(e, e.return, l);
        }
        if (e === t) {
          $ = null;
          break;
        }
        var a = e.sibling;
        if (a !== null) {
          a.return = e.return, $ = a;
          break;
        }
        $ = e.return;
      }
    }
    var UN = Math.ceil, Gc = qn.ReactCurrentDispatcher, Pd = qn.ReactCurrentOwner, Tr = qn.ReactCurrentBatchConfig, pe = 0, xt = null, et = null, wt = 0, or = 0, as = Co(0), ut = 0, gl = null, pi = 0, ip = 0, Rd = 0, Za = null, Xt = null, Vd = 0, vs = 1 / 0, Mn = null, Hc = false, Qm = null, _o = null, dc = false, ho = null, $c = 0, Ja = 0, Km = null, Tc = -1, Ac = 0;
    function It() {
      return pe & 6 ? Xe() : Tc !== -1 ? Tc : Tc = Xe();
    }
    function vo(t) {
      return t.mode & 1 ? pe & 2 && wt !== 0 ? wt & -wt : EN.transition !== null ? (Ac === 0 && (Ac = av()), Ac) : (t = _e, t !== 0 || (t = window.event, t = t === void 0 ? 16 : mv(t.type)), t) : 1;
    }
    function Hr(t, e, r, n) {
      if (50 < Ja) throw Ja = 0, Km = null, Error(F(185));
      xl(t, r, n), (!(pe & 2) || t !== xt) && (t === xt && (!(pe & 2) && (ip |= r), ut === 4 && co(t, wt)), Zt(t, n), r === 1 && pe === 0 && !(e.mode & 1) && (vs = Xe() + 500, tp && ko()));
    }
    function Zt(t, e) {
      var r = t.callbackNode;
      Nb(t, e);
      var n = Oc(t, t === xt ? wt : 0);
      if (n === 0) r !== null && qy(r), t.callbackNode = null, t.callbackPriority = 0;
      else if (e = n & -n, t.callbackPriority !== e) {
        if (r != null && qy(r), e === 1) t.tag === 0 ? kN(R_.bind(null, t)) : Pv(R_.bind(null, t)), SN(function() {
          !(pe & 6) && ko();
        }), r = null;
        else {
          switch (lv(n)) {
            case 1:
              r = ad;
              break;
            case 4:
              r = iv;
              break;
            case 16:
              r = Nc;
              break;
            case 536870912:
              r = sv;
              break;
            default:
              r = Nc;
          }
          r = D0(r, A0.bind(null, t));
        }
        t.callbackPriority = e, t.callbackNode = r;
      }
    }
    function A0(t, e) {
      if (Tc = -1, Ac = 0, pe & 6) throw Error(F(327));
      var r = t.callbackNode;
      if (fs() && t.callbackNode !== r) return null;
      var n = Oc(t, t === xt ? wt : 0);
      if (n === 0) return null;
      if (n & 30 || n & t.expiredLanes || e) e = Xc(t, n);
      else {
        e = n;
        var o = pe;
        pe |= 2;
        var i = k0();
        (xt !== t || wt !== e) && (Mn = null, vs = Xe() + 500, si(t, e));
        do
          try {
            $N();
            break;
          } catch (a) {
            C0(t, a);
          }
        while (true);
        vd(), Gc.current = i, pe = o, et !== null ? e = 0 : (xt = null, wt = 0, e = ut);
      }
      if (e !== 0) {
        if (e === 2 && (o = Am(t), o !== 0 && (n = o, e = Zm(t, o))), e === 1) throw r = gl, si(t, 0), co(t, n), Zt(t, Xe()), r;
        if (e === 6) co(t, n);
        else {
          if (o = t.current.alternate, !(n & 30) && !GN(o) && (e = Xc(t, n), e === 2 && (i = Am(t), i !== 0 && (n = i, e = Zm(t, i))), e === 1)) throw r = gl, si(t, 0), co(t, n), Zt(t, Xe()), r;
          switch (t.finishedWork = o, t.finishedLanes = n, e) {
            case 0:
            case 1:
              throw Error(F(345));
            case 2:
              ri(t, Xt, Mn);
              break;
            case 3:
              if (co(t, n), (n & 130023424) === n && (e = Vd + 500 - Xe(), 10 < e)) {
                if (Oc(t, 0) !== 0) break;
                if (o = t.suspendedLanes, (o & n) !== n) {
                  It(), t.pingedLanes |= t.suspendedLanes & o;
                  break;
                }
                t.timeoutHandle = Mm(ri.bind(null, t, Xt, Mn), e);
                break;
              }
              ri(t, Xt, Mn);
              break;
            case 4:
              if (co(t, n), (n & 4194240) === n) break;
              for (e = t.eventTimes, o = -1; 0 < n; ) {
                var s = 31 - Gr(n);
                i = 1 << s, s = e[s], s > o && (o = s), n &= ~i;
              }
              if (n = o, n = Xe() - n, n = (120 > n ? 120 : 480 > n ? 480 : 1080 > n ? 1080 : 1920 > n ? 1920 : 3e3 > n ? 3e3 : 4320 > n ? 4320 : 1960 * UN(n / 1960)) - n, 10 < n) {
                t.timeoutHandle = Mm(ri.bind(null, t, Xt, Mn), n);
                break;
              }
              ri(t, Xt, Mn);
              break;
            case 5:
              ri(t, Xt, Mn);
              break;
            default:
              throw Error(F(329));
          }
        }
      }
      return Zt(t, Xe()), t.callbackNode === r ? A0.bind(null, t) : null;
    }
    function Zm(t, e) {
      var r = Za;
      return t.current.memoizedState.isDehydrated && (si(t, e).flags |= 256), t = Xc(t, e), t !== 2 && (e = Xt, Xt = r, e !== null && Jm(e)), t;
    }
    function Jm(t) {
      Xt === null ? Xt = t : Xt.push.apply(Xt, t);
    }
    function GN(t) {
      for (var e = t; ; ) {
        if (e.flags & 16384) {
          var r = e.updateQueue;
          if (r !== null && (r = r.stores, r !== null)) for (var n = 0; n < r.length; n++) {
            var o = r[n], i = o.getSnapshot;
            o = o.value;
            try {
              if (!$r(i(), o)) return false;
            } catch {
              return false;
            }
          }
        }
        if (r = e.child, e.subtreeFlags & 16384 && r !== null) r.return = e, e = r;
        else {
          if (e === t) break;
          for (; e.sibling === null; ) {
            if (e.return === null || e.return === t) return true;
            e = e.return;
          }
          e.sibling.return = e.return, e = e.sibling;
        }
      }
      return true;
    }
    function co(t, e) {
      for (e &= ~Rd, e &= ~ip, t.suspendedLanes |= e, t.pingedLanes &= ~e, t = t.expirationTimes; 0 < e; ) {
        var r = 31 - Gr(e), n = 1 << r;
        t[r] = -1, e &= ~n;
      }
    }
    function R_(t) {
      if (pe & 6) throw Error(F(327));
      fs();
      var e = Oc(t, 0);
      if (!(e & 1)) return Zt(t, Xe()), null;
      var r = Xc(t, e);
      if (t.tag !== 0 && r === 2) {
        var n = Am(t);
        n !== 0 && (e = n, r = Zm(t, n));
      }
      if (r === 1) throw r = gl, si(t, 0), co(t, e), Zt(t, Xe()), r;
      if (r === 6) throw Error(F(345));
      return t.finishedWork = t.current.alternate, t.finishedLanes = e, ri(t, Xt, Mn), Zt(t, Xe()), null;
    }
    function Fd(t, e) {
      var r = pe;
      pe |= 1;
      try {
        return t(e);
      } finally {
        pe = r, pe === 0 && (vs = Xe() + 500, tp && ko());
      }
    }
    function hi(t) {
      ho !== null && ho.tag === 0 && !(pe & 6) && fs();
      var e = pe;
      pe |= 1;
      var r = Tr.transition, n = _e;
      try {
        if (Tr.transition = null, _e = 1, t) return t();
      } finally {
        _e = n, Tr.transition = r, pe = e, !(pe & 6) && ko();
      }
    }
    function Id() {
      or = as.current, Ee(as);
    }
    function si(t, e) {
      t.finishedWork = null, t.finishedLanes = 0;
      var r = t.timeoutHandle;
      if (r !== -1 && (t.timeoutHandle = -1, wN(r)), et !== null) for (r = et.return; r !== null; ) {
        var n = r;
        switch (xd(n), n.tag) {
          case 1:
            n = n.type.childContextTypes, n != null && Vc();
            break;
          case 3:
            ys(), Ee(Qt), Ee(Nt), kd();
            break;
          case 5:
            Cd(n);
            break;
          case 4:
            ys();
            break;
          case 13:
            Ee(Pe);
            break;
          case 19:
            Ee(Pe);
            break;
          case 10:
            wd(n.type._context);
            break;
          case 22:
          case 23:
            Id();
        }
        r = r.return;
      }
      if (xt = t, et = t = wo(t.current, null), wt = or = e, ut = 0, gl = null, Rd = ip = pi = 0, Xt = Za = null, oi !== null) {
        for (e = 0; e < oi.length; e++) if (r = oi[e], n = r.interleaved, n !== null) {
          r.interleaved = null;
          var o = n.next, i = r.pending;
          if (i !== null) {
            var s = i.next;
            i.next = o, n.next = s;
          }
          r.pending = n;
        }
        oi = null;
      }
      return t;
    }
    function C0(t, e) {
      do {
        var r = et;
        try {
          if (vd(), vc.current = Uc, Wc) {
            for (var n = Re.memoizedState; n !== null; ) {
              var o = n.queue;
              o !== null && (o.pending = null), n = n.next;
            }
            Wc = false;
          }
          if (ci = 0, gt = lt = Re = null, Qa = false, fl = 0, Pd.current = null, r === null || r.return === null) {
            ut = 1, gl = e, et = null;
            break;
          }
          e: {
            var i = t, s = r.return, a = r, l = e;
            if (e = wt, a.flags |= 32768, l !== null && typeof l == "object" && typeof l.then == "function") {
              var u = l, c = a, p = c.tag;
              if (!(c.mode & 1) && (p === 0 || p === 11 || p === 15)) {
                var h = c.alternate;
                h ? (c.updateQueue = h.updateQueue, c.memoizedState = h.memoizedState, c.lanes = h.lanes) : (c.updateQueue = null, c.memoizedState = null);
              }
              var f = w_(s);
              if (f !== null) {
                f.flags &= -257, S_(f, s, a, i, e), f.mode & 1 && v_(i, u, e), e = f, l = u;
                var m = e.updateQueue;
                if (m === null) {
                  var x = /* @__PURE__ */ new Set();
                  x.add(l), e.updateQueue = x;
                } else m.add(l);
                break e;
              } else {
                if (!(e & 1)) {
                  v_(i, u, e), Ld();
                  break e;
                }
                l = Error(F(426));
              }
            } else if (be && a.mode & 1) {
              var _ = w_(s);
              if (_ !== null) {
                !(_.flags & 65536) && (_.flags |= 256), S_(_, s, a, i, e), yd(_s(l, a));
                break e;
              }
            }
            i = l = _s(l, a), ut !== 4 && (ut = 2), Za === null ? Za = [i] : Za.push(i), i = s;
            do {
              switch (i.tag) {
                case 3:
                  i.flags |= 65536, e &= -e, i.lanes |= e;
                  var d = l0(i, l, e);
                  m_(i, d);
                  break e;
                case 1:
                  a = l;
                  var g = i.type, y = i.stateNode;
                  if (!(i.flags & 128) && (typeof g.getDerivedStateFromError == "function" || y !== null && typeof y.componentDidCatch == "function" && (_o === null || !_o.has(y)))) {
                    i.flags |= 65536, e &= -e, i.lanes |= e;
                    var S = u0(i, a, e);
                    m_(i, S);
                    break e;
                  }
              }
              i = i.return;
            } while (i !== null);
          }
          b0(r);
        } catch (v) {
          e = v, et === r && r !== null && (et = r = r.return);
          continue;
        }
        break;
      } while (true);
    }
    function k0() {
      var t = Gc.current;
      return Gc.current = Uc, t === null ? Uc : t;
    }
    function Ld() {
      (ut === 0 || ut === 3 || ut === 2) && (ut = 4), xt === null || !(pi & 268435455) && !(ip & 268435455) || co(xt, wt);
    }
    function Xc(t, e) {
      var r = pe;
      pe |= 2;
      var n = k0();
      (xt !== t || wt !== e) && (Mn = null, si(t, e));
      do
        try {
          HN();
          break;
        } catch (o) {
          C0(t, o);
        }
      while (true);
      if (vd(), pe = r, Gc.current = n, et !== null) throw Error(F(261));
      return xt = null, wt = 0, ut;
    }
    function HN() {
      for (; et !== null; ) E0(et);
    }
    function $N() {
      for (; et !== null && !vb(); ) E0(et);
    }
    function E0(t) {
      var e = O0(t.alternate, t, or);
      t.memoizedProps = t.pendingProps, e === null ? b0(t) : et = e, Pd.current = null;
    }
    function b0(t) {
      var e = t;
      do {
        var r = e.alternate;
        if (t = e.return, e.flags & 32768) {
          if (r = jN(r, e), r !== null) {
            r.flags &= 32767, et = r;
            return;
          }
          if (t !== null) t.flags |= 32768, t.subtreeFlags = 0, t.deletions = null;
          else {
            ut = 6, et = null;
            return;
          }
        } else if (r = BN(r, e, or), r !== null) {
          et = r;
          return;
        }
        if (e = e.sibling, e !== null) {
          et = e;
          return;
        }
        et = e = t;
      } while (e !== null);
      ut === 0 && (ut = 5);
    }
    function ri(t, e, r) {
      var n = _e, o = Tr.transition;
      try {
        Tr.transition = null, _e = 1, XN(t, e, r, n);
      } finally {
        Tr.transition = o, _e = n;
      }
      return null;
    }
    function XN(t, e, r, n) {
      do
        fs();
      while (ho !== null);
      if (pe & 6) throw Error(F(327));
      r = t.finishedWork;
      var o = t.finishedLanes;
      if (r === null) return null;
      if (t.finishedWork = null, t.finishedLanes = 0, r === t.current) throw Error(F(177));
      t.callbackNode = null, t.callbackPriority = 0;
      var i = r.lanes | r.childLanes;
      if (Ob(t, i), t === xt && (et = xt = null, wt = 0), !(r.subtreeFlags & 2064) && !(r.flags & 2064) || dc || (dc = true, D0(Nc, function() {
        return fs(), null;
      })), i = (r.flags & 15990) !== 0, r.subtreeFlags & 15990 || i) {
        i = Tr.transition, Tr.transition = null;
        var s = _e;
        _e = 1;
        var a = pe;
        pe |= 4, Pd.current = null, zN(t, r), S0(r, t), gN(Om), Dc = !!Nm, Om = Nm = null, t.current = r, WN(r, t, o), wb(), pe = a, _e = s, Tr.transition = i;
      } else t.current = r;
      if (dc && (dc = false, ho = t, $c = o), i = t.pendingLanes, i === 0 && (_o = null), Ab(r.stateNode, n), Zt(t, Xe()), e !== null) for (n = t.onRecoverableError, r = 0; r < e.length; r++) o = e[r], n(o.value, { componentStack: o.stack, digest: o.digest });
      if (Hc) throw Hc = false, t = Qm, Qm = null, t;
      return $c & 1 && t.tag !== 0 && fs(), i = t.pendingLanes, i & 1 ? t === Km ? Ja++ : (Ja = 0, Km = t) : Ja = 0, ko(), null;
    }
    function fs() {
      if (ho !== null) {
        var t = lv($c), e = Tr.transition, r = _e;
        try {
          if (Tr.transition = null, _e = 16 > t ? 16 : t, ho === null) var n = false;
          else {
            if (t = ho, ho = null, $c = 0, pe & 6) throw Error(F(331));
            var o = pe;
            for (pe |= 4, $ = t.current; $ !== null; ) {
              var i = $, s = i.child;
              if ($.flags & 16) {
                var a = i.deletions;
                if (a !== null) {
                  for (var l = 0; l < a.length; l++) {
                    var u = a[l];
                    for ($ = u; $ !== null; ) {
                      var c = $;
                      switch (c.tag) {
                        case 0:
                        case 11:
                        case 15:
                          Ka(8, c, i);
                      }
                      var p = c.child;
                      if (p !== null) p.return = c, $ = p;
                      else for (; $ !== null; ) {
                        c = $;
                        var h = c.sibling, f = c.return;
                        if (_0(c), c === u) {
                          $ = null;
                          break;
                        }
                        if (h !== null) {
                          h.return = f, $ = h;
                          break;
                        }
                        $ = f;
                      }
                    }
                  }
                  var m = i.alternate;
                  if (m !== null) {
                    var x = m.child;
                    if (x !== null) {
                      m.child = null;
                      do {
                        var _ = x.sibling;
                        x.sibling = null, x = _;
                      } while (x !== null);
                    }
                  }
                  $ = i;
                }
              }
              if (i.subtreeFlags & 2064 && s !== null) s.return = i, $ = s;
              else e: for (; $ !== null; ) {
                if (i = $, i.flags & 2048) switch (i.tag) {
                  case 0:
                  case 11:
                  case 15:
                    Ka(9, i, i.return);
                }
                var d = i.sibling;
                if (d !== null) {
                  d.return = i.return, $ = d;
                  break e;
                }
                $ = i.return;
              }
            }
            var g = t.current;
            for ($ = g; $ !== null; ) {
              s = $;
              var y = s.child;
              if (s.subtreeFlags & 2064 && y !== null) y.return = s, $ = y;
              else e: for (s = g; $ !== null; ) {
                if (a = $, a.flags & 2048) try {
                  switch (a.tag) {
                    case 0:
                    case 11:
                    case 15:
                      op(9, a);
                  }
                } catch (v) {
                  We(a, a.return, v);
                }
                if (a === s) {
                  $ = null;
                  break e;
                }
                var S = a.sibling;
                if (S !== null) {
                  S.return = a.return, $ = S;
                  break e;
                }
                $ = a.return;
              }
            }
            if (pe = o, ko(), mn && typeof mn.onPostCommitFiberRoot == "function") try {
              mn.onPostCommitFiberRoot(Qc, t);
            } catch {
            }
            n = true;
          }
          return n;
        } finally {
          _e = r, Tr.transition = e;
        }
      }
      return false;
    }
    function V_(t, e, r) {
      e = _s(r, e), e = l0(t, e, 1), t = yo(t, e, 1), e = It(), t !== null && (xl(t, 1, e), Zt(t, e));
    }
    function We(t, e, r) {
      if (t.tag === 3) V_(t, t, r);
      else for (; e !== null; ) {
        if (e.tag === 3) {
          V_(e, t, r);
          break;
        } else if (e.tag === 1) {
          var n = e.stateNode;
          if (typeof e.type.getDerivedStateFromError == "function" || typeof n.componentDidCatch == "function" && (_o === null || !_o.has(n))) {
            t = _s(r, t), t = u0(e, t, 1), e = yo(e, t, 1), t = It(), e !== null && (xl(e, 1, t), Zt(e, t));
            break;
          }
        }
        e = e.return;
      }
    }
    function YN(t, e, r) {
      var n = t.pingCache;
      n !== null && n.delete(e), e = It(), t.pingedLanes |= t.suspendedLanes & r, xt === t && (wt & r) === r && (ut === 4 || ut === 3 && (wt & 130023424) === wt && 500 > Xe() - Vd ? si(t, 0) : Rd |= r), Zt(t, e);
    }
    function N0(t, e) {
      e === 0 && (t.mode & 1 ? (e = tc, tc <<= 1, !(tc & 130023424) && (tc = 4194304)) : e = 1);
      var r = It();
      t = Bn(t, e), t !== null && (xl(t, e, r), Zt(t, r));
    }
    function QN(t) {
      var e = t.memoizedState, r = 0;
      e !== null && (r = e.retryLane), N0(t, r);
    }
    function KN(t, e) {
      var r = 0;
      switch (t.tag) {
        case 13:
          var n = t.stateNode, o = t.memoizedState;
          o !== null && (r = o.retryLane);
          break;
        case 19:
          n = t.stateNode;
          break;
        default:
          throw Error(F(314));
      }
      n !== null && n.delete(e), N0(t, r);
    }
    var O0;
    O0 = function(t, e, r) {
      if (t !== null) if (t.memoizedProps !== e.pendingProps || Qt.current) Yt = true;
      else {
        if (!(t.lanes & r) && !(e.flags & 128)) return Yt = false, LN(t, e, r);
        Yt = !!(t.flags & 131072);
      }
      else Yt = false, be && e.flags & 1048576 && Rv(e, Lc, e.index);
      switch (e.lanes = 0, e.tag) {
        case 2:
          var n = e.type;
          Sc(t, e), t = e.pendingProps;
          var o = ds(e, Nt.current);
          hs(e, r), o = bd(null, e, n, t, o, r);
          var i = Nd();
          return e.flags |= 1, typeof o == "object" && o !== null && typeof o.render == "function" && o.$$typeof === void 0 ? (e.tag = 1, e.memoizedState = null, e.updateQueue = null, Kt(n) ? (i = true, Fc(e)) : i = false, e.memoizedState = o.state !== null && o.state !== void 0 ? o.state : null, Td(e), o.updater = np, e.stateNode = o, o._reactInternals = e, Bm(e, n, t, r), e = zm(null, e, n, true, i, r)) : (e.tag = 0, be && i && gd(e), Ft(null, e, o, r), e = e.child), e;
        case 16:
          n = e.elementType;
          e: {
            switch (Sc(t, e), t = e.pendingProps, o = n._init, n = o(n._payload), e.type = n, o = e.tag = JN(n), t = zr(n, t), o) {
              case 0:
                e = qm(null, e, n, t, r);
                break e;
              case 1:
                e = C_(null, e, n, t, r);
                break e;
              case 11:
                e = T_(null, e, n, t, r);
                break e;
              case 14:
                e = A_(null, e, n, zr(n.type, t), r);
                break e;
            }
            throw Error(F(306, n, ""));
          }
          return e;
        case 0:
          return n = e.type, o = e.pendingProps, o = e.elementType === n ? o : zr(n, o), qm(t, e, n, o, r);
        case 1:
          return n = e.type, o = e.pendingProps, o = e.elementType === n ? o : zr(n, o), C_(t, e, n, o, r);
        case 3:
          e: {
            if (f0(e), t === null) throw Error(F(387));
            n = e.pendingProps, i = e.memoizedState, o = i.element, jv(t, e), qc(e, n, null, r);
            var s = e.memoizedState;
            if (n = s.element, i.isDehydrated) if (i = { element: n, isDehydrated: false, cache: s.cache, pendingSuspenseBoundaries: s.pendingSuspenseBoundaries, transitions: s.transitions }, e.updateQueue.baseState = i, e.memoizedState = i, e.flags & 256) {
              o = _s(Error(F(423)), e), e = k_(t, e, n, r, o);
              break e;
            } else if (n !== o) {
              o = _s(Error(F(424)), e), e = k_(t, e, n, r, o);
              break e;
            } else for (ir = xo(e.stateNode.containerInfo.firstChild), sr = e, be = true, Ur = null, r = Lv(e, null, n, r), e.child = r; r; ) r.flags = r.flags & -3 | 4096, r = r.sibling;
            else {
              if (gs(), n === o) {
                e = jn(t, e, r);
                break e;
              }
              Ft(t, e, n, r);
            }
            e = e.child;
          }
          return e;
        case 5:
          return qv(e), t === null && Fm(e), n = e.type, o = e.pendingProps, i = t !== null ? t.memoizedProps : null, s = o.children, Dm(n, o) ? s = null : i !== null && Dm(n, i) && (e.flags |= 32), h0(t, e), Ft(t, e, s, r), e.child;
        case 6:
          return t === null && Fm(e), null;
        case 13:
          return m0(t, e, r);
        case 4:
          return Ad(e, e.stateNode.containerInfo), n = e.pendingProps, t === null ? e.child = xs(e, null, n, r) : Ft(t, e, n, r), e.child;
        case 11:
          return n = e.type, o = e.pendingProps, o = e.elementType === n ? o : zr(n, o), T_(t, e, n, o, r);
        case 7:
          return Ft(t, e, e.pendingProps, r), e.child;
        case 8:
          return Ft(t, e, e.pendingProps.children, r), e.child;
        case 12:
          return Ft(t, e, e.pendingProps.children, r), e.child;
        case 10:
          e: {
            if (n = e.type._context, o = e.pendingProps, i = e.memoizedProps, s = o.value, Ae(Bc, n._currentValue), n._currentValue = s, i !== null) if ($r(i.value, s)) {
              if (i.children === o.children && !Qt.current) {
                e = jn(t, e, r);
                break e;
              }
            } else for (i = e.child, i !== null && (i.return = e); i !== null; ) {
              var a = i.dependencies;
              if (a !== null) {
                s = i.child;
                for (var l = a.firstContext; l !== null; ) {
                  if (l.context === n) {
                    if (i.tag === 1) {
                      l = Fn(-1, r & -r), l.tag = 2;
                      var u = i.updateQueue;
                      if (u !== null) {
                        u = u.shared;
                        var c = u.pending;
                        c === null ? l.next = l : (l.next = c.next, c.next = l), u.pending = l;
                      }
                    }
                    i.lanes |= r, l = i.alternate, l !== null && (l.lanes |= r), Im(i.return, r, e), a.lanes |= r;
                    break;
                  }
                  l = l.next;
                }
              } else if (i.tag === 10) s = i.type === e.type ? null : i.child;
              else if (i.tag === 18) {
                if (s = i.return, s === null) throw Error(F(341));
                s.lanes |= r, a = s.alternate, a !== null && (a.lanes |= r), Im(s, r, e), s = i.sibling;
              } else s = i.child;
              if (s !== null) s.return = i;
              else for (s = i; s !== null; ) {
                if (s === e) {
                  s = null;
                  break;
                }
                if (i = s.sibling, i !== null) {
                  i.return = s.return, s = i;
                  break;
                }
                s = s.return;
              }
              i = s;
            }
            Ft(t, e, o.children, r), e = e.child;
          }
          return e;
        case 9:
          return o = e.type, n = e.pendingProps.children, hs(e, r), o = Ar(o), n = n(o), e.flags |= 1, Ft(t, e, n, r), e.child;
        case 14:
          return n = e.type, o = zr(n, e.pendingProps), o = zr(n.type, o), A_(t, e, n, o, r);
        case 15:
          return c0(t, e, e.type, e.pendingProps, r);
        case 17:
          return n = e.type, o = e.pendingProps, o = e.elementType === n ? o : zr(n, o), Sc(t, e), e.tag = 1, Kt(n) ? (t = true, Fc(e)) : t = false, hs(e, r), a0(e, n, o), Bm(e, n, o, r), zm(null, e, n, true, t, r);
        case 19:
          return d0(t, e, r);
        case 22:
          return p0(t, e, r);
      }
      throw Error(F(156, e.tag));
    };
    function D0(t, e) {
      return ov(t, e);
    }
    function ZN(t, e, r, n) {
      this.tag = t, this.key = r, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = e, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = n, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
    }
    function Sr(t, e, r, n) {
      return new ZN(t, e, r, n);
    }
    function Bd(t) {
      return t = t.prototype, !(!t || !t.isReactComponent);
    }
    function JN(t) {
      if (typeof t == "function") return Bd(t) ? 1 : 0;
      if (t != null) {
        if (t = t.$$typeof, t === od) return 11;
        if (t === id) return 14;
      }
      return 2;
    }
    function wo(t, e) {
      var r = t.alternate;
      return r === null ? (r = Sr(t.tag, e, t.key, t.mode), r.elementType = t.elementType, r.type = t.type, r.stateNode = t.stateNode, r.alternate = t, t.alternate = r) : (r.pendingProps = e, r.type = t.type, r.flags = 0, r.subtreeFlags = 0, r.deletions = null), r.flags = t.flags & 14680064, r.childLanes = t.childLanes, r.lanes = t.lanes, r.child = t.child, r.memoizedProps = t.memoizedProps, r.memoizedState = t.memoizedState, r.updateQueue = t.updateQueue, e = t.dependencies, r.dependencies = e === null ? null : { lanes: e.lanes, firstContext: e.firstContext }, r.sibling = t.sibling, r.index = t.index, r.ref = t.ref, r;
    }
    function Cc(t, e, r, n, o, i) {
      var s = 2;
      if (n = t, typeof t == "function") Bd(t) && (s = 1);
      else if (typeof t == "string") s = 5;
      else e: switch (t) {
        case Ki:
          return ai(r.children, o, i, e);
        case nd:
          s = 8, o |= 8;
          break;
        case um:
          return t = Sr(12, r, e, o | 2), t.elementType = um, t.lanes = i, t;
        case cm:
          return t = Sr(13, r, e, o), t.elementType = cm, t.lanes = i, t;
        case pm:
          return t = Sr(19, r, e, o), t.elementType = pm, t.lanes = i, t;
        case q_:
          return sp(r, o, i, e);
        default:
          if (typeof t == "object" && t !== null) switch (t.$$typeof) {
            case B_:
              s = 10;
              break e;
            case j_:
              s = 9;
              break e;
            case od:
              s = 11;
              break e;
            case id:
              s = 14;
              break e;
            case ao:
              s = 16, n = null;
              break e;
          }
          throw Error(F(130, t == null ? t : typeof t, ""));
      }
      return e = Sr(s, r, e, o), e.elementType = t, e.type = n, e.lanes = i, e;
    }
    function ai(t, e, r, n) {
      return t = Sr(7, t, n, e), t.lanes = r, t;
    }
    function sp(t, e, r, n) {
      return t = Sr(22, t, n, e), t.elementType = q_, t.lanes = r, t.stateNode = { isHidden: false }, t;
    }
    function sm(t, e, r) {
      return t = Sr(6, t, null, e), t.lanes = r, t;
    }
    function am(t, e, r) {
      return e = Sr(4, t.children !== null ? t.children : [], t.key, e), e.lanes = r, e.stateNode = { containerInfo: t.containerInfo, pendingChildren: null, implementation: t.implementation }, e;
    }
    function eO(t, e, r, n, o) {
      this.tag = e, this.containerInfo = t, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Uf(0), this.expirationTimes = Uf(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Uf(0), this.identifierPrefix = n, this.onRecoverableError = o, this.mutableSourceEagerHydrationData = null;
    }
    function jd(t, e, r, n, o, i, s, a, l) {
      return t = new eO(t, e, r, a, l), e === 1 ? (e = 1, i === true && (e |= 8)) : e = 0, i = Sr(3, null, null, e), t.current = i, i.stateNode = t, i.memoizedState = { element: n, isDehydrated: r, cache: null, transitions: null, pendingSuspenseBoundaries: null }, Td(i), t;
    }
    function tO(t, e, r) {
      var n = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
      return { $$typeof: Qi, key: n == null ? null : "" + n, children: t, containerInfo: e, implementation: r };
    }
    function M0(t) {
      if (!t) return To;
      t = t._reactInternals;
      e: {
        if (mi(t) !== t || t.tag !== 1) throw Error(F(170));
        var e = t;
        do {
          switch (e.tag) {
            case 3:
              e = e.stateNode.context;
              break e;
            case 1:
              if (Kt(e.type)) {
                e = e.stateNode.__reactInternalMemoizedMergedChildContext;
                break e;
              }
          }
          e = e.return;
        } while (e !== null);
        throw Error(F(171));
      }
      if (t.tag === 1) {
        var r = t.type;
        if (Kt(r)) return Mv(t, r, e);
      }
      return e;
    }
    function P0(t, e, r, n, o, i, s, a, l) {
      return t = jd(r, n, true, t, o, i, s, a, l), t.context = M0(null), r = t.current, n = It(), o = vo(r), i = Fn(n, o), i.callback = e ?? null, yo(r, i, o), t.current.lanes = o, xl(t, o, n), Zt(t, n), t;
    }
    function ap(t, e, r, n) {
      var o = e.current, i = It(), s = vo(o);
      return r = M0(r), e.context === null ? e.context = r : e.pendingContext = r, e = Fn(i, s), e.payload = { element: t }, n = n === void 0 ? null : n, n !== null && (e.callback = n), t = yo(o, e, s), t !== null && (Hr(t, o, s, i), _c(t, o, s)), s;
    }
    function Yc(t) {
      if (t = t.current, !t.child) return null;
      switch (t.child.tag) {
        case 5:
          return t.child.stateNode;
        default:
          return t.child.stateNode;
      }
    }
    function F_(t, e) {
      if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
        var r = t.retryLane;
        t.retryLane = r !== 0 && r < e ? r : e;
      }
    }
    function qd(t, e) {
      F_(t, e), (t = t.alternate) && F_(t, e);
    }
    function rO() {
      return null;
    }
    var R0 = typeof reportError == "function" ? reportError : function(t) {
      console.error(t);
    };
    function zd(t) {
      this._internalRoot = t;
    }
    lp.prototype.render = zd.prototype.render = function(t) {
      var e = this._internalRoot;
      if (e === null) throw Error(F(409));
      ap(t, e, null, null);
    };
    lp.prototype.unmount = zd.prototype.unmount = function() {
      var t = this._internalRoot;
      if (t !== null) {
        this._internalRoot = null;
        var e = t.containerInfo;
        hi(function() {
          ap(null, t, null, null);
        }), e[Ln] = null;
      }
    };
    function lp(t) {
      this._internalRoot = t;
    }
    lp.prototype.unstable_scheduleHydration = function(t) {
      if (t) {
        var e = pv();
        t = { blockedOn: null, target: t, priority: e };
        for (var r = 0; r < uo.length && e !== 0 && e < uo[r].priority; r++) ;
        uo.splice(r, 0, t), r === 0 && fv(t);
      }
    };
    function Wd(t) {
      return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11);
    }
    function up(t) {
      return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11 && (t.nodeType !== 8 || t.nodeValue !== " react-mount-point-unstable "));
    }
    function I_() {
    }
    function nO(t, e, r, n, o) {
      if (o) {
        if (typeof n == "function") {
          var i = n;
          n = function() {
            var u = Yc(s);
            i.call(u);
          };
        }
        var s = P0(e, n, t, 0, null, false, false, "", I_);
        return t._reactRootContainer = s, t[Ln] = s.current, ll(t.nodeType === 8 ? t.parentNode : t), hi(), s;
      }
      for (; o = t.lastChild; ) t.removeChild(o);
      if (typeof n == "function") {
        var a = n;
        n = function() {
          var u = Yc(l);
          a.call(u);
        };
      }
      var l = jd(t, 0, false, null, null, false, false, "", I_);
      return t._reactRootContainer = l, t[Ln] = l.current, ll(t.nodeType === 8 ? t.parentNode : t), hi(function() {
        ap(e, l, r, n);
      }), l;
    }
    function cp(t, e, r, n, o) {
      var i = r._reactRootContainer;
      if (i) {
        var s = i;
        if (typeof o == "function") {
          var a = o;
          o = function() {
            var l = Yc(s);
            a.call(l);
          };
        }
        ap(e, s, t, o);
      } else s = nO(r, e, t, o, n);
      return Yc(s);
    }
    uv = function(t) {
      switch (t.tag) {
        case 3:
          var e = t.stateNode;
          if (e.current.memoizedState.isDehydrated) {
            var r = Wa(e.pendingLanes);
            r !== 0 && (ld(e, r | 1), Zt(e, Xe()), !(pe & 6) && (vs = Xe() + 500, ko()));
          }
          break;
        case 13:
          hi(function() {
            var n = Bn(t, 1);
            if (n !== null) {
              var o = It();
              Hr(n, t, 1, o);
            }
          }), qd(t, 1);
      }
    };
    ud = function(t) {
      if (t.tag === 13) {
        var e = Bn(t, 134217728);
        if (e !== null) {
          var r = It();
          Hr(e, t, 134217728, r);
        }
        qd(t, 134217728);
      }
    };
    cv = function(t) {
      if (t.tag === 13) {
        var e = vo(t), r = Bn(t, e);
        if (r !== null) {
          var n = It();
          Hr(r, t, e, n);
        }
        qd(t, e);
      }
    };
    pv = function() {
      return _e;
    };
    hv = function(t, e) {
      var r = _e;
      try {
        return _e = t, e();
      } finally {
        _e = r;
      }
    };
    wm = function(t, e, r) {
      switch (e) {
        case "input":
          if (mm(t, r), e = r.name, r.type === "radio" && e != null) {
            for (r = t; r.parentNode; ) r = r.parentNode;
            for (r = r.querySelectorAll("input[name=" + JSON.stringify("" + e) + '][type="radio"]'), e = 0; e < r.length; e++) {
              var n = r[e];
              if (n !== t && n.form === t.form) {
                var o = ep(n);
                if (!o) throw Error(F(90));
                W_(n), mm(n, o);
              }
            }
          }
          break;
        case "textarea":
          G_(t, r);
          break;
        case "select":
          e = r.value, e != null && ls(t, !!r.multiple, e, false);
      }
    };
    Z_ = Fd;
    J_ = hi;
    var oO = { usingClientEntryPoint: false, Events: [_l, ts, ep, Q_, K_, Fd] }, Ba = { findFiberByHostInstance: ni, bundleType: 0, version: "18.3.1", rendererPackageName: "react-dom" }, iO = { bundleType: Ba.bundleType, version: Ba.version, rendererPackageName: Ba.rendererPackageName, rendererConfig: Ba.rendererConfig, overrideHookState: null, overrideHookStateDeletePath: null, overrideHookStateRenamePath: null, overrideProps: null, overridePropsDeletePath: null, overridePropsRenamePath: null, setErrorHandler: null, setSuspenseHandler: null, scheduleUpdate: null, currentDispatcherRef: qn.ReactCurrentDispatcher, findHostInstanceByFiber: function(t) {
      return t = rv(t), t === null ? null : t.stateNode;
    }, findFiberByHostInstance: Ba.findFiberByHostInstance || rO, findHostInstancesForRefresh: null, scheduleRefresh: null, scheduleRoot: null, setRefreshHandler: null, getCurrentFiber: null, reconcilerVersion: "18.3.1-next-f1338f8080-20240426" };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && (ja = __REACT_DEVTOOLS_GLOBAL_HOOK__, !ja.isDisabled && ja.supportsFiber)) try {
      Qc = ja.inject(iO), mn = ja;
    } catch {
    }
    var ja;
    ur.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = oO;
    ur.createPortal = function(t, e) {
      var r = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!Wd(e)) throw Error(F(200));
      return tO(t, e, null, r);
    };
    ur.createRoot = function(t, e) {
      if (!Wd(t)) throw Error(F(299));
      var r = false, n = "", o = R0;
      return e != null && (e.unstable_strictMode === true && (r = true), e.identifierPrefix !== void 0 && (n = e.identifierPrefix), e.onRecoverableError !== void 0 && (o = e.onRecoverableError)), e = jd(t, 1, false, null, null, r, false, n, o), t[Ln] = e.current, ll(t.nodeType === 8 ? t.parentNode : t), new zd(e);
    };
    ur.findDOMNode = function(t) {
      if (t == null) return null;
      if (t.nodeType === 1) return t;
      var e = t._reactInternals;
      if (e === void 0) throw typeof t.render == "function" ? Error(F(188)) : (t = Object.keys(t).join(","), Error(F(268, t)));
      return t = rv(e), t = t === null ? null : t.stateNode, t;
    };
    ur.flushSync = function(t) {
      return hi(t);
    };
    ur.hydrate = function(t, e, r) {
      if (!up(e)) throw Error(F(200));
      return cp(null, t, e, true, r);
    };
    ur.hydrateRoot = function(t, e, r) {
      if (!Wd(t)) throw Error(F(405));
      var n = r != null && r.hydratedSources || null, o = false, i = "", s = R0;
      if (r != null && (r.unstable_strictMode === true && (o = true), r.identifierPrefix !== void 0 && (i = r.identifierPrefix), r.onRecoverableError !== void 0 && (s = r.onRecoverableError)), e = P0(e, null, t, 1, r ?? null, o, false, i, s), t[Ln] = e.current, ll(t), n) for (t = 0; t < n.length; t++) r = n[t], o = r._getVersion, o = o(r._source), e.mutableSourceEagerHydrationData == null ? e.mutableSourceEagerHydrationData = [r, o] : e.mutableSourceEagerHydrationData.push(r, o);
      return new lp(e);
    };
    ur.render = function(t, e, r) {
      if (!up(e)) throw Error(F(200));
      return cp(null, t, e, false, r);
    };
    ur.unmountComponentAtNode = function(t) {
      if (!up(t)) throw Error(F(40));
      return t._reactRootContainer ? (hi(function() {
        cp(null, null, t, false, function() {
          t._reactRootContainer = null, t[Ln] = null;
        });
      }), true) : false;
    };
    ur.unstable_batchedUpdates = Fd;
    ur.unstable_renderSubtreeIntoContainer = function(t, e, r, n) {
      if (!up(r)) throw Error(F(200));
      if (t == null || t._reactInternals === void 0) throw Error(F(38));
      return cp(t, e, r, false, n);
    };
    ur.version = "18.3.1-next-f1338f8080-20240426";
  });
  var L0 = $e((OV, I0) => {
    "use strict";
    function F0() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(F0);
      } catch (t) {
        console.error(t);
      }
    }
    F0(), I0.exports = V0();
  });
  var j0 = $e((Ud) => {
    "use strict";
    var B0 = L0();
    Ud.createRoot = B0.createRoot, Ud.hydrateRoot = B0.hydrateRoot;
    var DV;
  });
  var q0 = $e((RV, Sl) => {
    function sO(t) {
      if (Array.isArray(t)) return t;
    }
    Sl.exports = sO, Sl.exports.__esModule = true, Sl.exports.default = Sl.exports;
  });
  var z0 = $e((VV, Tl) => {
    function aO(t, e) {
      var r = t == null ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
      if (r != null) {
        var n, o, i, s, a = [], l = true, u = false;
        try {
          if (i = (r = r.call(t)).next, e === 0) {
            if (Object(r) !== r) return;
            l = false;
          } else for (; !(l = (n = i.call(r)).done) && (a.push(n.value), a.length !== e); l = true) ;
        } catch (c) {
          u = true, o = c;
        } finally {
          try {
            if (!l && r.return != null && (s = r.return(), Object(s) !== s)) return;
          } finally {
            if (u) throw o;
          }
        }
        return a;
      }
    }
    Tl.exports = aO, Tl.exports.__esModule = true, Tl.exports.default = Tl.exports;
  });
  var W0 = $e((FV, Al) => {
    function lO(t, e) {
      (e == null || e > t.length) && (e = t.length);
      for (var r = 0, n = Array(e); r < e; r++) n[r] = t[r];
      return n;
    }
    Al.exports = lO, Al.exports.__esModule = true, Al.exports.default = Al.exports;
  });
  var G0 = $e((IV, Cl) => {
    var U0 = W0();
    function uO(t, e) {
      if (t) {
        if (typeof t == "string") return U0(t, e);
        var r = {}.toString.call(t).slice(8, -1);
        return r === "Object" && t.constructor && (r = t.constructor.name), r === "Map" || r === "Set" ? Array.from(t) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? U0(t, e) : void 0;
      }
    }
    Cl.exports = uO, Cl.exports.__esModule = true, Cl.exports.default = Cl.exports;
  });
  var H0 = $e((LV, kl) => {
    function cO() {
      throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
    }
    kl.exports = cO, kl.exports.__esModule = true, kl.exports.default = kl.exports;
  });
  var $0 = $e((BV, El) => {
    var pO = q0(), hO = z0(), fO = G0(), mO = H0();
    function dO(t, e) {
      return pO(t) || hO(t, e) || fO(t, e) || mO();
    }
    El.exports = dO, El.exports.__esModule = true, El.exports.default = El.exports;
  });
  var X0 = $e((jV, bl) => {
    function gO(t, e) {
      if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
    }
    bl.exports = gO, bl.exports.__esModule = true, bl.exports.default = bl.exports;
  });
  var Hd = $e((qV, zn) => {
    function Gd(t) {
      "@babel/helpers - typeof";
      return zn.exports = Gd = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e;
      } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
      }, zn.exports.__esModule = true, zn.exports.default = zn.exports, Gd(t);
    }
    zn.exports = Gd, zn.exports.__esModule = true, zn.exports.default = zn.exports;
  });
  var Q0 = $e((zV, Nl) => {
    var Y0 = Hd().default;
    function xO(t, e) {
      if (Y0(t) != "object" || !t) return t;
      var r = t[Symbol.toPrimitive];
      if (r !== void 0) {
        var n = r.call(t, e || "default");
        if (Y0(n) != "object") return n;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (e === "string" ? String : Number)(t);
    }
    Nl.exports = xO, Nl.exports.__esModule = true, Nl.exports.default = Nl.exports;
  });
  var K0 = $e((WV, Ol) => {
    var yO = Hd().default, _O = Q0();
    function vO(t) {
      var e = _O(t, "string");
      return yO(e) == "symbol" ? e : e + "";
    }
    Ol.exports = vO, Ol.exports.__esModule = true, Ol.exports.default = Ol.exports;
  });
  var J0 = $e((UV, Dl) => {
    var wO = K0();
    function Z0(t, e) {
      for (var r = 0; r < e.length; r++) {
        var n = e[r];
        n.enumerable = n.enumerable || false, n.configurable = true, "value" in n && (n.writable = true), Object.defineProperty(t, wO(n.key), n);
      }
    }
    function SO(t, e, r) {
      return e && Z0(t.prototype, e), r && Z0(t, r), Object.defineProperty(t, "prototype", { writable: false }), t;
    }
    Dl.exports = SO, Dl.exports.__esModule = true, Dl.exports.default = Dl.exports;
  });
  var $d = $e((pp, ew) => {
    (function(t, e) {
      typeof pp == "object" && typeof ew < "u" ? e(pp, $0(), X0(), J0()) : typeof define == "function" && define.amd ? define(["exports", "@babel/runtime/helpers/slicedToArray", "@babel/runtime/helpers/classCallCheck", "@babel/runtime/helpers/createClass"], e) : (t = typeof globalThis < "u" ? globalThis : t || self, e(t.automationEvents = {}, t._slicedToArray, t._classCallCheck, t._createClass));
    })(pp, function(t, e, r, n) {
      "use strict";
      var o = function(C, E, O) {
        return { endTime: E, insertTime: O, type: "exponentialRampToValue", value: C };
      }, i = function(C, E, O) {
        return { endTime: E, insertTime: O, type: "linearRampToValue", value: C };
      }, s = function(C, E) {
        return { startTime: E, type: "setValue", value: C };
      }, a = function(C, E, O) {
        return { duration: O, startTime: E, type: "setValueCurve", values: C };
      }, l = function(C, E, O) {
        var R = O.startTime, P = O.target, V = O.timeConstant;
        return P + (E - P) * Math.exp((R - C) / V);
      }, u = function(C) {
        return C.type === "exponentialRampToValue";
      }, c = function(C) {
        return C.type === "linearRampToValue";
      }, p = function(C) {
        return u(C) || c(C);
      }, h = function(C) {
        return C.type === "setValue";
      }, f = function(C) {
        return C.type === "setValueCurve";
      }, m = function(C, E, O, R) {
        var P = C[E];
        return P === void 0 ? R : p(P) || h(P) ? P.value : f(P) ? P.values[P.values.length - 1] : l(O, m(C, E - 1, P.startTime, R), P);
      }, x = function(C, E, O, R, P) {
        return O === void 0 ? [R.insertTime, P] : p(O) ? [O.endTime, O.value] : h(O) ? [O.startTime, O.value] : f(O) ? [O.startTime + O.duration, O.values[O.values.length - 1]] : [O.startTime, m(C, E - 1, O.startTime, P)];
      }, _ = function(C) {
        return C.type === "cancelAndHold";
      }, d = function(C) {
        return C.type === "cancelScheduledValues";
      }, g = function(C) {
        return _(C) || d(C) ? C.cancelTime : u(C) || c(C) ? C.endTime : C.startTime;
      }, y = function(C, E, O, R) {
        var P = R.endTime, V = R.value;
        return O === V ? V : 0 < O && 0 < V || O < 0 && V < 0 ? O * Math.pow(V / O, (C - E) / (P - E)) : C < P ? O : V;
      }, S = function(C, E, O, R) {
        var P = R.endTime, V = R.value;
        return O + (C - E) / (P - E) * (V - O);
      }, v = function(C, E) {
        var O = Math.floor(E);
        if (O === E) return C[O];
        var R = Math.ceil(E);
        return (1 - (E - O)) * C[O] + (1 - (R - E)) * C[R];
      }, T = function(C, E) {
        var O = E.duration, R = E.startTime, P = E.values, V = (C - R) / O * (P.length - 1);
        return v(P, V);
      }, A = function(C, E, O) {
        for (var R = C.length, P = Math.max(1, Math.floor(O / E * R)) + 1, V = C instanceof Float32Array ? new Float32Array(P) : C.slice(0, P), te = 0; te < P; te += 1) {
          var j = te / (P - 1) * O, re = j / E * (R - 1);
          V[te] = v(C, re);
        }
        return V;
      }, w = function(C) {
        return C.type === "setTarget";
      }, N = (function() {
        function I(C) {
          r(this, I), this._automationEvents = [], this._currenTime = 0, this._defaultValue = C;
        }
        return n(I, [{ key: Symbol.iterator, value: function() {
          return this._automationEvents[Symbol.iterator]();
        } }, { key: "add", value: function(E) {
          var O = g(E);
          if (_(E) || d(E)) {
            var R = this._automationEvents.findIndex(function(Je) {
              return d(E) && f(Je) ? Je.startTime + Je.duration >= O : g(Je) >= O;
            }), P = this._automationEvents[R];
            if (R !== -1 && (this._automationEvents = this._automationEvents.slice(0, R)), _(E)) {
              var V = this._automationEvents[this._automationEvents.length - 1];
              if (P !== void 0 && p(P)) {
                if (V !== void 0 && w(V)) throw new Error("The internal list is malformed.");
                var te = V === void 0 ? P.insertTime : f(V) ? V.startTime + V.duration : g(V), j = V === void 0 ? this._defaultValue : f(V) ? V.values[V.values.length - 1] : V.value, re = u(P) ? y(O, te, j, P) : S(O, te, j, P), Y = u(P) ? o(re, O, this._currenTime) : i(re, O, this._currenTime);
                this._automationEvents.push(Y);
              }
              if (V !== void 0 && w(V) && this._automationEvents.push(s(this.getValue(O), O)), V !== void 0 && f(V) && V.startTime + V.duration > O) {
                var K = O - V.startTime;
                this._automationEvents[this._automationEvents.length - 1] = a(A(V.values, V.duration, K), V.startTime, K);
              }
            }
          } else {
            var ue = this._automationEvents.findIndex(function(Je) {
              return g(Je) > O;
            }), W = ue === -1 ? this._automationEvents[this._automationEvents.length - 1] : this._automationEvents[ue - 1];
            if (W !== void 0 && f(W) && g(W) + W.duration > O) return false;
            var st = u(E) ? o(E.value, E.endTime, this._currenTime) : c(E) ? i(E.value, O, this._currenTime) : E;
            if (ue === -1) this._automationEvents.push(st);
            else {
              if (f(E) && O + E.duration > g(this._automationEvents[ue])) return false;
              this._automationEvents.splice(ue, 0, st);
            }
          }
          return true;
        } }, { key: "flush", value: function(E) {
          var O = this._automationEvents.findIndex(function(V) {
            return g(V) > E;
          });
          if (O > 1) {
            var R = this._automationEvents.slice(O - 1), P = R[0];
            w(P) && R.unshift(s(m(this._automationEvents, O - 2, P.startTime, this._defaultValue), P.startTime)), this._automationEvents = R;
          }
        } }, { key: "getValue", value: function(E) {
          if (this._automationEvents.length === 0) return this._defaultValue;
          var O = this._automationEvents.findIndex(function(Je) {
            return g(Je) > E;
          }), R = this._automationEvents[O], P = (O === -1 ? this._automationEvents.length : O) - 1, V = this._automationEvents[P];
          if (V !== void 0 && w(V) && (R === void 0 || !p(R) || R.insertTime > E)) return l(E, m(this._automationEvents, P - 1, V.startTime, this._defaultValue), V);
          if (V !== void 0 && h(V) && (R === void 0 || !p(R))) return V.value;
          if (V !== void 0 && f(V) && (R === void 0 || !p(R) || V.startTime + V.duration > E)) return E < V.startTime + V.duration ? T(E, V) : V.values[V.values.length - 1];
          if (V !== void 0 && p(V) && (R === void 0 || !p(R))) return V.value;
          if (R !== void 0 && u(R)) {
            var te = x(this._automationEvents, P, V, R, this._defaultValue), j = e(te, 2), re = j[0], Y = j[1];
            return y(E, re, Y, R);
          }
          if (R !== void 0 && c(R)) {
            var K = x(this._automationEvents, P, V, R, this._defaultValue), ue = e(K, 2), W = ue[0], st = ue[1];
            return S(E, W, st, R);
          }
          return this._defaultValue;
        } }]);
      })(), k = function(C) {
        return { cancelTime: C, type: "cancelAndHold" };
      }, D = function(C) {
        return { cancelTime: C, type: "cancelScheduledValues" };
      }, M = function(C, E) {
        return { endTime: E, type: "exponentialRampToValue", value: C };
      }, q = function(C, E) {
        return { endTime: E, type: "linearRampToValue", value: C };
      }, B = function(C, E, O) {
        return { startTime: E, target: C, timeConstant: O, type: "setTarget" };
      };
      t.AutomationEventList = N, t.createCancelAndHoldAutomationEvent = k, t.createCancelScheduledValuesAutomationEvent = D, t.createExponentialRampToValueAutomationEvent = M, t.createLinearRampToValueAutomationEvent = q, t.createSetTargetAutomationEvent = B, t.createSetValueAutomationEvent = s, t.createSetValueCurveAutomationEvent = a;
    });
  });
  var vA = $e((Zp) => {
    "use strict";
    var PM = xe(), RM = Symbol.for("react.element"), VM = Symbol.for("react.fragment"), FM = Object.prototype.hasOwnProperty, IM = PM.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, LM = { key: true, ref: true, __self: true, __source: true };
    function _A(t, e, r) {
      var n, o = {}, i = null, s = null;
      r !== void 0 && (i = "" + r), e.key !== void 0 && (i = "" + e.key), e.ref !== void 0 && (s = e.ref);
      for (n in e) FM.call(e, n) && !LM.hasOwnProperty(n) && (o[n] = e[n]);
      if (t && t.defaultProps) for (n in e = t.defaultProps, e) o[n] === void 0 && (o[n] = e[n]);
      return { $$typeof: RM, type: t, key: i, ref: s, props: o, _owner: IM.current };
    }
    Zp.Fragment = VM;
    Zp.jsx = _A;
    Zp.jsxs = _A;
  });
  var Io = $e((Txe, wA) => {
    "use strict";
    wA.exports = vA();
  });
  var ge = se(xe()), RE = se(j0());
  var wl = "15.1.22";
  var Jt = se($d());
  var tw = () => new DOMException("", "AbortError");
  var rw = (t) => (e, r, [n, o, i], s) => {
    t(e[o], [r, n, i], (a) => a[0] === r && a[1] === n, s);
  };
  var nw = (t) => (e, r, n) => {
    let o = [];
    for (let i = 0; i < n.numberOfInputs; i += 1) o.push(/* @__PURE__ */ new Set());
    t.set(e, { activeInputs: o, outputs: /* @__PURE__ */ new Set(), passiveInputs: /* @__PURE__ */ new WeakMap(), renderer: r });
  };
  var ow = (t) => (e, r) => {
    t.set(e, { activeInputs: /* @__PURE__ */ new Set(), passiveInputs: /* @__PURE__ */ new WeakMap(), renderer: r });
  };
  var gn = /* @__PURE__ */ new WeakSet(), hp = /* @__PURE__ */ new WeakMap(), Ts = /* @__PURE__ */ new WeakMap(), fp = /* @__PURE__ */ new WeakMap(), Ml = /* @__PURE__ */ new WeakMap(), As = /* @__PURE__ */ new WeakMap(), mp = /* @__PURE__ */ new WeakMap(), Pl = /* @__PURE__ */ new WeakMap(), Rl = /* @__PURE__ */ new WeakMap(), Vl = /* @__PURE__ */ new WeakMap();
  var iw = { construct() {
    return iw;
  } }, sw = (t) => {
    try {
      let e = new Proxy(t, iw);
      new e();
    } catch {
      return false;
    }
    return true;
  };
  var aw = /^import(?:(?:[\s]+[\w]+|(?:[\s]+[\w]+[\s]*,)?[\s]*\{[\s]*[\w]+(?:[\s]+as[\s]+[\w]+)?(?:[\s]*,[\s]*[\w]+(?:[\s]+as[\s]+[\w]+)?)*[\s]*}|(?:[\s]+[\w]+[\s]*,)?[\s]*\*[\s]+as[\s]+[\w]+)[\s]+from)?(?:[\s]*)("([^"\\]|\\.)+"|'([^'\\]|\\.)+')(?:[\s]*);?/, Xd = (t, e) => {
    let r = [], n = t.replace(/^[\s]+/, ""), o = n.match(aw);
    for (; o !== null; ) {
      let i = o[1].slice(1, -1), s = o[0].replace(/([\s]+)?;?$/, "").replace(i, new URL(i, e).toString());
      r.push(s), n = n.slice(o[0].length).replace(/^[\s]+/, ""), o = n.match(aw);
    }
    return [r.join(";"), n];
  };
  var lw = (t) => {
    if (t !== void 0 && !Array.isArray(t)) throw new TypeError("The parameterDescriptors property of given value for processorCtor is not an array.");
  }, uw = (t) => {
    if (!sw(t)) throw new TypeError("The given value for processorCtor should be a constructor.");
    if (t.prototype === null || typeof t.prototype != "object") throw new TypeError("The given value for processorCtor should have a prototype.");
  }, cw = (t, e, r, n, o, i, s, a, l, u, c, p, h) => {
    let f = 0;
    return (m, x, _ = { credentials: "omit" }) => {
      let d = c.get(m);
      if (d !== void 0 && d.has(x)) return Promise.resolve();
      let g = u.get(m);
      if (g !== void 0) {
        let v = g.get(x);
        if (v !== void 0) return v;
      }
      let y = i(m), S = y.audioWorklet === void 0 ? o(x).then(([v, T]) => {
        let [A, w] = Xd(v, T), N = `${A};((a,b)=>{(a[b]=a[b]||[]).push((AudioWorkletProcessor,global,registerProcessor,sampleRate,self,window)=>{${w}
})})(window,'_AWGS')`;
        return r(N);
      }).then(() => {
        let v = h._AWGS.pop();
        if (v === void 0) throw new SyntaxError();
        n(y.currentTime, y.sampleRate, () => v(class {
        }, void 0, (T, A) => {
          if (T.trim() === "") throw e();
          let w = Rl.get(y);
          if (w !== void 0) {
            if (w.has(T)) throw e();
            uw(A), lw(A.parameterDescriptors), w.set(T, A);
          } else uw(A), lw(A.parameterDescriptors), Rl.set(y, /* @__PURE__ */ new Map([[T, A]]));
        }, y.sampleRate, void 0, void 0));
      }) : Promise.all([o(x), Promise.resolve(t(p, p))]).then(([[v, T], A]) => {
        let w = f + 1;
        f = w;
        let [N, k] = Xd(v, T), B = `${N};((AudioWorkletProcessor,registerProcessor)=>{${k}
})(${A ? "AudioWorkletProcessor" : "class extends AudioWorkletProcessor {__b=new WeakSet();constructor(){super();(p=>p.postMessage=(q=>(m,t)=>q.call(p,m,t?t.filter(u=>!this.__b.has(u)):t))(p.postMessage))(this.port)}}"},(n,p)=>registerProcessor(n,class extends p{${A ? "" : "__c = (a) => a.forEach(e=>this.__b.add(e.buffer));"}process(i,o,p){${A ? "" : "i.forEach(this.__c);o.forEach(this.__c);this.__c(Object.values(p));"}return super.process(i.map(j=>j.some(k=>k.length===0)?[]:j),o,p)}}));registerProcessor('__sac${w}',class extends AudioWorkletProcessor{process(){return !1}})`, I = new Blob([B], { type: "application/javascript; charset=utf-8" }), C = URL.createObjectURL(I);
        return y.audioWorklet.addModule(C, _).then(() => {
          if (a(y)) return y;
          let E = s(y);
          return E.audioWorklet.addModule(C, _).then(() => E);
        }).then((E) => {
          if (l === null) throw new SyntaxError();
          try {
            new l(E, `__sac${w}`);
          } catch {
            throw new SyntaxError();
          }
        }).finally(() => URL.revokeObjectURL(C));
      });
      return g === void 0 ? u.set(m, /* @__PURE__ */ new Map([[x, S]])) : g.set(x, S), S.then(() => {
        let v = c.get(m);
        v === void 0 ? c.set(m, /* @__PURE__ */ new Set([x])) : v.add(x);
      }).finally(() => {
        let v = u.get(m);
        v !== void 0 && v.delete(x);
      }), S;
    };
  };
  var tt = (t, e) => {
    let r = t.get(e);
    if (r === void 0) throw new Error("A value with the given key could not be found.");
    return r;
  };
  var Eo = (t, e) => {
    let r = Array.from(t).filter(e);
    if (r.length > 1) throw Error("More than one element was found.");
    if (r.length === 0) throw Error("No element was found.");
    let [n] = r;
    return t.delete(n), n;
  };
  var dp = (t, e, r, n) => {
    let o = tt(t, e), i = Eo(o, (s) => s[0] === r && s[1] === n);
    return o.size === 0 && t.delete(e), i;
  };
  var xn = (t) => tt(mp, t);
  var Xr = (t) => {
    if (gn.has(t)) throw new Error("The AudioNode is already stored.");
    gn.add(t), xn(t).forEach((e) => e(true));
  };
  var gp = (t) => "port" in t;
  var yn = (t) => {
    if (!gn.has(t)) throw new Error("The AudioNode is not stored.");
    gn.delete(t), xn(t).forEach((e) => e(false));
  };
  var Fl = (t, e) => {
    !gp(t) && e.every((r) => r.size === 0) && yn(t);
  };
  var pw = (t, e, r, n, o, i, s, a, l, u, c, p, h) => {
    let f = /* @__PURE__ */ new WeakMap();
    return (m, x, _, d, g) => {
      let { activeInputs: y, passiveInputs: S } = i(x), { outputs: v } = i(m), T = a(m), A = (w) => {
        let N = l(x), k = l(m);
        if (w) {
          let D = dp(S, m, _, d);
          t(y, m, D, false), !g && !p(m) && r(k, N, _, d), h(x) && Xr(x);
        } else {
          let D = n(y, m, _, d);
          e(S, d, D, false), !g && !p(m) && o(k, N, _, d);
          let M = s(x);
          if (M === 0) c(x) && Fl(x, y);
          else {
            let q = f.get(x);
            q !== void 0 && clearTimeout(q), f.set(x, setTimeout(() => {
              c(x) && Fl(x, y);
            }, M * 1e3));
          }
        }
      };
      return u(v, [x, _, d], (w) => w[0] === x && w[1] === _ && w[2] === d, true) ? (T.add(A), c(m) ? t(y, m, [_, d, A], true) : e(S, d, [m, _, A], true), true) : false;
    };
  };
  var hw = (t) => (e, r, [n, o, i], s) => {
    let a = e.get(n);
    a === void 0 ? e.set(n, /* @__PURE__ */ new Set([[o, r, i]])) : t(a, [o, r, i], (l) => l[0] === o && l[1] === r, s);
  };
  var fw = (t) => (e, r) => {
    let n = t(e, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", gain: 0 });
    r.connect(n).connect(e.destination);
    let o = () => {
      r.removeEventListener("ended", o), r.disconnect(n), n.disconnect();
    };
    r.addEventListener("ended", o);
  };
  var mw = (t) => (e, r) => {
    t(e).add(r);
  };
  var TO = { channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", fftSize: 2048, maxDecibels: -30, minDecibels: -100, smoothingTimeConstant: 0.8 }, dw = (t, e, r, n, o, i) => class extends t {
    constructor(a, l) {
      let u = o(a), c = { ...TO, ...l }, p = n(u, c), h = i(u) ? e() : null;
      super(a, false, p, h), this._nativeAnalyserNode = p;
    }
    get fftSize() {
      return this._nativeAnalyserNode.fftSize;
    }
    set fftSize(a) {
      this._nativeAnalyserNode.fftSize = a;
    }
    get frequencyBinCount() {
      return this._nativeAnalyserNode.frequencyBinCount;
    }
    get maxDecibels() {
      return this._nativeAnalyserNode.maxDecibels;
    }
    set maxDecibels(a) {
      let l = this._nativeAnalyserNode.maxDecibels;
      if (this._nativeAnalyserNode.maxDecibels = a, !(a > this._nativeAnalyserNode.minDecibels)) throw this._nativeAnalyserNode.maxDecibels = l, r();
    }
    get minDecibels() {
      return this._nativeAnalyserNode.minDecibels;
    }
    set minDecibels(a) {
      let l = this._nativeAnalyserNode.minDecibels;
      if (this._nativeAnalyserNode.minDecibels = a, !(this._nativeAnalyserNode.maxDecibels > a)) throw this._nativeAnalyserNode.minDecibels = l, r();
    }
    get smoothingTimeConstant() {
      return this._nativeAnalyserNode.smoothingTimeConstant;
    }
    set smoothingTimeConstant(a) {
      this._nativeAnalyserNode.smoothingTimeConstant = a;
    }
    getByteFrequencyData(a) {
      this._nativeAnalyserNode.getByteFrequencyData(a);
    }
    getByteTimeDomainData(a) {
      this._nativeAnalyserNode.getByteTimeDomainData(a);
    }
    getFloatFrequencyData(a) {
      this._nativeAnalyserNode.getFloatFrequencyData(a);
    }
    getFloatTimeDomainData(a) {
      this._nativeAnalyserNode.getFloatTimeDomainData(a);
    }
  };
  var he = (t, e) => t.context === e;
  var gw = (t, e, r) => () => {
    let n = /* @__PURE__ */ new WeakMap(), o = async (i, s) => {
      let a = e(i);
      if (!he(a, s)) {
        let u = { channelCount: a.channelCount, channelCountMode: a.channelCountMode, channelInterpretation: a.channelInterpretation, fftSize: a.fftSize, maxDecibels: a.maxDecibels, minDecibels: a.minDecibels, smoothingTimeConstant: a.smoothingTimeConstant };
        a = t(s, u);
      }
      return n.set(s, a), await r(i, s, a), a;
    };
    return { render(i, s) {
      let a = n.get(s);
      return a !== void 0 ? Promise.resolve(a) : o(i, s);
    } };
  };
  var Cs = (t) => {
    try {
      t.copyToChannel(new Float32Array(1), 0, -1);
    } catch {
      return false;
    }
    return true;
  };
  var kr = () => new DOMException("", "IndexSizeError");
  var ks = (t) => {
    t.getChannelData = /* @__PURE__ */ ((e) => (r) => {
      try {
        return e.call(t, r);
      } catch (n) {
        throw n.code === 12 ? kr() : n;
      }
    })(t.getChannelData);
  };
  var AO = { numberOfChannels: 1 }, xw = (t, e, r, n, o, i, s, a) => {
    let l = null;
    return class yw {
      constructor(c) {
        if (o === null) throw new Error("Missing the native OfflineAudioContext constructor.");
        let { length: p, numberOfChannels: h, sampleRate: f } = { ...AO, ...c };
        l === null && (l = new o(1, 1, 44100));
        let m = n !== null && e(i, i) ? new n({ length: p, numberOfChannels: h, sampleRate: f }) : l.createBuffer(h, p, f);
        if (m.numberOfChannels === 0) throw r();
        return typeof m.copyFromChannel != "function" ? (s(m), ks(m)) : e(Cs, () => Cs(m)) || a(m), t.add(m), m;
      }
      static [Symbol.hasInstance](c) {
        return c !== null && typeof c == "object" && Object.getPrototypeOf(c) === yw.prototype || t.has(c);
      }
    };
  };
  var Ye = -34028234663852886e22, Ue = -Ye;
  var Bt = (t) => gn.has(t);
  var CO = { buffer: null, channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", loop: false, loopEnd: 0, loopStart: 0, playbackRate: 1 }, _w = (t, e, r, n, o, i, s, a) => class extends t {
    constructor(u, c) {
      let p = i(u), h = { ...CO, ...c }, f = o(p, h), m = s(p), x = m ? e() : null;
      super(u, false, f, x), this._audioBufferSourceNodeRenderer = x, this._isBufferNullified = false, this._isBufferSet = h.buffer !== null, this._nativeAudioBufferSourceNode = f, this._onended = null, this._playbackRate = r(this, m, f.playbackRate, Ue, Ye);
    }
    get buffer() {
      return this._isBufferNullified ? null : this._nativeAudioBufferSourceNode.buffer;
    }
    set buffer(u) {
      if (this._nativeAudioBufferSourceNode.buffer = u, u !== null) {
        if (this._isBufferSet) throw n();
        this._isBufferSet = true;
      }
    }
    get loop() {
      return this._nativeAudioBufferSourceNode.loop;
    }
    set loop(u) {
      this._nativeAudioBufferSourceNode.loop = u;
    }
    get loopEnd() {
      return this._nativeAudioBufferSourceNode.loopEnd;
    }
    set loopEnd(u) {
      this._nativeAudioBufferSourceNode.loopEnd = u;
    }
    get loopStart() {
      return this._nativeAudioBufferSourceNode.loopStart;
    }
    set loopStart(u) {
      this._nativeAudioBufferSourceNode.loopStart = u;
    }
    get onended() {
      return this._onended;
    }
    set onended(u) {
      let c = typeof u == "function" ? a(this, u) : null;
      this._nativeAudioBufferSourceNode.onended = c;
      let p = this._nativeAudioBufferSourceNode.onended;
      this._onended = p !== null && p === c ? u : p;
    }
    get playbackRate() {
      return this._playbackRate;
    }
    start(u = 0, c = 0, p) {
      if (this._nativeAudioBufferSourceNode.start(u, c, p), this._audioBufferSourceNodeRenderer !== null && (this._audioBufferSourceNodeRenderer.start = p === void 0 ? [u, c] : [u, c, p]), this.context.state !== "closed") {
        Xr(this);
        let h = () => {
          this._nativeAudioBufferSourceNode.removeEventListener("ended", h), Bt(this) && yn(this);
        };
        this._nativeAudioBufferSourceNode.addEventListener("ended", h);
      }
    }
    stop(u = 0) {
      this._nativeAudioBufferSourceNode.stop(u), this._audioBufferSourceNodeRenderer !== null && (this._audioBufferSourceNodeRenderer.stop = u);
    }
  };
  var vw = (t, e, r, n, o) => () => {
    let i = /* @__PURE__ */ new WeakMap(), s = null, a = null, l = async (u, c) => {
      let p = r(u), h = he(p, c);
      if (!h) {
        let f = { buffer: p.buffer, channelCount: p.channelCount, channelCountMode: p.channelCountMode, channelInterpretation: p.channelInterpretation, loop: p.loop, loopEnd: p.loopEnd, loopStart: p.loopStart, playbackRate: p.playbackRate.value };
        p = e(c, f), s !== null && p.start(...s), a !== null && p.stop(a);
      }
      return i.set(c, p), h ? await t(c, u.playbackRate, p.playbackRate) : await n(c, u.playbackRate, p.playbackRate), await o(u, c, p), p;
    };
    return { set start(u) {
      s = u;
    }, set stop(u) {
      a = u;
    }, render(u, c) {
      let p = i.get(c);
      return p !== void 0 ? Promise.resolve(p) : l(u, c);
    } };
  };
  var ww = (t) => "playbackRate" in t;
  var Sw = (t) => "frequency" in t && "gain" in t;
  var Tw = (t) => "offset" in t;
  var Aw = (t) => !("frequency" in t) && "gain" in t;
  var Cw = (t) => "detune" in t && "frequency" in t && !("gain" in t);
  var kw = (t) => "pan" in t;
  var ct = (t) => tt(hp, t);
  var bo = (t) => tt(fp, t);
  var xp = (t, e) => {
    let { activeInputs: r } = ct(t);
    r.forEach((o) => o.forEach(([i]) => {
      e.includes(t) || xp(i, [...e, t]);
    }));
    let n = ww(t) ? [t.playbackRate] : gp(t) ? Array.from(t.parameters.values()) : Sw(t) ? [t.Q, t.detune, t.frequency, t.gain] : Tw(t) ? [t.offset] : Aw(t) ? [t.gain] : Cw(t) ? [t.detune, t.frequency] : kw(t) ? [t.pan] : [];
    for (let o of n) {
      let i = bo(o);
      i !== void 0 && i.activeInputs.forEach(([s]) => xp(s, e));
    }
    Bt(t) && yn(t);
  };
  var No = (t) => {
    xp(t.destination, []);
  };
  var yp = (t) => t === void 0 || typeof t == "number" || typeof t == "string" && (t === "balanced" || t === "interactive" || t === "playback");
  var Ew = (t, e, r, n, o, i, s, a, l) => class extends t {
    constructor(c = {}) {
      if (l === null) throw new Error("Missing the native AudioContext constructor.");
      let p;
      try {
        p = new l(c);
      } catch (m) {
        throw m.code === 12 && m.message === "sampleRate is not in range" ? r() : m;
      }
      if (p === null) throw n();
      if (!yp(c.latencyHint)) throw new TypeError(`The provided value '${c.latencyHint}' is not a valid enum value of type AudioContextLatencyCategory.`);
      if (c.sampleRate !== void 0 && p.sampleRate !== c.sampleRate) throw r();
      super(p, 2);
      let { latencyHint: h } = c, { sampleRate: f } = p;
      if (this._baseLatency = typeof p.baseLatency == "number" ? p.baseLatency : h === "balanced" ? 512 / f : h === "interactive" || h === void 0 ? 256 / f : h === "playback" ? 1024 / f : Math.max(2, Math.min(128, Math.round(h * f / 128))) * 128 / f, this._nativeAudioContext = p, l.name === "webkitAudioContext" ? (this._nativeGainNode = p.createGain(), this._nativeOscillatorNode = p.createOscillator(), this._nativeGainNode.gain.value = 1e-37, this._nativeOscillatorNode.connect(this._nativeGainNode).connect(p.destination), this._nativeOscillatorNode.start()) : (this._nativeGainNode = null, this._nativeOscillatorNode = null), this._state = null, p.state === "running") {
        this._state = "suspended";
        let m = () => {
          this._state === "suspended" && (this._state = null), p.removeEventListener("statechange", m);
        };
        p.addEventListener("statechange", m);
      }
    }
    get baseLatency() {
      return this._baseLatency;
    }
    get state() {
      return this._state !== null ? this._state : this._nativeAudioContext.state;
    }
    close() {
      return this.state === "closed" ? this._nativeAudioContext.close().then(() => {
        throw e();
      }) : (this._state === "suspended" && (this._state = null), this._nativeAudioContext.close().then(() => {
        this._nativeGainNode !== null && this._nativeOscillatorNode !== null && (this._nativeOscillatorNode.stop(), this._nativeGainNode.disconnect(), this._nativeOscillatorNode.disconnect()), No(this);
      }));
    }
    createMediaElementSource(c) {
      return new o(this, { mediaElement: c });
    }
    createMediaStreamDestination() {
      return new i(this);
    }
    createMediaStreamSource(c) {
      return new s(this, { mediaStream: c });
    }
    createMediaStreamTrackSource(c) {
      return new a(this, { mediaStreamTrack: c });
    }
    resume() {
      return this._state === "suspended" ? new Promise((c, p) => {
        let h = () => {
          this._nativeAudioContext.removeEventListener("statechange", h), this._nativeAudioContext.state === "running" ? c() : this.resume().then(c, p);
        };
        this._nativeAudioContext.addEventListener("statechange", h);
      }) : this._nativeAudioContext.resume().catch((c) => {
        throw c === void 0 || c.code === 15 ? e() : c;
      });
    }
    suspend() {
      return this._nativeAudioContext.suspend().catch((c) => {
        throw c === void 0 ? e() : c;
      });
    }
  };
  var bw = (t, e, r, n, o, i, s, a) => class extends t {
    constructor(u, c) {
      let p = i(u), h = s(p), f = o(p, c, h), m = h ? e(a) : null;
      super(u, false, f, m), this._isNodeOfNativeOfflineAudioContext = h, this._nativeAudioDestinationNode = f;
    }
    get channelCount() {
      return this._nativeAudioDestinationNode.channelCount;
    }
    set channelCount(u) {
      if (this._isNodeOfNativeOfflineAudioContext) throw n();
      if (u > this._nativeAudioDestinationNode.maxChannelCount) throw r();
      this._nativeAudioDestinationNode.channelCount = u;
    }
    get channelCountMode() {
      return this._nativeAudioDestinationNode.channelCountMode;
    }
    set channelCountMode(u) {
      if (this._isNodeOfNativeOfflineAudioContext) throw n();
      this._nativeAudioDestinationNode.channelCountMode = u;
    }
    get maxChannelCount() {
      return this._nativeAudioDestinationNode.maxChannelCount;
    }
  };
  var Nw = (t) => {
    let e = /* @__PURE__ */ new WeakMap(), r = async (n, o) => {
      let i = o.destination;
      return e.set(o, i), await t(n, o, i), i;
    };
    return { render(n, o) {
      let i = e.get(o);
      return i !== void 0 ? Promise.resolve(i) : r(n, o);
    } };
  };
  var Ow = (t, e, r, n, o, i, s, a) => (l, u) => {
    let c = u.listener, p = () => {
      let v = new Float32Array(1), T = e(u, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: 9 }), A = s(u), w = false, N = [0, 0, -1, 0, 1, 0], k = [0, 0, 0], D = () => {
        if (w) return;
        w = true;
        let I = n(u, 256, 9, 0);
        I.onaudioprocess = ({ inputBuffer: C }) => {
          let E = [i(C, v, 0), i(C, v, 1), i(C, v, 2), i(C, v, 3), i(C, v, 4), i(C, v, 5)];
          E.some((R, P) => R !== N[P]) && (c.setOrientation(...E), N = E);
          let O = [i(C, v, 6), i(C, v, 7), i(C, v, 8)];
          O.some((R, P) => R !== k[P]) && (c.setPosition(...O), k = O);
        }, T.connect(I);
      }, M = (I) => (C) => {
        C !== N[I] && (N[I] = C, c.setOrientation(...N));
      }, q = (I) => (C) => {
        C !== k[I] && (k[I] = C, c.setPosition(...k));
      }, B = (I, C, E) => {
        let O = r(u, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", offset: C });
        O.connect(T, 0, I), O.start(), Object.defineProperty(O.offset, "defaultValue", { get() {
          return C;
        } });
        let R = t({ context: l }, A, O.offset, Ue, Ye);
        return a(R, "value", (P) => () => P.call(R), (P) => (V) => {
          try {
            P.call(R, V);
          } catch (te) {
            if (te.code !== 9) throw te;
          }
          D(), A && E(V);
        }), R.cancelAndHoldAtTime = /* @__PURE__ */ ((P) => A ? () => {
          throw o();
        } : (...V) => {
          let te = P.apply(R, V);
          return D(), te;
        })(R.cancelAndHoldAtTime), R.cancelScheduledValues = /* @__PURE__ */ ((P) => A ? () => {
          throw o();
        } : (...V) => {
          let te = P.apply(R, V);
          return D(), te;
        })(R.cancelScheduledValues), R.exponentialRampToValueAtTime = /* @__PURE__ */ ((P) => A ? () => {
          throw o();
        } : (...V) => {
          let te = P.apply(R, V);
          return D(), te;
        })(R.exponentialRampToValueAtTime), R.linearRampToValueAtTime = /* @__PURE__ */ ((P) => A ? () => {
          throw o();
        } : (...V) => {
          let te = P.apply(R, V);
          return D(), te;
        })(R.linearRampToValueAtTime), R.setTargetAtTime = /* @__PURE__ */ ((P) => A ? () => {
          throw o();
        } : (...V) => {
          let te = P.apply(R, V);
          return D(), te;
        })(R.setTargetAtTime), R.setValueAtTime = /* @__PURE__ */ ((P) => A ? () => {
          throw o();
        } : (...V) => {
          let te = P.apply(R, V);
          return D(), te;
        })(R.setValueAtTime), R.setValueCurveAtTime = /* @__PURE__ */ ((P) => A ? () => {
          throw o();
        } : (...V) => {
          let te = P.apply(R, V);
          return D(), te;
        })(R.setValueCurveAtTime), R;
      };
      return { forwardX: B(0, 0, M(0)), forwardY: B(1, 0, M(1)), forwardZ: B(2, -1, M(2)), positionX: B(6, 0, q(0)), positionY: B(7, 0, q(1)), positionZ: B(8, 0, q(2)), upX: B(3, 0, M(3)), upY: B(4, 1, M(4)), upZ: B(5, 0, M(5)) };
    }, { forwardX: h, forwardY: f, forwardZ: m, positionX: x, positionY: _, positionZ: d, upX: g, upY: y, upZ: S } = c.forwardX === void 0 ? p() : c;
    return { get forwardX() {
      return h;
    }, get forwardY() {
      return f;
    }, get forwardZ() {
      return m;
    }, get positionX() {
      return x;
    }, get positionY() {
      return _;
    }, get positionZ() {
      return d;
    }, get upX() {
      return g;
    }, get upY() {
      return y;
    }, get upZ() {
      return S;
    } };
  };
  var di = (t) => "context" in t;
  var Oo = (t) => di(t[0]);
  var Yr = (t, e, r, n) => {
    for (let o of t) if (r(o)) {
      if (n) return false;
      throw Error("The set contains at least one similar element.");
    }
    return t.add(e), true;
  };
  var Yd = (t, e, [r, n], o) => {
    Yr(t, [e, r, n], (i) => i[0] === e && i[1] === r, o);
  };
  var Qd = (t, [e, r, n], o) => {
    let i = t.get(e);
    i === void 0 ? t.set(e, /* @__PURE__ */ new Set([[r, n]])) : Yr(i, [r, n], (s) => s[0] === r, o);
  };
  var Er = (t) => "inputs" in t;
  var Es = (t, e, r, n) => {
    if (Er(e)) {
      let o = e.inputs[n];
      return t.connect(o, r, 0), [o, r, 0];
    }
    return t.connect(e, r, n), [e, r, n];
  };
  var Kd = (t, e, r) => {
    for (let n of t) if (n[0] === e && n[1] === r) return t.delete(n), n;
    return null;
  };
  var Dw = (t, e, r) => Eo(t, (n) => n[0] === e && n[1] === r);
  var Zd = (t, e) => {
    if (!xn(t).delete(e)) throw new Error("Missing the expected event listener.");
  };
  var Jd = (t, e, r) => {
    let n = tt(t, e), o = Eo(n, (i) => i[0] === r);
    return n.size === 0 && t.delete(e), o;
  };
  var bs = (t, e, r, n) => {
    Er(e) ? t.disconnect(e.inputs[n], r, 0) : t.disconnect(e, r, n);
  };
  var we = (t) => tt(Ts, t);
  var gi = (t) => tt(Ml, t);
  var Wn = (t) => Pl.has(t);
  var Ns = (t) => !gn.has(t);
  var eg = (t, e) => new Promise((r) => {
    if (e !== null) r(true);
    else {
      let n = t.createScriptProcessor(256, 1, 1), o = t.createGain(), i = t.createBuffer(1, 2, 44100), s = i.getChannelData(0);
      s[0] = 1, s[1] = 1;
      let a = t.createBufferSource();
      a.buffer = i, a.loop = true, a.connect(n).connect(t.destination), a.connect(o), a.disconnect(o), n.onaudioprocess = (l) => {
        let u = l.inputBuffer.getChannelData(0);
        Array.prototype.some.call(u, (c) => c === 1) ? r(true) : r(false), a.stop(), n.onaudioprocess = null, a.disconnect(n), n.disconnect(t.destination);
      }, a.start();
    }
  });
  var _p = (t, e) => {
    let r = /* @__PURE__ */ new Map();
    for (let n of t) for (let o of n) {
      let i = r.get(o);
      r.set(o, i === void 0 ? 1 : i + 1);
    }
    r.forEach((n, o) => e(o, n));
  };
  var xi = (t) => "context" in t;
  var Mw = (t) => {
    let e = /* @__PURE__ */ new Map();
    t.connect = /* @__PURE__ */ ((r) => (n, o = 0, i = 0) => {
      let s = xi(n) ? r(n, o, i) : r(n, o), a = e.get(n);
      return a === void 0 ? e.set(n, [{ input: i, output: o }]) : a.every((l) => l.input !== i || l.output !== o) && a.push({ input: i, output: o }), s;
    })(t.connect.bind(t)), t.disconnect = /* @__PURE__ */ ((r) => (n, o, i) => {
      if (r.apply(t), n === void 0) e.clear();
      else if (typeof n == "number") for (let [s, a] of e) {
        let l = a.filter((u) => u.output !== n);
        l.length === 0 ? e.delete(s) : e.set(s, l);
      }
      else if (e.has(n)) if (o === void 0) e.delete(n);
      else {
        let s = e.get(n);
        if (s !== void 0) {
          let a = s.filter((l) => l.output !== o && (l.input !== i || i === void 0));
          a.length === 0 ? e.delete(n) : e.set(n, a);
        }
      }
      for (let [s, a] of e) a.forEach((l) => {
        xi(s) ? t.connect(s, l.output, l.input) : t.connect(s, l.output);
      });
    })(t.disconnect);
  };
  var kO = (t, e, r, n) => {
    let { activeInputs: o, passiveInputs: i } = bo(e), { outputs: s } = ct(t), a = xn(t), l = (u) => {
      let c = we(t), p = gi(e);
      if (u) {
        let h = Jd(i, t, r);
        Yd(o, t, h, false), !n && !Wn(t) && c.connect(p, r);
      } else {
        let h = Dw(o, t, r);
        Qd(i, h, false), !n && !Wn(t) && c.disconnect(p, r);
      }
    };
    return Yr(s, [e, r], (u) => u[0] === e && u[1] === r, true) ? (a.add(l), Bt(t) ? Yd(o, t, [r, l], true) : Qd(i, [t, r, l], true), true) : false;
  }, EO = (t, e, r, n) => {
    let { activeInputs: o, passiveInputs: i } = ct(e), s = Kd(o[n], t, r);
    return s === null ? [dp(i, t, r, n)[2], false] : [s[2], true];
  }, bO = (t, e, r) => {
    let { activeInputs: n, passiveInputs: o } = bo(e), i = Kd(n, t, r);
    return i === null ? [Jd(o, t, r)[1], false] : [i[2], true];
  }, tg = (t, e, r, n, o) => {
    let [i, s] = EO(t, r, n, o);
    if (i !== null && (Zd(t, i), s && !e && !Wn(t) && bs(we(t), we(r), n, o)), Bt(r)) {
      let { activeInputs: a } = ct(r);
      Fl(r, a);
    }
  }, rg = (t, e, r, n) => {
    let [o, i] = bO(t, r, n);
    o !== null && (Zd(t, o), i && !e && !Wn(t) && we(t).disconnect(gi(r), n));
  }, NO = (t, e) => {
    let r = ct(t), n = [];
    for (let o of r.outputs) Oo(o) ? tg(t, e, ...o) : rg(t, e, ...o), n.push(o[0]);
    return r.outputs.clear(), n;
  }, OO = (t, e, r) => {
    let n = ct(t), o = [];
    for (let i of n.outputs) i[1] === r && (Oo(i) ? tg(t, e, ...i) : rg(t, e, ...i), o.push(i[0]), n.outputs.delete(i));
    return o;
  }, DO = (t, e, r, n, o) => {
    let i = ct(t);
    return Array.from(i.outputs).filter((s) => s[0] === r && (n === void 0 || s[1] === n) && (o === void 0 || s[2] === o)).map((s) => (Oo(s) ? tg(t, e, ...s) : rg(t, e, ...s), i.outputs.delete(s), s[0]));
  }, Pw = (t, e, r, n, o, i, s, a, l, u, c, p, h, f, m, x) => class extends u {
    constructor(d, g, y, S) {
      super(y), this._context = d, this._nativeAudioNode = y;
      let v = c(d);
      p(v) && r(eg, () => eg(v, x)) !== true && Mw(y), Ts.set(this, y), mp.set(this, /* @__PURE__ */ new Set()), d.state !== "closed" && g && Xr(this), t(this, S, y);
    }
    get channelCount() {
      return this._nativeAudioNode.channelCount;
    }
    set channelCount(d) {
      this._nativeAudioNode.channelCount = d;
    }
    get channelCountMode() {
      return this._nativeAudioNode.channelCountMode;
    }
    set channelCountMode(d) {
      this._nativeAudioNode.channelCountMode = d;
    }
    get channelInterpretation() {
      return this._nativeAudioNode.channelInterpretation;
    }
    set channelInterpretation(d) {
      this._nativeAudioNode.channelInterpretation = d;
    }
    get context() {
      return this._context;
    }
    get numberOfInputs() {
      return this._nativeAudioNode.numberOfInputs;
    }
    get numberOfOutputs() {
      return this._nativeAudioNode.numberOfOutputs;
    }
    connect(d, g = 0, y = 0) {
      if (g < 0 || g >= this._nativeAudioNode.numberOfOutputs) throw o();
      let S = c(this._context), v = m(S);
      if (h(d) || f(d)) throw i();
      if (di(d)) {
        let w = we(d);
        try {
          let k = Es(this._nativeAudioNode, w, g, y), D = Ns(this);
          (v || D) && this._nativeAudioNode.disconnect(...k), this.context.state !== "closed" && !D && Ns(d) && Xr(d);
        } catch (k) {
          throw k.code === 12 ? i() : k;
        }
        if (e(this, d, g, y, v)) {
          let k = l([this], d);
          _p(k, n(v));
        }
        return d;
      }
      let T = gi(d);
      if (T.name === "playbackRate" && T.maxValue === 1024) throw s();
      try {
        this._nativeAudioNode.connect(T, g), (v || Ns(this)) && this._nativeAudioNode.disconnect(T, g);
      } catch (w) {
        throw w.code === 12 ? i() : w;
      }
      if (kO(this, d, g, v)) {
        let w = l([this], d);
        _p(w, n(v));
      }
    }
    disconnect(d, g, y) {
      let S, v = c(this._context), T = m(v);
      if (d === void 0) S = NO(this, T);
      else if (typeof d == "number") {
        if (d < 0 || d >= this.numberOfOutputs) throw o();
        S = OO(this, T, d);
      } else {
        if (g !== void 0 && (g < 0 || g >= this.numberOfOutputs) || di(d) && y !== void 0 && (y < 0 || y >= d.numberOfInputs)) throw o();
        if (S = DO(this, T, d, g, y), S.length === 0) throw i();
      }
      for (let A of S) {
        let w = l([this], A);
        _p(w, a);
      }
    }
  };
  var Rw = se($d()), Vw = (t, e, r, n, o, i, s, a, l, u, c, p, h) => (f, m, x, _ = null, d = null) => {
    let g = x.value, y = new Rw.AutomationEventList(g), S = m ? n(y) : null, v = { get defaultValue() {
      return g;
    }, get maxValue() {
      return _ === null ? x.maxValue : _;
    }, get minValue() {
      return d === null ? x.minValue : d;
    }, get value() {
      return x.value;
    }, set value(T) {
      x.value = T, v.setValueAtTime(T, f.context.currentTime);
    }, cancelAndHoldAtTime(T) {
      if (typeof x.cancelAndHoldAtTime == "function") S === null && y.flush(f.context.currentTime), y.add(o(T)), x.cancelAndHoldAtTime(T);
      else {
        let A = Array.from(y).pop();
        S === null && y.flush(f.context.currentTime), y.add(o(T));
        let w = Array.from(y).pop();
        x.cancelScheduledValues(T), A !== w && w !== void 0 && (w.type === "exponentialRampToValue" ? x.exponentialRampToValueAtTime(w.value, w.endTime) : w.type === "linearRampToValue" ? x.linearRampToValueAtTime(w.value, w.endTime) : w.type === "setValue" ? x.setValueAtTime(w.value, w.startTime) : w.type === "setValueCurve" && x.setValueCurveAtTime(w.values, w.startTime, w.duration));
      }
      return v;
    }, cancelScheduledValues(T) {
      return S === null && y.flush(f.context.currentTime), y.add(i(T)), x.cancelScheduledValues(T), v;
    }, exponentialRampToValueAtTime(T, A) {
      if (T === 0) throw new RangeError();
      if (!Number.isFinite(A) || A < 0) throw new RangeError();
      let w = f.context.currentTime;
      return S === null && y.flush(w), Array.from(y).length === 0 && (y.add(u(g, w)), x.setValueAtTime(g, w)), y.add(s(T, A)), x.exponentialRampToValueAtTime(T, A), v;
    }, linearRampToValueAtTime(T, A) {
      let w = f.context.currentTime;
      return S === null && y.flush(w), Array.from(y).length === 0 && (y.add(u(g, w)), x.setValueAtTime(g, w)), y.add(a(T, A)), x.linearRampToValueAtTime(T, A), v;
    }, setTargetAtTime(T, A, w) {
      return S === null && y.flush(f.context.currentTime), y.add(l(T, A, w)), x.setTargetAtTime(T, A, w), v;
    }, setValueAtTime(T, A) {
      return S === null && y.flush(f.context.currentTime), y.add(u(T, A)), x.setValueAtTime(T, A), v;
    }, setValueCurveAtTime(T, A, w) {
      let N = T instanceof Float32Array ? T : new Float32Array(T);
      if (p !== null && p.name === "webkitAudioContext") {
        let k = A + w, D = f.context.sampleRate, M = Math.ceil(A * D), q = Math.floor(k * D), B = q - M, I = new Float32Array(B);
        for (let E = 0; E < B; E += 1) {
          let O = (N.length - 1) / w * ((M + E) / D - A), R = Math.floor(O), P = Math.ceil(O);
          I[E] = R === P ? N[R] : (1 - (O - R)) * N[R] + (1 - (P - O)) * N[P];
        }
        S === null && y.flush(f.context.currentTime), y.add(c(I, A, w)), x.setValueCurveAtTime(I, A, w);
        let C = q / D;
        C < k && h(v, I[I.length - 1], C), h(v, N[N.length - 1], k);
      } else S === null && y.flush(f.context.currentTime), y.add(c(N, A, w)), x.setValueCurveAtTime(N, A, w);
      return v;
    } };
    return r.set(v, x), e.set(v, f), t(v, S), v;
  };
  var Fw = (t) => ({ replay(e) {
    for (let r of t) if (r.type === "exponentialRampToValue") {
      let { endTime: n, value: o } = r;
      e.exponentialRampToValueAtTime(o, n);
    } else if (r.type === "linearRampToValue") {
      let { endTime: n, value: o } = r;
      e.linearRampToValueAtTime(o, n);
    } else if (r.type === "setTarget") {
      let { startTime: n, target: o, timeConstant: i } = r;
      e.setTargetAtTime(o, n, i);
    } else if (r.type === "setValue") {
      let { startTime: n, value: o } = r;
      e.setValueAtTime(o, n);
    } else if (r.type === "setValueCurve") {
      let { duration: n, startTime: o, values: i } = r;
      e.setValueCurveAtTime(i, o, n);
    } else throw new Error("Can't apply an unknown automation.");
  } });
  var Os = class {
    constructor(e) {
      this._map = new Map(e);
    }
    get size() {
      return this._map.size;
    }
    entries() {
      return this._map.entries();
    }
    forEach(e, r = null) {
      return this._map.forEach((n, o) => e.call(r, n, o, this));
    }
    get(e) {
      return this._map.get(e);
    }
    has(e) {
      return this._map.has(e);
    }
    keys() {
      return this._map.keys();
    }
    values() {
      return this._map.values();
    }
  };
  var MO = { channelCount: 2, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: 1, numberOfOutputs: 1, parameterData: {}, processorOptions: {} }, Iw = (t, e, r, n, o, i, s, a, l, u, c, p, h, f) => class extends e {
    constructor(x, _, d) {
      var g;
      let y = a(x), S = l(y), v = c({ ...MO, ...d });
      h(v);
      let T = Rl.get(y), A = T == null ? void 0 : T.get(_), w = S || y.state !== "closed" ? y : (g = s(y)) !== null && g !== void 0 ? g : y, N = o(w, S ? null : x.baseLatency, u, _, A, v), k = S ? n(_, v, A) : null;
      super(x, true, N, k);
      let D = [];
      N.parameters.forEach((q, B) => {
        let I = r(this, S, q);
        D.push([B, I]);
      }), this._nativeAudioWorkletNode = N, this._onprocessorerror = null, this._parameters = new Os(D), S && t(y, this);
      let { activeInputs: M } = i(this);
      p(N, M);
    }
    get onprocessorerror() {
      return this._onprocessorerror;
    }
    set onprocessorerror(x) {
      let _ = typeof x == "function" ? f(this, x) : null;
      this._nativeAudioWorkletNode.onprocessorerror = _;
      let d = this._nativeAudioWorkletNode.onprocessorerror;
      this._onprocessorerror = d !== null && d === _ ? x : d;
    }
    get parameters() {
      return this._parameters === null ? this._nativeAudioWorkletNode.parameters : this._parameters;
    }
    get port() {
      return this._nativeAudioWorkletNode.port;
    }
  };
  function Ds(t, e, r, n, o) {
    if (typeof t.copyFromChannel == "function") e[r].byteLength === 0 && (e[r] = new Float32Array(128)), t.copyFromChannel(e[r], n, o);
    else {
      let i = t.getChannelData(n);
      if (e[r].byteLength === 0) e[r] = i.slice(o, o + 128);
      else {
        let s = new Float32Array(i.buffer, o * Float32Array.BYTES_PER_ELEMENT, 128);
        e[r].set(s);
      }
    }
  }
  var vp = (t, e, r, n, o) => {
    typeof t.copyToChannel == "function" ? e[r].byteLength !== 0 && t.copyToChannel(e[r], n, o) : e[r].byteLength !== 0 && t.getChannelData(n).set(e[r], o);
  };
  var Ms = (t, e) => {
    let r = [];
    for (let n = 0; n < t; n += 1) {
      let o = [], i = typeof e == "number" ? e : e[n];
      for (let s = 0; s < i; s += 1) o.push(new Float32Array(128));
      r.push(o);
    }
    return r;
  };
  var Lw = (t, e) => {
    let r = tt(Vl, t), n = we(e);
    return tt(r, n);
  };
  var PO = async (t, e, r, n, o, i, s) => {
    let a = e === null ? Math.ceil(t.context.length / 128) * 128 : e.length, l = n.channelCount * n.numberOfInputs, u = o.reduce((_, d) => _ + d, 0), c = u === 0 ? null : r.createBuffer(u, a, r.sampleRate);
    if (i === void 0) throw new Error("Missing the processor constructor.");
    let p = ct(t), h = await Lw(r, t), f = Ms(n.numberOfInputs, n.channelCount), m = Ms(n.numberOfOutputs, o), x = Array.from(t.parameters.keys()).reduce((_, d) => ({ ..._, [d]: new Float32Array(128) }), {});
    for (let _ = 0; _ < a; _ += 128) {
      if (n.numberOfInputs > 0 && e !== null) for (let d = 0; d < n.numberOfInputs; d += 1) for (let g = 0; g < n.channelCount; g += 1) Ds(e, f[d], g, g, _);
      i.parameterDescriptors !== void 0 && e !== null && i.parameterDescriptors.forEach(({ name: d }, g) => {
        Ds(e, x, d, l + g, _);
      });
      for (let d = 0; d < n.numberOfInputs; d += 1) for (let g = 0; g < o[d]; g += 1) m[d][g].byteLength === 0 && (m[d][g] = new Float32Array(128));
      try {
        let d = f.map((y, S) => p.activeInputs[S].size === 0 ? [] : y), g = s(_ / r.sampleRate, r.sampleRate, () => h.process(d, m, x));
        if (c !== null) for (let y = 0, S = 0; y < n.numberOfOutputs; y += 1) {
          for (let v = 0; v < o[y]; v += 1) vp(c, m[y], v, S + v, _);
          S += o[y];
        }
        if (!g) break;
      } catch (d) {
        t.dispatchEvent(new ErrorEvent("processorerror", { colno: d.colno, filename: d.filename, lineno: d.lineno, message: d.message }));
        break;
      }
    }
    return c;
  }, Bw = (t, e, r, n, o, i, s, a, l, u, c, p, h, f, m, x) => (_, d, g) => {
    let y = /* @__PURE__ */ new WeakMap(), S = null, v = async (T, A) => {
      let w = c(T), N = null, k = he(w, A), D = Array.isArray(d.outputChannelCount) ? d.outputChannelCount : Array.from(d.outputChannelCount);
      if (p === null) {
        let M = D.reduce((C, E) => C + E, 0), q = o(A, { channelCount: Math.max(1, M), channelCountMode: "explicit", channelInterpretation: "discrete", numberOfOutputs: Math.max(1, M) }), B = [];
        for (let C = 0; C < T.numberOfOutputs; C += 1) B.push(n(A, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: D[C] }));
        let I = s(A, { channelCount: d.channelCount, channelCountMode: d.channelCountMode, channelInterpretation: d.channelInterpretation, gain: 1 });
        I.connect = e.bind(null, B), I.disconnect = l.bind(null, B), N = [q, B, I];
      } else k || (w = new p(A, _));
      if (y.set(A, N === null ? w : N[2]), N !== null) {
        if (S === null) {
          if (g === void 0) throw new Error("Missing the processor constructor.");
          if (h === null) throw new Error("Missing the native OfflineAudioContext constructor.");
          let E = T.channelCount * T.numberOfInputs, O = g.parameterDescriptors === void 0 ? 0 : g.parameterDescriptors.length, R = E + O;
          S = PO(T, R === 0 ? null : await (async () => {
            let V = new h(R, Math.ceil(T.context.length / 128) * 128, A.sampleRate), te = [], j = [];
            for (let K = 0; K < d.numberOfInputs; K += 1) te.push(s(V, { channelCount: d.channelCount, channelCountMode: d.channelCountMode, channelInterpretation: d.channelInterpretation, gain: 1 })), j.push(o(V, { channelCount: d.channelCount, channelCountMode: "explicit", channelInterpretation: "discrete", numberOfOutputs: d.channelCount }));
            let re = await Promise.all(Array.from(T.parameters.values()).map(async (K) => {
              let ue = i(V, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", offset: K.value });
              return await f(V, K, ue.offset), ue;
            })), Y = n(V, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: Math.max(1, E + O) });
            for (let K = 0; K < d.numberOfInputs; K += 1) {
              te[K].connect(j[K]);
              for (let ue = 0; ue < d.channelCount; ue += 1) j[K].connect(Y, ue, K * d.channelCount + ue);
            }
            for (let [K, ue] of re.entries()) ue.connect(Y, 0, E + K), ue.start(0);
            return Y.connect(V.destination), await Promise.all(te.map((K) => m(T, V, K))), x(V);
          })(), A, d, D, g, u);
        }
        let M = await S, q = r(A, { buffer: null, channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", loop: false, loopEnd: 0, loopStart: 0, playbackRate: 1 }), [B, I, C] = N;
        M !== null && (q.buffer = M, q.start(0)), q.connect(B);
        for (let E = 0, O = 0; E < T.numberOfOutputs; E += 1) {
          let R = I[E];
          for (let P = 0; P < D[E]; P += 1) B.connect(R, O + P, P);
          O += D[E];
        }
        return C;
      }
      if (k) for (let [M, q] of T.parameters.entries()) await t(A, q, w.parameters.get(M));
      else for (let [M, q] of T.parameters.entries()) await f(A, q, w.parameters.get(M));
      return await m(T, A, w), w;
    };
    return { render(T, A) {
      a(A, T);
      let w = y.get(A);
      return w !== void 0 ? Promise.resolve(w) : v(T, A);
    } };
  };
  var jw = (t, e, r, n, o, i, s, a, l, u, c, p, h, f, m, x, _, d, g, y) => class extends m {
    constructor(v, T) {
      super(v, T), this._nativeContext = v, this._audioWorklet = t === void 0 ? void 0 : { addModule: (A, w) => t(this, A, w) };
    }
    get audioWorklet() {
      return this._audioWorklet;
    }
    createAnalyser() {
      return new e(this);
    }
    createBiquadFilter() {
      return new o(this);
    }
    createBuffer(v, T, A) {
      return new r({ length: T, numberOfChannels: v, sampleRate: A });
    }
    createBufferSource() {
      return new n(this);
    }
    createChannelMerger(v = 6) {
      return new i(this, { numberOfInputs: v });
    }
    createChannelSplitter(v = 6) {
      return new s(this, { numberOfOutputs: v });
    }
    createConstantSource() {
      return new a(this);
    }
    createConvolver() {
      return new l(this);
    }
    createDelay(v = 1) {
      return new c(this, { maxDelayTime: v });
    }
    createDynamicsCompressor() {
      return new p(this);
    }
    createGain() {
      return new h(this);
    }
    createIIRFilter(v, T) {
      return new f(this, { feedback: T, feedforward: v });
    }
    createOscillator() {
      return new x(this);
    }
    createPanner() {
      return new _(this);
    }
    createPeriodicWave(v, T, A = { disableNormalization: false }) {
      return new d(this, { ...A, imag: T, real: v });
    }
    createStereoPanner() {
      return new g(this);
    }
    createWaveShaper() {
      return new y(this);
    }
    decodeAudioData(v, T, A) {
      return u(this._nativeContext, v).then((w) => (typeof T == "function" && T(w), w), (w) => {
        throw typeof A == "function" && A(w), w;
      });
    }
  };
  var RO = { Q: 1, channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", detune: 0, frequency: 350, gain: 0, type: "lowpass" }, qw = (t, e, r, n, o, i, s, a) => class extends t {
    constructor(u, c) {
      let p = i(u), h = { ...RO, ...c }, f = o(p, h), m = s(p), x = m ? r() : null;
      super(u, false, f, x), this._Q = e(this, m, f.Q, Ue, Ye), this._detune = e(this, m, f.detune, 1200 * Math.log2(Ue), -1200 * Math.log2(Ue)), this._frequency = e(this, m, f.frequency, u.sampleRate / 2, 0), this._gain = e(this, m, f.gain, 40 * Math.log10(Ue), Ye), this._nativeBiquadFilterNode = f, a(this, 1);
    }
    get detune() {
      return this._detune;
    }
    get frequency() {
      return this._frequency;
    }
    get gain() {
      return this._gain;
    }
    get Q() {
      return this._Q;
    }
    get type() {
      return this._nativeBiquadFilterNode.type;
    }
    set type(u) {
      this._nativeBiquadFilterNode.type = u;
    }
    getFrequencyResponse(u, c, p) {
      try {
        this._nativeBiquadFilterNode.getFrequencyResponse(u, c, p);
      } catch (h) {
        throw h.code === 11 ? n() : h;
      }
      if (u.length !== c.length || c.length !== p.length) throw n();
    }
  };
  var zw = (t, e, r, n, o) => () => {
    let i = /* @__PURE__ */ new WeakMap(), s = async (a, l) => {
      let u = r(a), c = he(u, l);
      if (!c) {
        let p = { Q: u.Q.value, channelCount: u.channelCount, channelCountMode: u.channelCountMode, channelInterpretation: u.channelInterpretation, detune: u.detune.value, frequency: u.frequency.value, gain: u.gain.value, type: u.type };
        u = e(l, p);
      }
      return i.set(l, u), c ? (await t(l, a.Q, u.Q), await t(l, a.detune, u.detune), await t(l, a.frequency, u.frequency), await t(l, a.gain, u.gain)) : (await n(l, a.Q, u.Q), await n(l, a.detune, u.detune), await n(l, a.frequency, u.frequency), await n(l, a.gain, u.gain)), await o(a, l, u), u;
    };
    return { render(a, l) {
      let u = i.get(l);
      return u !== void 0 ? Promise.resolve(u) : s(a, l);
    } };
  };
  var Ww = (t, e) => (r, n) => {
    let o = e.get(r);
    if (o !== void 0) return o;
    let i = t.get(r);
    if (i !== void 0) return i;
    try {
      let s = n();
      return s instanceof Promise ? (t.set(r, s), s.catch(() => false).then((a) => (t.delete(r), e.set(r, a), a))) : (e.set(r, s), s);
    } catch {
      return e.set(r, false), false;
    }
  };
  var VO = { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: 6 }, Uw = (t, e, r, n, o) => class extends t {
    constructor(s, a) {
      let l = n(s), u = { ...VO, ...a }, c = r(l, u), p = o(l) ? e() : null;
      super(s, false, c, p);
    }
  };
  var Gw = (t, e, r) => () => {
    let n = /* @__PURE__ */ new WeakMap(), o = async (i, s) => {
      let a = e(i);
      if (!he(a, s)) {
        let u = { channelCount: a.channelCount, channelCountMode: a.channelCountMode, channelInterpretation: a.channelInterpretation, numberOfInputs: a.numberOfInputs };
        a = t(s, u);
      }
      return n.set(s, a), await r(i, s, a), a;
    };
    return { render(i, s) {
      let a = n.get(s);
      return a !== void 0 ? Promise.resolve(a) : o(i, s);
    } };
  };
  var FO = { channelCount: 6, channelCountMode: "explicit", channelInterpretation: "discrete", numberOfOutputs: 6 }, Hw = (t, e, r, n, o, i) => class extends t {
    constructor(a, l) {
      let u = n(a), c = i({ ...FO, ...l }), p = r(u, c), h = o(u) ? e() : null;
      super(a, false, p, h);
    }
  };
  var $w = (t, e, r) => () => {
    let n = /* @__PURE__ */ new WeakMap(), o = async (i, s) => {
      let a = e(i);
      if (!he(a, s)) {
        let u = { channelCount: a.channelCount, channelCountMode: a.channelCountMode, channelInterpretation: a.channelInterpretation, numberOfOutputs: a.numberOfOutputs };
        a = t(s, u);
      }
      return n.set(s, a), await r(i, s, a), a;
    };
    return { render(i, s) {
      let a = n.get(s);
      return a !== void 0 ? Promise.resolve(a) : o(i, s);
    } };
  };
  var Xw = (t) => (e, r, n) => t(r, e, n);
  var Yw = (t) => (e, r, n = 0, o = 0) => {
    let i = e[n];
    if (i === void 0) throw t();
    return xi(r) ? i.connect(r, 0, o) : i.connect(r, 0);
  };
  var Qw = (t) => (e, r) => {
    let n = t(e, { buffer: null, channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", loop: false, loopEnd: 0, loopStart: 0, playbackRate: 1 }), o = e.createBuffer(1, 2, 44100);
    return n.buffer = o, n.loop = true, n.connect(r), n.start(), () => {
      n.stop(), n.disconnect(r);
    };
  };
  var IO = { channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", offset: 1 }, Kw = (t, e, r, n, o, i, s) => class extends t {
    constructor(l, u) {
      let c = o(l), p = { ...IO, ...u }, h = n(c, p), f = i(c), m = f ? r() : null;
      super(l, false, h, m), this._constantSourceNodeRenderer = m, this._nativeConstantSourceNode = h, this._offset = e(this, f, h.offset, Ue, Ye), this._onended = null;
    }
    get offset() {
      return this._offset;
    }
    get onended() {
      return this._onended;
    }
    set onended(l) {
      let u = typeof l == "function" ? s(this, l) : null;
      this._nativeConstantSourceNode.onended = u;
      let c = this._nativeConstantSourceNode.onended;
      this._onended = c !== null && c === u ? l : c;
    }
    start(l = 0) {
      if (this._nativeConstantSourceNode.start(l), this._constantSourceNodeRenderer !== null && (this._constantSourceNodeRenderer.start = l), this.context.state !== "closed") {
        Xr(this);
        let u = () => {
          this._nativeConstantSourceNode.removeEventListener("ended", u), Bt(this) && yn(this);
        };
        this._nativeConstantSourceNode.addEventListener("ended", u);
      }
    }
    stop(l = 0) {
      this._nativeConstantSourceNode.stop(l), this._constantSourceNodeRenderer !== null && (this._constantSourceNodeRenderer.stop = l);
    }
  };
  var Zw = (t, e, r, n, o) => () => {
    let i = /* @__PURE__ */ new WeakMap(), s = null, a = null, l = async (u, c) => {
      let p = r(u), h = he(p, c);
      if (!h) {
        let f = { channelCount: p.channelCount, channelCountMode: p.channelCountMode, channelInterpretation: p.channelInterpretation, offset: p.offset.value };
        p = e(c, f), s !== null && p.start(s), a !== null && p.stop(a);
      }
      return i.set(c, p), h ? await t(c, u.offset, p.offset) : await n(c, u.offset, p.offset), await o(u, c, p), p;
    };
    return { set start(u) {
      s = u;
    }, set stop(u) {
      a = u;
    }, render(u, c) {
      let p = i.get(c);
      return p !== void 0 ? Promise.resolve(p) : l(u, c);
    } };
  };
  var Jw = (t) => (e) => (t[0] = e, t[0]);
  var LO = { buffer: null, channelCount: 2, channelCountMode: "clamped-max", channelInterpretation: "speakers", disableNormalization: false }, eS = (t, e, r, n, o, i) => class extends t {
    constructor(a, l) {
      let u = n(a), c = { ...LO, ...l }, p = r(u, c), f = o(u) ? e() : null;
      super(a, false, p, f), this._isBufferNullified = false, this._nativeConvolverNode = p, c.buffer !== null && i(this, c.buffer.duration);
    }
    get buffer() {
      return this._isBufferNullified ? null : this._nativeConvolverNode.buffer;
    }
    set buffer(a) {
      if (this._nativeConvolverNode.buffer = a, a === null && this._nativeConvolverNode.buffer !== null) {
        let l = this._nativeConvolverNode.context;
        this._nativeConvolverNode.buffer = l.createBuffer(1, 1, l.sampleRate), this._isBufferNullified = true, i(this, 0);
      } else this._isBufferNullified = false, i(this, this._nativeConvolverNode.buffer === null ? 0 : this._nativeConvolverNode.buffer.duration);
    }
    get normalize() {
      return this._nativeConvolverNode.normalize;
    }
    set normalize(a) {
      this._nativeConvolverNode.normalize = a;
    }
  };
  var tS = (t, e, r) => () => {
    let n = /* @__PURE__ */ new WeakMap(), o = async (i, s) => {
      let a = e(i);
      if (!he(a, s)) {
        let u = { buffer: a.buffer, channelCount: a.channelCount, channelCountMode: a.channelCountMode, channelInterpretation: a.channelInterpretation, disableNormalization: !a.normalize };
        a = t(s, u);
      }
      return n.set(s, a), Er(a) ? await r(i, s, a.inputs[0]) : await r(i, s, a), a;
    };
    return { render(i, s) {
      let a = n.get(s);
      return a !== void 0 ? Promise.resolve(a) : o(i, s);
    } };
  };
  var rS = (t, e) => (r, n, o) => {
    if (e === null) throw new Error("Missing the native OfflineAudioContext constructor.");
    try {
      return new e(r, n, o);
    } catch (i) {
      throw i.name === "SyntaxError" ? t() : i;
    }
  };
  var nS = () => new DOMException("", "DataCloneError");
  var ng = (t) => {
    let { port1: e, port2: r } = new MessageChannel();
    return new Promise((n) => {
      let o = () => {
        r.onmessage = null, e.close(), r.close(), n();
      };
      r.onmessage = () => o();
      try {
        e.postMessage(t, [t]);
      } catch {
      } finally {
        o();
      }
    });
  };
  var oS = (t, e, r, n, o, i, s, a, l, u, c) => (p, h) => {
    let f = s(p) ? p : i(p);
    if (o.has(h)) {
      let m = r();
      return Promise.reject(m);
    }
    try {
      o.add(h);
    } catch {
    }
    return e(l, () => l(f)) ? f.decodeAudioData(h).then((m) => (ng(h).catch(() => {
    }), e(a, () => a(m)) || c(m), t.add(m), m)) : new Promise((m, x) => {
      let _ = async () => {
        try {
          await ng(h);
        } catch {
        }
      }, d = (g) => {
        x(g), _();
      };
      try {
        f.decodeAudioData(h, (g) => {
          typeof g.copyFromChannel != "function" && (u(g), ks(g)), t.add(g), _().then(() => m(g));
        }, (g) => {
          d(g === null ? n() : g);
        });
      } catch (g) {
        d(g);
      }
    });
  };
  var iS = (t, e, r, n, o, i, s, a) => (l, u) => {
    let c = e.get(l);
    if (c === void 0) throw new Error("Missing the expected cycle count.");
    let p = i(l.context), h = a(p);
    if (c === u) {
      if (e.delete(l), !h && s(l)) {
        let f = n(l), { outputs: m } = r(l);
        for (let x of m) if (Oo(x)) {
          let _ = n(x[0]);
          t(f, _, x[1], x[2]);
        } else {
          let _ = o(x[0]);
          f.connect(_, x[1]);
        }
      }
    } else e.set(l, c - u);
  };
  var BO = { channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", delayTime: 0, maxDelayTime: 1 }, sS = (t, e, r, n, o, i, s) => class extends t {
    constructor(l, u) {
      let c = o(l), p = { ...BO, ...u }, h = n(c, p), f = i(c), m = f ? r(p.maxDelayTime) : null;
      super(l, false, h, m), this._delayTime = e(this, f, h.delayTime), s(this, p.maxDelayTime);
    }
    get delayTime() {
      return this._delayTime;
    }
  };
  var aS = (t, e, r, n, o) => (i) => {
    let s = /* @__PURE__ */ new WeakMap(), a = async (l, u) => {
      let c = r(l), p = he(c, u);
      if (!p) {
        let h = { channelCount: c.channelCount, channelCountMode: c.channelCountMode, channelInterpretation: c.channelInterpretation, delayTime: c.delayTime.value, maxDelayTime: i };
        c = e(u, h);
      }
      return s.set(u, c), p ? await t(u, l.delayTime, c.delayTime) : await n(u, l.delayTime, c.delayTime), await o(l, u, c), c;
    };
    return { render(l, u) {
      let c = s.get(u);
      return c !== void 0 ? Promise.resolve(c) : a(l, u);
    } };
  };
  var lS = (t) => (e, r, n, o) => t(e[o], (i) => i[0] === r && i[1] === n);
  var uS = (t) => (e, r) => {
    t(e).delete(r);
  };
  var cS = (t) => "delayTime" in t;
  var pS = (t, e, r) => function n(o, i) {
    let s = di(i) ? i : r(t, i);
    if (cS(s)) return [];
    if (o[0] === s) return [o];
    if (o.includes(s)) return [];
    let { outputs: a } = e(s);
    return Array.from(a).map((l) => n([...o, s], l[0])).reduce((l, u) => l.concat(u), []);
  };
  var wp = (t, e, r) => {
    let n = e[r];
    if (n === void 0) throw t();
    return n;
  }, hS = (t) => (e, r = void 0, n = void 0, o = 0) => r === void 0 ? e.forEach((i) => i.disconnect()) : typeof r == "number" ? wp(t, e, r).disconnect() : xi(r) ? n === void 0 ? e.forEach((i) => i.disconnect(r)) : o === void 0 ? wp(t, e, n).disconnect(r, 0) : wp(t, e, n).disconnect(r, 0, o) : n === void 0 ? e.forEach((i) => i.disconnect(r)) : wp(t, e, n).disconnect(r, 0);
  var jO = { attack: 3e-3, channelCount: 2, channelCountMode: "clamped-max", channelInterpretation: "speakers", knee: 30, ratio: 12, release: 0.25, threshold: -24 }, fS = (t, e, r, n, o, i, s, a) => class extends t {
    constructor(u, c) {
      let p = i(u), h = { ...jO, ...c }, f = n(p, h), m = s(p), x = m ? r() : null;
      super(u, false, f, x), this._attack = e(this, m, f.attack), this._knee = e(this, m, f.knee), this._nativeDynamicsCompressorNode = f, this._ratio = e(this, m, f.ratio), this._release = e(this, m, f.release), this._threshold = e(this, m, f.threshold), a(this, 6e-3);
    }
    get attack() {
      return this._attack;
    }
    get channelCount() {
      return this._nativeDynamicsCompressorNode.channelCount;
    }
    set channelCount(u) {
      let c = this._nativeDynamicsCompressorNode.channelCount;
      if (this._nativeDynamicsCompressorNode.channelCount = u, u > 2) throw this._nativeDynamicsCompressorNode.channelCount = c, o();
    }
    get channelCountMode() {
      return this._nativeDynamicsCompressorNode.channelCountMode;
    }
    set channelCountMode(u) {
      let c = this._nativeDynamicsCompressorNode.channelCountMode;
      if (this._nativeDynamicsCompressorNode.channelCountMode = u, u === "max") throw this._nativeDynamicsCompressorNode.channelCountMode = c, o();
    }
    get knee() {
      return this._knee;
    }
    get ratio() {
      return this._ratio;
    }
    get reduction() {
      return typeof this._nativeDynamicsCompressorNode.reduction.value == "number" ? this._nativeDynamicsCompressorNode.reduction.value : this._nativeDynamicsCompressorNode.reduction;
    }
    get release() {
      return this._release;
    }
    get threshold() {
      return this._threshold;
    }
  };
  var mS = (t, e, r, n, o) => () => {
    let i = /* @__PURE__ */ new WeakMap(), s = async (a, l) => {
      let u = r(a), c = he(u, l);
      if (!c) {
        let p = { attack: u.attack.value, channelCount: u.channelCount, channelCountMode: u.channelCountMode, channelInterpretation: u.channelInterpretation, knee: u.knee.value, ratio: u.ratio.value, release: u.release.value, threshold: u.threshold.value };
        u = e(l, p);
      }
      return i.set(l, u), c ? (await t(l, a.attack, u.attack), await t(l, a.knee, u.knee), await t(l, a.ratio, u.ratio), await t(l, a.release, u.release), await t(l, a.threshold, u.threshold)) : (await n(l, a.attack, u.attack), await n(l, a.knee, u.knee), await n(l, a.ratio, u.ratio), await n(l, a.release, u.release), await n(l, a.threshold, u.threshold)), await o(a, l, u), u;
    };
    return { render(a, l) {
      let u = i.get(l);
      return u !== void 0 ? Promise.resolve(u) : s(a, l);
    } };
  };
  var dS = () => new DOMException("", "EncodingError");
  var gS = (t) => (e) => new Promise((r, n) => {
    if (t === null) {
      n(new SyntaxError());
      return;
    }
    let o = t.document.head;
    if (o === null) n(new SyntaxError());
    else {
      let i = t.document.createElement("script"), s = new Blob([e], { type: "application/javascript" }), a = URL.createObjectURL(s), l = t.onerror, u = () => {
        t.onerror = l, URL.revokeObjectURL(a);
      };
      t.onerror = (c, p, h, f, m) => {
        if (p === a || p === t.location.href && h === 1 && f === 1) return u(), n(m), false;
        if (l !== null) return l(c, p, h, f, m);
      }, i.onerror = () => {
        u(), n(new SyntaxError());
      }, i.onload = () => {
        u(), r();
      }, i.src = a, i.type = "module", o.appendChild(i);
    }
  });
  var xS = (t) => class {
    constructor(r) {
      this._nativeEventTarget = r, this._listeners = /* @__PURE__ */ new WeakMap();
    }
    addEventListener(r, n, o) {
      if (n !== null) {
        let i = this._listeners.get(n);
        i === void 0 && (i = t(this, n), typeof n == "function" && this._listeners.set(n, i)), this._nativeEventTarget.addEventListener(r, i, o);
      }
    }
    dispatchEvent(r) {
      return this._nativeEventTarget.dispatchEvent(r);
    }
    removeEventListener(r, n, o) {
      let i = n === null ? void 0 : this._listeners.get(n);
      this._nativeEventTarget.removeEventListener(r, i === void 0 ? null : i, o);
    }
  };
  var yS = (t) => (e, r, n) => {
    Object.defineProperties(t, { currentFrame: { configurable: true, get() {
      return Math.round(e * r);
    } }, currentTime: { configurable: true, get() {
      return e;
    } } });
    try {
      return n();
    } finally {
      t !== null && (delete t.currentFrame, delete t.currentTime);
    }
  };
  var _S = (t) => async (e) => {
    try {
      let r = await fetch(e);
      if (r.ok) return [await r.text(), r.url];
    } catch {
    }
    throw t();
  };
  var qO = { channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", gain: 1 }, vS = (t, e, r, n, o, i) => class extends t {
    constructor(a, l) {
      let u = o(a), c = { ...qO, ...l }, p = n(u, c), h = i(u), f = h ? r() : null;
      super(a, false, p, f), this._gain = e(this, h, p.gain, Ue, Ye);
    }
    get gain() {
      return this._gain;
    }
  };
  var wS = (t, e, r, n, o) => () => {
    let i = /* @__PURE__ */ new WeakMap(), s = async (a, l) => {
      let u = r(a), c = he(u, l);
      if (!c) {
        let p = { channelCount: u.channelCount, channelCountMode: u.channelCountMode, channelInterpretation: u.channelInterpretation, gain: u.gain.value };
        u = e(l, p);
      }
      return i.set(l, u), c ? await t(l, a.gain, u.gain) : await n(l, a.gain, u.gain), await o(a, l, u), u;
    };
    return { render(a, l) {
      let u = i.get(l);
      return u !== void 0 ? Promise.resolve(u) : s(a, l);
    } };
  };
  var SS = (t, e) => (r) => e(t, r);
  var TS = (t) => (e) => {
    let r = t(e);
    if (r.renderer === null) throw new Error("Missing the renderer of the given AudioNode in the audio graph.");
    return r.renderer;
  };
  var AS = (t) => (e) => {
    var r;
    return (r = t.get(e)) !== null && r !== void 0 ? r : 0;
  };
  var CS = (t) => (e) => {
    let r = t(e);
    if (r.renderer === null) throw new Error("Missing the renderer of the given AudioParam in the audio graph.");
    return r.renderer;
  };
  var kS = (t) => (e) => t.get(e);
  var Ne = () => new DOMException("", "InvalidStateError");
  var ES = (t) => (e) => {
    let r = t.get(e);
    if (r === void 0) throw Ne();
    return r;
  };
  var bS = (t, e) => (r) => {
    let n = t.get(r);
    if (n !== void 0) return n;
    if (e === null) throw new Error("Missing the native OfflineAudioContext constructor.");
    return n = new e(1, 1, 44100), t.set(r, n), n;
  };
  var NS = (t) => (e) => {
    let r = t.get(e);
    if (r === void 0) throw new Error("The context has no set of AudioWorkletNodes.");
    return r;
  };
  var Ps = () => new DOMException("", "InvalidAccessError");
  var OS = (t) => {
    t.getFrequencyResponse = /* @__PURE__ */ ((e) => (r, n, o) => {
      if (r.length !== n.length || n.length !== o.length) throw Ps();
      return e.call(t, r, n, o);
    })(t.getFrequencyResponse);
  };
  var zO = { channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers" }, DS = (t, e, r, n, o, i) => class extends t {
    constructor(a, l) {
      let u = n(a), c = o(u), p = { ...zO, ...l }, h = e(u, c ? null : a.baseLatency, p), f = c ? r(p.feedback, p.feedforward) : null;
      super(a, false, h, f), OS(h), this._nativeIIRFilterNode = h, i(this, 1);
    }
    getFrequencyResponse(a, l, u) {
      return this._nativeIIRFilterNode.getFrequencyResponse(a, l, u);
    }
  };
  var Sp = (t, e, r, n, o, i, s, a, l, u, c) => {
    let p = u.length, h = a;
    for (let f = 0; f < p; f += 1) {
      let m = r[0] * u[f];
      for (let x = 1; x < o; x += 1) {
        let _ = h - x & l - 1;
        m += r[x] * i[_], m -= t[x] * s[_];
      }
      for (let x = o; x < n; x += 1) m += r[x] * i[h - x & l - 1];
      for (let x = o; x < e; x += 1) m -= t[x] * s[h - x & l - 1];
      i[h] = u[f], s[h] = m, h = h + 1 & l - 1, c[f] = m;
    }
    return h;
  };
  var WO = (t, e, r, n) => {
    let o = r instanceof Float64Array ? r : new Float64Array(r), i = n instanceof Float64Array ? n : new Float64Array(n), s = o.length, a = i.length, l = Math.min(s, a);
    if (o[0] !== 1) {
      for (let m = 0; m < s; m += 1) i[m] /= o[0];
      for (let m = 1; m < a; m += 1) o[m] /= o[0];
    }
    let u = 32, c = new Float32Array(u), p = new Float32Array(u), h = e.createBuffer(t.numberOfChannels, t.length, t.sampleRate), f = t.numberOfChannels;
    for (let m = 0; m < f; m += 1) {
      let x = t.getChannelData(m), _ = h.getChannelData(m);
      c.fill(0), p.fill(0), Sp(o, s, i, a, l, c, p, 0, u, x, _);
    }
    return h;
  }, MS = (t, e, r, n, o) => (i, s) => {
    let a = /* @__PURE__ */ new WeakMap(), l = null, u = async (c, p) => {
      let h = null, f = e(c), m = he(f, p);
      if (p.createIIRFilter === void 0 ? h = t(p, { buffer: null, channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", loop: false, loopEnd: 0, loopStart: 0, playbackRate: 1 }) : m || (f = p.createIIRFilter(s, i)), a.set(p, h === null ? f : h), h !== null) {
        if (l === null) {
          if (r === null) throw new Error("Missing the native OfflineAudioContext constructor.");
          let _ = new r(c.context.destination.channelCount, c.context.length, p.sampleRate);
          l = (async () => {
            await n(c, _, _.destination);
            let d = await o(_);
            return WO(d, p, i, s);
          })();
        }
        let x = await l;
        return h.buffer = x, h.start(0), h;
      }
      return await n(c, p, f), f;
    };
    return { render(c, p) {
      let h = a.get(p);
      return h !== void 0 ? Promise.resolve(h) : u(c, p);
    } };
  };
  var PS = (t, e, r, n, o, i) => (s) => (a, l) => {
    let u = t.get(a);
    if (u === void 0) {
      if (!s && i(a)) {
        let c = n(a), { outputs: p } = r(a);
        for (let h of p) if (Oo(h)) {
          let f = n(h[0]);
          e(c, f, h[1], h[2]);
        } else {
          let f = o(h[0]);
          c.disconnect(f, h[1]);
        }
      }
      t.set(a, l);
    } else t.set(a, u + l);
  };
  var RS = (t, e) => (r) => {
    let n = t.get(r);
    return e(n) || e(r);
  };
  var VS = (t, e) => (r) => t.has(r) || e(r);
  var FS = (t, e) => (r) => t.has(r) || e(r);
  var IS = (t, e) => (r) => {
    let n = t.get(r);
    return e(n) || e(r);
  };
  var LS = (t) => (e) => t !== null && e instanceof t;
  var BS = (t) => (e) => t !== null && typeof t.AudioNode == "function" && e instanceof t.AudioNode;
  var jS = (t) => (e) => t !== null && typeof t.AudioParam == "function" && e instanceof t.AudioParam;
  var qS = (t, e) => (r) => t(r) || e(r);
  var zS = (t) => (e) => t !== null && e instanceof t;
  var WS = (t) => t !== null && t.isSecureContext;
  var US = (t, e, r, n) => class extends t {
    constructor(i, s) {
      let a = r(i), l = e(a, s);
      if (n(a)) throw TypeError();
      super(i, true, l, null), this._nativeMediaElementAudioSourceNode = l;
    }
    get mediaElement() {
      return this._nativeMediaElementAudioSourceNode.mediaElement;
    }
  };
  var UO = { channelCount: 2, channelCountMode: "explicit", channelInterpretation: "speakers" }, GS = (t, e, r, n) => class extends t {
    constructor(i, s) {
      let a = r(i);
      if (n(a)) throw new TypeError();
      let l = { ...UO, ...s }, u = e(a, l);
      super(i, false, u, null), this._nativeMediaStreamAudioDestinationNode = u;
    }
    get stream() {
      return this._nativeMediaStreamAudioDestinationNode.stream;
    }
  };
  var HS = (t, e, r, n) => class extends t {
    constructor(i, s) {
      let a = r(i), l = e(a, s);
      if (n(a)) throw new TypeError();
      super(i, true, l, null), this._nativeMediaStreamAudioSourceNode = l;
    }
    get mediaStream() {
      return this._nativeMediaStreamAudioSourceNode.mediaStream;
    }
  };
  var $S = (t, e, r) => class extends t {
    constructor(o, i) {
      let s = r(o), a = e(s, i);
      super(o, true, a, null);
    }
  };
  var XS = (t, e, r, n, o) => class extends n {
    constructor(s = {}) {
      if (o === null) throw new Error("Missing the native AudioContext constructor.");
      let a;
      try {
        a = new o(s);
      } catch (c) {
        throw c.code === 12 && c.message === "sampleRate is not in range" ? e() : c;
      }
      if (a === null) throw r();
      if (!yp(s.latencyHint)) throw new TypeError(`The provided value '${s.latencyHint}' is not a valid enum value of type AudioContextLatencyCategory.`);
      if (s.sampleRate !== void 0 && a.sampleRate !== s.sampleRate) throw e();
      super(a, 2);
      let { latencyHint: l } = s, { sampleRate: u } = a;
      if (this._baseLatency = typeof a.baseLatency == "number" ? a.baseLatency : l === "balanced" ? 512 / u : l === "interactive" || l === void 0 ? 256 / u : l === "playback" ? 1024 / u : Math.max(2, Math.min(128, Math.round(l * u / 128))) * 128 / u, this._nativeAudioContext = a, o.name === "webkitAudioContext" ? (this._nativeGainNode = a.createGain(), this._nativeOscillatorNode = a.createOscillator(), this._nativeGainNode.gain.value = 1e-37, this._nativeOscillatorNode.connect(this._nativeGainNode).connect(a.destination), this._nativeOscillatorNode.start()) : (this._nativeGainNode = null, this._nativeOscillatorNode = null), this._state = null, a.state === "running") {
        this._state = "suspended";
        let c = () => {
          this._state === "suspended" && (this._state = null), a.removeEventListener("statechange", c);
        };
        a.addEventListener("statechange", c);
      }
    }
    get baseLatency() {
      return this._baseLatency;
    }
    get state() {
      return this._state !== null ? this._state : this._nativeAudioContext.state;
    }
    close() {
      return this.state === "closed" ? this._nativeAudioContext.close().then(() => {
        throw t();
      }) : (this._state === "suspended" && (this._state = null), this._nativeAudioContext.close().then(() => {
        this._nativeGainNode !== null && this._nativeOscillatorNode !== null && (this._nativeOscillatorNode.stop(), this._nativeGainNode.disconnect(), this._nativeOscillatorNode.disconnect()), No(this);
      }));
    }
    resume() {
      return this._state === "suspended" ? new Promise((s, a) => {
        let l = () => {
          this._nativeAudioContext.removeEventListener("statechange", l), this._nativeAudioContext.state === "running" ? s() : this.resume().then(s, a);
        };
        this._nativeAudioContext.addEventListener("statechange", l);
      }) : this._nativeAudioContext.resume().catch((s) => {
        throw s === void 0 || s.code === 15 ? t() : s;
      });
    }
    suspend() {
      return this._nativeAudioContext.suspend().catch((s) => {
        throw s === void 0 ? t() : s;
      });
    }
  };
  var YS = (t, e, r, n, o, i) => class extends r {
    constructor(a, l) {
      super(a), this._nativeContext = a, As.set(this, a), n(a) && o.set(a, /* @__PURE__ */ new Set()), this._destination = new t(this, l), this._listener = e(this, a), this._onstatechange = null;
    }
    get currentTime() {
      return this._nativeContext.currentTime;
    }
    get destination() {
      return this._destination;
    }
    get listener() {
      return this._listener;
    }
    get onstatechange() {
      return this._onstatechange;
    }
    set onstatechange(a) {
      let l = typeof a == "function" ? i(this, a) : null;
      this._nativeContext.onstatechange = l;
      let u = this._nativeContext.onstatechange;
      this._onstatechange = u !== null && u === l ? a : u;
    }
    get sampleRate() {
      return this._nativeContext.sampleRate;
    }
    get state() {
      return this._nativeContext.state;
    }
  };
  var Qr = (t) => {
    let e = new Uint32Array([1179011410, 40, 1163280727, 544501094, 16, 131073, 44100, 176400, 1048580, 1635017060, 4, 0]);
    try {
      let r = t.decodeAudioData(e.buffer, () => {
      });
      return r === void 0 ? false : (r.catch(() => {
      }), true);
    } catch {
    }
    return false;
  };
  var GO = { numberOfChannels: 1 }, QS = (t, e, r, n, o) => class extends n {
    constructor(s) {
      let { length: a, numberOfChannels: l, sampleRate: u } = { ...GO, ...s }, c = r(l, a, u);
      t(Qr, () => Qr(c)) || c.addEventListener("statechange", /* @__PURE__ */ (() => {
        let p = 0, h = (f) => {
          this._state === "running" && (p > 0 ? (c.removeEventListener("statechange", h), f.stopImmediatePropagation(), this._waitForThePromiseToSettle(f)) : p += 1);
        };
        return h;
      })()), super(c, l), this._length = a, this._nativeOfflineAudioContext = c, this._state = null;
    }
    get length() {
      return this._nativeOfflineAudioContext.length === void 0 ? this._length : this._nativeOfflineAudioContext.length;
    }
    get state() {
      return this._state === null ? this._nativeOfflineAudioContext.state : this._state;
    }
    startRendering() {
      return this._state === "running" ? Promise.reject(e()) : (this._state = "running", o(this.destination, this._nativeOfflineAudioContext).finally(() => {
        this._state = null, No(this);
      }));
    }
    _waitForThePromiseToSettle(s) {
      this._state === null ? this._nativeOfflineAudioContext.dispatchEvent(s) : setTimeout(() => this._waitForThePromiseToSettle(s));
    }
  };
  var KS = (t, e) => (r, n, o) => {
    let i = /* @__PURE__ */ new Set();
    return r.connect = /* @__PURE__ */ ((s) => (a, l = 0, u = 0) => {
      let c = i.size === 0;
      if (e(a)) return s.call(r, a, l, u), t(i, [a, l, u], (p) => p[0] === a && p[1] === l && p[2] === u, true), c && n(), a;
      s.call(r, a, l), t(i, [a, l], (p) => p[0] === a && p[1] === l, true), c && n();
    })(r.connect), r.disconnect = /* @__PURE__ */ ((s) => (a, l, u) => {
      let c = i.size > 0;
      if (a === void 0) s.apply(r), i.clear();
      else if (typeof a == "number") {
        s.call(r, a);
        for (let h of i) h[1] === a && i.delete(h);
      } else {
        e(a) ? s.call(r, a, l, u) : s.call(r, a, l);
        for (let h of i) h[0] === a && (l === void 0 || h[1] === l) && (u === void 0 || h[2] === u) && i.delete(h);
      }
      let p = i.size === 0;
      c && p && o();
    })(r.disconnect), r;
  };
  var fe = (t, e, r) => {
    let n = e[r];
    n !== void 0 && n !== t[r] && (t[r] = n);
  };
  var le = (t, e) => {
    fe(t, e, "channelCount"), fe(t, e, "channelCountMode"), fe(t, e, "channelInterpretation");
  };
  var og = (t) => typeof t.getFloatTimeDomainData == "function";
  var ZS = (t) => {
    t.getFloatTimeDomainData = (e) => {
      let r = new Uint8Array(e.length);
      t.getByteTimeDomainData(r);
      let n = Math.max(r.length, t.fftSize);
      for (let o = 0; o < n; o += 1) e[o] = (r[o] - 128) * 78125e-7;
      return e;
    };
  };
  var JS = (t, e) => (r, n) => {
    let o = r.createAnalyser();
    if (le(o, n), !(n.maxDecibels > n.minDecibels)) throw e();
    return fe(o, n, "fftSize"), fe(o, n, "maxDecibels"), fe(o, n, "minDecibels"), fe(o, n, "smoothingTimeConstant"), t(og, () => og(o)) || ZS(o), o;
  };
  var eT = (t) => t === null ? null : t.hasOwnProperty("AudioBuffer") ? t.AudioBuffer : null;
  var de = (t, e, r) => {
    let n = e[r];
    n !== void 0 && n !== t[r].value && (t[r].value = n);
  };
  var tT = (t) => {
    t.start = /* @__PURE__ */ ((e) => {
      let r = false;
      return (n = 0, o = 0, i) => {
        if (r) throw Ne();
        e.call(t, n, o, i), r = true;
      };
    })(t.start);
  };
  var Rs = (t) => {
    t.start = /* @__PURE__ */ ((e) => (r = 0, n = 0, o) => {
      if (typeof o == "number" && o < 0 || n < 0 || r < 0) throw new RangeError("The parameters can't be negative.");
      e.call(t, r, n, o);
    })(t.start);
  };
  var Vs = (t) => {
    t.stop = /* @__PURE__ */ ((e) => (r = 0) => {
      if (r < 0) throw new RangeError("The parameter can't be negative.");
      e.call(t, r);
    })(t.stop);
  };
  var rT = (t, e, r, n, o, i, s, a, l, u, c) => (p, h) => {
    let f = p.createBufferSource();
    return le(f, h), de(f, h, "playbackRate"), fe(f, h, "buffer"), fe(f, h, "loop"), fe(f, h, "loopEnd"), fe(f, h, "loopStart"), e(r, () => r(p)) || tT(f), e(n, () => n(p)) || l(f), e(o, () => o(p)) || u(f, p), e(i, () => i(p)) || Rs(f), e(s, () => s(p)) || c(f, p), e(a, () => a(p)) || Vs(f), t(p, f), f;
  };
  var nT = (t) => t === null ? null : t.hasOwnProperty("AudioContext") ? t.AudioContext : t.hasOwnProperty("webkitAudioContext") ? t.webkitAudioContext : null;
  var oT = (t, e) => (r, n, o) => {
    let i = r.destination;
    if (i.channelCount !== n) try {
      i.channelCount = n;
    } catch {
    }
    o && i.channelCountMode !== "explicit" && (i.channelCountMode = "explicit"), i.maxChannelCount === 0 && Object.defineProperty(i, "maxChannelCount", { value: n });
    let s = t(r, { channelCount: n, channelCountMode: i.channelCountMode, channelInterpretation: i.channelInterpretation, gain: 1 });
    return e(s, "channelCount", (a) => () => a.call(s), (a) => (l) => {
      a.call(s, l);
      try {
        i.channelCount = l;
      } catch (u) {
        if (l > i.maxChannelCount) throw u;
      }
    }), e(s, "channelCountMode", (a) => () => a.call(s), (a) => (l) => {
      a.call(s, l), i.channelCountMode = l;
    }), e(s, "channelInterpretation", (a) => () => a.call(s), (a) => (l) => {
      a.call(s, l), i.channelInterpretation = l;
    }), Object.defineProperty(s, "maxChannelCount", { get: () => i.maxChannelCount }), s.connect(i), s;
  };
  var iT = (t) => t === null ? null : t.hasOwnProperty("AudioWorkletNode") ? t.AudioWorkletNode : null;
  var sT = (t) => {
    let { port1: e } = new MessageChannel();
    try {
      e.postMessage(t);
    } finally {
      e.close();
    }
  };
  var aT = (t, e, r, n, o) => (i, s, a, l, u, c) => {
    if (a !== null) try {
      let p = new a(i, l, c), h = /* @__PURE__ */ new Map(), f = null;
      if (Object.defineProperties(p, { channelCount: { get: () => c.channelCount, set: () => {
        throw t();
      } }, channelCountMode: { get: () => "explicit", set: () => {
        throw t();
      } }, onprocessorerror: { get: () => f, set: (m) => {
        typeof f == "function" && p.removeEventListener("processorerror", f), f = typeof m == "function" ? m : null, typeof f == "function" && p.addEventListener("processorerror", f);
      } } }), p.addEventListener = /* @__PURE__ */ ((m) => (...x) => {
        if (x[0] === "processorerror") {
          let _ = typeof x[1] == "function" ? x[1] : typeof x[1] == "object" && x[1] !== null && typeof x[1].handleEvent == "function" ? x[1].handleEvent : null;
          if (_ !== null) {
            let d = h.get(x[1]);
            d !== void 0 ? x[1] = d : (x[1] = (g) => {
              g.type === "error" ? (Object.defineProperties(g, { type: { value: "processorerror" } }), _(g)) : _(new ErrorEvent(x[0], { ...g }));
            }, h.set(_, x[1]));
          }
        }
        return m.call(p, "error", x[1], x[2]), m.call(p, ...x);
      })(p.addEventListener), p.removeEventListener = /* @__PURE__ */ ((m) => (...x) => {
        if (x[0] === "processorerror") {
          let _ = h.get(x[1]);
          _ !== void 0 && (h.delete(x[1]), x[1] = _);
        }
        return m.call(p, "error", x[1], x[2]), m.call(p, x[0], x[1], x[2]);
      })(p.removeEventListener), c.numberOfOutputs !== 0) {
        let m = r(i, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", gain: 0 });
        return p.connect(m).connect(i.destination), o(p, () => m.disconnect(), () => m.connect(i.destination));
      }
      return p;
    } catch (p) {
      throw p.code === 11 ? n() : p;
    }
    if (u === void 0) throw n();
    return sT(c), e(i, s, u, c);
  };
  var Tp = (t, e) => t === null ? 512 : Math.max(512, Math.min(16384, Math.pow(2, Math.round(Math.log2(t * e)))));
  var lT = (t) => new Promise((e, r) => {
    let { port1: n, port2: o } = new MessageChannel();
    n.onmessage = ({ data: i }) => {
      n.close(), o.close(), e(i);
    }, n.onmessageerror = ({ data: i }) => {
      n.close(), o.close(), r(i);
    }, o.postMessage(t);
  });
  var uT = async (t, e) => {
    let r = await lT(e);
    return new t(r);
  };
  var cT = (t, e, r, n) => {
    let o = Vl.get(t);
    o === void 0 && (o = /* @__PURE__ */ new WeakMap(), Vl.set(t, o));
    let i = uT(r, n);
    return o.set(e, i), i;
  };
  var pT = (t, e, r, n, o, i, s, a, l, u, c, p, h) => (f, m, x, _) => {
    if (_.numberOfInputs === 0 && _.numberOfOutputs === 0) throw l();
    let d = Array.isArray(_.outputChannelCount) ? _.outputChannelCount : Array.from(_.outputChannelCount);
    if (d.some((H) => H < 1)) throw l();
    if (d.length !== _.numberOfOutputs) throw e();
    if (_.channelCountMode !== "explicit") throw l();
    let g = _.channelCount * _.numberOfInputs, y = d.reduce((H, J) => H + J, 0), S = x.parameterDescriptors === void 0 ? 0 : x.parameterDescriptors.length;
    if (g + S > 6 || y > 6) throw l();
    let v = new MessageChannel(), T = [], A = [];
    for (let H = 0; H < _.numberOfInputs; H += 1) T.push(s(f, { channelCount: _.channelCount, channelCountMode: _.channelCountMode, channelInterpretation: _.channelInterpretation, gain: 1 })), A.push(o(f, { channelCount: _.channelCount, channelCountMode: "explicit", channelInterpretation: "discrete", numberOfOutputs: _.channelCount }));
    let w = [];
    if (x.parameterDescriptors !== void 0) for (let { defaultValue: H, maxValue: J, minValue: at, name: Me } of x.parameterDescriptors) {
      let me = i(f, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", offset: _.parameterData[Me] !== void 0 ? _.parameterData[Me] : H === void 0 ? 0 : H });
      Object.defineProperties(me.offset, { defaultValue: { get: () => H === void 0 ? 0 : H }, maxValue: { get: () => J === void 0 ? Ue : J }, minValue: { get: () => at === void 0 ? Ye : at } }), w.push(me);
    }
    let N = n(f, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: Math.max(1, g + S) }), k = Tp(m, f.sampleRate), D = a(f, k, g + S, Math.max(1, y)), M = o(f, { channelCount: Math.max(1, y), channelCountMode: "explicit", channelInterpretation: "discrete", numberOfOutputs: Math.max(1, y) }), q = [];
    for (let H = 0; H < _.numberOfOutputs; H += 1) q.push(n(f, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: d[H] }));
    for (let H = 0; H < _.numberOfInputs; H += 1) {
      T[H].connect(A[H]);
      for (let J = 0; J < _.channelCount; J += 1) A[H].connect(N, J, H * _.channelCount + J);
    }
    let B = new Os(x.parameterDescriptors === void 0 ? [] : x.parameterDescriptors.map(({ name: H }, J) => {
      let at = w[J];
      return at.connect(N, 0, g + J), at.start(0), [H, at.offset];
    }));
    N.connect(D);
    let I = _.channelInterpretation, C = null, E = _.numberOfOutputs === 0 ? [D] : q, O = { get bufferSize() {
      return k;
    }, get channelCount() {
      return _.channelCount;
    }, set channelCount(H) {
      throw r();
    }, get channelCountMode() {
      return _.channelCountMode;
    }, set channelCountMode(H) {
      throw r();
    }, get channelInterpretation() {
      return I;
    }, set channelInterpretation(H) {
      for (let J of T) J.channelInterpretation = H;
      I = H;
    }, get context() {
      return D.context;
    }, get inputs() {
      return T;
    }, get numberOfInputs() {
      return _.numberOfInputs;
    }, get numberOfOutputs() {
      return _.numberOfOutputs;
    }, get onprocessorerror() {
      return C;
    }, set onprocessorerror(H) {
      typeof C == "function" && O.removeEventListener("processorerror", C), C = typeof H == "function" ? H : null, typeof C == "function" && O.addEventListener("processorerror", C);
    }, get parameters() {
      return B;
    }, get port() {
      return v.port2;
    }, addEventListener(...H) {
      return D.addEventListener(H[0], H[1], H[2]);
    }, connect: t.bind(null, E), disconnect: u.bind(null, E), dispatchEvent(...H) {
      return D.dispatchEvent(H[0]);
    }, removeEventListener(...H) {
      return D.removeEventListener(H[0], H[1], H[2]);
    } }, R = /* @__PURE__ */ new Map();
    v.port1.addEventListener = /* @__PURE__ */ ((H) => (...J) => {
      if (J[0] === "message") {
        let at = typeof J[1] == "function" ? J[1] : typeof J[1] == "object" && J[1] !== null && typeof J[1].handleEvent == "function" ? J[1].handleEvent : null;
        if (at !== null) {
          let Me = R.get(J[1]);
          Me !== void 0 ? J[1] = Me : (J[1] = (me) => {
            c(f.currentTime, f.sampleRate, () => at(me));
          }, R.set(at, J[1]));
        }
      }
      return H.call(v.port1, J[0], J[1], J[2]);
    })(v.port1.addEventListener), v.port1.removeEventListener = /* @__PURE__ */ ((H) => (...J) => {
      if (J[0] === "message") {
        let at = R.get(J[1]);
        at !== void 0 && (R.delete(J[1]), J[1] = at);
      }
      return H.call(v.port1, J[0], J[1], J[2]);
    })(v.port1.removeEventListener);
    let P = null;
    Object.defineProperty(v.port1, "onmessage", { get: () => P, set: (H) => {
      typeof P == "function" && v.port1.removeEventListener("message", P), P = typeof H == "function" ? H : null, typeof P == "function" && (v.port1.addEventListener("message", P), v.port1.start());
    } }), x.prototype.port = v.port1;
    let V = null;
    cT(f, O, x, _).then((H) => V = H);
    let j = Ms(_.numberOfInputs, _.channelCount), re = Ms(_.numberOfOutputs, d), Y = x.parameterDescriptors === void 0 ? [] : x.parameterDescriptors.reduce((H, { name: J }) => ({ ...H, [J]: new Float32Array(128) }), {}), K = true, ue = () => {
      _.numberOfOutputs > 0 && D.disconnect(M);
      for (let H = 0, J = 0; H < _.numberOfOutputs; H += 1) {
        let at = q[H];
        for (let Me = 0; Me < d[H]; Me += 1) M.disconnect(at, J + Me, Me);
        J += d[H];
      }
    }, W = /* @__PURE__ */ new Map();
    D.onaudioprocess = ({ inputBuffer: H, outputBuffer: J }) => {
      if (V !== null) {
        let at = p(O);
        for (let Me = 0; Me < k; Me += 128) {
          for (let me = 0; me < _.numberOfInputs; me += 1) for (let ze = 0; ze < _.channelCount; ze += 1) Ds(H, j[me], ze, ze, Me);
          x.parameterDescriptors !== void 0 && x.parameterDescriptors.forEach(({ name: me }, ze) => {
            Ds(H, Y, me, g + ze, Me);
          });
          for (let me = 0; me < _.numberOfInputs; me += 1) for (let ze = 0; ze < d[me]; ze += 1) re[me][ze].byteLength === 0 && (re[me][ze] = new Float32Array(128));
          try {
            let me = j.map((yr, oo) => {
              if (at[oo].size > 0) return W.set(oo, k / 128), yr;
              let Cf = W.get(oo);
              return Cf === void 0 ? [] : (yr.every((VE) => VE.every((FE) => FE === 0)) && (Cf === 1 ? W.delete(oo) : W.set(oo, Cf - 1)), yr);
            });
            K = c(f.currentTime + Me / f.sampleRate, f.sampleRate, () => V.process(me, re, Y));
            for (let yr = 0, oo = 0; yr < _.numberOfOutputs; yr += 1) {
              for (let ba = 0; ba < d[yr]; ba += 1) vp(J, re[yr], ba, oo + ba, Me);
              oo += d[yr];
            }
          } catch (me) {
            K = false, O.dispatchEvent(new ErrorEvent("processorerror", { colno: me.colno, filename: me.filename, lineno: me.lineno, message: me.message }));
          }
          if (!K) {
            for (let me = 0; me < _.numberOfInputs; me += 1) {
              T[me].disconnect(A[me]);
              for (let ze = 0; ze < _.channelCount; ze += 1) A[Me].disconnect(N, ze, me * _.channelCount + ze);
            }
            if (x.parameterDescriptors !== void 0) {
              let me = x.parameterDescriptors.length;
              for (let ze = 0; ze < me; ze += 1) {
                let yr = w[ze];
                yr.disconnect(N, 0, g + ze), yr.stop();
              }
            }
            N.disconnect(D), D.onaudioprocess = null, st ? ue() : Br();
            break;
          }
        }
      }
    };
    let st = false, Je = s(f, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", gain: 0 }), un = () => D.connect(Je).connect(f.destination), Br = () => {
      D.disconnect(Je), Je.disconnect();
    }, qu = () => {
      if (K) {
        Br(), _.numberOfOutputs > 0 && D.connect(M);
        for (let H = 0, J = 0; H < _.numberOfOutputs; H += 1) {
          let at = q[H];
          for (let Me = 0; Me < d[H]; Me += 1) M.connect(at, J + Me, Me);
          J += d[H];
        }
      }
      st = true;
    }, zu = () => {
      K && (un(), ue()), st = false;
    };
    return un(), h(O, qu, zu);
  };
  var ig = (t, e) => {
    let r = t.createBiquadFilter();
    return le(r, e), de(r, e, "Q"), de(r, e, "detune"), de(r, e, "frequency"), de(r, e, "gain"), fe(r, e, "type"), r;
  };
  var hT = (t, e) => (r, n) => {
    let o = r.createChannelMerger(n.numberOfInputs);
    return t !== null && t.name === "webkitAudioContext" && e(r, o), le(o, n), o;
  };
  var fT = (t) => {
    let e = t.numberOfOutputs;
    Object.defineProperty(t, "channelCount", { get: () => e, set: (r) => {
      if (r !== e) throw Ne();
    } }), Object.defineProperty(t, "channelCountMode", { get: () => "explicit", set: (r) => {
      if (r !== "explicit") throw Ne();
    } }), Object.defineProperty(t, "channelInterpretation", { get: () => "discrete", set: (r) => {
      if (r !== "discrete") throw Ne();
    } });
  };
  var Fs = (t, e) => {
    let r = t.createChannelSplitter(e.numberOfOutputs);
    return le(r, e), fT(r), r;
  };
  var mT = (t, e, r, n, o) => (i, s) => {
    if (i.createConstantSource === void 0) return r(i, s);
    let a = i.createConstantSource();
    return le(a, s), de(a, s, "offset"), e(n, () => n(i)) || Rs(a), e(o, () => o(i)) || Vs(a), t(i, a), a;
  };
  var br = (t, e) => (t.connect = e.connect.bind(e), t.disconnect = e.disconnect.bind(e), t);
  var dT = (t, e, r, n) => (o, { offset: i, ...s }) => {
    let a = o.createBuffer(1, 2, 44100), l = e(o, { buffer: null, channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", loop: false, loopEnd: 0, loopStart: 0, playbackRate: 1 }), u = r(o, { ...s, gain: i }), c = a.getChannelData(0);
    c[0] = 1, c[1] = 1, l.buffer = a, l.loop = true;
    let p = { get bufferSize() {
    }, get channelCount() {
      return u.channelCount;
    }, set channelCount(m) {
      u.channelCount = m;
    }, get channelCountMode() {
      return u.channelCountMode;
    }, set channelCountMode(m) {
      u.channelCountMode = m;
    }, get channelInterpretation() {
      return u.channelInterpretation;
    }, set channelInterpretation(m) {
      u.channelInterpretation = m;
    }, get context() {
      return u.context;
    }, get inputs() {
      return [];
    }, get numberOfInputs() {
      return l.numberOfInputs;
    }, get numberOfOutputs() {
      return u.numberOfOutputs;
    }, get offset() {
      return u.gain;
    }, get onended() {
      return l.onended;
    }, set onended(m) {
      l.onended = m;
    }, addEventListener(...m) {
      return l.addEventListener(m[0], m[1], m[2]);
    }, dispatchEvent(...m) {
      return l.dispatchEvent(m[0]);
    }, removeEventListener(...m) {
      return l.removeEventListener(m[0], m[1], m[2]);
    }, start(m = 0) {
      l.start.call(l, m);
    }, stop(m = 0) {
      l.stop.call(l, m);
    } }, h = () => l.connect(u), f = () => l.disconnect(u);
    return t(o, l), n(br(p, u), h, f);
  };
  var gT = (t, e) => (r, n) => {
    let o = r.createConvolver();
    if (le(o, n), n.disableNormalization === o.normalize && (o.normalize = !n.disableNormalization), fe(o, n, "buffer"), n.channelCount > 2 || (e(o, "channelCount", (i) => () => i.call(o), (i) => (s) => {
      if (s > 2) throw t();
      return i.call(o, s);
    }), n.channelCountMode === "max")) throw t();
    return e(o, "channelCountMode", (i) => () => i.call(o), (i) => (s) => {
      if (s === "max") throw t();
      return i.call(o, s);
    }), o;
  };
  var sg = (t, e) => {
    let r = t.createDelay(e.maxDelayTime);
    return le(r, e), de(r, e, "delayTime"), r;
  };
  var xT = (t) => (e, r) => {
    let n = e.createDynamicsCompressor();
    if (le(n, r), r.channelCount > 2 || r.channelCountMode === "max") throw t();
    return de(n, r, "attack"), de(n, r, "knee"), de(n, r, "ratio"), de(n, r, "release"), de(n, r, "threshold"), n;
  };
  var jt = (t, e) => {
    let r = t.createGain();
    return le(r, e), de(r, e, "gain"), r;
  };
  var yT = (t) => (e, r, n) => {
    if (e.createIIRFilter === void 0) return t(e, r, n);
    let o = e.createIIRFilter(n.feedforward, n.feedback);
    return le(o, n), o;
  };
  function HO(t, e) {
    let r = e[0] * e[0] + e[1] * e[1];
    return [(t[0] * e[0] + t[1] * e[1]) / r, (t[1] * e[0] - t[0] * e[1]) / r];
  }
  function $O(t, e) {
    return [t[0] * e[0] - t[1] * e[1], t[0] * e[1] + t[1] * e[0]];
  }
  function _T(t, e) {
    let r = [0, 0];
    for (let n = t.length - 1; n >= 0; n -= 1) r = $O(r, e), r[0] += t[n];
    return r;
  }
  var vT = (t, e, r, n) => (o, i, { channelCount: s, channelCountMode: a, channelInterpretation: l, feedback: u, feedforward: c }) => {
    let p = Tp(i, o.sampleRate), h = u instanceof Float64Array ? u : new Float64Array(u), f = c instanceof Float64Array ? c : new Float64Array(c), m = h.length, x = f.length, _ = Math.min(m, x);
    if (m === 0 || m > 20) throw n();
    if (h[0] === 0) throw e();
    if (x === 0 || x > 20) throw n();
    if (f[0] === 0) throw e();
    if (h[0] !== 1) {
      for (let w = 0; w < x; w += 1) f[w] /= h[0];
      for (let w = 1; w < m; w += 1) h[w] /= h[0];
    }
    let d = r(o, p, s, s);
    d.channelCount = s, d.channelCountMode = a, d.channelInterpretation = l;
    let g = 32, y = [], S = [], v = [];
    for (let w = 0; w < s; w += 1) {
      y.push(0);
      let N = new Float32Array(g), k = new Float32Array(g);
      N.fill(0), k.fill(0), S.push(N), v.push(k);
    }
    d.onaudioprocess = (w) => {
      let N = w.inputBuffer, k = w.outputBuffer, D = N.numberOfChannels;
      for (let M = 0; M < D; M += 1) {
        let q = N.getChannelData(M), B = k.getChannelData(M);
        y[M] = Sp(h, m, f, x, _, S[M], v[M], y[M], g, q, B);
      }
    };
    let T = o.sampleRate / 2;
    return br({ get bufferSize() {
      return p;
    }, get channelCount() {
      return d.channelCount;
    }, set channelCount(w) {
      d.channelCount = w;
    }, get channelCountMode() {
      return d.channelCountMode;
    }, set channelCountMode(w) {
      d.channelCountMode = w;
    }, get channelInterpretation() {
      return d.channelInterpretation;
    }, set channelInterpretation(w) {
      d.channelInterpretation = w;
    }, get context() {
      return d.context;
    }, get inputs() {
      return [d];
    }, get numberOfInputs() {
      return d.numberOfInputs;
    }, get numberOfOutputs() {
      return d.numberOfOutputs;
    }, addEventListener(...w) {
      return d.addEventListener(w[0], w[1], w[2]);
    }, dispatchEvent(...w) {
      return d.dispatchEvent(w[0]);
    }, getFrequencyResponse(w, N, k) {
      if (w.length !== N.length || N.length !== k.length) throw t();
      let D = w.length;
      for (let M = 0; M < D; M += 1) {
        let q = -Math.PI * (w[M] / T), B = [Math.cos(q), Math.sin(q)], I = _T(f, B), C = _T(h, B), E = HO(I, C);
        N[M] = Math.sqrt(E[0] * E[0] + E[1] * E[1]), k[M] = Math.atan2(E[1], E[0]);
      }
    }, removeEventListener(...w) {
      return d.removeEventListener(w[0], w[1], w[2]);
    } }, d);
  };
  var wT = (t, e) => t.createMediaElementSource(e.mediaElement);
  var ST = (t, e) => {
    let r = t.createMediaStreamDestination();
    return le(r, e), r.numberOfOutputs === 1 && Object.defineProperty(r, "numberOfOutputs", { get: () => 0 }), r;
  };
  var TT = (t, { mediaStream: e }) => {
    let r = e.getAudioTracks();
    r.sort((i, s) => i.id < s.id ? -1 : i.id > s.id ? 1 : 0);
    let n = r.slice(0, 1), o = t.createMediaStreamSource(new MediaStream(n));
    return Object.defineProperty(o, "mediaStream", { value: e }), o;
  };
  var AT = (t, e) => (r, { mediaStreamTrack: n }) => {
    if (typeof r.createMediaStreamTrackSource == "function") return r.createMediaStreamTrackSource(n);
    let o = new MediaStream([n]), i = r.createMediaStreamSource(o);
    if (n.kind !== "audio") throw t();
    if (e(r)) throw new TypeError();
    return i;
  };
  var CT = (t) => t === null ? null : t.hasOwnProperty("OfflineAudioContext") ? t.OfflineAudioContext : t.hasOwnProperty("webkitOfflineAudioContext") ? t.webkitOfflineAudioContext : null;
  var kT = (t, e, r, n, o, i) => (s, a) => {
    let l = s.createOscillator();
    return le(l, a), de(l, a, "detune"), de(l, a, "frequency"), a.periodicWave !== void 0 ? l.setPeriodicWave(a.periodicWave) : fe(l, a, "type"), e(r, () => r(s)) || Rs(l), e(n, () => n(s)) || i(l, s), e(o, () => o(s)) || Vs(l), t(s, l), l;
  };
  var ET = (t) => (e, r) => {
    let n = e.createPanner();
    return n.orientationX === void 0 ? t(e, r) : (le(n, r), de(n, r, "orientationX"), de(n, r, "orientationY"), de(n, r, "orientationZ"), de(n, r, "positionX"), de(n, r, "positionY"), de(n, r, "positionZ"), fe(n, r, "coneInnerAngle"), fe(n, r, "coneOuterAngle"), fe(n, r, "coneOuterGain"), fe(n, r, "distanceModel"), fe(n, r, "maxDistance"), fe(n, r, "panningModel"), fe(n, r, "refDistance"), fe(n, r, "rolloffFactor"), n);
  };
  var bT = (t, e, r, n, o, i, s, a, l, u) => (c, { coneInnerAngle: p, coneOuterAngle: h, coneOuterGain: f, distanceModel: m, maxDistance: x, orientationX: _, orientationY: d, orientationZ: g, panningModel: y, positionX: S, positionY: v, positionZ: T, refDistance: A, rolloffFactor: w, ...N }) => {
    let k = c.createPanner();
    if (N.channelCount > 2 || N.channelCountMode === "max") throw s();
    le(k, N);
    let D = { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete" }, M = r(c, { ...D, channelInterpretation: "speakers", numberOfInputs: 6 }), q = n(c, { ...N, gain: 1 }), B = n(c, { ...D, gain: 1 }), I = n(c, { ...D, gain: 0 }), C = n(c, { ...D, gain: 0 }), E = n(c, { ...D, gain: 0 }), O = n(c, { ...D, gain: 0 }), R = n(c, { ...D, gain: 0 }), P = o(c, 256, 6, 1), V = i(c, { ...D, curve: new Float32Array([1, 1]), oversample: "none" }), te = [_, d, g], j = [S, v, T], re = new Float32Array(1);
    P.onaudioprocess = ({ inputBuffer: W }) => {
      let st = [l(W, re, 0), l(W, re, 1), l(W, re, 2)];
      st.some((un, Br) => un !== te[Br]) && (k.setOrientation(...st), te = st);
      let Je = [l(W, re, 3), l(W, re, 4), l(W, re, 5)];
      Je.some((un, Br) => un !== j[Br]) && (k.setPosition(...Je), j = Je);
    }, Object.defineProperty(I.gain, "defaultValue", { get: () => 0 }), Object.defineProperty(C.gain, "defaultValue", { get: () => 0 }), Object.defineProperty(E.gain, "defaultValue", { get: () => 0 }), Object.defineProperty(O.gain, "defaultValue", { get: () => 0 }), Object.defineProperty(R.gain, "defaultValue", { get: () => 0 });
    let Y = { get bufferSize() {
    }, get channelCount() {
      return k.channelCount;
    }, set channelCount(W) {
      if (W > 2) throw s();
      q.channelCount = W, k.channelCount = W;
    }, get channelCountMode() {
      return k.channelCountMode;
    }, set channelCountMode(W) {
      if (W === "max") throw s();
      q.channelCountMode = W, k.channelCountMode = W;
    }, get channelInterpretation() {
      return k.channelInterpretation;
    }, set channelInterpretation(W) {
      q.channelInterpretation = W, k.channelInterpretation = W;
    }, get coneInnerAngle() {
      return k.coneInnerAngle;
    }, set coneInnerAngle(W) {
      k.coneInnerAngle = W;
    }, get coneOuterAngle() {
      return k.coneOuterAngle;
    }, set coneOuterAngle(W) {
      k.coneOuterAngle = W;
    }, get coneOuterGain() {
      return k.coneOuterGain;
    }, set coneOuterGain(W) {
      if (W < 0 || W > 1) throw e();
      k.coneOuterGain = W;
    }, get context() {
      return k.context;
    }, get distanceModel() {
      return k.distanceModel;
    }, set distanceModel(W) {
      k.distanceModel = W;
    }, get inputs() {
      return [q];
    }, get maxDistance() {
      return k.maxDistance;
    }, set maxDistance(W) {
      if (W < 0) throw new RangeError();
      k.maxDistance = W;
    }, get numberOfInputs() {
      return k.numberOfInputs;
    }, get numberOfOutputs() {
      return k.numberOfOutputs;
    }, get orientationX() {
      return B.gain;
    }, get orientationY() {
      return I.gain;
    }, get orientationZ() {
      return C.gain;
    }, get panningModel() {
      return k.panningModel;
    }, set panningModel(W) {
      k.panningModel = W;
    }, get positionX() {
      return E.gain;
    }, get positionY() {
      return O.gain;
    }, get positionZ() {
      return R.gain;
    }, get refDistance() {
      return k.refDistance;
    }, set refDistance(W) {
      if (W < 0) throw new RangeError();
      k.refDistance = W;
    }, get rolloffFactor() {
      return k.rolloffFactor;
    }, set rolloffFactor(W) {
      if (W < 0) throw new RangeError();
      k.rolloffFactor = W;
    }, addEventListener(...W) {
      return q.addEventListener(W[0], W[1], W[2]);
    }, dispatchEvent(...W) {
      return q.dispatchEvent(W[0]);
    }, removeEventListener(...W) {
      return q.removeEventListener(W[0], W[1], W[2]);
    } };
    p !== Y.coneInnerAngle && (Y.coneInnerAngle = p), h !== Y.coneOuterAngle && (Y.coneOuterAngle = h), f !== Y.coneOuterGain && (Y.coneOuterGain = f), m !== Y.distanceModel && (Y.distanceModel = m), x !== Y.maxDistance && (Y.maxDistance = x), _ !== Y.orientationX.value && (Y.orientationX.value = _), d !== Y.orientationY.value && (Y.orientationY.value = d), g !== Y.orientationZ.value && (Y.orientationZ.value = g), y !== Y.panningModel && (Y.panningModel = y), S !== Y.positionX.value && (Y.positionX.value = S), v !== Y.positionY.value && (Y.positionY.value = v), T !== Y.positionZ.value && (Y.positionZ.value = T), A !== Y.refDistance && (Y.refDistance = A), w !== Y.rolloffFactor && (Y.rolloffFactor = w), (te[0] !== 1 || te[1] !== 0 || te[2] !== 0) && k.setOrientation(...te), (j[0] !== 0 || j[1] !== 0 || j[2] !== 0) && k.setPosition(...j);
    let K = () => {
      q.connect(k), t(q, V, 0, 0), V.connect(B).connect(M, 0, 0), V.connect(I).connect(M, 0, 1), V.connect(C).connect(M, 0, 2), V.connect(E).connect(M, 0, 3), V.connect(O).connect(M, 0, 4), V.connect(R).connect(M, 0, 5), M.connect(P).connect(c.destination);
    }, ue = () => {
      q.disconnect(k), a(q, V, 0, 0), V.disconnect(B), B.disconnect(M), V.disconnect(I), I.disconnect(M), V.disconnect(C), C.disconnect(M), V.disconnect(E), E.disconnect(M), V.disconnect(O), O.disconnect(M), V.disconnect(R), R.disconnect(M), M.disconnect(P), P.disconnect(c.destination);
    };
    return u(br(Y, k), K, ue);
  };
  var NT = (t) => (e, { disableNormalization: r, imag: n, real: o }) => {
    let i = n instanceof Float32Array ? n : new Float32Array(n), s = o instanceof Float32Array ? o : new Float32Array(o), a = e.createPeriodicWave(s, i, { disableNormalization: r });
    if (Array.from(n).length < 2) throw t();
    return a;
  };
  var Is = (t, e, r, n) => t.createScriptProcessor(e, r, n);
  var OT = (t, e) => (r, n) => {
    let o = n.channelCountMode;
    if (o === "clamped-max") throw e();
    if (r.createStereoPanner === void 0) return t(r, n);
    let i = r.createStereoPanner();
    return le(i, n), de(i, n, "pan"), Object.defineProperty(i, "channelCountMode", { get: () => o, set: (s) => {
      if (s !== o) throw e();
    } }), i;
  };
  var DT = (t, e, r, n, o, i) => {
    let a = new Float32Array([1, 1]), l = Math.PI / 2, u = { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete" }, c = { ...u, oversample: "none" }, p = (m, x, _, d) => {
      let g = new Float32Array(16385), y = new Float32Array(16385);
      for (let N = 0; N < 16385; N += 1) {
        let k = N / 16384 * l;
        g[N] = Math.cos(k), y[N] = Math.sin(k);
      }
      let S = r(m, { ...u, gain: 0 }), v = n(m, { ...c, curve: g }), T = n(m, { ...c, curve: a }), A = r(m, { ...u, gain: 0 }), w = n(m, { ...c, curve: y });
      return { connectGraph() {
        x.connect(S), x.connect(T.inputs === void 0 ? T : T.inputs[0]), x.connect(A), T.connect(_), _.connect(v.inputs === void 0 ? v : v.inputs[0]), _.connect(w.inputs === void 0 ? w : w.inputs[0]), v.connect(S.gain), w.connect(A.gain), S.connect(d, 0, 0), A.connect(d, 0, 1);
      }, disconnectGraph() {
        x.disconnect(S), x.disconnect(T.inputs === void 0 ? T : T.inputs[0]), x.disconnect(A), T.disconnect(_), _.disconnect(v.inputs === void 0 ? v : v.inputs[0]), _.disconnect(w.inputs === void 0 ? w : w.inputs[0]), v.disconnect(S.gain), w.disconnect(A.gain), S.disconnect(d, 0, 0), A.disconnect(d, 0, 1);
      } };
    }, h = (m, x, _, d) => {
      let g = new Float32Array(16385), y = new Float32Array(16385), S = new Float32Array(16385), v = new Float32Array(16385), T = Math.floor(16385 / 2);
      for (let E = 0; E < 16385; E += 1) if (E > T) {
        let O = (E - T) / (16384 - T) * l;
        g[E] = Math.cos(O), y[E] = Math.sin(O), S[E] = 0, v[E] = 1;
      } else {
        let O = E / (16384 - T) * l;
        g[E] = 1, y[E] = 0, S[E] = Math.cos(O), v[E] = Math.sin(O);
      }
      let A = e(m, { channelCount: 2, channelCountMode: "explicit", channelInterpretation: "discrete", numberOfOutputs: 2 }), w = r(m, { ...u, gain: 0 }), N = n(m, { ...c, curve: g }), k = r(m, { ...u, gain: 0 }), D = n(m, { ...c, curve: y }), M = n(m, { ...c, curve: a }), q = r(m, { ...u, gain: 0 }), B = n(m, { ...c, curve: S }), I = r(m, { ...u, gain: 0 }), C = n(m, { ...c, curve: v });
      return { connectGraph() {
        x.connect(A), x.connect(M.inputs === void 0 ? M : M.inputs[0]), A.connect(w, 0), A.connect(k, 0), A.connect(q, 1), A.connect(I, 1), M.connect(_), _.connect(N.inputs === void 0 ? N : N.inputs[0]), _.connect(D.inputs === void 0 ? D : D.inputs[0]), _.connect(B.inputs === void 0 ? B : B.inputs[0]), _.connect(C.inputs === void 0 ? C : C.inputs[0]), N.connect(w.gain), D.connect(k.gain), B.connect(q.gain), C.connect(I.gain), w.connect(d, 0, 0), q.connect(d, 0, 0), k.connect(d, 0, 1), I.connect(d, 0, 1);
      }, disconnectGraph() {
        x.disconnect(A), x.disconnect(M.inputs === void 0 ? M : M.inputs[0]), A.disconnect(w, 0), A.disconnect(k, 0), A.disconnect(q, 1), A.disconnect(I, 1), M.disconnect(_), _.disconnect(N.inputs === void 0 ? N : N.inputs[0]), _.disconnect(D.inputs === void 0 ? D : D.inputs[0]), _.disconnect(B.inputs === void 0 ? B : B.inputs[0]), _.disconnect(C.inputs === void 0 ? C : C.inputs[0]), N.disconnect(w.gain), D.disconnect(k.gain), B.disconnect(q.gain), C.disconnect(I.gain), w.disconnect(d, 0, 0), q.disconnect(d, 0, 0), k.disconnect(d, 0, 1), I.disconnect(d, 0, 1);
      } };
    }, f = (m, x, _, d, g) => {
      if (x === 1) return p(m, _, d, g);
      if (x === 2) return h(m, _, d, g);
      throw o();
    };
    return (m, { channelCount: x, channelCountMode: _, pan: d, ...g }) => {
      if (_ === "max") throw o();
      let y = t(m, { ...g, channelCount: 1, channelCountMode: _, numberOfInputs: 2 }), S = r(m, { ...g, channelCount: x, channelCountMode: _, gain: 1 }), v = r(m, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", gain: d }), { connectGraph: T, disconnectGraph: A } = f(m, x, S, v, y);
      Object.defineProperty(v.gain, "defaultValue", { get: () => 0 }), Object.defineProperty(v.gain, "maxValue", { get: () => 1 }), Object.defineProperty(v.gain, "minValue", { get: () => -1 });
      let w = { get bufferSize() {
      }, get channelCount() {
        return S.channelCount;
      }, set channelCount(M) {
        S.channelCount !== M && (N && A(), { connectGraph: T, disconnectGraph: A } = f(m, M, S, v, y), N && T()), S.channelCount = M;
      }, get channelCountMode() {
        return S.channelCountMode;
      }, set channelCountMode(M) {
        if (M === "clamped-max" || M === "max") throw o();
        S.channelCountMode = M;
      }, get channelInterpretation() {
        return S.channelInterpretation;
      }, set channelInterpretation(M) {
        S.channelInterpretation = M;
      }, get context() {
        return S.context;
      }, get inputs() {
        return [S];
      }, get numberOfInputs() {
        return S.numberOfInputs;
      }, get numberOfOutputs() {
        return S.numberOfOutputs;
      }, get pan() {
        return v.gain;
      }, addEventListener(...M) {
        return S.addEventListener(M[0], M[1], M[2]);
      }, dispatchEvent(...M) {
        return S.dispatchEvent(M[0]);
      }, removeEventListener(...M) {
        return S.removeEventListener(M[0], M[1], M[2]);
      } }, N = false, k = () => {
        T(), N = true;
      }, D = () => {
        A(), N = false;
      };
      return i(br(w, y), k, D);
    };
  };
  var MT = (t, e, r, n, o, i, s) => (a, l) => {
    let u = a.createWaveShaper();
    if (i !== null && i.name === "webkitAudioContext" && a.createGain().gain.automationRate === void 0) return r(a, l);
    le(u, l);
    let c = l.curve === null || l.curve instanceof Float32Array ? l.curve : new Float32Array(l.curve);
    if (c !== null && c.length < 2) throw e();
    fe(u, { curve: c }, "curve"), fe(u, l, "oversample");
    let p = null, h = false;
    return s(u, "curve", (x) => () => x.call(u), (x) => (_) => (x.call(u, _), h && (n(_) && p === null ? p = t(a, u) : !n(_) && p !== null && (p(), p = null)), _)), o(u, () => {
      h = true, n(u.curve) && (p = t(a, u));
    }, () => {
      h = false, p !== null && (p(), p = null);
    });
  };
  var PT = (t, e, r, n, o) => (i, { curve: s, oversample: a, ...l }) => {
    let u = i.createWaveShaper(), c = i.createWaveShaper();
    le(u, l), le(c, l);
    let p = r(i, { ...l, gain: 1 }), h = r(i, { ...l, gain: -1 }), f = r(i, { ...l, gain: 1 }), m = r(i, { ...l, gain: -1 }), x = null, _ = false, d = null, g = { get bufferSize() {
    }, get channelCount() {
      return u.channelCount;
    }, set channelCount(v) {
      p.channelCount = v, h.channelCount = v, u.channelCount = v, f.channelCount = v, c.channelCount = v, m.channelCount = v;
    }, get channelCountMode() {
      return u.channelCountMode;
    }, set channelCountMode(v) {
      p.channelCountMode = v, h.channelCountMode = v, u.channelCountMode = v, f.channelCountMode = v, c.channelCountMode = v, m.channelCountMode = v;
    }, get channelInterpretation() {
      return u.channelInterpretation;
    }, set channelInterpretation(v) {
      p.channelInterpretation = v, h.channelInterpretation = v, u.channelInterpretation = v, f.channelInterpretation = v, c.channelInterpretation = v, m.channelInterpretation = v;
    }, get context() {
      return u.context;
    }, get curve() {
      return d;
    }, set curve(v) {
      if (v !== null && v.length < 2) throw e();
      if (v === null) u.curve = v, c.curve = v;
      else {
        let T = v.length, A = new Float32Array(T + 2 - T % 2), w = new Float32Array(T + 2 - T % 2);
        A[0] = v[0], w[0] = -v[T - 1];
        let N = Math.ceil((T + 1) / 2), k = (T + 1) / 2 - 1;
        for (let D = 1; D < N; D += 1) {
          let M = D / N * k, q = Math.floor(M), B = Math.ceil(M);
          A[D] = q === B ? v[q] : (1 - (M - q)) * v[q] + (1 - (B - M)) * v[B], w[D] = q === B ? -v[T - 1 - q] : -((1 - (M - q)) * v[T - 1 - q]) - (1 - (B - M)) * v[T - 1 - B];
        }
        A[N] = T % 2 === 1 ? v[N - 1] : (v[N - 2] + v[N - 1]) / 2, u.curve = A, c.curve = w;
      }
      d = v, _ && (n(d) && x === null ? x = t(i, p) : x !== null && (x(), x = null));
    }, get inputs() {
      return [p];
    }, get numberOfInputs() {
      return u.numberOfInputs;
    }, get numberOfOutputs() {
      return u.numberOfOutputs;
    }, get oversample() {
      return u.oversample;
    }, set oversample(v) {
      u.oversample = v, c.oversample = v;
    }, addEventListener(...v) {
      return p.addEventListener(v[0], v[1], v[2]);
    }, dispatchEvent(...v) {
      return p.dispatchEvent(v[0]);
    }, removeEventListener(...v) {
      return p.removeEventListener(v[0], v[1], v[2]);
    } };
    s !== null && (g.curve = s instanceof Float32Array ? s : new Float32Array(s)), a !== g.oversample && (g.oversample = a);
    let y = () => {
      p.connect(u).connect(f), p.connect(h).connect(c).connect(m).connect(f), _ = true, n(d) && (x = t(i, p));
    }, S = () => {
      p.disconnect(u), u.disconnect(f), p.disconnect(h), h.disconnect(c), c.disconnect(m), m.disconnect(f), _ = false, x !== null && (x(), x = null);
    };
    return o(br(g, f), y, S);
  };
  var Tt = () => new DOMException("", "NotSupportedError");
  var XO = { numberOfChannels: 1 }, RT = (t, e, r, n, o) => class extends t {
    constructor(s, a, l) {
      let u;
      if (typeof s == "number" && a !== void 0 && l !== void 0) u = { length: a, numberOfChannels: s, sampleRate: l };
      else if (typeof s == "object") u = s;
      else throw new Error("The given parameters are not valid.");
      let { length: c, numberOfChannels: p, sampleRate: h } = { ...XO, ...u }, f = n(p, c, h);
      e(Qr, () => Qr(f)) || f.addEventListener("statechange", /* @__PURE__ */ (() => {
        let m = 0, x = (_) => {
          this._state === "running" && (m > 0 ? (f.removeEventListener("statechange", x), _.stopImmediatePropagation(), this._waitForThePromiseToSettle(_)) : m += 1);
        };
        return x;
      })()), super(f, p), this._length = c, this._nativeOfflineAudioContext = f, this._state = null;
    }
    get length() {
      return this._nativeOfflineAudioContext.length === void 0 ? this._length : this._nativeOfflineAudioContext.length;
    }
    get state() {
      return this._state === null ? this._nativeOfflineAudioContext.state : this._state;
    }
    startRendering() {
      return this._state === "running" ? Promise.reject(r()) : (this._state = "running", o(this.destination, this._nativeOfflineAudioContext).finally(() => {
        this._state = null, No(this);
      }));
    }
    _waitForThePromiseToSettle(s) {
      this._state === null ? this._nativeOfflineAudioContext.dispatchEvent(s) : setTimeout(() => this._waitForThePromiseToSettle(s));
    }
  };
  var YO = { channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", detune: 0, frequency: 440, periodicWave: void 0, type: "sine" }, VT = (t, e, r, n, o, i, s) => class extends t {
    constructor(l, u) {
      let c = o(l), p = { ...YO, ...u }, h = r(c, p), f = i(c), m = f ? n() : null, x = l.sampleRate / 2;
      super(l, false, h, m), this._detune = e(this, f, h.detune, 153600, -153600), this._frequency = e(this, f, h.frequency, x, -x), this._nativeOscillatorNode = h, this._onended = null, this._oscillatorNodeRenderer = m, this._oscillatorNodeRenderer !== null && p.periodicWave !== void 0 && (this._oscillatorNodeRenderer.periodicWave = p.periodicWave);
    }
    get detune() {
      return this._detune;
    }
    get frequency() {
      return this._frequency;
    }
    get onended() {
      return this._onended;
    }
    set onended(l) {
      let u = typeof l == "function" ? s(this, l) : null;
      this._nativeOscillatorNode.onended = u;
      let c = this._nativeOscillatorNode.onended;
      this._onended = c !== null && c === u ? l : c;
    }
    get type() {
      return this._nativeOscillatorNode.type;
    }
    set type(l) {
      this._nativeOscillatorNode.type = l, this._oscillatorNodeRenderer !== null && (this._oscillatorNodeRenderer.periodicWave = null);
    }
    setPeriodicWave(l) {
      this._nativeOscillatorNode.setPeriodicWave(l), this._oscillatorNodeRenderer !== null && (this._oscillatorNodeRenderer.periodicWave = l);
    }
    start(l = 0) {
      if (this._nativeOscillatorNode.start(l), this._oscillatorNodeRenderer !== null && (this._oscillatorNodeRenderer.start = l), this.context.state !== "closed") {
        Xr(this);
        let u = () => {
          this._nativeOscillatorNode.removeEventListener("ended", u), Bt(this) && yn(this);
        };
        this._nativeOscillatorNode.addEventListener("ended", u);
      }
    }
    stop(l = 0) {
      this._nativeOscillatorNode.stop(l), this._oscillatorNodeRenderer !== null && (this._oscillatorNodeRenderer.stop = l);
    }
  };
  var FT = (t, e, r, n, o) => () => {
    let i = /* @__PURE__ */ new WeakMap(), s = null, a = null, l = null, u = async (c, p) => {
      let h = r(c), f = he(h, p);
      if (!f) {
        let m = { channelCount: h.channelCount, channelCountMode: h.channelCountMode, channelInterpretation: h.channelInterpretation, detune: h.detune.value, frequency: h.frequency.value, periodicWave: s === null ? void 0 : s, type: h.type };
        h = e(p, m), a !== null && h.start(a), l !== null && h.stop(l);
      }
      return i.set(p, h), f ? (await t(p, c.detune, h.detune), await t(p, c.frequency, h.frequency)) : (await n(p, c.detune, h.detune), await n(p, c.frequency, h.frequency)), await o(c, p, h), h;
    };
    return { set periodicWave(c) {
      s = c;
    }, set start(c) {
      a = c;
    }, set stop(c) {
      l = c;
    }, render(c, p) {
      let h = i.get(p);
      return h !== void 0 ? Promise.resolve(h) : u(c, p);
    } };
  };
  var QO = { channelCount: 2, channelCountMode: "clamped-max", channelInterpretation: "speakers", coneInnerAngle: 360, coneOuterAngle: 360, coneOuterGain: 0, distanceModel: "inverse", maxDistance: 1e4, orientationX: 1, orientationY: 0, orientationZ: 0, panningModel: "equalpower", positionX: 0, positionY: 0, positionZ: 0, refDistance: 1, rolloffFactor: 1 }, IT = (t, e, r, n, o, i, s) => class extends t {
    constructor(l, u) {
      let c = o(l), p = { ...QO, ...u }, h = r(c, p), f = i(c), m = f ? n() : null;
      super(l, false, h, m), this._nativePannerNode = h, this._orientationX = e(this, f, h.orientationX, Ue, Ye), this._orientationY = e(this, f, h.orientationY, Ue, Ye), this._orientationZ = e(this, f, h.orientationZ, Ue, Ye), this._positionX = e(this, f, h.positionX, Ue, Ye), this._positionY = e(this, f, h.positionY, Ue, Ye), this._positionZ = e(this, f, h.positionZ, Ue, Ye), s(this, 1);
    }
    get coneInnerAngle() {
      return this._nativePannerNode.coneInnerAngle;
    }
    set coneInnerAngle(l) {
      this._nativePannerNode.coneInnerAngle = l;
    }
    get coneOuterAngle() {
      return this._nativePannerNode.coneOuterAngle;
    }
    set coneOuterAngle(l) {
      this._nativePannerNode.coneOuterAngle = l;
    }
    get coneOuterGain() {
      return this._nativePannerNode.coneOuterGain;
    }
    set coneOuterGain(l) {
      this._nativePannerNode.coneOuterGain = l;
    }
    get distanceModel() {
      return this._nativePannerNode.distanceModel;
    }
    set distanceModel(l) {
      this._nativePannerNode.distanceModel = l;
    }
    get maxDistance() {
      return this._nativePannerNode.maxDistance;
    }
    set maxDistance(l) {
      this._nativePannerNode.maxDistance = l;
    }
    get orientationX() {
      return this._orientationX;
    }
    get orientationY() {
      return this._orientationY;
    }
    get orientationZ() {
      return this._orientationZ;
    }
    get panningModel() {
      return this._nativePannerNode.panningModel;
    }
    set panningModel(l) {
      this._nativePannerNode.panningModel = l;
    }
    get positionX() {
      return this._positionX;
    }
    get positionY() {
      return this._positionY;
    }
    get positionZ() {
      return this._positionZ;
    }
    get refDistance() {
      return this._nativePannerNode.refDistance;
    }
    set refDistance(l) {
      this._nativePannerNode.refDistance = l;
    }
    get rolloffFactor() {
      return this._nativePannerNode.rolloffFactor;
    }
    set rolloffFactor(l) {
      this._nativePannerNode.rolloffFactor = l;
    }
  };
  var LT = (t, e, r, n, o, i, s, a, l, u) => () => {
    let c = /* @__PURE__ */ new WeakMap(), p = null, h = async (f, m) => {
      let x = null, _ = i(f), d = { channelCount: _.channelCount, channelCountMode: _.channelCountMode, channelInterpretation: _.channelInterpretation }, g = { ...d, coneInnerAngle: _.coneInnerAngle, coneOuterAngle: _.coneOuterAngle, coneOuterGain: _.coneOuterGain, distanceModel: _.distanceModel, maxDistance: _.maxDistance, panningModel: _.panningModel, refDistance: _.refDistance, rolloffFactor: _.rolloffFactor }, y = he(_, m);
      if ("bufferSize" in _) x = n(m, { ...d, gain: 1 });
      else if (!y) {
        let S = { ...g, orientationX: _.orientationX.value, orientationY: _.orientationY.value, orientationZ: _.orientationZ.value, positionX: _.positionX.value, positionY: _.positionY.value, positionZ: _.positionZ.value };
        _ = o(m, S);
      }
      if (c.set(m, x === null ? _ : x), x !== null) {
        if (p === null) {
          if (s === null) throw new Error("Missing the native OfflineAudioContext constructor.");
          let D = new s(6, f.context.length, m.sampleRate), M = e(D, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "speakers", numberOfInputs: 6 });
          M.connect(D.destination), p = (async () => {
            let q = await Promise.all([f.orientationX, f.orientationY, f.orientationZ, f.positionX, f.positionY, f.positionZ].map(async (B, I) => {
              let C = r(D, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", offset: I === 0 ? 1 : 0 });
              return await a(D, B, C.offset), C;
            }));
            for (let B = 0; B < 6; B += 1) q[B].connect(M, 0, B), q[B].start(0);
            return u(D);
          })();
        }
        let S = await p, v = n(m, { ...d, gain: 1 });
        await l(f, m, v);
        let T = [];
        for (let D = 0; D < S.numberOfChannels; D += 1) T.push(S.getChannelData(D));
        let A = [T[0][0], T[1][0], T[2][0]], w = [T[3][0], T[4][0], T[5][0]], N = n(m, { ...d, gain: 1 }), k = o(m, { ...g, orientationX: A[0], orientationY: A[1], orientationZ: A[2], positionX: w[0], positionY: w[1], positionZ: w[2] });
        v.connect(N).connect(k.inputs[0]), k.connect(x);
        for (let D = 128; D < S.length; D += 128) {
          let M = [T[0][D], T[1][D], T[2][D]], q = [T[3][D], T[4][D], T[5][D]];
          if (M.some((B, I) => B !== A[I]) || q.some((B, I) => B !== w[I])) {
            A = M, w = q;
            let B = D / m.sampleRate;
            N.gain.setValueAtTime(0, B), N = n(m, { ...d, gain: 0 }), k = o(m, { ...g, orientationX: A[0], orientationY: A[1], orientationZ: A[2], positionX: w[0], positionY: w[1], positionZ: w[2] }), N.gain.setValueAtTime(1, B), v.connect(N).connect(k.inputs[0]), k.connect(x);
          }
        }
        return x;
      }
      return y ? (await t(m, f.orientationX, _.orientationX), await t(m, f.orientationY, _.orientationY), await t(m, f.orientationZ, _.orientationZ), await t(m, f.positionX, _.positionX), await t(m, f.positionY, _.positionY), await t(m, f.positionZ, _.positionZ)) : (await a(m, f.orientationX, _.orientationX), await a(m, f.orientationY, _.orientationY), await a(m, f.orientationZ, _.orientationZ), await a(m, f.positionX, _.positionX), await a(m, f.positionY, _.positionY), await a(m, f.positionZ, _.positionZ)), Er(_) ? await l(f, m, _.inputs[0]) : await l(f, m, _), _;
    };
    return { render(f, m) {
      let x = c.get(m);
      return x !== void 0 ? Promise.resolve(x) : h(f, m);
    } };
  };
  var KO = { disableNormalization: false }, BT = (t, e, r, n) => class jT {
    constructor(i, s) {
      let a = e(i), l = n({ ...KO, ...s }), u = t(a, l);
      return r.add(u), u;
    }
    static [Symbol.hasInstance](i) {
      return i !== null && typeof i == "object" && Object.getPrototypeOf(i) === jT.prototype || r.has(i);
    }
  };
  var qT = (t, e) => (r, n, o) => (t(n).replay(o), e(n, r, o));
  var zT = (t, e, r) => async (n, o, i) => {
    let s = t(n);
    await Promise.all(s.activeInputs.map((a, l) => Array.from(a).map(async ([u, c]) => {
      let h = await e(u).render(u, o), f = n.context.destination;
      !r(u) && (n !== f || !r(n)) && h.connect(i, c, l);
    })).reduce((a, l) => [...a, ...l], []));
  };
  var WT = (t, e, r) => async (n, o, i) => {
    let s = e(n);
    await Promise.all(Array.from(s.activeInputs).map(async ([a, l]) => {
      let c = await t(a).render(a, o);
      r(a) || c.connect(i, l);
    }));
  };
  var UT = (t, e, r, n) => (o) => t(Qr, () => Qr(o)) ? Promise.resolve(t(n, n)).then((i) => {
    if (!i) {
      let s = r(o, 512, 0, 1);
      o.oncomplete = () => {
        s.onaudioprocess = null, s.disconnect();
      }, s.onaudioprocess = () => o.currentTime, s.connect(o.destination);
    }
    return o.startRendering();
  }) : new Promise((i) => {
    let s = e(o, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", gain: 0 });
    o.oncomplete = (a) => {
      s.disconnect(), i(a.renderedBuffer);
    }, s.connect(o.destination), o.startRendering();
  });
  var GT = (t) => (e, r) => {
    t.set(e, r);
  };
  var HT = (t) => (e, r) => t.set(e, r);
  var $T = (t, e, r, n, o, i, s, a) => (l, u) => r(l).render(l, u).then(() => Promise.all(Array.from(n(u)).map((c) => r(c).render(c, u)))).then(() => o(u)).then((c) => (typeof c.copyFromChannel != "function" ? (s(c), ks(c)) : e(i, () => i(c)) || a(c), t.add(c), c));
  var ZO = { channelCount: 2, channelCountMode: "explicit", channelInterpretation: "speakers", pan: 0 }, XT = (t, e, r, n, o, i) => class extends t {
    constructor(a, l) {
      let u = o(a), c = { ...ZO, ...l }, p = r(u, c), h = i(u), f = h ? n() : null;
      super(a, false, p, f), this._pan = e(this, h, p.pan);
    }
    get pan() {
      return this._pan;
    }
  };
  var YT = (t, e, r, n, o) => () => {
    let i = /* @__PURE__ */ new WeakMap(), s = async (a, l) => {
      let u = r(a), c = he(u, l);
      if (!c) {
        let p = { channelCount: u.channelCount, channelCountMode: u.channelCountMode, channelInterpretation: u.channelInterpretation, pan: u.pan.value };
        u = e(l, p);
      }
      return i.set(l, u), c ? await t(l, a.pan, u.pan) : await n(l, a.pan, u.pan), Er(u) ? await o(a, l, u.inputs[0]) : await o(a, l, u), u;
    };
    return { render(a, l) {
      let u = i.get(l);
      return u !== void 0 ? Promise.resolve(u) : s(a, l);
    } };
  };
  var QT = (t) => () => {
    if (t === null) return false;
    try {
      new t({ length: 1, sampleRate: 44100 });
    } catch {
      return false;
    }
    return true;
  };
  var KT = (t, e) => async () => {
    if (t === null) return true;
    if (e === null) return false;
    let r = new Blob(['class A extends AudioWorkletProcessor{process(i){this.port.postMessage(i,[i[0][0].buffer])}}registerProcessor("a",A)'], { type: "application/javascript; charset=utf-8" }), n = new e(1, 128, 44100), o = URL.createObjectURL(r), i = false, s = false;
    try {
      await n.audioWorklet.addModule(o);
      let a = new t(n, "a", { numberOfOutputs: 0 }), l = n.createOscillator();
      a.port.onmessage = () => i = true, a.onprocessorerror = () => s = true, l.connect(a), l.start(0), await n.startRendering(), await new Promise((u) => setTimeout(u));
    } catch {
    } finally {
      URL.revokeObjectURL(o);
    }
    return i && !s;
  };
  var ZT = (t, e) => () => {
    if (e === null) return Promise.resolve(false);
    let r = new e(1, 1, 44100), n = t(r, { channelCount: 1, channelCountMode: "explicit", channelInterpretation: "discrete", gain: 0 });
    return new Promise((o) => {
      r.oncomplete = () => {
        n.disconnect(), o(r.currentTime !== 0);
      }, r.startRendering();
    });
  };
  var ag = () => new DOMException("", "UnknownError");
  var JO = { channelCount: 2, channelCountMode: "max", channelInterpretation: "speakers", curve: null, oversample: "none" }, JT = (t, e, r, n, o, i, s) => class extends t {
    constructor(l, u) {
      let c = o(l), p = { ...JO, ...u }, h = r(c, p), m = i(c) ? n() : null;
      super(l, true, h, m), this._isCurveNullified = false, this._nativeWaveShaperNode = h, s(this, 1);
    }
    get curve() {
      return this._isCurveNullified ? null : this._nativeWaveShaperNode.curve;
    }
    set curve(l) {
      if (l === null) this._isCurveNullified = true, this._nativeWaveShaperNode.curve = new Float32Array([0, 0]);
      else {
        if (l.length < 2) throw e();
        this._isCurveNullified = false, this._nativeWaveShaperNode.curve = l;
      }
    }
    get oversample() {
      return this._nativeWaveShaperNode.oversample;
    }
    set oversample(l) {
      this._nativeWaveShaperNode.oversample = l;
    }
  };
  var e1 = (t, e, r) => () => {
    let n = /* @__PURE__ */ new WeakMap(), o = async (i, s) => {
      let a = e(i);
      if (!he(a, s)) {
        let u = { channelCount: a.channelCount, channelCountMode: a.channelCountMode, channelInterpretation: a.channelInterpretation, curve: a.curve, oversample: a.oversample };
        a = t(s, u);
      }
      return n.set(s, a), Er(a) ? await r(i, s, a.inputs[0]) : await r(i, s, a), a;
    };
    return { render(i, s) {
      let a = n.get(s);
      return a !== void 0 ? Promise.resolve(a) : o(i, s);
    } };
  };
  var t1 = () => typeof window > "u" ? null : window;
  var r1 = (t, e) => (r) => {
    r.copyFromChannel = (n, o, i = 0) => {
      let s = t(i), a = t(o);
      if (a >= r.numberOfChannels) throw e();
      let l = r.length, u = r.getChannelData(a), c = n.length;
      for (let p = s < 0 ? -s : 0; p + s < l && p < c; p += 1) n[p] = u[p + s];
    }, r.copyToChannel = (n, o, i = 0) => {
      let s = t(i), a = t(o);
      if (a >= r.numberOfChannels) throw e();
      let l = r.length, u = r.getChannelData(a), c = n.length;
      for (let p = s < 0 ? -s : 0; p + s < l && p < c; p += 1) u[p + s] = n[p];
    };
  };
  var n1 = (t) => (e) => {
    e.copyFromChannel = /* @__PURE__ */ ((r) => (n, o, i = 0) => {
      let s = t(i), a = t(o);
      if (s < e.length) return r.call(e, n, a, s);
    })(e.copyFromChannel), e.copyToChannel = /* @__PURE__ */ ((r) => (n, o, i = 0) => {
      let s = t(i), a = t(o);
      if (s < e.length) return r.call(e, n, a, s);
    })(e.copyToChannel);
  };
  var o1 = (t) => (e, r) => {
    let n = r.createBuffer(1, 1, 44100);
    e.buffer === null && (e.buffer = n), t(e, "buffer", (o) => () => {
      let i = o.call(e);
      return i === n ? null : i;
    }, (o) => (i) => o.call(e, i === null ? n : i));
  };
  var i1 = (t, e) => (r, n) => {
    n.channelCount = 1, n.channelCountMode = "explicit", Object.defineProperty(n, "channelCount", { get: () => 1, set: () => {
      throw t();
    } }), Object.defineProperty(n, "channelCountMode", { get: () => "explicit", set: () => {
      throw t();
    } });
    let o = r.createBufferSource();
    e(n, () => {
      let a = n.numberOfInputs;
      for (let l = 0; l < a; l += 1) o.connect(n, 0, l);
    }, () => o.disconnect(n));
  };
  var lg = (t, e, r) => t.copyFromChannel === void 0 ? t.getChannelData(r)[0] : (t.copyFromChannel(e, r), e[0]);
  var ug = (t) => {
    if (t === null) return false;
    let e = t.length;
    return e % 2 !== 0 ? t[Math.floor(e / 2)] !== 0 : t[e / 2 - 1] + t[e / 2] !== 0;
  };
  var Ls = (t, e, r, n) => {
    let o = t;
    for (; !o.hasOwnProperty(e); ) o = Object.getPrototypeOf(o);
    let { get: i, set: s } = Object.getOwnPropertyDescriptor(o, e);
    Object.defineProperty(t, e, { get: r(i), set: n(s) });
  };
  var s1 = (t) => ({ ...t, outputChannelCount: t.outputChannelCount !== void 0 ? t.outputChannelCount : t.numberOfInputs === 1 && t.numberOfOutputs === 1 ? [t.channelCount] : Array.from({ length: t.numberOfOutputs }, () => 1) });
  var a1 = (t) => ({ ...t, channelCount: t.numberOfOutputs });
  var l1 = (t) => {
    let { imag: e, real: r } = t;
    return e === void 0 ? r === void 0 ? { ...t, imag: [0, 0], real: [0, 0] } : { ...t, imag: Array.from(r, () => 0), real: r } : r === void 0 ? { ...t, imag: e, real: Array.from(e, () => 0) } : { ...t, imag: e, real: r };
  };
  var cg = (t, e, r) => {
    try {
      t.setValueAtTime(e, r);
    } catch (n) {
      if (n.code !== 9) throw n;
      cg(t, e, r + 1e-7);
    }
  };
  var u1 = (t) => {
    let e = t.createBufferSource();
    e.start();
    try {
      e.start();
    } catch {
      return true;
    }
    return false;
  };
  var c1 = (t) => {
    let e = t.createBufferSource(), r = t.createBuffer(1, 1, 44100);
    e.buffer = r;
    try {
      e.start(0, 1);
    } catch {
      return false;
    }
    return true;
  };
  var p1 = (t) => {
    let e = t.createBufferSource();
    e.start();
    try {
      e.stop();
    } catch {
      return false;
    }
    return true;
  };
  var Ap = (t) => {
    let e = t.createOscillator();
    try {
      e.start(-1);
    } catch (r) {
      return r instanceof RangeError;
    }
    return false;
  };
  var pg = (t) => {
    let e = t.createBuffer(1, 1, 44100), r = t.createBufferSource();
    r.buffer = e, r.start(), r.stop();
    try {
      return r.stop(), true;
    } catch {
      return false;
    }
  };
  var Cp = (t) => {
    let e = t.createOscillator();
    try {
      e.stop(-1);
    } catch (r) {
      return r instanceof RangeError;
    }
    return false;
  };
  var h1 = (t) => {
    let { port1: e, port2: r } = new MessageChannel();
    try {
      e.postMessage(t);
    } finally {
      e.close(), r.close();
    }
  };
  var f1 = (t) => {
    t.start = /* @__PURE__ */ ((e) => (r = 0, n = 0, o) => {
      let i = t.buffer, s = i === null ? n : Math.min(i.duration, n);
      i !== null && s > i.duration - 0.5 / t.context.sampleRate ? e.call(t, r, 0, 0) : e.call(t, r, s, o);
    })(t.start);
  };
  var hg = (t, e) => {
    let r = e.createGain();
    t.connect(r);
    let n = /* @__PURE__ */ ((o) => () => {
      o.call(t, r), t.removeEventListener("ended", n);
    })(t.disconnect);
    t.addEventListener("ended", n), br(t, r), t.stop = /* @__PURE__ */ ((o) => {
      let i = false;
      return (s = 0) => {
        if (i) try {
          o.call(t, s);
        } catch {
          r.gain.setValueAtTime(0, s);
        }
        else o.call(t, s), i = true;
      };
    })(t.stop);
  };
  var yi = (t, e) => (r) => {
    let n = { value: t };
    return Object.defineProperties(r, { currentTarget: n, target: n }), typeof e == "function" ? e.call(t, r) : e.handleEvent.call(t, r);
  };
  var eD = rw(Yr), tD = hw(Yr), rD = lS(Eo), d1 = /* @__PURE__ */ new WeakMap(), nD = AS(d1), Nr = Ww(/* @__PURE__ */ new Map(), /* @__PURE__ */ new WeakMap()), _n = t1(), g1 = JS(Nr, kr), fg = TS(ct), At = zT(ct, fg, Wn), oD = gw(g1, we, At), Ce = ES(As), Un = CT(_n), Se = zS(Un), x1 = /* @__PURE__ */ new WeakMap(), y1 = xS(yi), Bs = nT(_n), mg = LS(Bs), dg = BS(_n), _1 = jS(_n), Il = iT(_n), Qe = Pw(nw(hp), pw(eD, tD, Es, rD, bs, ct, nD, xn, we, Yr, Bt, Wn, Ns), Nr, PS(Pl, bs, ct, we, gi, Bt), kr, Ps, Tt, iS(Es, Pl, ct, we, gi, Ce, Bt, Se), pS(x1, ct, tt), y1, Ce, mg, dg, _1, Se, Il), iD = dw(Qe, oD, kr, g1, Ce, Se);
  var gg = /* @__PURE__ */ new WeakSet(), m1 = eT(_n), v1 = Jw(new Uint32Array(1)), xg = r1(v1, kr), yg = n1(v1), _g = xw(gg, Nr, Tt, m1, Un, QT(m1), xg, yg);
  var kp = fw(jt), w1 = WT(fg, bo, Wn), vn = Xw(w1), js = rT(kp, Nr, u1, c1, p1, Ap, pg, Cp, f1, o1(Ls), hg), wn = qT(CS(bo), w1), sD = vw(vn, js, we, wn, At), Kr = Vw(ow(fp), x1, Ml, Fw, Jt.createCancelAndHoldAutomationEvent, Jt.createCancelScheduledValuesAutomationEvent, Jt.createExponentialRampToValueAutomationEvent, Jt.createLinearRampToValueAutomationEvent, Jt.createSetTargetAutomationEvent, Jt.createSetValueAutomationEvent, Jt.createSetValueCurveAutomationEvent, Bs, cg), aD = _w(Qe, sD, Kr, Ne, js, Ce, Se, yi);
  var lD = bw(Qe, Nw, kr, Ne, oT(jt, Ls), Ce, Se, At), uD = zw(vn, ig, we, wn, At), _i = HT(d1), cD = qw(Qe, Kr, uD, Ps, ig, Ce, Se, _i), Do = KS(Yr, dg), pD = i1(Ne, Do), Mo = hT(Bs, pD), hD = Gw(Mo, we, At), fD = Uw(Qe, hD, Mo, Ce, Se), mD = $w(Fs, we, At), dD = Hw(Qe, mD, Fs, Ce, Se, a1), gD = dT(kp, js, jt, Do), qs = mT(kp, Nr, gD, Ap, Cp), xD = Zw(vn, qs, we, wn, At), yD = Kw(Qe, Kr, xD, qs, Ce, Se, yi), S1 = gT(Tt, Ls), _D = tS(S1, we, At), vD = eS(Qe, _D, S1, Ce, Se, _i), wD = aS(vn, sg, we, wn, At), SD = sS(Qe, Kr, wD, sg, Ce, Se, _i), T1 = xT(Tt), TD = mS(vn, T1, we, wn, At), AD = fS(Qe, Kr, TD, T1, Tt, Ce, Se, _i), CD = wS(vn, jt, we, wn, At), kD = vS(Qe, Kr, CD, jt, Ce, Se), ED = vT(Ps, Ne, Is, Tt), Ep = UT(Nr, jt, Is, ZT(jt, Un)), bD = MS(js, we, Un, At, Ep), ND = yT(ED), OD = DS(Qe, ND, bD, Ce, Se, _i), DD = Ow(Kr, Mo, qs, Is, Tt, lg, Se, Ls), A1 = /* @__PURE__ */ new WeakMap(), vg = YS(lD, DD, y1, Se, A1, yi), C1 = kT(kp, Nr, Ap, pg, Cp, hg), MD = FT(vn, C1, we, wn, At), PD = VT(Qe, Kr, C1, MD, Ce, Se, yi), k1 = Qw(js), RD = PT(k1, Ne, jt, ug, Do), bp = MT(k1, Ne, RD, ug, Do, Bs, Ls), VD = bT(Es, Ne, Mo, jt, Is, bp, Tt, bs, lg, Do), E1 = ET(VD), FD = LT(vn, Mo, qs, jt, E1, we, Un, wn, At, Ep), ID = IT(Qe, Kr, E1, FD, Ce, Se, _i), LD = NT(kr), BD = BT(LD, Ce, /* @__PURE__ */ new WeakSet(), l1), jD = DT(Mo, Fs, jt, bp, Tt, Do), b1 = OT(jD, Tt), qD = YT(vn, b1, we, wn, At), zD = XT(Qe, Kr, b1, qD, Ce, Se), WD = e1(bp, we, At), UD = JT(Qe, Ne, bp, WD, Ce, Se, _i), N1 = WS(_n), wg = yS(_n), O1 = /* @__PURE__ */ new WeakMap(), GD = bS(O1, Un), HD = N1 ? cw(Nr, Tt, gS(_n), wg, _S(tw), Ce, GD, Se, Il, /* @__PURE__ */ new WeakMap(), /* @__PURE__ */ new WeakMap(), KT(Il, Un), _n) : void 0, $D = qS(mg, Se), XD = oS(gg, Nr, nS, dS, /* @__PURE__ */ new WeakSet(), Ce, $D, Cs, Qr, xg, yg), D1 = jw(HD, iD, _g, aD, cD, fD, dD, yD, vD, XD, SD, AD, kD, OD, vg, PD, ID, BD, zD, UD), YD = US(Qe, wT, Ce, Se), QD = GS(Qe, ST, Ce, Se), KD = HS(Qe, TT, Ce, Se), ZD = AT(Ne, Se), JD = $S(Qe, ZD, Ce), M1 = Ew(D1, Ne, Tt, ag, YD, QD, KD, JD, Bs);
  var Sg = NS(A1), eM = mw(Sg), P1 = Yw(kr), tM = uS(Sg), R1 = hS(kr), V1 = /* @__PURE__ */ new WeakMap(), rM = SS(V1, tt), nM = pT(P1, kr, Ne, Mo, Fs, qs, jt, Is, Tt, R1, wg, rM, Do), oM = aT(Ne, nM, jt, Tt, Do), iM = Bw(vn, P1, js, Mo, Fs, qs, jt, tM, R1, wg, we, Il, Un, wn, At, Ep), sM = kS(O1), aM = GT(V1), Tg = N1 ? Iw(eM, Qe, Kr, iM, oM, ct, sM, Ce, Se, Il, s1, aM, h1, yi) : void 0;
  var XY = XS(Ne, Tt, ag, vg, Bs);
  var F1 = rS(Tt, Un), I1 = $T(gg, Nr, fg, Sg, Ep, Cs, xg, yg), YY = QS(Nr, Ne, F1, vg, I1);
  var L1 = RT(D1, Nr, Ne, F1, I1);
  var B1 = RS(As, mg), j1 = VS(Ts, dg), q1 = FS(Ml, _1), z1 = IS(As, Se);
  function Ke(t) {
    return t === void 0;
  }
  function Q(t) {
    return t !== void 0;
  }
  function W1(t) {
    return typeof t == "function";
  }
  function Ot(t) {
    return typeof t == "number";
  }
  function Zr(t) {
    return Object.prototype.toString.call(t) === "[object Object]" && t.constructor === Object;
  }
  function Ag(t) {
    return typeof t == "boolean";
  }
  function Fe(t) {
    return Array.isArray(t);
  }
  function Dt(t) {
    return typeof t == "string";
  }
  function Ll(t) {
    return Dt(t) && /^([a-g]{1}(?:b|#|x|bb)?)(-?[0-9]+)/i.test(t);
  }
  function U(t, e) {
    if (!t) throw new Error(e);
  }
  function yt(t, e, r = 1 / 0) {
    if (!(e <= t && t <= r)) throw new RangeError(`Value must be within [${e}, ${r}], got: ${t}`);
  }
  function Np(t) {
    !t.isOffline && t.state !== "running" && vi('The AudioContext is "suspended". Invoke Tone.start() from a user action to start the audio.');
  }
  var G1 = false, U1 = false;
  function Cg(t) {
    G1 = t;
  }
  function H1(t) {
    Ke(t) && G1 && !U1 && (U1 = true, vi("Events scheduled inside of scheduled callbacks should use the passed in scheduling time. See https://github.com/Tonejs/Tone.js/wiki/Accurate-Timing"));
  }
  var $1 = console;
  function X1(...t) {
    $1.log(...t);
  }
  function vi(...t) {
    $1.warn(...t);
  }
  function Y1(t) {
    return new M1(t);
  }
  function Q1(t, e, r) {
    return new L1(t, e, r);
  }
  var Mt = typeof self == "object" ? self : null, K1 = Mt && (Mt.hasOwnProperty("AudioContext") || Mt.hasOwnProperty("webkitAudioContext"));
  function Z1(t, e, r) {
    return U(Q(Tg), "AudioWorkletNode only works in a secure context (https or localhost)"), new (t instanceof (Mt == null ? void 0 : Mt.BaseAudioContext) ? Mt == null ? void 0 : Mt.AudioWorkletNode : Tg)(t, e, r);
  }
  function Pt(t, e, r, n) {
    var o = arguments.length, i = o < 3 ? e : n === null ? n = Object.getOwnPropertyDescriptor(e, r) : n, s;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") i = Reflect.decorate(t, e, r, n);
    else for (var a = t.length - 1; a >= 0; a--) (s = t[a]) && (i = (o < 3 ? s(i) : o > 3 ? s(e, r, i) : s(e, r)) || i);
    return o > 3 && i && Object.defineProperty(e, r, i), i;
  }
  function ce(t, e, r, n) {
    function o(i) {
      return i instanceof r ? i : new r(function(s) {
        s(i);
      });
    }
    return new (r || (r = Promise))(function(i, s) {
      function a(c) {
        try {
          u(n.next(c));
        } catch (p) {
          s(p);
        }
      }
      function l(c) {
        try {
          u(n.throw(c));
        } catch (p) {
          s(p);
        }
      }
      function u(c) {
        c.done ? i(c.value) : o(c.value).then(a, l);
      }
      u((n = n.apply(t, e || [])).next());
    });
  }
  var Op = class {
    constructor(e, r, n, o) {
      this._callback = e, this._type = r, this._minimumUpdateInterval = Math.max(128 / (o || 44100), 1e-3), this.updateInterval = n, this._createClock();
    }
    _createWorker() {
      let e = new Blob([`
			// the initial timeout time
			let timeoutTime =  ${(this._updateInterval * 1e3).toFixed(1)};
			// onmessage callback
			self.onmessage = function(msg){
				timeoutTime = parseInt(msg.data);
			};
			// the tick function which posts a message
			// and schedules a new tick
			function tick(){
				setTimeout(tick, timeoutTime);
				self.postMessage('tick');
			}
			// call tick initially
			tick();
			`], { type: "text/javascript" }), r = URL.createObjectURL(e), n = new Worker(r);
      n.onmessage = this._callback.bind(this), this._worker = n;
    }
    _createTimeout() {
      this._timeout = setTimeout(() => {
        this._createTimeout(), this._callback();
      }, this._updateInterval * 1e3);
    }
    _createClock() {
      if (this._type === "worker") try {
        this._createWorker();
      } catch {
        this._type = "timeout", this._createClock();
      }
      else this._type === "timeout" && this._createTimeout();
    }
    _disposeClock() {
      this._timeout && clearTimeout(this._timeout), this._worker && (this._worker.terminate(), this._worker.onmessage = null);
    }
    get updateInterval() {
      return this._updateInterval;
    }
    set updateInterval(e) {
      var r;
      this._updateInterval = Math.max(e, this._minimumUpdateInterval), this._type === "worker" && ((r = this._worker) === null || r === void 0 || r.postMessage(this._updateInterval * 1e3));
    }
    get type() {
      return this._type;
    }
    set type(e) {
      this._disposeClock(), this._type = e, this._createClock();
    }
    dispose() {
      this._disposeClock();
    }
  };
  function Jr(t) {
    return q1(t);
  }
  function Sn(t) {
    return j1(t);
  }
  function zs(t) {
    return z1(t);
  }
  function Po(t) {
    return B1(t);
  }
  function J1(t) {
    return t instanceof _g;
  }
  function cM(t, e) {
    return t === "value" || Jr(e) || Sn(e) || J1(e);
  }
  function Or(t, ...e) {
    if (!e.length) return t;
    let r = e.shift();
    if (Zr(t) && Zr(r)) for (let n in r) cM(n, r[n]) ? t[n] = r[n] : Zr(r[n]) ? (t[n] || Object.assign(t, { [n]: {} }), Or(t[n], r[n])) : Object.assign(t, { [n]: r[n] });
    return Or(t, ...e);
  }
  function eA(t, e) {
    return t.length === e.length && t.every((r, n) => e[n] === r);
  }
  function b(t, e, r = [], n) {
    let o = {}, i = Array.from(e);
    if (Zr(i[0]) && n && !Reflect.has(i[0], n) && (Object.keys(i[0]).some((a) => Reflect.has(t, a)) || (Or(o, { [n]: i[0] }), r.splice(r.indexOf(n), 1), i.shift())), i.length === 1 && Zr(i[0])) Or(o, i[0]);
    else for (let s = 0; s < r.length; s++) Q(i[s]) && (o[r[s]] = i[s]);
    return Or(t, o);
  }
  function tA(t) {
    return t.constructor.getDefaults();
  }
  function cr(t, e) {
    return Ke(t) ? e : t;
  }
  function en(t, e) {
    return e.forEach((r) => {
      Reflect.has(t, r) && delete t[r];
    }), t;
  }
  var pt = class {
    constructor() {
      this.debug = false, this._wasDisposed = false;
    }
    static getDefaults() {
      return {};
    }
    log(...e) {
      (this.debug || Mt && this.toString() === Mt.TONE_DEBUG_CLASS) && X1(this, ...e);
    }
    dispose() {
      return this._wasDisposed = true, this;
    }
    get disposed() {
      return this._wasDisposed;
    }
    toString() {
      return this.name;
    }
  };
  pt.version = wl;
  function Gn(t, e) {
    return t > e + 1e-6;
  }
  function Bl(t, e) {
    return Gn(t, e) || qt(t, e);
  }
  function wi(t, e) {
    return t + 1e-6 < e;
  }
  function qt(t, e) {
    return Math.abs(t - e) < 1e-6;
  }
  function kg(t, e, r) {
    return Math.max(Math.min(t, r), e);
  }
  var rt = class t extends pt {
    constructor() {
      super(), this.name = "Timeline", this._timeline = [];
      let e = b(t.getDefaults(), arguments, ["memory"]);
      this.memory = e.memory, this.increasing = e.increasing;
    }
    static getDefaults() {
      return { memory: 1 / 0, increasing: false };
    }
    get length() {
      return this._timeline.length;
    }
    add(e) {
      if (U(Reflect.has(e, "time"), "Timeline: events must have a time attribute"), e.time = e.time.valueOf(), this.increasing && this.length) {
        let r = this._timeline[this.length - 1];
        U(Bl(e.time, r.time), "The time must be greater than or equal to the last scheduled time"), this._timeline.push(e);
      } else {
        let r = this._search(e.time);
        this._timeline.splice(r + 1, 0, e);
      }
      if (this.length > this.memory) {
        let r = this.length - this.memory;
        this._timeline.splice(0, r);
      }
      return this;
    }
    remove(e) {
      let r = this._timeline.indexOf(e);
      return r !== -1 && this._timeline.splice(r, 1), this;
    }
    get(e, r = "time") {
      let n = this._search(e, r);
      return n !== -1 ? this._timeline[n] : null;
    }
    peek() {
      return this._timeline[0];
    }
    shift() {
      return this._timeline.shift();
    }
    getAfter(e, r = "time") {
      let n = this._search(e, r);
      return n + 1 < this._timeline.length ? this._timeline[n + 1] : null;
    }
    getBefore(e) {
      let r = this._timeline.length;
      if (r > 0 && this._timeline[r - 1].time < e) return this._timeline[r - 1];
      let n = this._search(e);
      return n - 1 >= 0 ? this._timeline[n - 1] : null;
    }
    cancel(e) {
      if (this._timeline.length > 1) {
        let r = this._search(e);
        if (r >= 0) if (qt(this._timeline[r].time, e)) {
          for (let n = r; n >= 0 && qt(this._timeline[n].time, e); n--) r = n;
          this._timeline = this._timeline.slice(0, r);
        } else this._timeline = this._timeline.slice(0, r + 1);
        else this._timeline = [];
      } else this._timeline.length === 1 && Bl(this._timeline[0].time, e) && (this._timeline = []);
      return this;
    }
    cancelBefore(e) {
      let r = this._search(e);
      return r >= 0 && (this._timeline = this._timeline.slice(r + 1)), this;
    }
    previousEvent(e) {
      let r = this._timeline.indexOf(e);
      return r > 0 ? this._timeline[r - 1] : null;
    }
    _search(e, r = "time") {
      if (this._timeline.length === 0) return -1;
      let n = 0, o = this._timeline.length, i = o;
      if (o > 0 && this._timeline[o - 1][r] <= e) return o - 1;
      for (; n < i; ) {
        let s = Math.floor(n + (i - n) / 2), a = this._timeline[s], l = this._timeline[s + 1];
        if (qt(a[r], e)) {
          for (let u = s; u < this._timeline.length; u++) {
            let c = this._timeline[u];
            if (qt(c[r], e)) s = u;
            else break;
          }
          return s;
        } else {
          if (wi(a[r], e) && Gn(l[r], e)) return s;
          Gn(a[r], e) ? i = s : n = s + 1;
        }
      }
      return -1;
    }
    _iterate(e, r = 0, n = this._timeline.length - 1) {
      this._timeline.slice(r, n + 1).forEach(e);
    }
    forEach(e) {
      return this._iterate(e), this;
    }
    forEachBefore(e, r) {
      let n = this._search(e);
      return n !== -1 && this._iterate(r, 0, n), this;
    }
    forEachAfter(e, r) {
      let n = this._search(e);
      return this._iterate(r, n + 1), this;
    }
    forEachBetween(e, r, n) {
      let o = this._search(e), i = this._search(r);
      return o !== -1 && i !== -1 ? (this._timeline[o].time !== e && (o += 1), this._timeline[i].time === r && (i -= 1), this._iterate(n, o, i)) : o === -1 && this._iterate(n, 0, i), this;
    }
    forEachFrom(e, r) {
      let n = this._search(e);
      for (; n >= 0 && this._timeline[n].time >= e; ) n--;
      return this._iterate(r, n + 1), this;
    }
    forEachAtTime(e, r) {
      let n = this._search(e);
      if (n !== -1 && qt(this._timeline[n].time, e)) {
        let o = n;
        for (let i = n; i >= 0 && qt(this._timeline[i].time, e); i--) o = i;
        this._iterate((i) => {
          r(i);
        }, o, n);
      }
      return this;
    }
    dispose() {
      return super.dispose(), this._timeline = [], this;
    }
  };
  var rA = [];
  function Ro(t) {
    rA.push(t);
  }
  function nA(t) {
    rA.forEach((e) => e(t));
  }
  var oA = [];
  function Vo(t) {
    oA.push(t);
  }
  function iA(t) {
    oA.forEach((e) => e(t));
  }
  var Fo = class t extends pt {
    constructor() {
      super(...arguments), this.name = "Emitter";
    }
    on(e, r) {
      return e.split(/\W+/).forEach((o) => {
        Ke(this._events) && (this._events = {}), this._events.hasOwnProperty(o) || (this._events[o] = []), this._events[o].push(r);
      }), this;
    }
    once(e, r) {
      let n = (...o) => {
        r(...o), this.off(e, n);
      };
      return this.on(e, n), this;
    }
    off(e, r) {
      return e.split(/\W+/).forEach((o) => {
        if (Ke(this._events) && (this._events = {}), this._events.hasOwnProperty(o)) if (Ke(r)) this._events[o] = [];
        else {
          let i = this._events[o];
          for (let s = i.length - 1; s >= 0; s--) i[s] === r && i.splice(s, 1);
        }
      }), this;
    }
    emit(e, ...r) {
      if (this._events && this._events.hasOwnProperty(e)) {
        let n = this._events[e].slice(0);
        for (let o = 0, i = n.length; o < i; o++) n[o].apply(this, r);
      }
      return this;
    }
    static mixin(e) {
      ["on", "once", "off", "emit"].forEach((r) => {
        let n = Object.getOwnPropertyDescriptor(t.prototype, r);
        Object.defineProperty(e.prototype, r, n);
      });
    }
    dispose() {
      return super.dispose(), this._events = void 0, this;
    }
  };
  var Ws = class extends Fo {
    constructor() {
      super(...arguments), this.isOffline = false;
    }
    toJSON() {
      return {};
    }
  };
  var Si = class t extends Ws {
    constructor() {
      var e, r;
      super(), this.name = "Context", this._constants = /* @__PURE__ */ new Map(), this._timeouts = new rt(), this._timeoutIds = 0, this._initialized = false, this._closeStarted = false, this.isOffline = false, this._workletPromise = null;
      let n = b(t.getDefaults(), arguments, ["context"]);
      n.context ? (this._context = n.context, this._latencyHint = ((e = arguments[0]) === null || e === void 0 ? void 0 : e.latencyHint) || "") : (this._context = Y1({ latencyHint: n.latencyHint }), this._latencyHint = n.latencyHint), this._ticker = new Op(this.emit.bind(this, "tick"), n.clockSource, n.updateInterval, this._context.sampleRate), this.on("tick", this._timeoutLoop.bind(this)), this._context.onstatechange = () => {
        this.emit("statechange", this.state);
      }, this[!((r = arguments[0]) === null || r === void 0) && r.hasOwnProperty("updateInterval") ? "_lookAhead" : "lookAhead"] = n.lookAhead;
    }
    static getDefaults() {
      return { clockSource: "worker", latencyHint: "interactive", lookAhead: 0.1, updateInterval: 0.05 };
    }
    initialize() {
      return this._initialized || (nA(this), this._initialized = true), this;
    }
    createAnalyser() {
      return this._context.createAnalyser();
    }
    createOscillator() {
      return this._context.createOscillator();
    }
    createBufferSource() {
      return this._context.createBufferSource();
    }
    createBiquadFilter() {
      return this._context.createBiquadFilter();
    }
    createBuffer(e, r, n) {
      return this._context.createBuffer(e, r, n);
    }
    createChannelMerger(e) {
      return this._context.createChannelMerger(e);
    }
    createChannelSplitter(e) {
      return this._context.createChannelSplitter(e);
    }
    createConstantSource() {
      return this._context.createConstantSource();
    }
    createConvolver() {
      return this._context.createConvolver();
    }
    createDelay(e) {
      return this._context.createDelay(e);
    }
    createDynamicsCompressor() {
      return this._context.createDynamicsCompressor();
    }
    createGain() {
      return this._context.createGain();
    }
    createIIRFilter(e, r) {
      return this._context.createIIRFilter(e, r);
    }
    createPanner() {
      return this._context.createPanner();
    }
    createPeriodicWave(e, r, n) {
      return this._context.createPeriodicWave(e, r, n);
    }
    createStereoPanner() {
      return this._context.createStereoPanner();
    }
    createWaveShaper() {
      return this._context.createWaveShaper();
    }
    createMediaStreamSource(e) {
      return U(Po(this._context), "Not available if OfflineAudioContext"), this._context.createMediaStreamSource(e);
    }
    createMediaElementSource(e) {
      return U(Po(this._context), "Not available if OfflineAudioContext"), this._context.createMediaElementSource(e);
    }
    createMediaStreamDestination() {
      return U(Po(this._context), "Not available if OfflineAudioContext"), this._context.createMediaStreamDestination();
    }
    decodeAudioData(e) {
      return this._context.decodeAudioData(e);
    }
    get currentTime() {
      return this._context.currentTime;
    }
    get state() {
      return this._context.state;
    }
    get sampleRate() {
      return this._context.sampleRate;
    }
    get listener() {
      return this.initialize(), this._listener;
    }
    set listener(e) {
      U(!this._initialized, "The listener cannot be set after initialization."), this._listener = e;
    }
    get transport() {
      return this.initialize(), this._transport;
    }
    set transport(e) {
      U(!this._initialized, "The transport cannot be set after initialization."), this._transport = e;
    }
    get draw() {
      return this.initialize(), this._draw;
    }
    set draw(e) {
      U(!this._initialized, "Draw cannot be set after initialization."), this._draw = e;
    }
    get destination() {
      return this.initialize(), this._destination;
    }
    set destination(e) {
      U(!this._initialized, "The destination cannot be set after initialization."), this._destination = e;
    }
    createAudioWorkletNode(e, r) {
      return Z1(this.rawContext, e, r);
    }
    addAudioWorkletModule(e) {
      return ce(this, void 0, void 0, function* () {
        U(Q(this.rawContext.audioWorklet), "AudioWorkletNode is only available in a secure context (https or localhost)"), this._workletPromise || (this._workletPromise = this.rawContext.audioWorklet.addModule(e)), yield this._workletPromise;
      });
    }
    workletsAreReady() {
      return ce(this, void 0, void 0, function* () {
        (yield this._workletPromise) ? this._workletPromise : Promise.resolve();
      });
    }
    get updateInterval() {
      return this._ticker.updateInterval;
    }
    set updateInterval(e) {
      this._ticker.updateInterval = e;
    }
    get clockSource() {
      return this._ticker.type;
    }
    set clockSource(e) {
      this._ticker.type = e;
    }
    get lookAhead() {
      return this._lookAhead;
    }
    set lookAhead(e) {
      this._lookAhead = e, this.updateInterval = e ? e / 2 : 0.01;
    }
    get latencyHint() {
      return this._latencyHint;
    }
    get rawContext() {
      return this._context;
    }
    now() {
      return this._context.currentTime + this._lookAhead;
    }
    immediate() {
      return this._context.currentTime;
    }
    resume() {
      return Po(this._context) ? this._context.resume() : Promise.resolve();
    }
    close() {
      return ce(this, void 0, void 0, function* () {
        Po(this._context) && this.state !== "closed" && !this._closeStarted && (this._closeStarted = true, yield this._context.close()), this._initialized && iA(this);
      });
    }
    getConstant(e) {
      if (this._constants.has(e)) return this._constants.get(e);
      {
        let r = this._context.createBuffer(1, 128, this._context.sampleRate), n = r.getChannelData(0);
        for (let i = 0; i < n.length; i++) n[i] = e;
        let o = this._context.createBufferSource();
        return o.channelCount = 1, o.channelCountMode = "explicit", o.buffer = r, o.loop = true, o.start(0), this._constants.set(e, o), o;
      }
    }
    dispose() {
      return super.dispose(), this._ticker.dispose(), this._timeouts.dispose(), Object.keys(this._constants).map((e) => this._constants[e].disconnect()), this.close(), this;
    }
    _timeoutLoop() {
      let e = this.now();
      this._timeouts.forEachBefore(e, (r) => {
        r.callback(), this._timeouts.remove(r);
      });
    }
    setTimeout(e, r) {
      this._timeoutIds++;
      let n = this.now();
      return this._timeouts.add({ callback: e, id: this._timeoutIds, time: n + r }), this._timeoutIds;
    }
    clearTimeout(e) {
      return this._timeouts.forEach((r) => {
        r.id === e && this._timeouts.remove(r);
      }), this;
    }
    clearInterval(e) {
      return this.clearTimeout(e);
    }
    setInterval(e, r) {
      let n = ++this._timeoutIds, o = () => {
        let i = this.now();
        this._timeouts.add({ callback: () => {
          e(), o();
        }, id: n, time: i + r });
      };
      return o(), n;
    }
  };
  var Dp = class extends Ws {
    constructor() {
      super(...arguments), this.lookAhead = 0, this.latencyHint = 0, this.isOffline = false;
    }
    createAnalyser() {
      return {};
    }
    createOscillator() {
      return {};
    }
    createBufferSource() {
      return {};
    }
    createBiquadFilter() {
      return {};
    }
    createBuffer(e, r, n) {
      return {};
    }
    createChannelMerger(e) {
      return {};
    }
    createChannelSplitter(e) {
      return {};
    }
    createConstantSource() {
      return {};
    }
    createConvolver() {
      return {};
    }
    createDelay(e) {
      return {};
    }
    createDynamicsCompressor() {
      return {};
    }
    createGain() {
      return {};
    }
    createIIRFilter(e, r) {
      return {};
    }
    createPanner() {
      return {};
    }
    createPeriodicWave(e, r, n) {
      return {};
    }
    createStereoPanner() {
      return {};
    }
    createWaveShaper() {
      return {};
    }
    createMediaStreamSource(e) {
      return {};
    }
    createMediaElementSource(e) {
      return {};
    }
    createMediaStreamDestination() {
      return {};
    }
    decodeAudioData(e) {
      return Promise.resolve({});
    }
    createAudioWorkletNode(e, r) {
      return {};
    }
    get rawContext() {
      return {};
    }
    addAudioWorkletModule(e) {
      return ce(this, void 0, void 0, function* () {
        return Promise.resolve();
      });
    }
    resume() {
      return Promise.resolve();
    }
    setTimeout(e, r) {
      return 0;
    }
    clearTimeout(e) {
      return this;
    }
    setInterval(e, r) {
      return 0;
    }
    clearInterval(e) {
      return this;
    }
    getConstant(e) {
      return {};
    }
    get currentTime() {
      return 0;
    }
    get state() {
      return {};
    }
    get sampleRate() {
      return 0;
    }
    get listener() {
      return {};
    }
    get transport() {
      return {};
    }
    get draw() {
      return {};
    }
    set draw(e) {
    }
    get destination() {
      return {};
    }
    set destination(e) {
    }
    now() {
      return 0;
    }
    immediate() {
      return 0;
    }
  };
  function z(t, e) {
    Fe(e) ? e.forEach((r) => z(t, r)) : Object.defineProperty(t, e, { enumerable: true, writable: false });
  }
  function Us(t, e) {
    Fe(e) ? e.forEach((r) => Us(t, r)) : Object.defineProperty(t, e, { writable: true });
  }
  var Z = () => {
  };
  var ht = class t extends pt {
    constructor() {
      super(), this.name = "ToneAudioBuffer", this.onload = Z;
      let e = b(t.getDefaults(), arguments, ["url", "onload", "onerror"]);
      this.reverse = e.reverse, this.onload = e.onload, Dt(e.url) ? this.load(e.url).catch(e.onerror) : e.url && this.set(e.url);
    }
    static getDefaults() {
      return { onerror: Z, onload: Z, reverse: false };
    }
    get sampleRate() {
      return this._buffer ? this._buffer.sampleRate : Ge().sampleRate;
    }
    set(e) {
      return e instanceof t ? e.loaded ? this._buffer = e.get() : e.onload = () => {
        this.set(e), this.onload(this);
      } : this._buffer = e, this._reversed && this._reverse(), this;
    }
    get() {
      return this._buffer;
    }
    load(e) {
      return ce(this, void 0, void 0, function* () {
        let r = t.load(e).then((n) => {
          this.set(n), this.onload(this);
        });
        t.downloads.push(r);
        try {
          yield r;
        } finally {
          let n = t.downloads.indexOf(r);
          t.downloads.splice(n, 1);
        }
        return this;
      });
    }
    dispose() {
      return super.dispose(), this._buffer = void 0, this;
    }
    fromArray(e) {
      let r = Fe(e) && e[0].length > 0, n = r ? e.length : 1, o = r ? e[0].length : e.length, i = Ge(), s = i.createBuffer(n, o, i.sampleRate), a = !r && n === 1 ? [e] : e;
      for (let l = 0; l < n; l++) s.copyToChannel(a[l], l);
      return this._buffer = s, this;
    }
    toMono(e) {
      if (Ot(e)) this.fromArray(this.toArray(e));
      else {
        let r = new Float32Array(this.length), n = this.numberOfChannels;
        for (let o = 0; o < n; o++) {
          let i = this.toArray(o);
          for (let s = 0; s < i.length; s++) r[s] += i[s];
        }
        r = r.map((o) => o / n), this.fromArray(r);
      }
      return this;
    }
    toArray(e) {
      if (Ot(e)) return this.getChannelData(e);
      if (this.numberOfChannels === 1) return this.toArray(0);
      {
        let r = [];
        for (let n = 0; n < this.numberOfChannels; n++) r[n] = this.getChannelData(n);
        return r;
      }
    }
    getChannelData(e) {
      return this._buffer ? this._buffer.getChannelData(e) : new Float32Array(0);
    }
    slice(e, r = this.duration) {
      U(this.loaded, "Buffer is not loaded");
      let n = Math.floor(e * this.sampleRate), o = Math.floor(r * this.sampleRate);
      U(n < o, "The start time must be less than the end time");
      let i = o - n, s = Ge().createBuffer(this.numberOfChannels, i, this.sampleRate);
      for (let a = 0; a < this.numberOfChannels; a++) s.copyToChannel(this.getChannelData(a).subarray(n, o), a);
      return new t(s);
    }
    _reverse() {
      if (this.loaded) for (let e = 0; e < this.numberOfChannels; e++) this.getChannelData(e).reverse();
      return this;
    }
    get loaded() {
      return this.length > 0;
    }
    get duration() {
      return this._buffer ? this._buffer.duration : 0;
    }
    get length() {
      return this._buffer ? this._buffer.length : 0;
    }
    get numberOfChannels() {
      return this._buffer ? this._buffer.numberOfChannels : 0;
    }
    get reverse() {
      return this._reversed;
    }
    set reverse(e) {
      this._reversed !== e && (this._reversed = e, this._reverse());
    }
    static fromArray(e) {
      return new t().fromArray(e);
    }
    static fromUrl(e) {
      return ce(this, void 0, void 0, function* () {
        return yield new t().load(e);
      });
    }
    static load(e) {
      return ce(this, void 0, void 0, function* () {
        let r = t.baseUrl === "" || t.baseUrl.endsWith("/") ? t.baseUrl : t.baseUrl + "/", n = yield fetch(r + e);
        if (!n.ok) throw new Error(`could not load url: ${e}`);
        let o = yield n.arrayBuffer();
        return yield Ge().decodeAudioData(o);
      });
    }
    static supportsType(e) {
      let r = e.split("."), n = r[r.length - 1];
      return document.createElement("audio").canPlayType("audio/" + n) !== "";
    }
    static loaded() {
      return ce(this, void 0, void 0, function* () {
        for (yield Promise.resolve(); t.downloads.length; ) yield t.downloads[0];
      });
    }
  };
  ht.baseUrl = "";
  ht.downloads = [];
  var Tn = class extends Si {
    constructor() {
      super({ clockSource: "offline", context: zs(arguments[0]) ? arguments[0] : Q1(arguments[0], arguments[1] * arguments[2], arguments[2]), lookAhead: 0, updateInterval: zs(arguments[0]) ? 128 / arguments[0].sampleRate : 128 / arguments[2] }), this.name = "OfflineContext", this._currentTime = 0, this.isOffline = true, this._duration = zs(arguments[0]) ? arguments[0].length / arguments[0].sampleRate : arguments[1];
    }
    now() {
      return this._currentTime;
    }
    get currentTime() {
      return this._currentTime;
    }
    _renderClock(e) {
      return ce(this, void 0, void 0, function* () {
        let r = 0;
        for (; this._duration - this._currentTime >= 0; ) {
          this.emit("tick"), this._currentTime += 128 / this.sampleRate, r++;
          let n = Math.floor(this.sampleRate / 128);
          e && r % n === 0 && (yield new Promise((o) => setTimeout(o, 1)));
        }
      });
    }
    render() {
      return ce(this, arguments, void 0, function* (e = true) {
        yield this.workletsAreReady(), yield this._renderClock(e);
        let r = yield this._context.startRendering();
        return new ht(r);
      });
    }
    close() {
      return Promise.resolve();
    }
  };
  var sA = new Dp(), Ti = sA;
  function Ge() {
    return Ti === sA && K1 && Eg(new Si()), Ti;
  }
  function Eg(t, e = false) {
    e && Ti.dispose(), Po(t) ? Ti = new Si(t) : zs(t) ? Ti = new Tn(t) : Ti = t;
  }
  function bg() {
    return Ti.resume();
  }
  if (Mt && !Mt.TONE_SILENCE_LOGGING) {
    let t = "v";
    wl === "dev" && (t = "");
    let e = ` * Tone.js ${t}${wl} * `;
    console.log(`%c${e}`, "background: #000; color: #fff");
  }
  function Gs(t) {
    return Math.pow(10, t / 20);
  }
  function Hs(t) {
    return 20 * (Math.log(t) / Math.LN10);
  }
  function Ai(t) {
    return Math.pow(2, t / 12);
  }
  var Mp = 440;
  function aA() {
    return Mp;
  }
  function lA(t) {
    Mp = t;
  }
  function tn(t) {
    return Math.round(Ng(t));
  }
  function Ng(t) {
    return 69 + 12 * Math.log2(t / Mp);
  }
  function jl(t) {
    return Mp * Math.pow(2, (t - 69) / 12);
  }
  var Pp = class t extends pt {
    constructor(e, r, n) {
      super(), this.defaultUnits = "s", this._val = r, this._units = n, this.context = e, this._expressions = this._getExpressions();
    }
    _getExpressions() {
      return { hz: { method: (e) => this._frequencyToUnits(parseFloat(e)), regexp: /^(\d+(?:\.\d+)?)hz$/i }, i: { method: (e) => this._ticksToUnits(parseInt(e, 10)), regexp: /^(\d+)i$/i }, m: { method: (e) => this._beatsToUnits(parseInt(e, 10) * this._getTimeSignature()), regexp: /^(\d+)m$/i }, n: { method: (e, r) => {
        let n = parseInt(e, 10), o = r === "." ? 1.5 : 1;
        return n === 1 ? this._beatsToUnits(this._getTimeSignature()) * o : this._beatsToUnits(4 / n) * o;
      }, regexp: /^(\d+)n(\.?)$/i }, number: { method: (e) => this._expressions[this.defaultUnits].method.call(this, e), regexp: /^(\d+(?:\.\d+)?)$/ }, s: { method: (e) => this._secondsToUnits(parseFloat(e)), regexp: /^(\d+(?:\.\d+)?)s$/ }, samples: { method: (e) => parseInt(e, 10) / this.context.sampleRate, regexp: /^(\d+)samples$/ }, t: { method: (e) => {
        let r = parseInt(e, 10);
        return this._beatsToUnits(8 / (Math.floor(r) * 3));
      }, regexp: /^(\d+)t$/i }, tr: { method: (e, r, n) => {
        let o = 0;
        return e && e !== "0" && (o += this._beatsToUnits(this._getTimeSignature() * parseFloat(e))), r && r !== "0" && (o += this._beatsToUnits(parseFloat(r))), n && n !== "0" && (o += this._beatsToUnits(parseFloat(n) / 4)), o;
      }, regexp: /^(\d+(?:\.\d+)?):(\d+(?:\.\d+)?):?(\d+(?:\.\d+)?)?$/ } };
    }
    valueOf() {
      if (this._val instanceof t && this.fromType(this._val), Ke(this._val)) return this._noArg();
      if (Dt(this._val) && Ke(this._units)) {
        for (let e in this._expressions) if (this._expressions[e].regexp.test(this._val.trim())) {
          this._units = e;
          break;
        }
      } else if (Zr(this._val)) {
        let e = 0;
        for (let r in this._val) if (Q(this._val[r])) {
          let n = this._val[r], o = new this.constructor(this.context, r).valueOf() * n;
          e += o;
        }
        return e;
      }
      if (Q(this._units)) {
        let e = this._expressions[this._units], r = this._val.toString().trim().match(e.regexp);
        return r ? e.method.apply(this, r.slice(1)) : e.method.call(this, this._val);
      } else return Dt(this._val) ? parseFloat(this._val) : this._val;
    }
    _frequencyToUnits(e) {
      return 1 / e;
    }
    _beatsToUnits(e) {
      return 60 / this._getBpm() * e;
    }
    _secondsToUnits(e) {
      return e;
    }
    _ticksToUnits(e) {
      return e * this._beatsToUnits(1) / this._getPPQ();
    }
    _noArg() {
      return this._now();
    }
    _getBpm() {
      return this.context.transport.bpm.value;
    }
    _getTimeSignature() {
      return this.context.transport.timeSignature;
    }
    _getPPQ() {
      return this.context.transport.PPQ;
    }
    fromType(e) {
      switch (this._units = void 0, this.defaultUnits) {
        case "s":
          this._val = e.toSeconds();
          break;
        case "i":
          this._val = e.toTicks();
          break;
        case "hz":
          this._val = e.toFrequency();
          break;
        case "midi":
          this._val = e.toMidi();
          break;
      }
      return this;
    }
    toFrequency() {
      return 1 / this.toSeconds();
    }
    toSamples() {
      return this.toSeconds() * this.context.sampleRate;
    }
    toMilliseconds() {
      return this.toSeconds() * 1e3;
    }
  };
  var pr = class t extends Pp {
    constructor() {
      super(...arguments), this.name = "TimeClass";
    }
    _getExpressions() {
      return Object.assign(super._getExpressions(), { now: { method: (e) => this._now() + new this.constructor(this.context, e).valueOf(), regexp: /^\+(.+)/ }, quantize: { method: (e) => {
        let r = new t(this.context, e).valueOf();
        return this._secondsToUnits(this.context.transport.nextSubdivision(r));
      }, regexp: /^@(.+)/ } });
    }
    quantize(e, r = 1) {
      let n = new this.constructor(this.context, e).valueOf(), o = this.valueOf(), a = Math.round(o / n) * n - o;
      return o + a * r;
    }
    toNotation() {
      let e = this.toSeconds(), r = ["1m"];
      for (let i = 1; i < 9; i++) {
        let s = Math.pow(2, i);
        r.push(s + "n."), r.push(s + "n"), r.push(s + "t");
      }
      r.push("0");
      let n = r[0], o = new t(this.context, r[0]).toSeconds();
      return r.forEach((i) => {
        let s = new t(this.context, i).toSeconds();
        Math.abs(s - e) < Math.abs(o - e) && (n = i, o = s);
      }), n;
    }
    toBarsBeatsSixteenths() {
      let e = this._beatsToUnits(1), r = this.valueOf() / e;
      r = parseFloat(r.toFixed(4));
      let n = Math.floor(r / this._getTimeSignature()), o = r % 1 * 4;
      r = Math.floor(r) % this._getTimeSignature();
      let i = o.toString();
      return i.length > 3 && (o = parseFloat(parseFloat(i).toFixed(3))), [n, r, o].join(":");
    }
    toTicks() {
      let e = this._beatsToUnits(1);
      return this.valueOf() / e * this._getPPQ();
    }
    toSeconds() {
      return this.valueOf();
    }
    toMidi() {
      return tn(this.toFrequency());
    }
    _now() {
      return this.context.now();
    }
  };
  var zt = class t extends pr {
    constructor() {
      super(...arguments), this.name = "Frequency", this.defaultUnits = "hz";
    }
    static get A4() {
      return aA();
    }
    static set A4(e) {
      lA(e);
    }
    _getExpressions() {
      return Object.assign({}, super._getExpressions(), { midi: { regexp: /^(\d+(?:\.\d+)?midi)/, method(e) {
        return this.defaultUnits === "midi" ? e : t.mtof(e);
      } }, note: { regexp: /^([a-g]{1}(?:b|#|##|x|bb|###|#x|x#|bbb)?)(-?[0-9]+)/i, method(e, r) {
        let o = pM[e.toLowerCase()] + (parseInt(r, 10) + 1) * 12;
        return this.defaultUnits === "midi" ? o : t.mtof(o);
      } }, tr: { regexp: /^(\d+(?:\.\d+)?):(\d+(?:\.\d+)?):?(\d+(?:\.\d+)?)?/, method(e, r, n) {
        let o = 1;
        return e && e !== "0" && (o *= this._beatsToUnits(this._getTimeSignature() * parseFloat(e))), r && r !== "0" && (o *= this._beatsToUnits(parseFloat(r))), n && n !== "0" && (o *= this._beatsToUnits(parseFloat(n) / 4)), o;
      } } });
    }
    transpose(e) {
      return new t(this.context, this.valueOf() * Ai(e));
    }
    harmonize(e) {
      return e.map((r) => this.transpose(r));
    }
    toMidi() {
      return tn(this.valueOf());
    }
    toNote() {
      let e = this.toFrequency(), r = Math.log2(e / t.A4), n = Math.round(12 * r) + 57, o = Math.floor(n / 12);
      return o < 0 && (n += -12 * o), hM[n % 12] + o.toString();
    }
    toSeconds() {
      return 1 / super.toSeconds();
    }
    toTicks() {
      let e = this._beatsToUnits(1), r = this.valueOf() / e;
      return Math.floor(r * this._getPPQ());
    }
    _noArg() {
      return 0;
    }
    _frequencyToUnits(e) {
      return e;
    }
    _ticksToUnits(e) {
      return 1 / (e * 60 / (this._getBpm() * this._getPPQ()));
    }
    _beatsToUnits(e) {
      return 1 / super._beatsToUnits(e);
    }
    _secondsToUnits(e) {
      return 1 / e;
    }
    static mtof(e) {
      return jl(e);
    }
    static ftom(e) {
      return tn(e);
    }
  }, pM = { cbbb: -3, cbb: -2, cb: -1, c: 0, "c#": 1, cx: 2, "c##": 2, "c###": 3, "cx#": 3, "c#x": 3, dbbb: -1, dbb: 0, db: 1, d: 2, "d#": 3, dx: 4, "d##": 4, "d###": 5, "dx#": 5, "d#x": 5, ebbb: 1, ebb: 2, eb: 3, e: 4, "e#": 5, ex: 6, "e##": 6, "e###": 7, "ex#": 7, "e#x": 7, fbbb: 2, fbb: 3, fb: 4, f: 5, "f#": 6, fx: 7, "f##": 7, "f###": 8, "fx#": 8, "f#x": 8, gbbb: 4, gbb: 5, gb: 6, g: 7, "g#": 8, gx: 9, "g##": 9, "g###": 10, "gx#": 10, "g#x": 10, abbb: 6, abb: 7, ab: 8, a: 9, "a#": 10, ax: 11, "a##": 11, "a###": 12, "ax#": 12, "a#x": 12, bbbb: 8, bbb: 9, bb: 10, b: 11, "b#": 12, bx: 13, "b##": 13, "b###": 14, "bx#": 14, "b#x": 14 }, hM = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  var Dr = class extends pr {
    constructor() {
      super(...arguments), this.name = "TransportTime";
    }
    _now() {
      return this.context.transport.seconds;
    }
  };
  var nt = class t extends pt {
    constructor() {
      super();
      let e = b(t.getDefaults(), arguments, ["context"]);
      this.defaultContext ? this.context = this.defaultContext : this.context = e.context;
    }
    static getDefaults() {
      return { context: Ge() };
    }
    now() {
      return this.context.currentTime + this.context.lookAhead;
    }
    immediate() {
      return this.context.currentTime;
    }
    get sampleTime() {
      return 1 / this.context.sampleRate;
    }
    get blockTime() {
      return 128 / this.context.sampleRate;
    }
    toSeconds(e) {
      return H1(e), new pr(this.context, e).toSeconds();
    }
    toFrequency(e) {
      return new zt(this.context, e).toFrequency();
    }
    toTicks(e) {
      return new Dr(this.context, e).toTicks();
    }
    _getPartialProperties(e) {
      let r = this.get();
      return Object.keys(r).forEach((n) => {
        Ke(e[n]) && delete r[n];
      }), r;
    }
    get() {
      let e = tA(this);
      return Object.keys(e).forEach((r) => {
        if (Reflect.has(this, r)) {
          let n = this[r];
          Q(n) && Q(n.value) && Q(n.setValueAtTime) ? e[r] = n.value : n instanceof t ? e[r] = n._getPartialProperties(e[r]) : Fe(n) || Ot(n) || Dt(n) || Ag(n) ? e[r] = n : delete e[r];
        }
      }), e;
    }
    set(e) {
      return Object.keys(e).forEach((r) => {
        Reflect.has(this, r) && Q(this[r]) && (this[r] && Q(this[r].value) && Q(this[r].setValueAtTime) ? this[r].value !== e[r] && (this[r].value = e[r]) : this[r] instanceof t ? this[r].set(e[r]) : this[r] = e[r]);
      }), this;
    }
  };
  var An = class extends rt {
    constructor(e = "stopped") {
      super(), this.name = "StateTimeline", this._initial = e, this.setStateAtTime(this._initial, 0);
    }
    getValueAtTime(e) {
      let r = this.get(e);
      return r !== null ? r.state : this._initial;
    }
    setStateAtTime(e, r, n) {
      return yt(r, 0), this.add(Object.assign({}, n, { state: e, time: r })), this;
    }
    getLastState(e, r) {
      let n = this._search(r);
      for (let o = n; o >= 0; o--) {
        let i = this._timeline[o];
        if (i.state === e) return i;
      }
    }
    getNextState(e, r) {
      let n = this._search(r);
      if (n !== -1) for (let o = n; o < this._timeline.length; o++) {
        let i = this._timeline[o];
        if (i.state === e) return i;
      }
    }
  };
  var ie = class t extends nt {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["param", "units", "convert"]);
      for (super(e), this.name = "Param", this.overridden = false, this._minOutput = 1e-7, U(Q(e.param) && (Jr(e.param) || e.param instanceof t), "param must be an AudioParam"); !Jr(e.param); ) e.param = e.param._param;
      this._swappable = Q(e.swappable) ? e.swappable : false, this._swappable ? (this.input = this.context.createGain(), this._param = e.param, this.input.connect(this._param)) : this._param = this.input = e.param, this._events = new rt(1e3), this._initialValue = this._param.defaultValue, this.units = e.units, this.convert = e.convert, this._minValue = e.minValue, this._maxValue = e.maxValue, Q(e.value) && e.value !== this._toType(this._initialValue) && this.setValueAtTime(e.value, 0);
    }
    static getDefaults() {
      return Object.assign(nt.getDefaults(), { convert: true, units: "number" });
    }
    get value() {
      let e = this.now();
      return this.getValueAtTime(e);
    }
    set value(e) {
      this.cancelScheduledValues(this.now()), this.setValueAtTime(e, this.now());
    }
    get minValue() {
      return Q(this._minValue) ? this._minValue : this.units === "time" || this.units === "frequency" || this.units === "normalRange" || this.units === "positive" || this.units === "transportTime" || this.units === "ticks" || this.units === "bpm" || this.units === "hertz" || this.units === "samples" ? 0 : this.units === "audioRange" ? -1 : this.units === "decibels" ? -1 / 0 : this._param.minValue;
    }
    get maxValue() {
      return Q(this._maxValue) ? this._maxValue : this.units === "normalRange" || this.units === "audioRange" ? 1 : this._param.maxValue;
    }
    _is(e, r) {
      return this.units === r;
    }
    _assertRange(e) {
      return Q(this.maxValue) && Q(this.minValue) && yt(e, this._fromType(this.minValue), this._fromType(this.maxValue)), e;
    }
    _fromType(e) {
      return this.convert && !this.overridden ? this._is(e, "time") ? this.toSeconds(e) : this._is(e, "decibels") ? Gs(e) : this._is(e, "frequency") ? this.toFrequency(e) : e : this.overridden ? 0 : e;
    }
    _toType(e) {
      return this.convert && this.units === "decibels" ? Hs(e) : e;
    }
    setValueAtTime(e, r) {
      let n = this.toSeconds(r), o = this._fromType(e);
      return U(isFinite(o) && isFinite(n), `Invalid argument(s) to setValueAtTime: ${JSON.stringify(e)}, ${JSON.stringify(r)}`), this._assertRange(o), this.log(this.units, "setValueAtTime", e, n), this._events.add({ time: n, type: "setValueAtTime", value: o }), this._param.setValueAtTime(o, n), this;
    }
    getValueAtTime(e) {
      let r = Math.max(this.toSeconds(e), 0), n = this._events.getAfter(r), o = this._events.get(r), i = this._initialValue;
      if (o === null) i = this._initialValue;
      else if (o.type === "setTargetAtTime" && (n === null || n.type === "setValueAtTime")) {
        let s = this._events.getBefore(o.time), a;
        s === null ? a = this._initialValue : a = s.value, o.type === "setTargetAtTime" && (i = this._exponentialApproach(o.time, a, o.value, o.constant, r));
      } else if (n === null) i = o.value;
      else if (n.type === "linearRampToValueAtTime" || n.type === "exponentialRampToValueAtTime") {
        let s = o.value;
        if (o.type === "setTargetAtTime") {
          let a = this._events.getBefore(o.time);
          a === null ? s = this._initialValue : s = a.value;
        }
        n.type === "linearRampToValueAtTime" ? i = this._linearInterpolate(o.time, s, n.time, n.value, r) : i = this._exponentialInterpolate(o.time, s, n.time, n.value, r);
      } else i = o.value;
      return this._toType(i);
    }
    setRampPoint(e) {
      e = this.toSeconds(e);
      let r = this.getValueAtTime(e);
      return this.cancelAndHoldAtTime(e), this._fromType(r) === 0 && (r = this._toType(this._minOutput)), this.setValueAtTime(r, e), this;
    }
    linearRampToValueAtTime(e, r) {
      let n = this._fromType(e), o = this.toSeconds(r);
      return U(isFinite(n) && isFinite(o), `Invalid argument(s) to linearRampToValueAtTime: ${JSON.stringify(e)}, ${JSON.stringify(r)}`), this._assertRange(n), this._events.add({ time: o, type: "linearRampToValueAtTime", value: n }), this.log(this.units, "linearRampToValueAtTime", e, o), this._param.linearRampToValueAtTime(n, o), this;
    }
    exponentialRampToValueAtTime(e, r) {
      let n = this._fromType(e);
      n = qt(n, 0) ? this._minOutput : n, this._assertRange(n);
      let o = this.toSeconds(r);
      return U(isFinite(n) && isFinite(o), `Invalid argument(s) to exponentialRampToValueAtTime: ${JSON.stringify(e)}, ${JSON.stringify(r)}`), this._events.add({ time: o, type: "exponentialRampToValueAtTime", value: n }), this.log(this.units, "exponentialRampToValueAtTime", e, o), this._param.exponentialRampToValueAtTime(n, o), this;
    }
    exponentialRampTo(e, r, n) {
      return n = this.toSeconds(n), this.setRampPoint(n), this.exponentialRampToValueAtTime(e, n + this.toSeconds(r)), this;
    }
    linearRampTo(e, r, n) {
      return n = this.toSeconds(n), this.setRampPoint(n), this.linearRampToValueAtTime(e, n + this.toSeconds(r)), this;
    }
    targetRampTo(e, r, n) {
      return n = this.toSeconds(n), this.setRampPoint(n), this.exponentialApproachValueAtTime(e, n, r), this;
    }
    exponentialApproachValueAtTime(e, r, n) {
      r = this.toSeconds(r), n = this.toSeconds(n);
      let o = Math.log(n + 1) / Math.log(200);
      return this.setTargetAtTime(e, r, o), this.cancelAndHoldAtTime(r + n * 0.9), this.linearRampToValueAtTime(e, r + n), this;
    }
    setTargetAtTime(e, r, n) {
      let o = this._fromType(e);
      U(isFinite(n) && n > 0, "timeConstant must be a number greater than 0");
      let i = this.toSeconds(r);
      return this._assertRange(o), U(isFinite(o) && isFinite(i), `Invalid argument(s) to setTargetAtTime: ${JSON.stringify(e)}, ${JSON.stringify(r)}`), this._events.add({ constant: n, time: i, type: "setTargetAtTime", value: o }), this.log(this.units, "setTargetAtTime", e, i, n), this._param.setTargetAtTime(o, i, n), this;
    }
    setValueCurveAtTime(e, r, n, o = 1) {
      n = this.toSeconds(n), r = this.toSeconds(r);
      let i = this._fromType(e[0]) * o;
      this.setValueAtTime(this._toType(i), r);
      let s = n / (e.length - 1);
      for (let a = 1; a < e.length; a++) {
        let l = this._fromType(e[a]) * o;
        this.linearRampToValueAtTime(this._toType(l), r + a * s);
      }
      return this;
    }
    cancelScheduledValues(e) {
      let r = this.toSeconds(e);
      return U(isFinite(r), `Invalid argument to cancelScheduledValues: ${JSON.stringify(e)}`), this._events.cancel(r), this._param.cancelScheduledValues(r), this.log(this.units, "cancelScheduledValues", r), this;
    }
    cancelAndHoldAtTime(e) {
      let r = this.toSeconds(e), n = this._fromType(this.getValueAtTime(r));
      U(isFinite(r), `Invalid argument to cancelAndHoldAtTime: ${JSON.stringify(e)}`), this.log(this.units, "cancelAndHoldAtTime", r, "value=" + n);
      let o = this._events.get(r), i = this._events.getAfter(r);
      return o && qt(o.time, r) ? i ? (this._param.cancelScheduledValues(i.time), this._events.cancel(i.time)) : (this._param.cancelAndHoldAtTime(r), this._events.cancel(r + this.sampleTime)) : i && (this._param.cancelScheduledValues(i.time), this._events.cancel(i.time), i.type === "linearRampToValueAtTime" ? this.linearRampToValueAtTime(this._toType(n), r) : i.type === "exponentialRampToValueAtTime" && this.exponentialRampToValueAtTime(this._toType(n), r)), this._events.add({ time: r, type: "setValueAtTime", value: n }), this._param.setValueAtTime(n, r), this;
    }
    rampTo(e, r = 0.1, n) {
      return this.units === "frequency" || this.units === "bpm" || this.units === "decibels" ? this.exponentialRampTo(e, r, n) : this.linearRampTo(e, r, n), this;
    }
    apply(e) {
      let r = this.context.currentTime;
      e.setValueAtTime(this.getValueAtTime(r), r);
      let n = this._events.get(r);
      if (n && n.type === "setTargetAtTime") {
        let o = this._events.getAfter(n.time), i = o ? o.time : r + 2, s = (i - r) / 10;
        for (let a = r; a < i; a += s) e.linearRampToValueAtTime(this.getValueAtTime(a), a);
      }
      return this._events.forEachAfter(this.context.currentTime, (o) => {
        o.type === "cancelScheduledValues" ? e.cancelScheduledValues(o.time) : o.type === "setTargetAtTime" ? e.setTargetAtTime(o.value, o.time, o.constant) : e[o.type](o.value, o.time);
      }), this;
    }
    setParam(e) {
      U(this._swappable, "The Param must be assigned as 'swappable' in the constructor");
      let r = this.input;
      return r.disconnect(this._param), this.apply(e), this._param = e, r.connect(this._param), this;
    }
    dispose() {
      return super.dispose(), this._events.dispose(), this;
    }
    get defaultValue() {
      return this._toType(this._param.defaultValue);
    }
    _exponentialApproach(e, r, n, o, i) {
      return n + (r - n) * Math.exp(-(i - e) / o);
    }
    _linearInterpolate(e, r, n, o, i) {
      return r + (o - r) * ((i - e) / (n - e));
    }
    _exponentialInterpolate(e, r, n, o, i) {
      return r * Math.pow(o / r, (i - e) / (n - e));
    }
  };
  var L = class t extends nt {
    constructor() {
      super(...arguments), this._internalChannels = [];
    }
    get numberOfInputs() {
      return Q(this.input) ? Jr(this.input) || this.input instanceof ie ? 1 : this.input.numberOfInputs : 0;
    }
    get numberOfOutputs() {
      return Q(this.output) ? this.output.numberOfOutputs : 0;
    }
    _isAudioNode(e) {
      return Q(e) && (e instanceof t || Sn(e));
    }
    _getInternalNodes() {
      let e = this._internalChannels.slice(0);
      return this._isAudioNode(this.input) && e.push(this.input), this._isAudioNode(this.output) && this.input !== this.output && e.push(this.output), e;
    }
    _setChannelProperties(e) {
      this._getInternalNodes().forEach((n) => {
        n.channelCount = e.channelCount, n.channelCountMode = e.channelCountMode, n.channelInterpretation = e.channelInterpretation;
      });
    }
    _getChannelProperties() {
      let e = this._getInternalNodes();
      U(e.length > 0, "ToneAudioNode does not have any internal nodes");
      let r = e[0];
      return { channelCount: r.channelCount, channelCountMode: r.channelCountMode, channelInterpretation: r.channelInterpretation };
    }
    get channelCount() {
      return this._getChannelProperties().channelCount;
    }
    set channelCount(e) {
      let r = this._getChannelProperties();
      this._setChannelProperties(Object.assign(r, { channelCount: e }));
    }
    get channelCountMode() {
      return this._getChannelProperties().channelCountMode;
    }
    set channelCountMode(e) {
      let r = this._getChannelProperties();
      this._setChannelProperties(Object.assign(r, { channelCountMode: e }));
    }
    get channelInterpretation() {
      return this._getChannelProperties().channelInterpretation;
    }
    set channelInterpretation(e) {
      let r = this._getChannelProperties();
      this._setChannelProperties(Object.assign(r, { channelInterpretation: e }));
    }
    connect(e, r = 0, n = 0) {
      return Wt(this, e, r, n), this;
    }
    toDestination() {
      return this.connect(this.context.destination), this;
    }
    toMaster() {
      return vi("toMaster() has been renamed toDestination()"), this.toDestination();
    }
    disconnect(e, r = 0, n = 0) {
      return uA(this, e, r, n), this;
    }
    chain(...e) {
      return rn(this, ...e), this;
    }
    fan(...e) {
      return e.forEach((r) => this.connect(r)), this;
    }
    dispose() {
      return super.dispose(), Q(this.input) && (this.input instanceof t ? this.input.dispose() : Sn(this.input) && this.input.disconnect()), Q(this.output) && (this.output instanceof t ? this.output.dispose() : Sn(this.output) && this.output.disconnect()), this._internalChannels = [], this;
    }
  };
  function rn(...t) {
    let e = t.shift();
    t.reduce((r, n) => (r instanceof L ? r.connect(n) : Sn(r) && Wt(r, n), n), e);
  }
  function Wt(t, e, r = 0, n = 0) {
    for (U(Q(t), "Cannot connect from undefined node"), U(Q(e), "Cannot connect to undefined node"), (e instanceof L || Sn(e)) && U(e.numberOfInputs > 0, "Cannot connect to node with no inputs"), U(t.numberOfOutputs > 0, "Cannot connect from node with no outputs"); e instanceof L || e instanceof ie; ) Q(e.input) && (e = e.input);
    for (; t instanceof L; ) Q(t.output) && (t = t.output);
    Jr(e) ? t.connect(e, r) : t.connect(e, r, n);
  }
  function uA(t, e, r = 0, n = 0) {
    if (Q(e)) for (; e instanceof L; ) e = e.input;
    for (; !Sn(t); ) Q(t.output) && (t = t.output);
    Jr(e) ? t.disconnect(e, r) : Sn(e) ? t.disconnect(e, r, n) : t.disconnect();
  }
  var X = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["gain", "units"]);
      super(e), this.name = "Gain", this._gainNode = this.context.createGain(), this.input = this._gainNode, this.output = this._gainNode, this.gain = new ie({ context: this.context, convert: e.convert, param: this._gainNode.gain, units: e.units, value: e.gain, minValue: e.minValue, maxValue: e.maxValue }), z(this, "gain");
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { convert: true, gain: 1, units: "gain" });
    }
    dispose() {
      return super.dispose(), this._gainNode.disconnect(), this.gain.dispose(), this;
    }
  };
  var nn = class extends L {
    constructor(e) {
      super(e), this.onended = Z, this._startTime = -1, this._stopTime = -1, this._timeout = -1, this.output = new X({ context: this.context, gain: 0 }), this._gainNode = this.output, this.getStateAtTime = function(r) {
        let n = this.toSeconds(r);
        return this._startTime !== -1 && n >= this._startTime && (this._stopTime === -1 || n <= this._stopTime) ? "started" : "stopped";
      }, this._fadeIn = e.fadeIn, this._fadeOut = e.fadeOut, this._curve = e.curve, this.onended = e.onended;
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { curve: "linear", fadeIn: 0, fadeOut: 0, onended: Z });
    }
    _startGain(e, r = 1) {
      U(this._startTime === -1, "Source cannot be started more than once");
      let n = this.toSeconds(this._fadeIn);
      return this._startTime = e + n, this._startTime = Math.max(this._startTime, this.context.currentTime), n > 0 ? (this._gainNode.gain.setValueAtTime(0, e), this._curve === "linear" ? this._gainNode.gain.linearRampToValueAtTime(r, e + n) : this._gainNode.gain.exponentialApproachValueAtTime(r, e, n)) : this._gainNode.gain.setValueAtTime(r, e), this;
    }
    stop(e) {
      return this.log("stop", e), this._stopGain(this.toSeconds(e)), this;
    }
    _stopGain(e) {
      U(this._startTime !== -1, "'start' must be called before 'stop'"), this.cancelStop();
      let r = this.toSeconds(this._fadeOut);
      return this._stopTime = this.toSeconds(e) + r, this._stopTime = Math.max(this._stopTime, this.now()), r > 0 ? this._curve === "linear" ? this._gainNode.gain.linearRampTo(0, r, e) : this._gainNode.gain.targetRampTo(0, r, e) : (this._gainNode.gain.cancelAndHoldAtTime(e), this._gainNode.gain.setValueAtTime(0, e)), this.context.clearTimeout(this._timeout), this._timeout = this.context.setTimeout(() => {
        let n = this._curve === "exponential" ? r * 2 : 0;
        this._stopSource(this.now() + n), this._onended();
      }, this._stopTime - this.context.currentTime), this;
    }
    _onended() {
      if (this.onended !== Z && (this.onended(this), this.onended = Z, !this.context.isOffline)) {
        let e = () => this.dispose();
        typeof requestIdleCallback < "u" ? requestIdleCallback(e) : setTimeout(e, 10);
      }
    }
    get state() {
      return this.getStateAtTime(this.now());
    }
    cancelStop() {
      return this.log("cancelStop"), U(this._startTime !== -1, "Source is not started"), this._gainNode.gain.cancelScheduledValues(this._startTime + this.sampleTime), this.context.clearTimeout(this._timeout), this._stopTime = -1, this;
    }
    dispose() {
      return super.dispose(), this._gainNode.dispose(), this.onended = Z, this;
    }
  };
  var ql = class t extends nn {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["offset"]);
      super(e), this.name = "ToneConstantSource", this._source = this.context.createConstantSource(), Wt(this._source, this._gainNode), this.offset = new ie({ context: this.context, convert: e.convert, param: this._source.offset, units: e.units, value: e.offset, minValue: e.minValue, maxValue: e.maxValue });
    }
    static getDefaults() {
      return Object.assign(nn.getDefaults(), { convert: true, offset: 1, units: "number" });
    }
    start(e) {
      let r = this.toSeconds(e);
      return this.log("start", r), this._startGain(r), this._source.start(r), this;
    }
    _stopSource(e) {
      this._source.stop(e);
    }
    dispose() {
      return super.dispose(), this.state === "started" && this.stop(), this._source.disconnect(), this.offset.dispose(), this;
    }
  };
  var ee = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["value", "units"]);
      super(e), this.name = "Signal", this.override = true, this.output = this._constantSource = new ql({ context: this.context, convert: e.convert, offset: e.value, units: e.units, minValue: e.minValue, maxValue: e.maxValue }), this._constantSource.start(0), this.input = this._param = this._constantSource.offset;
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { convert: true, units: "number", value: 0 });
    }
    connect(e, r = 0, n = 0) {
      return $s(this, e, r, n), this;
    }
    dispose() {
      return super.dispose(), this._param.dispose(), this._constantSource.dispose(), this;
    }
    setValueAtTime(e, r) {
      return this._param.setValueAtTime(e, r), this;
    }
    getValueAtTime(e) {
      return this._param.getValueAtTime(e);
    }
    setRampPoint(e) {
      return this._param.setRampPoint(e), this;
    }
    linearRampToValueAtTime(e, r) {
      return this._param.linearRampToValueAtTime(e, r), this;
    }
    exponentialRampToValueAtTime(e, r) {
      return this._param.exponentialRampToValueAtTime(e, r), this;
    }
    exponentialRampTo(e, r, n) {
      return this._param.exponentialRampTo(e, r, n), this;
    }
    linearRampTo(e, r, n) {
      return this._param.linearRampTo(e, r, n), this;
    }
    targetRampTo(e, r, n) {
      return this._param.targetRampTo(e, r, n), this;
    }
    exponentialApproachValueAtTime(e, r, n) {
      return this._param.exponentialApproachValueAtTime(e, r, n), this;
    }
    setTargetAtTime(e, r, n) {
      return this._param.setTargetAtTime(e, r, n), this;
    }
    setValueCurveAtTime(e, r, n, o) {
      return this._param.setValueCurveAtTime(e, r, n, o), this;
    }
    cancelScheduledValues(e) {
      return this._param.cancelScheduledValues(e), this;
    }
    cancelAndHoldAtTime(e) {
      return this._param.cancelAndHoldAtTime(e), this;
    }
    rampTo(e, r, n) {
      return this._param.rampTo(e, r, n), this;
    }
    get value() {
      return this._param.value;
    }
    set value(e) {
      this._param.value = e;
    }
    get convert() {
      return this._param.convert;
    }
    set convert(e) {
      this._param.convert = e;
    }
    get units() {
      return this._param.units;
    }
    get overridden() {
      return this._param.overridden;
    }
    set overridden(e) {
      this._param.overridden = e;
    }
    get maxValue() {
      return this._param.maxValue;
    }
    get minValue() {
      return this._param.minValue;
    }
    apply(e) {
      return this._param.apply(e), this;
    }
  };
  function $s(t, e, r, n) {
    (e instanceof ie || Jr(e) || e instanceof ee && e.override) && (e.cancelScheduledValues(0), e.setValueAtTime(0, 0), e instanceof ee && (e.overridden = true)), Wt(t, e, r, n);
  }
  var Rp = class t extends ie {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["value"]);
      super(e), this.name = "TickParam", this._events = new rt(1 / 0), this._multiplier = 1, this._multiplier = e.multiplier, this._events.cancel(0), this._events.add({ ticks: 0, time: 0, type: "setValueAtTime", value: this._fromType(e.value) }), this.setValueAtTime(e.value, 0);
    }
    static getDefaults() {
      return Object.assign(ie.getDefaults(), { multiplier: 1, units: "hertz", value: 1 });
    }
    setTargetAtTime(e, r, n) {
      r = this.toSeconds(r), this.setRampPoint(r);
      let o = this._fromType(e), i = this._events.get(r), s = Math.round(Math.max(1 / n, 1));
      for (let a = 0; a <= s; a++) {
        let l = n * a + r, u = this._exponentialApproach(i.time, i.value, o, n, l);
        this.linearRampToValueAtTime(this._toType(u), l);
      }
      return this;
    }
    setValueAtTime(e, r) {
      let n = this.toSeconds(r);
      super.setValueAtTime(e, r);
      let o = this._events.get(n), i = this._events.previousEvent(o), s = this._getTicksUntilEvent(i, n);
      return o.ticks = Math.max(s, 0), this;
    }
    linearRampToValueAtTime(e, r) {
      let n = this.toSeconds(r);
      super.linearRampToValueAtTime(e, r);
      let o = this._events.get(n), i = this._events.previousEvent(o), s = this._getTicksUntilEvent(i, n);
      return o.ticks = Math.max(s, 0), this;
    }
    exponentialRampToValueAtTime(e, r) {
      r = this.toSeconds(r);
      let n = this._fromType(e), o = this._events.get(r), i = Math.round(Math.max((r - o.time) * 10, 1)), s = (r - o.time) / i;
      for (let a = 0; a <= i; a++) {
        let l = s * a + o.time, u = this._exponentialInterpolate(o.time, o.value, r, n, l);
        this.linearRampToValueAtTime(this._toType(u), l);
      }
      return this;
    }
    _getTicksUntilEvent(e, r) {
      if (e === null) e = { ticks: 0, time: 0, type: "setValueAtTime", value: 0 };
      else if (Ke(e.ticks)) {
        let s = this._events.previousEvent(e);
        e.ticks = this._getTicksUntilEvent(s, e.time);
      }
      let n = this._fromType(this.getValueAtTime(e.time)), o = this._fromType(this.getValueAtTime(r)), i = this._events.get(r);
      return i && i.time === r && i.type === "setValueAtTime" && (o = this._fromType(this.getValueAtTime(r - this.sampleTime))), 0.5 * (r - e.time) * (n + o) + e.ticks;
    }
    getTicksAtTime(e) {
      let r = this.toSeconds(e), n = this._events.get(r);
      return Math.max(this._getTicksUntilEvent(n, r), 0);
    }
    getDurationOfTicks(e, r) {
      let n = this.toSeconds(r), o = this.getTicksAtTime(r);
      return this.getTimeOfTick(o + e) - n;
    }
    getTimeOfTick(e) {
      let r = this._events.get(e, "ticks"), n = this._events.getAfter(e, "ticks");
      if (r && r.ticks === e) return r.time;
      if (r && n && n.type === "linearRampToValueAtTime" && r.value !== n.value) {
        let o = this._fromType(this.getValueAtTime(r.time)), s = (this._fromType(this.getValueAtTime(n.time)) - o) / (n.time - r.time), a = Math.sqrt(Math.pow(o, 2) - 2 * s * (r.ticks - e)), l = (-o + a) / s, u = (-o - a) / s;
        return (l > 0 ? l : u) + r.time;
      } else return r ? r.value === 0 ? 1 / 0 : r.time + (e - r.ticks) / r.value : e / this._initialValue;
    }
    ticksToTime(e, r) {
      return this.getDurationOfTicks(e, r);
    }
    timeToTicks(e, r) {
      let n = this.toSeconds(r), o = this.toSeconds(e), i = this.getTicksAtTime(n);
      return this.getTicksAtTime(n + o) - i;
    }
    _fromType(e) {
      return this.units === "bpm" && this.multiplier ? 1 / (60 / e / this.multiplier) : super._fromType(e);
    }
    _toType(e) {
      return this.units === "bpm" && this.multiplier ? e / this.multiplier * 60 : super._toType(e);
    }
    get multiplier() {
      return this._multiplier;
    }
    set multiplier(e) {
      let r = this.value;
      this._multiplier = e, this.cancelScheduledValues(0), this.setValueAtTime(r, 0);
    }
  };
  var Vp = class t extends ee {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["value"]);
      super(e), this.name = "TickSignal", this.input = this._param = new Rp({ context: this.context, convert: e.convert, multiplier: e.multiplier, param: this._constantSource.offset, units: e.units, value: e.value });
    }
    static getDefaults() {
      return Object.assign(ee.getDefaults(), { multiplier: 1, units: "hertz", value: 1 });
    }
    ticksToTime(e, r) {
      return this._param.ticksToTime(e, r);
    }
    timeToTicks(e, r) {
      return this._param.timeToTicks(e, r);
    }
    getTimeOfTick(e) {
      return this._param.getTimeOfTick(e);
    }
    getDurationOfTicks(e, r) {
      return this._param.getDurationOfTicks(e, r);
    }
    getTicksAtTime(e) {
      return this._param.getTicksAtTime(e);
    }
    get multiplier() {
      return this._param.multiplier;
    }
    set multiplier(e) {
      this._param.multiplier = e;
    }
    dispose() {
      return super.dispose(), this._param.dispose(), this;
    }
  };
  var Fp = class t extends nt {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency"]);
      super(e), this.name = "TickSource", this._state = new An(), this._tickOffset = new rt(), this._ticksAtTime = new rt(), this._secondsAtTime = new rt(), this.frequency = new Vp({ context: this.context, units: e.units, value: e.frequency }), z(this, "frequency"), this._state.setStateAtTime("stopped", 0), this.setTicksAtTime(0, 0);
    }
    static getDefaults() {
      return Object.assign({ frequency: 1, units: "hertz" }, nt.getDefaults());
    }
    get state() {
      return this.getStateAtTime(this.now());
    }
    start(e, r) {
      let n = this.toSeconds(e);
      return this._state.getValueAtTime(n) !== "started" && (this._state.setStateAtTime("started", n), Q(r) && this.setTicksAtTime(r, n), this._ticksAtTime.cancel(n), this._secondsAtTime.cancel(n)), this;
    }
    stop(e) {
      let r = this.toSeconds(e);
      if (this._state.getValueAtTime(r) === "stopped") {
        let n = this._state.get(r);
        n && n.time > 0 && (this._tickOffset.cancel(n.time), this._state.cancel(n.time));
      }
      return this._state.cancel(r), this._state.setStateAtTime("stopped", r), this.setTicksAtTime(0, r), this._ticksAtTime.cancel(r), this._secondsAtTime.cancel(r), this;
    }
    pause(e) {
      let r = this.toSeconds(e);
      return this._state.getValueAtTime(r) === "started" && (this._state.setStateAtTime("paused", r), this._ticksAtTime.cancel(r), this._secondsAtTime.cancel(r)), this;
    }
    cancel(e) {
      return e = this.toSeconds(e), this._state.cancel(e), this._tickOffset.cancel(e), this._ticksAtTime.cancel(e), this._secondsAtTime.cancel(e), this;
    }
    getTicksAtTime(e) {
      let r = this.toSeconds(e), n = this._state.getLastState("stopped", r), o = this._ticksAtTime.get(r), i = { state: "paused", time: r };
      this._state.add(i);
      let s = o || n, a = o ? o.ticks : 0, l = null;
      return this._state.forEachBetween(s.time, r + this.sampleTime, (u) => {
        let c = s.time, p = this._tickOffset.get(u.time);
        p && p.time >= s.time && (a = p.ticks, c = p.time), s.state === "started" && u.state !== "started" && (a += this.frequency.getTicksAtTime(u.time) - this.frequency.getTicksAtTime(c), u.time !== i.time && (l = { state: u.state, time: u.time, ticks: a })), s = u;
      }), this._state.remove(i), l && this._ticksAtTime.add(l), a;
    }
    get ticks() {
      return this.getTicksAtTime(this.now());
    }
    set ticks(e) {
      this.setTicksAtTime(e, this.now());
    }
    get seconds() {
      return this.getSecondsAtTime(this.now());
    }
    set seconds(e) {
      let r = this.now(), n = this.frequency.timeToTicks(e, r);
      this.setTicksAtTime(n, r);
    }
    getSecondsAtTime(e) {
      e = this.toSeconds(e);
      let r = this._state.getLastState("stopped", e), n = { state: "paused", time: e };
      this._state.add(n);
      let o = this._secondsAtTime.get(e), i = o || r, s = o ? o.seconds : 0, a = null;
      return this._state.forEachBetween(i.time, e + this.sampleTime, (l) => {
        let u = i.time, c = this._tickOffset.get(l.time);
        c && c.time >= i.time && (s = c.seconds, u = c.time), i.state === "started" && l.state !== "started" && (s += l.time - u, l.time !== n.time && (a = { state: l.state, time: l.time, seconds: s })), i = l;
      }), this._state.remove(n), a && this._secondsAtTime.add(a), s;
    }
    setTicksAtTime(e, r) {
      return r = this.toSeconds(r), this._tickOffset.cancel(r), this._tickOffset.add({ seconds: this.frequency.getDurationOfTicks(e, r), ticks: e, time: r }), this._ticksAtTime.cancel(r), this._secondsAtTime.cancel(r), this;
    }
    getStateAtTime(e) {
      return e = this.toSeconds(e), this._state.getValueAtTime(e);
    }
    getTimeOfTick(e, r = this.now()) {
      let n = this._tickOffset.get(r), o = this._state.get(r), i = Math.max(n.time, o.time), s = this.frequency.getTicksAtTime(i) + e - n.ticks;
      return this.frequency.getTimeOfTick(s);
    }
    forEachTickBetween(e, r, n) {
      let o = this._state.get(e);
      this._state.forEachBetween(e, r, (s) => {
        o && o.state === "started" && s.state !== "started" && this.forEachTickBetween(Math.max(o.time, e), s.time - this.sampleTime, n), o = s;
      });
      let i = null;
      if (o && o.state === "started") {
        let s = Math.max(o.time, e), a = this.frequency.getTicksAtTime(s), l = this.frequency.getTicksAtTime(o.time), u = a - l, c = Math.ceil(u) - u;
        c = qt(c, 1) ? 0 : c;
        let p = this.frequency.getTimeOfTick(a + c);
        for (; p < r; ) {
          try {
            n(p, Math.round(this.getTicksAtTime(p)));
          } catch (h) {
            i = h;
            break;
          }
          p += this.frequency.getDurationOfTicks(1, p);
        }
      }
      if (i) throw i;
      return this;
    }
    dispose() {
      return super.dispose(), this._state.dispose(), this._tickOffset.dispose(), this._ticksAtTime.dispose(), this._secondsAtTime.dispose(), this.frequency.dispose(), this;
    }
  };
  var Xs = class t extends nt {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["callback", "frequency"]);
      super(e), this.name = "Clock", this.callback = Z, this._lastUpdate = 0, this._state = new An("stopped"), this._boundLoop = this._loop.bind(this), this.callback = e.callback, this._tickSource = new Fp({ context: this.context, frequency: e.frequency, units: e.units }), this._lastUpdate = 0, this.frequency = this._tickSource.frequency, z(this, "frequency"), this._state.setStateAtTime("stopped", 0), this.context.on("tick", this._boundLoop);
    }
    static getDefaults() {
      return Object.assign(nt.getDefaults(), { callback: Z, frequency: 1, units: "hertz" });
    }
    get state() {
      return this._state.getValueAtTime(this.now());
    }
    start(e, r) {
      Np(this.context);
      let n = this.toSeconds(e);
      return this.log("start", n), this._state.getValueAtTime(n) !== "started" && (this._state.setStateAtTime("started", n), this._tickSource.start(n, r), n < this._lastUpdate && this.emit("start", n, r)), this;
    }
    stop(e) {
      let r = this.toSeconds(e);
      return this.log("stop", r), this._state.cancel(r), this._state.setStateAtTime("stopped", r), this._tickSource.stop(r), r < this._lastUpdate && this.emit("stop", r), this;
    }
    pause(e) {
      let r = this.toSeconds(e);
      return this._state.getValueAtTime(r) === "started" && (this._state.setStateAtTime("paused", r), this._tickSource.pause(r), r < this._lastUpdate && this.emit("pause", r)), this;
    }
    get ticks() {
      return Math.ceil(this.getTicksAtTime(this.now()));
    }
    set ticks(e) {
      this._tickSource.ticks = e;
    }
    get seconds() {
      return this._tickSource.seconds;
    }
    set seconds(e) {
      this._tickSource.seconds = e;
    }
    getSecondsAtTime(e) {
      return this._tickSource.getSecondsAtTime(e);
    }
    setTicksAtTime(e, r) {
      return this._tickSource.setTicksAtTime(e, r), this;
    }
    getTimeOfTick(e, r = this.now()) {
      return this._tickSource.getTimeOfTick(e, r);
    }
    getTicksAtTime(e) {
      return this._tickSource.getTicksAtTime(e);
    }
    nextTickTime(e, r) {
      let n = this.toSeconds(r), o = this.getTicksAtTime(n);
      return this._tickSource.getTimeOfTick(o + e, n);
    }
    _loop() {
      let e = this._lastUpdate, r = this.now();
      this._lastUpdate = r, this.log("loop", e, r), e !== r && (this._state.forEachBetween(e, r, (n) => {
        switch (n.state) {
          case "started":
            let o = this._tickSource.getTicksAtTime(n.time);
            this.emit("start", n.time, o);
            break;
          case "stopped":
            n.time !== 0 && this.emit("stop", n.time);
            break;
          case "paused":
            this.emit("pause", n.time);
            break;
        }
      }), this._tickSource.forEachTickBetween(e, r, (n, o) => {
        this.callback(n, o);
      }));
    }
    getStateAtTime(e) {
      let r = this.toSeconds(e);
      return this._state.getValueAtTime(r);
    }
    dispose() {
      return super.dispose(), this.context.off("tick", this._boundLoop), this._tickSource.dispose(), this._state.dispose(), this;
    }
  };
  Fo.mixin(Xs);
  var Mr = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["volume"]);
      super(e), this.name = "Volume", this.input = this.output = new X({ context: this.context, gain: e.volume, units: "decibels" }), this.volume = this.output.gain, z(this, "volume"), this._unmutedVolume = e.volume, this.mute = e.mute;
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { mute: false, volume: 0 });
    }
    get mute() {
      return this.volume.value === -1 / 0;
    }
    set mute(e) {
      !this.mute && e ? (this._unmutedVolume = this.volume.value, this.volume.value = -1 / 0) : this.mute && !e && (this.volume.value = this._unmutedVolume);
    }
    dispose() {
      return super.dispose(), this.input.dispose(), this.volume.dispose(), this;
    }
  };
  var Og = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments);
      super(e), this.name = "Destination", this.input = new Mr({ context: this.context }), this.output = new X({ context: this.context }), this.volume = this.input.volume, rn(this.input, this.output, this.context.rawContext.destination), this.mute = e.mute, this._internalChannels = [this.input, this.context.rawContext.destination, this.output];
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { mute: false, volume: 0 });
    }
    get mute() {
      return this.input.mute;
    }
    set mute(e) {
      this.input.mute = e;
    }
    chain(...e) {
      return this.input.disconnect(), e.unshift(this.input), e.push(this.output), rn(...e), this;
    }
    get maxChannelCount() {
      return this.context.rawContext.destination.maxChannelCount;
    }
    dispose() {
      return super.dispose(), this.volume.dispose(), this;
    }
  };
  Ro((t) => {
    t.destination = new Og({ context: t });
  });
  Vo((t) => {
    t.destination.dispose();
  });
  var Dg = class extends L {
    constructor() {
      super(...arguments), this.name = "Listener", this.positionX = new ie({ context: this.context, param: this.context.rawContext.listener.positionX }), this.positionY = new ie({ context: this.context, param: this.context.rawContext.listener.positionY }), this.positionZ = new ie({ context: this.context, param: this.context.rawContext.listener.positionZ }), this.forwardX = new ie({ context: this.context, param: this.context.rawContext.listener.forwardX }), this.forwardY = new ie({ context: this.context, param: this.context.rawContext.listener.forwardY }), this.forwardZ = new ie({ context: this.context, param: this.context.rawContext.listener.forwardZ }), this.upX = new ie({ context: this.context, param: this.context.rawContext.listener.upX }), this.upY = new ie({ context: this.context, param: this.context.rawContext.listener.upY }), this.upZ = new ie({ context: this.context, param: this.context.rawContext.listener.upZ });
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { positionX: 0, positionY: 0, positionZ: 0, forwardX: 0, forwardY: 0, forwardZ: -1, upX: 0, upY: 1, upZ: 0 });
    }
    dispose() {
      return super.dispose(), this.positionX.dispose(), this.positionY.dispose(), this.positionZ.dispose(), this.forwardX.dispose(), this.forwardY.dispose(), this.forwardZ.dispose(), this.upX.dispose(), this.upY.dispose(), this.upZ.dispose(), this;
    }
  };
  Ro((t) => {
    t.listener = new Dg({ context: t });
  });
  Vo((t) => {
    t.listener.dispose();
  });
  var Ys = class t extends pt {
    constructor() {
      super(), this.name = "ToneAudioBuffers", this._buffers = /* @__PURE__ */ new Map(), this._loadingCount = 0;
      let e = b(t.getDefaults(), arguments, ["urls", "onload", "baseUrl"], "urls");
      this.baseUrl = e.baseUrl, Object.keys(e.urls).forEach((r) => {
        this._loadingCount++;
        let n = e.urls[r];
        this.add(r, n, this._bufferLoaded.bind(this, e.onload), e.onerror);
      });
    }
    static getDefaults() {
      return { baseUrl: "", onerror: Z, onload: Z, urls: {} };
    }
    has(e) {
      return this._buffers.has(e.toString());
    }
    get(e) {
      return U(this.has(e), `ToneAudioBuffers has no buffer named: ${e}`), this._buffers.get(e.toString());
    }
    _bufferLoaded(e) {
      this._loadingCount--, this._loadingCount === 0 && e && e();
    }
    get loaded() {
      return Array.from(this._buffers).every(([e, r]) => r.loaded);
    }
    add(e, r, n = Z, o = Z) {
      return Dt(r) ? (this.baseUrl && r.trim().substring(0, 11).toLowerCase() === "data:audio/" && (this.baseUrl = ""), this._buffers.set(e.toString(), new ht(this.baseUrl + r, n, o))) : this._buffers.set(e.toString(), new ht(r, n, o)), this;
    }
    dispose() {
      return super.dispose(), this._buffers.forEach((e) => e.dispose()), this._buffers.clear(), this;
    }
  };
  var zl = class t extends zt {
    constructor() {
      super(...arguments), this.name = "MidiClass", this.defaultUnits = "midi";
    }
    _frequencyToUnits(e) {
      return tn(super._frequencyToUnits(e));
    }
    _ticksToUnits(e) {
      return tn(super._ticksToUnits(e));
    }
    _beatsToUnits(e) {
      return tn(super._beatsToUnits(e));
    }
    _secondsToUnits(e) {
      return tn(super._secondsToUnits(e));
    }
    toMidi() {
      return this.valueOf();
    }
    toFrequency() {
      return jl(this.toMidi());
    }
    transpose(e) {
      return new t(this.context, this.toMidi() + e);
    }
  };
  var hr = class extends Dr {
    constructor() {
      super(...arguments), this.name = "Ticks", this.defaultUnits = "i";
    }
    _now() {
      return this.context.transport.ticks;
    }
    _beatsToUnits(e) {
      return this._getPPQ() * e;
    }
    _secondsToUnits(e) {
      return Math.floor(e / (60 / this._getBpm()) * this._getPPQ());
    }
    _ticksToUnits(e) {
      return e;
    }
    toTicks() {
      return this.valueOf();
    }
    toSeconds() {
      return this.valueOf() / this._getPPQ() * (60 / this._getBpm());
    }
  };
  var Mg = class extends nt {
    constructor() {
      super(...arguments), this.name = "Draw", this.expiration = 0.25, this.anticipation = 8e-3, this._events = new rt(), this._boundDrawLoop = this._drawLoop.bind(this), this._animationFrame = -1;
    }
    schedule(e, r) {
      return this._events.add({ callback: e, time: this.toSeconds(r) }), this._events.length === 1 && (this._animationFrame = requestAnimationFrame(this._boundDrawLoop)), this;
    }
    cancel(e) {
      return this._events.cancel(this.toSeconds(e)), this;
    }
    _drawLoop() {
      let e = this.context.currentTime;
      this._events.forEachBefore(e + this.anticipation, (r) => {
        e - r.time <= this.expiration && r.callback(), this._events.remove(r);
      }), this._events.length > 0 && (this._animationFrame = requestAnimationFrame(this._boundDrawLoop));
    }
    dispose() {
      return super.dispose(), this._events.dispose(), cancelAnimationFrame(this._animationFrame), this;
    }
  };
  Ro((t) => {
    t.draw = new Mg({ context: t });
  });
  Vo((t) => {
    t.draw.dispose();
  });
  var Ip = class extends pt {
    constructor() {
      super(...arguments), this.name = "IntervalTimeline", this._root = null, this._length = 0;
    }
    add(e) {
      U(Q(e.time), "Events must have a time property"), U(Q(e.duration), "Events must have a duration parameter"), e.time = e.time.valueOf();
      let r = new Pg(e.time, e.time + e.duration, e);
      for (this._root === null ? this._root = r : this._root.insert(r), this._length++; r !== null; ) r.updateHeight(), r.updateMax(), this._rebalance(r), r = r.parent;
      return this;
    }
    remove(e) {
      if (this._root !== null) {
        let r = [];
        this._root.search(e.time, r);
        for (let n of r) if (n.event === e) {
          this._removeNode(n), this._length--;
          break;
        }
      }
      return this;
    }
    get length() {
      return this._length;
    }
    cancel(e) {
      return this.forEachFrom(e, (r) => this.remove(r)), this;
    }
    _setRoot(e) {
      this._root = e, this._root !== null && (this._root.parent = null);
    }
    _replaceNodeInParent(e, r) {
      e.parent !== null ? (e.isLeftChild() ? e.parent.left = r : e.parent.right = r, this._rebalance(e.parent)) : this._setRoot(r);
    }
    _removeNode(e) {
      if (e.left === null && e.right === null) this._replaceNodeInParent(e, null);
      else if (e.right === null) this._replaceNodeInParent(e, e.left);
      else if (e.left === null) this._replaceNodeInParent(e, e.right);
      else {
        let r = e.getBalance(), n, o = null;
        if (r > 0) if (e.left.right === null) n = e.left, n.right = e.right, o = n;
        else {
          for (n = e.left.right; n.right !== null; ) n = n.right;
          n.parent && (n.parent.right = n.left, o = n.parent, n.left = e.left, n.right = e.right);
        }
        else if (e.right.left === null) n = e.right, n.left = e.left, o = n;
        else {
          for (n = e.right.left; n.left !== null; ) n = n.left;
          n.parent && (n.parent.left = n.right, o = n.parent, n.left = e.left, n.right = e.right);
        }
        e.parent !== null ? e.isLeftChild() ? e.parent.left = n : e.parent.right = n : this._setRoot(n), o && this._rebalance(o);
      }
      e.dispose();
    }
    _rotateLeft(e) {
      let r = e.parent, n = e.isLeftChild(), o = e.right;
      o && (e.right = o.left, o.left = e), r !== null ? n ? r.left = o : r.right = o : this._setRoot(o);
    }
    _rotateRight(e) {
      let r = e.parent, n = e.isLeftChild(), o = e.left;
      o && (e.left = o.right, o.right = e), r !== null ? n ? r.left = o : r.right = o : this._setRoot(o);
    }
    _rebalance(e) {
      let r = e.getBalance();
      r > 1 && e.left ? e.left.getBalance() < 0 ? this._rotateLeft(e.left) : this._rotateRight(e) : r < -1 && e.right && (e.right.getBalance() > 0 ? this._rotateRight(e.right) : this._rotateLeft(e));
    }
    get(e) {
      if (this._root !== null) {
        let r = [];
        if (this._root.search(e, r), r.length > 0) {
          let n = r[0];
          for (let o = 1; o < r.length; o++) r[o].low > n.low && (n = r[o]);
          return n.event;
        }
      }
      return null;
    }
    forEach(e) {
      if (this._root !== null) {
        let r = [];
        this._root.traverse((n) => r.push(n)), r.forEach((n) => {
          n.event && e(n.event);
        });
      }
      return this;
    }
    forEachAtTime(e, r) {
      if (this._root !== null) {
        let n = [];
        this._root.search(e, n), n.forEach((o) => {
          o.event && r(o.event);
        });
      }
      return this;
    }
    forEachFrom(e, r) {
      if (this._root !== null) {
        let n = [];
        this._root.searchAfter(e, n), n.forEach((o) => {
          o.event && r(o.event);
        });
      }
      return this;
    }
    dispose() {
      return super.dispose(), this._root !== null && this._root.traverse((e) => e.dispose()), this._root = null, this;
    }
  }, Pg = class {
    constructor(e, r, n) {
      this._left = null, this._right = null, this.parent = null, this.height = 0, this.event = n, this.low = e, this.high = r, this.max = this.high;
    }
    insert(e) {
      e.low <= this.low ? this.left === null ? this.left = e : this.left.insert(e) : this.right === null ? this.right = e : this.right.insert(e);
    }
    search(e, r) {
      e > this.max || (this.left !== null && this.left.search(e, r), this.low <= e && this.high > e && r.push(this), !(this.low > e) && this.right !== null && this.right.search(e, r));
    }
    searchAfter(e, r) {
      this.low >= e && (r.push(this), this.left !== null && this.left.searchAfter(e, r)), this.right !== null && this.right.searchAfter(e, r);
    }
    traverse(e) {
      e(this), this.left !== null && this.left.traverse(e), this.right !== null && this.right.traverse(e);
    }
    updateHeight() {
      this.left !== null && this.right !== null ? this.height = Math.max(this.left.height, this.right.height) + 1 : this.right !== null ? this.height = this.right.height + 1 : this.left !== null ? this.height = this.left.height + 1 : this.height = 0;
    }
    updateMax() {
      this.max = this.high, this.left !== null && (this.max = Math.max(this.max, this.left.max)), this.right !== null && (this.max = Math.max(this.max, this.right.max));
    }
    getBalance() {
      let e = 0;
      return this.left !== null && this.right !== null ? e = this.left.height - this.right.height : this.left !== null ? e = this.left.height + 1 : this.right !== null && (e = -(this.right.height + 1)), e;
    }
    isLeftChild() {
      return this.parent !== null && this.parent.left === this;
    }
    get left() {
      return this._left;
    }
    set left(e) {
      this._left = e, e !== null && (e.parent = this), this.updateHeight(), this.updateMax();
    }
    get right() {
      return this._right;
    }
    set right(e) {
      this._right = e, e !== null && (e.parent = this), this.updateHeight(), this.updateMax();
    }
    dispose() {
      this.parent = null, this._left = null, this._right = null, this.event = null;
    }
  };
  var Lp = class extends pt {
    constructor(e) {
      super(), this.name = "TimelineValue", this._timeline = new rt({ memory: 10 }), this._initialValue = e;
    }
    set(e, r) {
      return this._timeline.add({ value: e, time: r }), this;
    }
    get(e) {
      let r = this._timeline.get(e);
      return r ? r.value : this._initialValue;
    }
  };
  var Ut = class t extends L {
    constructor() {
      super(b(t.getDefaults(), arguments, ["context"]));
    }
    connect(e, r = 0, n = 0) {
      return $s(this, e, r, n), this;
    }
  };
  var fr = class t extends Ut {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["mapping", "length"]);
      super(e), this.name = "WaveShaper", this._shaper = this.context.createWaveShaper(), this.input = this._shaper, this.output = this._shaper, Fe(e.mapping) || e.mapping instanceof Float32Array ? this.curve = Float32Array.from(e.mapping) : W1(e.mapping) && this.setMap(e.mapping, e.length);
    }
    static getDefaults() {
      return Object.assign(ee.getDefaults(), { length: 1024 });
    }
    setMap(e, r = 1024) {
      let n = new Float32Array(r);
      for (let o = 0, i = r; o < i; o++) {
        let s = o / (i - 1) * 2 - 1;
        n[o] = e(s, o);
      }
      return this.curve = n, this;
    }
    get curve() {
      return this._shaper.curve;
    }
    set curve(e) {
      this._shaper.curve = e;
    }
    get oversample() {
      return this._shaper.oversample;
    }
    set oversample(e) {
      let r = ["none", "2x", "4x"].some((n) => n.includes(e));
      U(r, "oversampling must be either 'none', '2x', or '4x'"), this._shaper.oversample = e;
    }
    dispose() {
      return super.dispose(), this._shaper.disconnect(), this;
    }
  };
  var Qs = class t extends Ut {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["value"]);
      super(e), this.name = "Pow", this._exponentScaler = this.input = this.output = new fr({ context: this.context, mapping: this._expFunc(e.value), length: 8192 }), this._exponent = e.value;
    }
    static getDefaults() {
      return Object.assign(Ut.getDefaults(), { value: 1 });
    }
    _expFunc(e) {
      return (r) => Math.pow(Math.abs(r), e);
    }
    get value() {
      return this._exponent;
    }
    set value(e) {
      this._exponent = e, this._exponentScaler.setMap(this._expFunc(this._exponent));
    }
    dispose() {
      return super.dispose(), this._exponentScaler.dispose(), this;
    }
  };
  var Hn = class t {
    constructor(e, r) {
      this.id = t._eventId++, this._remainderTime = 0;
      let n = Object.assign(t.getDefaults(), r);
      this.transport = e, this.callback = n.callback, this._once = n.once, this.time = Math.floor(n.time), this._remainderTime = n.time - this.time;
    }
    static getDefaults() {
      return { callback: Z, once: false, time: 0 };
    }
    get floatTime() {
      return this.time + this._remainderTime;
    }
    invoke(e) {
      if (this.callback) {
        let r = this.transport.bpm.getDurationOfTicks(1, e);
        this.callback(e + this._remainderTime * r), this._once && this.transport.clear(this.id);
      }
    }
    dispose() {
      return this.callback = void 0, this;
    }
  };
  Hn._eventId = 0;
  var Bp = class t extends Hn {
    constructor(e, r) {
      super(e, r), this._currentId = -1, this._nextId = -1, this._nextTick = this.time, this._boundRestart = this._restart.bind(this);
      let n = Object.assign(t.getDefaults(), r);
      this.duration = n.duration, this._interval = n.interval, this._nextTick = n.time, this.transport.on("start", this._boundRestart), this.transport.on("loopStart", this._boundRestart), this.transport.on("ticks", this._boundRestart), this.context = this.transport.context, this._restart();
    }
    static getDefaults() {
      return Object.assign({}, Hn.getDefaults(), { duration: 1 / 0, interval: 1, once: false });
    }
    invoke(e) {
      this._createEvents(e), super.invoke(e);
    }
    _createEvent() {
      return wi(this._nextTick, this.floatTime + this.duration) ? this.transport.scheduleOnce(this.invoke.bind(this), new hr(this.context, this._nextTick).toSeconds()) : -1;
    }
    _createEvents(e) {
      wi(this._nextTick + this._interval, this.floatTime + this.duration) && (this._nextTick += this._interval, this._currentId = this._nextId, this._nextId = this.transport.scheduleOnce(this.invoke.bind(this), new hr(this.context, this._nextTick).toSeconds()));
    }
    _restart(e) {
      this.transport.clear(this._currentId), this.transport.clear(this._nextId), this._nextTick = this.floatTime;
      let r = this.transport.getTicksAtTime(e);
      Gn(r, this.time) && (this._nextTick = this.floatTime + Math.ceil((r - this.floatTime) / this._interval) * this._interval), this._currentId = this._createEvent(), this._nextTick += this._interval, this._nextId = this._createEvent();
    }
    dispose() {
      return super.dispose(), this.transport.clear(this._currentId), this.transport.clear(this._nextId), this.transport.off("start", this._boundRestart), this.transport.off("loopStart", this._boundRestart), this.transport.off("ticks", this._boundRestart), this;
    }
  };
  var jp = class t extends nt {
    constructor() {
      let e = b(t.getDefaults(), arguments);
      super(e), this.name = "Transport", this._loop = new Lp(false), this._loopStart = 0, this._loopEnd = 0, this._scheduledEvents = {}, this._timeline = new rt(), this._repeatedEvents = new Ip(), this._syncedSignals = [], this._swingAmount = 0, this._ppq = e.ppq, this._clock = new Xs({ callback: this._processTick.bind(this), context: this.context, frequency: 0, units: "bpm" }), this._bindClockEvents(), this.bpm = this._clock.frequency, this._clock.frequency.multiplier = e.ppq, this.bpm.setValueAtTime(e.bpm, 0), z(this, "bpm"), this._timeSignature = e.timeSignature, this._swingTicks = e.ppq / 2;
    }
    static getDefaults() {
      return Object.assign(nt.getDefaults(), { bpm: 120, loopEnd: "4m", loopStart: 0, ppq: 192, swing: 0, swingSubdivision: "8n", timeSignature: 4 });
    }
    _processTick(e, r) {
      if (this._loop.get(e) && r >= this._loopEnd && (this.emit("loopEnd", e), this._clock.setTicksAtTime(this._loopStart, e), r = this._loopStart, this.emit("loopStart", e, this._clock.getSecondsAtTime(e)), this.emit("loop", e)), this._swingAmount > 0 && r % this._ppq !== 0 && r % (this._swingTicks * 2) !== 0) {
        let n = r % (this._swingTicks * 2) / (this._swingTicks * 2), o = Math.sin(n * Math.PI) * this._swingAmount;
        e += new hr(this.context, this._swingTicks * 2 / 3).toSeconds() * o;
      }
      Cg(true), this._timeline.forEachAtTime(r, (n) => n.invoke(e)), Cg(false);
    }
    schedule(e, r) {
      let n = new Hn(this, { callback: e, time: new Dr(this.context, r).toTicks() });
      return this._addEvent(n, this._timeline);
    }
    scheduleRepeat(e, r, n, o = 1 / 0) {
      let i = new Bp(this, { callback: e, duration: new pr(this.context, o).toTicks(), interval: new pr(this.context, r).toTicks(), time: new Dr(this.context, n).toTicks() });
      return this._addEvent(i, this._repeatedEvents);
    }
    scheduleOnce(e, r) {
      let n = new Hn(this, { callback: e, once: true, time: new Dr(this.context, r).toTicks() });
      return this._addEvent(n, this._timeline);
    }
    clear(e) {
      if (this._scheduledEvents.hasOwnProperty(e)) {
        let r = this._scheduledEvents[e.toString()];
        r.timeline.remove(r.event), r.event.dispose(), delete this._scheduledEvents[e.toString()];
      }
      return this;
    }
    _addEvent(e, r) {
      return this._scheduledEvents[e.id.toString()] = { event: e, timeline: r }, r.add(e), e.id;
    }
    cancel(e = 0) {
      let r = this.toTicks(e);
      return this._timeline.forEachFrom(r, (n) => this.clear(n.id)), this._repeatedEvents.forEachFrom(r, (n) => this.clear(n.id)), this;
    }
    _bindClockEvents() {
      this._clock.on("start", (e, r) => {
        r = new hr(this.context, r).toSeconds(), this.emit("start", e, r);
      }), this._clock.on("stop", (e) => {
        this.emit("stop", e);
      }), this._clock.on("pause", (e) => {
        this.emit("pause", e);
      });
    }
    get state() {
      return this._clock.getStateAtTime(this.now());
    }
    start(e, r) {
      this.context.resume();
      let n;
      return Q(r) && (n = this.toTicks(r)), this._clock.start(e, n), this;
    }
    stop(e) {
      return this._clock.stop(e), this;
    }
    pause(e) {
      return this._clock.pause(e), this;
    }
    toggle(e) {
      return e = this.toSeconds(e), this._clock.getStateAtTime(e) !== "started" ? this.start(e) : this.stop(e), this;
    }
    get timeSignature() {
      return this._timeSignature;
    }
    set timeSignature(e) {
      Fe(e) && (e = e[0] / e[1] * 4), this._timeSignature = e;
    }
    get loopStart() {
      return new pr(this.context, this._loopStart, "i").toSeconds();
    }
    set loopStart(e) {
      this._loopStart = this.toTicks(e);
    }
    get loopEnd() {
      return new pr(this.context, this._loopEnd, "i").toSeconds();
    }
    set loopEnd(e) {
      this._loopEnd = this.toTicks(e);
    }
    get loop() {
      return this._loop.get(this.now());
    }
    set loop(e) {
      this._loop.set(e, this.now());
    }
    setLoopPoints(e, r) {
      return this.loopStart = e, this.loopEnd = r, this;
    }
    get swing() {
      return this._swingAmount;
    }
    set swing(e) {
      this._swingAmount = e;
    }
    get swingSubdivision() {
      return new hr(this.context, this._swingTicks).toNotation();
    }
    set swingSubdivision(e) {
      this._swingTicks = this.toTicks(e);
    }
    get position() {
      let e = this.now(), r = this._clock.getTicksAtTime(e);
      return new hr(this.context, r).toBarsBeatsSixteenths();
    }
    set position(e) {
      let r = this.toTicks(e);
      this.ticks = r;
    }
    get seconds() {
      return this._clock.seconds;
    }
    set seconds(e) {
      let r = this.now(), n = this._clock.frequency.timeToTicks(e, r);
      this.ticks = n;
    }
    get progress() {
      if (this.loop) {
        let e = this.now();
        return (this._clock.getTicksAtTime(e) - this._loopStart) / (this._loopEnd - this._loopStart);
      } else return 0;
    }
    get ticks() {
      return this._clock.ticks;
    }
    set ticks(e) {
      if (this._clock.ticks !== e) {
        let r = this.now();
        if (this.state === "started") {
          let n = this._clock.getTicksAtTime(r), o = this._clock.frequency.getDurationOfTicks(Math.ceil(n) - n, r), i = r + o;
          this.emit("stop", i), this._clock.setTicksAtTime(e, i), this.emit("start", i, this._clock.getSecondsAtTime(i));
        } else this.emit("ticks", r), this._clock.setTicksAtTime(e, r);
      }
    }
    getTicksAtTime(e) {
      return this._clock.getTicksAtTime(e);
    }
    getSecondsAtTime(e) {
      return this._clock.getSecondsAtTime(e);
    }
    get PPQ() {
      return this._clock.frequency.multiplier;
    }
    set PPQ(e) {
      this._clock.frequency.multiplier = e;
    }
    nextSubdivision(e) {
      if (e = this.toTicks(e), this.state !== "started") return 0;
      {
        let r = this.now(), n = this.getTicksAtTime(r), o = e - n % e;
        return this._clock.nextTickTime(o, r);
      }
    }
    syncSignal(e, r) {
      let n = this.now(), o = this.bpm, i = 1 / (60 / o.getValueAtTime(n) / this.PPQ), s = [];
      if (e.units === "time") {
        let l = 0.015625 / i, u = new X(l), c = new Qs(-1), p = new X(l);
        o.chain(u, c, p), o = p, i = 1 / i, s = [u, c, p];
      }
      r || (e.getValueAtTime(n) !== 0 ? r = e.getValueAtTime(n) / i : r = 0);
      let a = new X(r);
      return o.connect(a), a.connect(e._param), s.push(a), this._syncedSignals.push({ initial: e.value, nodes: s, signal: e }), e.value = 0, this;
    }
    unsyncSignal(e) {
      for (let r = this._syncedSignals.length - 1; r >= 0; r--) {
        let n = this._syncedSignals[r];
        n.signal === e && (n.nodes.forEach((o) => o.dispose()), n.signal.value = n.initial, this._syncedSignals.splice(r, 1));
      }
      return this;
    }
    dispose() {
      return super.dispose(), this._clock.dispose(), Us(this, "bpm"), this._timeline.dispose(), this._repeatedEvents.dispose(), this;
    }
  };
  Fo.mixin(jp);
  Ro((t) => {
    t.transport = new jp({ context: t });
  });
  Vo((t) => {
    t.transport.dispose();
  });
  var ye = class extends L {
    constructor(e) {
      super(e), this.input = void 0, this._state = new An("stopped"), this._synced = false, this._scheduled = [], this._syncedStart = Z, this._syncedStop = Z, this._state.memory = 100, this._state.increasing = true, this._volume = this.output = new Mr({ context: this.context, mute: e.mute, volume: e.volume }), this.volume = this._volume.volume, z(this, "volume"), this.onstop = e.onstop;
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { mute: false, onstop: Z, volume: 0 });
    }
    get state() {
      return this._synced ? this.context.transport.state === "started" ? this._state.getValueAtTime(this.context.transport.seconds) : "stopped" : this._state.getValueAtTime(this.now());
    }
    get mute() {
      return this._volume.mute;
    }
    set mute(e) {
      this._volume.mute = e;
    }
    _clampToCurrentTime(e) {
      return this._synced ? e : Math.max(e, this.context.currentTime);
    }
    start(e, r, n) {
      let o = Ke(e) && this._synced ? this.context.transport.seconds : this.toSeconds(e);
      if (o = this._clampToCurrentTime(o), !this._synced && this._state.getValueAtTime(o) === "started") U(Gn(o, this._state.get(o).time), "Start time must be strictly greater than previous start time"), this._state.cancel(o), this._state.setStateAtTime("started", o), this.log("restart", o), this.restart(o, r, n);
      else if (this.log("start", o), this._state.setStateAtTime("started", o), this._synced) {
        let i = this._state.get(o);
        i && (i.offset = this.toSeconds(cr(r, 0)), i.duration = n ? this.toSeconds(n) : void 0);
        let s = this.context.transport.schedule((a) => {
          this._start(a, r, n);
        }, o);
        this._scheduled.push(s), this.context.transport.state === "started" && this.context.transport.getSecondsAtTime(this.immediate()) > o && this._syncedStart(this.now(), this.context.transport.seconds);
      } else Np(this.context), this._start(o, r, n);
      return this;
    }
    stop(e) {
      let r = Ke(e) && this._synced ? this.context.transport.seconds : this.toSeconds(e);
      if (r = this._clampToCurrentTime(r), this._state.getValueAtTime(r) === "started" || Q(this._state.getNextState("started", r))) {
        if (this.log("stop", r), !this._synced) this._stop(r);
        else {
          let n = this.context.transport.schedule(this._stop.bind(this), r);
          this._scheduled.push(n);
        }
        this._state.cancel(r), this._state.setStateAtTime("stopped", r);
      }
      return this;
    }
    restart(e, r, n) {
      return e = this.toSeconds(e), this._state.getValueAtTime(e) === "started" && (this._state.cancel(e), this._restart(e, r, n)), this;
    }
    sync() {
      return this._synced || (this._synced = true, this._syncedStart = (e, r) => {
        if (Gn(r, 0)) {
          let n = this._state.get(r);
          if (n && n.state === "started" && n.time !== r) {
            let o = r - this.toSeconds(n.time), i;
            n.duration && (i = this.toSeconds(n.duration) - o), this._start(e, this.toSeconds(n.offset) + o, i);
          }
        }
      }, this._syncedStop = (e) => {
        let r = this.context.transport.getSecondsAtTime(Math.max(e - this.sampleTime, 0));
        this._state.getValueAtTime(r) === "started" && this._stop(e);
      }, this.context.transport.on("start", this._syncedStart), this.context.transport.on("loopStart", this._syncedStart), this.context.transport.on("stop", this._syncedStop), this.context.transport.on("pause", this._syncedStop), this.context.transport.on("loopEnd", this._syncedStop)), this;
    }
    unsync() {
      return this._synced && (this.context.transport.off("stop", this._syncedStop), this.context.transport.off("pause", this._syncedStop), this.context.transport.off("loopEnd", this._syncedStop), this.context.transport.off("start", this._syncedStart), this.context.transport.off("loopStart", this._syncedStart)), this._synced = false, this._scheduled.forEach((e) => this.context.transport.clear(e)), this._scheduled = [], this._state.cancel(0), this._stop(0), this;
    }
    dispose() {
      return super.dispose(), this.onstop = Z, this.unsync(), this._volume.dispose(), this._state.dispose(), this;
    }
  };
  var $n = class t extends nn {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["url", "onload"]);
      super(e), this.name = "ToneBufferSource", this._source = this.context.createBufferSource(), this._internalChannels = [this._source], this._sourceStarted = false, this._sourceStopped = false, Wt(this._source, this._gainNode), this._source.onended = () => this._stopSource(), this.playbackRate = new ie({ context: this.context, param: this._source.playbackRate, units: "positive", value: e.playbackRate }), this.loop = e.loop, this.loopStart = e.loopStart, this.loopEnd = e.loopEnd, this._buffer = new ht(e.url, e.onload, e.onerror), this._internalChannels.push(this._source);
    }
    static getDefaults() {
      return Object.assign(nn.getDefaults(), { url: new ht(), loop: false, loopEnd: 0, loopStart: 0, onload: Z, onerror: Z, playbackRate: 1 });
    }
    get fadeIn() {
      return this._fadeIn;
    }
    set fadeIn(e) {
      this._fadeIn = e;
    }
    get fadeOut() {
      return this._fadeOut;
    }
    set fadeOut(e) {
      this._fadeOut = e;
    }
    get curve() {
      return this._curve;
    }
    set curve(e) {
      this._curve = e;
    }
    start(e, r, n, o = 1) {
      U(this.buffer.loaded, "buffer is either not set or not loaded");
      let i = this.toSeconds(e);
      this._startGain(i, o), this.loop ? r = cr(r, this.loopStart) : r = cr(r, 0);
      let s = Math.max(this.toSeconds(r), 0);
      if (this.loop) {
        let a = this.toSeconds(this.loopEnd) || this.buffer.duration, l = this.toSeconds(this.loopStart), u = a - l;
        Bl(s, a) && (s = (s - l) % u + l), qt(s, this.buffer.duration) && (s = 0);
      }
      if (this._source.buffer = this.buffer.get(), this._source.loopEnd = this.toSeconds(this.loopEnd) || this.buffer.duration, wi(s, this.buffer.duration) && (this._sourceStarted = true, this._source.start(i, s)), Q(n)) {
        let a = this.toSeconds(n);
        a = Math.max(a, 0), this.stop(i + a);
      }
      return this;
    }
    _stopSource(e) {
      !this._sourceStopped && this._sourceStarted && (this._sourceStopped = true, this._source.stop(this.toSeconds(e)), this._onended());
    }
    get loopStart() {
      return this._source.loopStart;
    }
    set loopStart(e) {
      this._source.loopStart = this.toSeconds(e);
    }
    get loopEnd() {
      return this._source.loopEnd;
    }
    set loopEnd(e) {
      this._source.loopEnd = this.toSeconds(e);
    }
    get buffer() {
      return this._buffer;
    }
    set buffer(e) {
      this._buffer.set(e);
    }
    get loop() {
      return this._source.loop;
    }
    set loop(e) {
      this._source.loop = e, this._sourceStarted && this.cancelStop();
    }
    dispose() {
      return super.dispose(), this._source.onended = null, this._source.disconnect(), this._buffer.dispose(), this.playbackRate.dispose(), this;
    }
  };
  var Ote = 44100 * 5;
  function er(t, e) {
    return ce(this, void 0, void 0, function* () {
      let r = e / t.context.sampleRate, n = new Tn(1, r, t.context.sampleRate);
      return new t.constructor(Object.assign(t.get(), { frequency: 2 / r, detune: 0, context: n })).toDestination().start(0), (yield n.render()).getChannelData(0);
    });
  }
  var Wl = class t extends nn {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "type"]);
      super(e), this.name = "ToneOscillatorNode", this._oscillator = this.context.createOscillator(), this._internalChannels = [this._oscillator], Wt(this._oscillator, this._gainNode), this.type = e.type, this.frequency = new ie({ context: this.context, param: this._oscillator.frequency, units: "frequency", value: e.frequency }), this.detune = new ie({ context: this.context, param: this._oscillator.detune, units: "cents", value: e.detune }), z(this, ["frequency", "detune"]);
    }
    static getDefaults() {
      return Object.assign(nn.getDefaults(), { detune: 0, frequency: 440, type: "sine" });
    }
    start(e) {
      let r = this.toSeconds(e);
      return this.log("start", r), this._startGain(r), this._oscillator.start(r), this;
    }
    _stopSource(e) {
      this._oscillator.stop(e);
    }
    setPeriodicWave(e) {
      return this._oscillator.setPeriodicWave(e), this;
    }
    get type() {
      return this._oscillator.type;
    }
    set type(e) {
      this._oscillator.type = e;
    }
    dispose() {
      return super.dispose(), this.state === "started" && this.stop(), this._oscillator.disconnect(), this.frequency.dispose(), this.detune.dispose(), this;
    }
  };
  var Ie = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "type"]);
      super(e), this.name = "Oscillator", this._oscillator = null, this.frequency = new ee({ context: this.context, units: "frequency", value: e.frequency }), z(this, "frequency"), this.detune = new ee({ context: this.context, units: "cents", value: e.detune }), z(this, "detune"), this._partials = e.partials, this._partialCount = e.partialCount, this._type = e.type, e.partialCount && e.type !== "custom" && (this._type = this.baseType + e.partialCount.toString()), this.phase = e.phase;
    }
    static getDefaults() {
      return Object.assign(ye.getDefaults(), { detune: 0, frequency: 440, partialCount: 0, partials: [], phase: 0, type: "sine" });
    }
    _start(e) {
      let r = this.toSeconds(e), n = new Wl({ context: this.context, onended: () => this.onstop(this) });
      this._oscillator = n, this._wave ? this._oscillator.setPeriodicWave(this._wave) : this._oscillator.type = this._type, this._oscillator.connect(this.output), this.frequency.connect(this._oscillator.frequency), this.detune.connect(this._oscillator.detune), this._oscillator.start(r);
    }
    _stop(e) {
      let r = this.toSeconds(e);
      this._oscillator && this._oscillator.stop(r);
    }
    _restart(e) {
      let r = this.toSeconds(e);
      return this.log("restart", r), this._oscillator && this._oscillator.cancelStop(), this._state.cancel(r), this;
    }
    syncFrequency() {
      return this.context.transport.syncSignal(this.frequency), this;
    }
    unsyncFrequency() {
      return this.context.transport.unsyncSignal(this.frequency), this;
    }
    _getCachedPeriodicWave() {
      if (this._type === "custom") return t._periodicWaveCache.find((r) => r.phase === this._phase && eA(r.partials, this._partials));
      {
        let e = t._periodicWaveCache.find((r) => r.type === this._type && r.phase === this._phase);
        return this._partialCount = e ? e.partialCount : this._partialCount, e;
      }
    }
    get type() {
      return this._type;
    }
    set type(e) {
      this._type = e;
      let r = ["sine", "square", "sawtooth", "triangle"].indexOf(e) !== -1;
      if (this._phase === 0 && r) this._wave = void 0, this._partialCount = 0, this._oscillator !== null && (this._oscillator.type = e);
      else {
        let n = this._getCachedPeriodicWave();
        if (Q(n)) {
          let { partials: o, wave: i } = n;
          this._wave = i, this._partials = o, this._oscillator !== null && this._oscillator.setPeriodicWave(this._wave);
        } else {
          let [o, i] = this._getRealImaginary(e, this._phase), s = this.context.createPeriodicWave(o, i);
          this._wave = s, this._oscillator !== null && this._oscillator.setPeriodicWave(this._wave), t._periodicWaveCache.push({ imag: i, partialCount: this._partialCount, partials: this._partials, phase: this._phase, real: o, type: this._type, wave: this._wave }), t._periodicWaveCache.length > 100 && t._periodicWaveCache.shift();
        }
      }
    }
    get baseType() {
      return this._type.replace(this.partialCount.toString(), "");
    }
    set baseType(e) {
      this.partialCount && this._type !== "custom" && e !== "custom" ? this.type = e + this.partialCount : this.type = e;
    }
    get partialCount() {
      return this._partialCount;
    }
    set partialCount(e) {
      yt(e, 0);
      let r = this._type, n = /^(sine|triangle|square|sawtooth)(\d+)$/.exec(this._type);
      if (n && (r = n[1]), this._type !== "custom") e === 0 ? this.type = r : this.type = r + e.toString();
      else {
        let o = new Float32Array(e);
        this._partials.forEach((i, s) => o[s] = i), this._partials = Array.from(o), this.type = this._type;
      }
    }
    _getRealImaginary(e, r) {
      let o = 2048, i = new Float32Array(o), s = new Float32Array(o), a = 1;
      if (e === "custom") {
        if (a = this._partials.length + 1, this._partialCount = this._partials.length, o = a, this._partials.length === 0) return [i, s];
      } else {
        let l = /^(sine|triangle|square|sawtooth)(\d+)$/.exec(e);
        l ? (a = parseInt(l[2], 10) + 1, this._partialCount = parseInt(l[2], 10), e = l[1], a = Math.max(a, 2), o = a) : this._partialCount = 0, this._partials = [];
      }
      for (let l = 1; l < o; ++l) {
        let u = 2 / (l * Math.PI), c;
        switch (e) {
          case "sine":
            c = l <= a ? 1 : 0, this._partials[l - 1] = c;
            break;
          case "square":
            c = l & 1 ? 2 * u : 0, this._partials[l - 1] = c;
            break;
          case "sawtooth":
            c = u * (l & 1 ? 1 : -1), this._partials[l - 1] = c;
            break;
          case "triangle":
            l & 1 ? c = 2 * (u * u) * (l - 1 >> 1 & 1 ? -1 : 1) : c = 0, this._partials[l - 1] = c;
            break;
          case "custom":
            c = this._partials[l - 1];
            break;
          default:
            throw new TypeError("Oscillator: invalid type: " + e);
        }
        c !== 0 ? (i[l] = -c * Math.sin(r * l), s[l] = c * Math.cos(r * l)) : (i[l] = 0, s[l] = 0);
      }
      return [i, s];
    }
    _inverseFFT(e, r, n) {
      let o = 0, i = e.length;
      for (let s = 0; s < i; s++) o += e[s] * Math.cos(s * n) + r[s] * Math.sin(s * n);
      return o;
    }
    getInitialValue() {
      let [e, r] = this._getRealImaginary(this._type, 0), n = 0, o = Math.PI * 2, i = 32;
      for (let s = 0; s < i; s++) n = Math.max(this._inverseFFT(e, r, s / i * o), n);
      return kg(-this._inverseFFT(e, r, this._phase) / n, -1, 1);
    }
    get partials() {
      return this._partials.slice(0, this.partialCount);
    }
    set partials(e) {
      this._partials = e, this._partialCount = this._partials.length, e.length && (this.type = "custom");
    }
    get phase() {
      return this._phase * (180 / Math.PI);
    }
    set phase(e) {
      this._phase = e * Math.PI / 180, this.type = this._type;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        return er(this, e);
      });
    }
    dispose() {
      return super.dispose(), this._oscillator !== null && this._oscillator.dispose(), this._wave = void 0, this.frequency.dispose(), this.detune.dispose(), this;
    }
  };
  Ie._periodicWaveCache = [];
  var Ks = class extends Ut {
    constructor() {
      super(...arguments), this.name = "AudioToGain", this._norm = new fr({ context: this.context, mapping: (e) => (e + 1) / 2 }), this.input = this._norm, this.output = this._norm;
    }
    dispose() {
      return super.dispose(), this._norm.dispose(), this;
    }
  };
  var ot = class t extends ee {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["value"]);
      super(e), this.name = "Multiply", this.override = false, this._mult = this.input = this.output = new X({ context: this.context, minValue: e.minValue, maxValue: e.maxValue }), this.factor = this._param = this._mult.gain, this.factor.setValueAtTime(e.value, 0);
    }
    static getDefaults() {
      return Object.assign(ee.getDefaults(), { value: 0 });
    }
    dispose() {
      return super.dispose(), this._mult.dispose(), this;
    }
  };
  var Ul = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "type", "modulationType"]);
      super(e), this.name = "AMOscillator", this._modulationScale = new Ks({ context: this.context }), this._modulationNode = new X({ context: this.context }), this._carrier = new Ie({ context: this.context, detune: e.detune, frequency: e.frequency, onstop: () => this.onstop(this), phase: e.phase, type: e.type }), this.frequency = this._carrier.frequency, this.detune = this._carrier.detune, this._modulator = new Ie({ context: this.context, phase: e.phase, type: e.modulationType }), this.harmonicity = new ot({ context: this.context, units: "positive", value: e.harmonicity }), this.frequency.chain(this.harmonicity, this._modulator.frequency), this._modulator.chain(this._modulationScale, this._modulationNode.gain), this._carrier.chain(this._modulationNode, this.output), z(this, ["frequency", "detune", "harmonicity"]);
    }
    static getDefaults() {
      return Object.assign(Ie.getDefaults(), { harmonicity: 1, modulationType: "square" });
    }
    _start(e) {
      this._modulator.start(e), this._carrier.start(e);
    }
    _stop(e) {
      this._modulator.stop(e), this._carrier.stop(e);
    }
    _restart(e) {
      this._modulator.restart(e), this._carrier.restart(e);
    }
    get type() {
      return this._carrier.type;
    }
    set type(e) {
      this._carrier.type = e;
    }
    get baseType() {
      return this._carrier.baseType;
    }
    set baseType(e) {
      this._carrier.baseType = e;
    }
    get partialCount() {
      return this._carrier.partialCount;
    }
    set partialCount(e) {
      this._carrier.partialCount = e;
    }
    get modulationType() {
      return this._modulator.type;
    }
    set modulationType(e) {
      this._modulator.type = e;
    }
    get phase() {
      return this._carrier.phase;
    }
    set phase(e) {
      this._carrier.phase = e, this._modulator.phase = e;
    }
    get partials() {
      return this._carrier.partials;
    }
    set partials(e) {
      this._carrier.partials = e;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        return er(this, e);
      });
    }
    dispose() {
      return super.dispose(), this.frequency.dispose(), this.detune.dispose(), this.harmonicity.dispose(), this._carrier.dispose(), this._modulator.dispose(), this._modulationNode.dispose(), this._modulationScale.dispose(), this;
    }
  };
  var Zs = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "type", "modulationType"]);
      super(e), this.name = "FMOscillator", this._modulationNode = new X({ context: this.context, gain: 0 }), this._carrier = new Ie({ context: this.context, detune: e.detune, frequency: 0, onstop: () => this.onstop(this), phase: e.phase, type: e.type }), this.detune = this._carrier.detune, this.frequency = new ee({ context: this.context, units: "frequency", value: e.frequency }), this._modulator = new Ie({ context: this.context, phase: e.phase, type: e.modulationType }), this.harmonicity = new ot({ context: this.context, units: "positive", value: e.harmonicity }), this.modulationIndex = new ot({ context: this.context, units: "positive", value: e.modulationIndex }), this.frequency.connect(this._carrier.frequency), this.frequency.chain(this.harmonicity, this._modulator.frequency), this.frequency.chain(this.modulationIndex, this._modulationNode), this._modulator.connect(this._modulationNode.gain), this._modulationNode.connect(this._carrier.frequency), this._carrier.connect(this.output), this.detune.connect(this._modulator.detune), z(this, ["modulationIndex", "frequency", "detune", "harmonicity"]);
    }
    static getDefaults() {
      return Object.assign(Ie.getDefaults(), { harmonicity: 1, modulationIndex: 2, modulationType: "square" });
    }
    _start(e) {
      this._modulator.start(e), this._carrier.start(e);
    }
    _stop(e) {
      this._modulator.stop(e), this._carrier.stop(e);
    }
    _restart(e) {
      return this._modulator.restart(e), this._carrier.restart(e), this;
    }
    get type() {
      return this._carrier.type;
    }
    set type(e) {
      this._carrier.type = e;
    }
    get baseType() {
      return this._carrier.baseType;
    }
    set baseType(e) {
      this._carrier.baseType = e;
    }
    get partialCount() {
      return this._carrier.partialCount;
    }
    set partialCount(e) {
      this._carrier.partialCount = e;
    }
    get modulationType() {
      return this._modulator.type;
    }
    set modulationType(e) {
      this._modulator.type = e;
    }
    get phase() {
      return this._carrier.phase;
    }
    set phase(e) {
      this._carrier.phase = e, this._modulator.phase = e;
    }
    get partials() {
      return this._carrier.partials;
    }
    set partials(e) {
      this._carrier.partials = e;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        return er(this, e);
      });
    }
    dispose() {
      return super.dispose(), this.frequency.dispose(), this.harmonicity.dispose(), this._carrier.dispose(), this._modulator.dispose(), this._modulationNode.dispose(), this.modulationIndex.dispose(), this;
    }
  };
  var Ci = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "width"]);
      super(e), this.name = "PulseOscillator", this._widthGate = new X({ context: this.context, gain: 0 }), this._thresh = new fr({ context: this.context, mapping: (r) => r <= 0 ? -1 : 1 }), this.width = new ee({ context: this.context, units: "audioRange", value: e.width }), this._triangle = new Ie({ context: this.context, detune: e.detune, frequency: e.frequency, onstop: () => this.onstop(this), phase: e.phase, type: "triangle" }), this.frequency = this._triangle.frequency, this.detune = this._triangle.detune, this._triangle.chain(this._thresh, this.output), this.width.chain(this._widthGate, this._thresh), z(this, ["width", "frequency", "detune"]);
    }
    static getDefaults() {
      return Object.assign(ye.getDefaults(), { detune: 0, frequency: 440, phase: 0, type: "pulse", width: 0.2 });
    }
    _start(e) {
      e = this.toSeconds(e), this._triangle.start(e), this._widthGate.gain.setValueAtTime(1, e);
    }
    _stop(e) {
      e = this.toSeconds(e), this._triangle.stop(e), this._widthGate.gain.cancelScheduledValues(e), this._widthGate.gain.setValueAtTime(0, e);
    }
    _restart(e) {
      this._triangle.restart(e), this._widthGate.gain.cancelScheduledValues(e), this._widthGate.gain.setValueAtTime(1, e);
    }
    get phase() {
      return this._triangle.phase;
    }
    set phase(e) {
      this._triangle.phase = e;
    }
    get type() {
      return "pulse";
    }
    get baseType() {
      return "pulse";
    }
    get partials() {
      return [];
    }
    get partialCount() {
      return 0;
    }
    set carrierType(e) {
      this._triangle.type = e;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        return er(this, e);
      });
    }
    dispose() {
      return super.dispose(), this._triangle.dispose(), this.width.dispose(), this._widthGate.dispose(), this._thresh.dispose(), this;
    }
  };
  var Gl = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "type", "spread"]);
      super(e), this.name = "FatOscillator", this._oscillators = [], this.frequency = new ee({ context: this.context, units: "frequency", value: e.frequency }), this.detune = new ee({ context: this.context, units: "cents", value: e.detune }), this._spread = e.spread, this._type = e.type, this._phase = e.phase, this._partials = e.partials, this._partialCount = e.partialCount, this.count = e.count, z(this, ["frequency", "detune"]);
    }
    static getDefaults() {
      return Object.assign(Ie.getDefaults(), { count: 3, spread: 20, type: "sawtooth" });
    }
    _start(e) {
      e = this.toSeconds(e), this._forEach((r) => r.start(e));
    }
    _stop(e) {
      e = this.toSeconds(e), this._forEach((r) => r.stop(e));
    }
    _restart(e) {
      this._forEach((r) => r.restart(e));
    }
    _forEach(e) {
      for (let r = 0; r < this._oscillators.length; r++) e(this._oscillators[r], r);
    }
    get type() {
      return this._type;
    }
    set type(e) {
      this._type = e, this._forEach((r) => r.type = e);
    }
    get spread() {
      return this._spread;
    }
    set spread(e) {
      if (this._spread = e, this._oscillators.length > 1) {
        let r = -e / 2, n = e / (this._oscillators.length - 1);
        this._forEach((o, i) => o.detune.value = r + n * i);
      }
    }
    get count() {
      return this._oscillators.length;
    }
    set count(e) {
      if (yt(e, 1), this._oscillators.length !== e) {
        this._forEach((r) => r.dispose()), this._oscillators = [];
        for (let r = 0; r < e; r++) {
          let n = new Ie({ context: this.context, volume: -6 - e * 1.1, type: this._type, phase: this._phase + r / e * 360, partialCount: this._partialCount, onstop: r === 0 ? () => this.onstop(this) : Z });
          this.type === "custom" && (n.partials = this._partials), this.frequency.connect(n.frequency), this.detune.connect(n.detune), n.detune.overridden = false, n.connect(this.output), this._oscillators[r] = n;
        }
        this.spread = this._spread, this.state === "started" && this._forEach((r) => r.start());
      }
    }
    get phase() {
      return this._phase;
    }
    set phase(e) {
      this._phase = e, this._forEach((r, n) => r.phase = this._phase + n / this.count * 360);
    }
    get baseType() {
      return this._oscillators[0].baseType;
    }
    set baseType(e) {
      this._forEach((r) => r.baseType = e), this._type = this._oscillators[0].type;
    }
    get partials() {
      return this._oscillators[0].partials;
    }
    set partials(e) {
      this._partials = e, this._partialCount = this._partials.length, e.length && (this._type = "custom", this._forEach((r) => r.partials = e));
    }
    get partialCount() {
      return this._oscillators[0].partialCount;
    }
    set partialCount(e) {
      this._partialCount = e, this._forEach((r) => r.partialCount = e), this._type = this._oscillators[0].type;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        return er(this, e);
      });
    }
    dispose() {
      return super.dispose(), this.frequency.dispose(), this.detune.dispose(), this._forEach((e) => e.dispose()), this;
    }
  };
  var Hl = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "modulationFrequency"]);
      super(e), this.name = "PWMOscillator", this.sourceType = "pwm", this._scale = new ot({ context: this.context, value: 2 }), this._pulse = new Ci({ context: this.context, frequency: e.modulationFrequency }), this._pulse.carrierType = "sine", this.modulationFrequency = this._pulse.frequency, this._modulator = new Ie({ context: this.context, detune: e.detune, frequency: e.frequency, onstop: () => this.onstop(this), phase: e.phase }), this.frequency = this._modulator.frequency, this.detune = this._modulator.detune, this._modulator.chain(this._scale, this._pulse.width), this._pulse.connect(this.output), z(this, ["modulationFrequency", "frequency", "detune"]);
    }
    static getDefaults() {
      return Object.assign(ye.getDefaults(), { detune: 0, frequency: 440, modulationFrequency: 0.4, phase: 0, type: "pwm" });
    }
    _start(e) {
      e = this.toSeconds(e), this._modulator.start(e), this._pulse.start(e);
    }
    _stop(e) {
      e = this.toSeconds(e), this._modulator.stop(e), this._pulse.stop(e);
    }
    _restart(e) {
      this._modulator.restart(e), this._pulse.restart(e);
    }
    get type() {
      return "pwm";
    }
    get baseType() {
      return "pwm";
    }
    get partials() {
      return [];
    }
    get partialCount() {
      return 0;
    }
    get phase() {
      return this._modulator.phase;
    }
    set phase(e) {
      this._modulator.phase = e;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        return er(this, e);
      });
    }
    dispose() {
      return super.dispose(), this._pulse.dispose(), this._scale.dispose(), this._modulator.dispose(), this;
    }
  };
  var cA = { am: Ul, fat: Gl, fm: Zs, oscillator: Ie, pulse: Ci, pwm: Hl }, ki = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["frequency", "type"]);
      super(e), this.name = "OmniOscillator", this.frequency = new ee({ context: this.context, units: "frequency", value: e.frequency }), this.detune = new ee({ context: this.context, units: "cents", value: e.detune }), z(this, ["frequency", "detune"]), this.set(e);
    }
    static getDefaults() {
      return Object.assign(Ie.getDefaults(), Zs.getDefaults(), Ul.getDefaults(), Gl.getDefaults(), Ci.getDefaults(), Hl.getDefaults());
    }
    _start(e) {
      this._oscillator.start(e);
    }
    _stop(e) {
      this._oscillator.stop(e);
    }
    _restart(e) {
      return this._oscillator.restart(e), this;
    }
    get type() {
      let e = "";
      return ["am", "fm", "fat"].some((r) => this._sourceType === r) && (e = this._sourceType), e + this._oscillator.type;
    }
    set type(e) {
      e.substr(0, 2) === "fm" ? (this._createNewOscillator("fm"), this._oscillator = this._oscillator, this._oscillator.type = e.substr(2)) : e.substr(0, 2) === "am" ? (this._createNewOscillator("am"), this._oscillator = this._oscillator, this._oscillator.type = e.substr(2)) : e.substr(0, 3) === "fat" ? (this._createNewOscillator("fat"), this._oscillator = this._oscillator, this._oscillator.type = e.substr(3)) : e === "pwm" ? (this._createNewOscillator("pwm"), this._oscillator = this._oscillator) : e === "pulse" ? this._createNewOscillator("pulse") : (this._createNewOscillator("oscillator"), this._oscillator = this._oscillator, this._oscillator.type = e);
    }
    get partials() {
      return this._oscillator.partials;
    }
    set partials(e) {
      !this._getOscType(this._oscillator, "pulse") && !this._getOscType(this._oscillator, "pwm") && (this._oscillator.partials = e);
    }
    get partialCount() {
      return this._oscillator.partialCount;
    }
    set partialCount(e) {
      !this._getOscType(this._oscillator, "pulse") && !this._getOscType(this._oscillator, "pwm") && (this._oscillator.partialCount = e);
    }
    set(e) {
      return Reflect.has(e, "type") && e.type && (this.type = e.type), super.set(e), this;
    }
    _createNewOscillator(e) {
      if (e !== this._sourceType) {
        this._sourceType = e;
        let r = cA[e], n = this.now();
        if (this._oscillator) {
          let o = this._oscillator;
          o.stop(n), this.context.setTimeout(() => o.dispose(), this.blockTime);
        }
        this._oscillator = new r({ context: this.context }), this.frequency.connect(this._oscillator.frequency), this.detune.connect(this._oscillator.detune), this._oscillator.connect(this.output), this._oscillator.onstop = () => this.onstop(this), this.state === "started" && this._oscillator.start(n);
      }
    }
    get phase() {
      return this._oscillator.phase;
    }
    set phase(e) {
      this._oscillator.phase = e;
    }
    get sourceType() {
      return this._sourceType;
    }
    set sourceType(e) {
      let r = "sine";
      this._oscillator.type !== "pwm" && this._oscillator.type !== "pulse" && (r = this._oscillator.type), e === "fm" ? this.type = "fm" + r : e === "am" ? this.type = "am" + r : e === "fat" ? this.type = "fat" + r : e === "oscillator" ? this.type = r : e === "pulse" ? this.type = "pulse" : e === "pwm" && (this.type = "pwm");
    }
    _getOscType(e, r) {
      return e instanceof cA[r];
    }
    get baseType() {
      return this._oscillator.baseType;
    }
    set baseType(e) {
      !this._getOscType(this._oscillator, "pulse") && !this._getOscType(this._oscillator, "pwm") && e !== "pulse" && e !== "pwm" && (this._oscillator.baseType = e);
    }
    get width() {
      if (this._getOscType(this._oscillator, "pulse")) return this._oscillator.width;
    }
    get count() {
      if (this._getOscType(this._oscillator, "fat")) return this._oscillator.count;
    }
    set count(e) {
      this._getOscType(this._oscillator, "fat") && Ot(e) && (this._oscillator.count = e);
    }
    get spread() {
      if (this._getOscType(this._oscillator, "fat")) return this._oscillator.spread;
    }
    set spread(e) {
      this._getOscType(this._oscillator, "fat") && Ot(e) && (this._oscillator.spread = e);
    }
    get modulationType() {
      if (this._getOscType(this._oscillator, "fm") || this._getOscType(this._oscillator, "am")) return this._oscillator.modulationType;
    }
    set modulationType(e) {
      (this._getOscType(this._oscillator, "fm") || this._getOscType(this._oscillator, "am")) && Dt(e) && (this._oscillator.modulationType = e);
    }
    get modulationIndex() {
      if (this._getOscType(this._oscillator, "fm")) return this._oscillator.modulationIndex;
    }
    get harmonicity() {
      if (this._getOscType(this._oscillator, "fm") || this._getOscType(this._oscillator, "am")) return this._oscillator.harmonicity;
    }
    get modulationFrequency() {
      if (this._getOscType(this._oscillator, "pwm")) return this._oscillator.modulationFrequency;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        return er(this, e);
      });
    }
    dispose() {
      return super.dispose(), this.detune.dispose(), this.frequency.dispose(), this._oscillator.dispose(), this;
    }
  };
  function zp(t, e = 1 / 0) {
    let r = /* @__PURE__ */ new WeakMap();
    return function(n, o) {
      Reflect.defineProperty(n, o, { configurable: true, enumerable: true, get: function() {
        return r.get(this);
      }, set: function(i) {
        yt(i, t, e), r.set(this, i);
      } });
    };
  }
  function tr(t, e = 1 / 0) {
    let r = /* @__PURE__ */ new WeakMap();
    return function(n, o) {
      Reflect.defineProperty(n, o, { configurable: true, enumerable: true, get: function() {
        return r.get(this);
      }, set: function(i) {
        yt(this.toSeconds(i), t, e), r.set(this, i);
      } });
    };
  }
  var $l = class t extends ye {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["url", "onload"]);
      super(e), this.name = "Player", this._activeSources = /* @__PURE__ */ new Set(), this._buffer = new ht({ onload: this._onload.bind(this, e.onload), onerror: e.onerror, reverse: e.reverse, url: e.url }), this.autostart = e.autostart, this._loop = e.loop, this._loopStart = e.loopStart, this._loopEnd = e.loopEnd, this._playbackRate = e.playbackRate, this.fadeIn = e.fadeIn, this.fadeOut = e.fadeOut;
    }
    static getDefaults() {
      return Object.assign(ye.getDefaults(), { autostart: false, fadeIn: 0, fadeOut: 0, loop: false, loopEnd: 0, loopStart: 0, onload: Z, onerror: Z, playbackRate: 1, reverse: false });
    }
    load(e) {
      return ce(this, void 0, void 0, function* () {
        return yield this._buffer.load(e), this._onload(), this;
      });
    }
    _onload(e = Z) {
      e(), this.autostart && this.start();
    }
    _onSourceEnd(e) {
      this.onstop(this), this._activeSources.delete(e), this._activeSources.size === 0 && !this._synced && this._state.getValueAtTime(this.now()) === "started" && (this._state.cancel(this.now()), this._state.setStateAtTime("stopped", this.now()));
    }
    start(e, r, n) {
      return super.start(e, r, n), this;
    }
    _start(e, r, n) {
      this._loop ? r = cr(r, this._loopStart) : r = cr(r, 0);
      let o = this.toSeconds(r), i = n;
      n = cr(n, Math.max(this._buffer.duration - o, 0));
      let s = this.toSeconds(n);
      s = s / this._playbackRate, e = this.toSeconds(e);
      let a = new $n({ url: this._buffer, context: this.context, fadeIn: this.fadeIn, fadeOut: this.fadeOut, loop: this._loop, loopEnd: this._loopEnd, loopStart: this._loopStart, onended: this._onSourceEnd.bind(this), playbackRate: this._playbackRate }).connect(this.output);
      !this._loop && !this._synced && (this._state.cancel(e + s), this._state.setStateAtTime("stopped", e + s, { implicitEnd: true })), this._activeSources.add(a), this._loop && Ke(i) ? a.start(e, o) : a.start(e, o, s - this.toSeconds(this.fadeOut));
    }
    _stop(e) {
      let r = this.toSeconds(e);
      this._activeSources.forEach((n) => n.stop(r));
    }
    restart(e, r, n) {
      return super.restart(e, r, n), this;
    }
    _restart(e, r, n) {
      var o;
      (o = [...this._activeSources].pop()) === null || o === void 0 || o.stop(e), this._start(e, r, n);
    }
    seek(e, r) {
      let n = this.toSeconds(r);
      if (this._state.getValueAtTime(n) === "started") {
        let o = this.toSeconds(e);
        this._stop(n), this._start(n, o);
      }
      return this;
    }
    setLoopPoints(e, r) {
      return this.loopStart = e, this.loopEnd = r, this;
    }
    get loopStart() {
      return this._loopStart;
    }
    set loopStart(e) {
      this._loopStart = e, this.buffer.loaded && yt(this.toSeconds(e), 0, this.buffer.duration), this._activeSources.forEach((r) => {
        r.loopStart = e;
      });
    }
    get loopEnd() {
      return this._loopEnd;
    }
    set loopEnd(e) {
      this._loopEnd = e, this.buffer.loaded && yt(this.toSeconds(e), 0, this.buffer.duration), this._activeSources.forEach((r) => {
        r.loopEnd = e;
      });
    }
    get buffer() {
      return this._buffer;
    }
    set buffer(e) {
      this._buffer.set(e);
    }
    get loop() {
      return this._loop;
    }
    set loop(e) {
      if (this._loop !== e && (this._loop = e, this._activeSources.forEach((r) => {
        r.loop = e;
      }), e)) {
        let r = this._state.getNextState("stopped", this.now());
        r && this._state.cancel(r.time);
      }
    }
    get playbackRate() {
      return this._playbackRate;
    }
    set playbackRate(e) {
      this._playbackRate = e;
      let r = this.now(), n = this._state.getNextState("stopped", r);
      n && n.implicitEnd && (this._state.cancel(n.time), this._activeSources.forEach((o) => o.cancelStop())), this._activeSources.forEach((o) => {
        o.playbackRate.setValueAtTime(e, r);
      });
    }
    get reverse() {
      return this._buffer.reverse;
    }
    set reverse(e) {
      this._buffer.reverse = e;
    }
    get loaded() {
      return this._buffer.loaded;
    }
    dispose() {
      return super.dispose(), this._activeSources.forEach((e) => e.dispose()), this._activeSources.clear(), this._buffer.dispose(), this;
    }
  };
  Pt([tr(0)], $l.prototype, "fadeIn", void 0);
  Pt([tr(0)], $l.prototype, "fadeOut", void 0);
  var Gt = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["attack", "decay", "sustain", "release"]);
      super(e), this.name = "Envelope", this._sig = new ee({ context: this.context, value: 0 }), this.output = this._sig, this.input = void 0, this.attack = e.attack, this.decay = e.decay, this.sustain = e.sustain, this.release = e.release, this.attackCurve = e.attackCurve, this.releaseCurve = e.releaseCurve, this.decayCurve = e.decayCurve;
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { attack: 0.01, attackCurve: "linear", decay: 0.1, decayCurve: "exponential", release: 1, releaseCurve: "exponential", sustain: 0.5 });
    }
    get value() {
      return this.getValueAtTime(this.now());
    }
    _getCurve(e, r) {
      if (Dt(e)) return e;
      {
        let n;
        for (n in Wp) if (Wp[n][r] === e) return n;
        return e;
      }
    }
    _setCurve(e, r, n) {
      if (Dt(n) && Reflect.has(Wp, n)) {
        let o = Wp[n];
        Zr(o) ? e !== "_decayCurve" && (this[e] = o[r]) : this[e] = o;
      } else if (Fe(n) && e !== "_decayCurve") this[e] = n;
      else throw new Error("Envelope: invalid curve: " + n);
    }
    get attackCurve() {
      return this._getCurve(this._attackCurve, "In");
    }
    set attackCurve(e) {
      this._setCurve("_attackCurve", "In", e);
    }
    get releaseCurve() {
      return this._getCurve(this._releaseCurve, "Out");
    }
    set releaseCurve(e) {
      this._setCurve("_releaseCurve", "Out", e);
    }
    get decayCurve() {
      return this._getCurve(this._decayCurve, "Out");
    }
    set decayCurve(e) {
      this._setCurve("_decayCurve", "Out", e);
    }
    triggerAttack(e, r = 1) {
      this.log("triggerAttack", e, r), e = this.toSeconds(e);
      let o = this.toSeconds(this.attack), i = this.toSeconds(this.decay), s = this.getValueAtTime(e);
      if (s > 0) {
        let a = 1 / o;
        o = (1 - s) / a;
      }
      if (o < this.sampleTime) this._sig.cancelScheduledValues(e), this._sig.setValueAtTime(r, e);
      else if (this._attackCurve === "linear") this._sig.linearRampTo(r, o, e);
      else if (this._attackCurve === "exponential") this._sig.targetRampTo(r, o, e);
      else {
        this._sig.cancelAndHoldAtTime(e);
        let a = this._attackCurve;
        for (let l = 1; l < a.length; l++) if (a[l - 1] <= s && s <= a[l]) {
          a = this._attackCurve.slice(l), a[0] = s;
          break;
        }
        this._sig.setValueCurveAtTime(a, e, o, r);
      }
      if (i && this.sustain < 1) {
        let a = r * this.sustain, l = e + o;
        this.log("decay", l), this._decayCurve === "linear" ? this._sig.linearRampToValueAtTime(a, i + l) : this._sig.exponentialApproachValueAtTime(a, l, i);
      }
      return this;
    }
    triggerRelease(e) {
      this.log("triggerRelease", e), e = this.toSeconds(e);
      let r = this.getValueAtTime(e);
      if (r > 0) {
        let n = this.toSeconds(this.release);
        n < this.sampleTime ? this._sig.setValueAtTime(0, e) : this._releaseCurve === "linear" ? this._sig.linearRampTo(0, n, e) : this._releaseCurve === "exponential" ? this._sig.targetRampTo(0, n, e) : (U(Fe(this._releaseCurve), "releaseCurve must be either 'linear', 'exponential' or an array"), this._sig.cancelAndHoldAtTime(e), this._sig.setValueCurveAtTime(this._releaseCurve, e, n, r));
      }
      return this;
    }
    getValueAtTime(e) {
      return this._sig.getValueAtTime(e);
    }
    triggerAttackRelease(e, r, n = 1) {
      return r = this.toSeconds(r), this.triggerAttack(r, n), this.triggerRelease(r + this.toSeconds(e)), this;
    }
    cancel(e) {
      return this._sig.cancelScheduledValues(this.toSeconds(e)), this;
    }
    connect(e, r = 0, n = 0) {
      return $s(this, e, r, n), this;
    }
    asArray() {
      return ce(this, arguments, void 0, function* (e = 1024) {
        let r = e / this.context.sampleRate, n = new Tn(1, r, this.context.sampleRate), o = this.toSeconds(this.attack) + this.toSeconds(this.decay), i = o + this.toSeconds(this.release), s = i * 0.1, a = i + s, l = new this.constructor(Object.assign(this.get(), { attack: r * this.toSeconds(this.attack) / a, decay: r * this.toSeconds(this.decay) / a, release: r * this.toSeconds(this.release) / a, context: n }));
        return l._sig.toDestination(), l.triggerAttackRelease(r * (o + s) / a, 0), (yield n.render()).getChannelData(0);
      });
    }
    dispose() {
      return super.dispose(), this._sig.dispose(), this;
    }
  };
  Pt([tr(0)], Gt.prototype, "attack", void 0);
  Pt([tr(0)], Gt.prototype, "decay", void 0);
  Pt([zp(0, 1)], Gt.prototype, "sustain", void 0);
  Pt([tr(0)], Gt.prototype, "release", void 0);
  var Wp = (() => {
    let e, r, n = [];
    for (e = 0; e < 128; e++) n[e] = Math.sin(e / 127 * (Math.PI / 2));
    let o = [], i = 6.4;
    for (e = 0; e < 127; e++) {
      r = e / 127;
      let h = Math.sin(r * (Math.PI * 2) * i - Math.PI / 2) + 1;
      o[e] = h / 10 + r * 0.83;
    }
    o[127] = 1;
    let s = [], a = 5;
    for (e = 0; e < 128; e++) s[e] = Math.ceil(e / 127 * a) / a;
    let l = [];
    for (e = 0; e < 128; e++) r = e / 127, l[e] = 0.5 * (1 - Math.cos(Math.PI * r));
    let u = [];
    for (e = 0; e < 128; e++) {
      r = e / 127;
      let h = Math.pow(r, 3) * 4 + 0.2, f = Math.cos(h * Math.PI * 2 * r);
      u[e] = Math.abs(f * (1 - r));
    }
    function c(h) {
      let f = new Array(h.length);
      for (let m = 0; m < h.length; m++) f[m] = 1 - h[m];
      return f;
    }
    function p(h) {
      return h.slice(0).reverse();
    }
    return { bounce: { In: c(u), Out: u }, cosine: { In: n, Out: p(n) }, exponential: "exponential", linear: "linear", ripple: { In: o, Out: c(o) }, sine: { In: l, Out: c(l) }, step: { In: s, Out: c(s) } };
  })();
  var mr = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments);
      super(e), this._scheduledEvents = [], this._synced = false, this._original_triggerAttack = this.triggerAttack, this._original_triggerRelease = this.triggerRelease, this._syncedRelease = (r) => this._original_triggerRelease(r), this._volume = this.output = new Mr({ context: this.context, volume: e.volume }), this.volume = this._volume.volume, z(this, "volume");
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { volume: 0 });
    }
    sync() {
      return this._syncState() && (this._syncMethod("triggerAttack", 1), this._syncMethod("triggerRelease", 0), this.context.transport.on("stop", this._syncedRelease), this.context.transport.on("pause", this._syncedRelease), this.context.transport.on("loopEnd", this._syncedRelease)), this;
    }
    _syncState() {
      let e = false;
      return this._synced || (this._synced = true, e = true), e;
    }
    _syncMethod(e, r) {
      let n = this["_original_" + e] = this[e];
      this[e] = (...o) => {
        let i = o[r], s = this.context.transport.schedule((a) => {
          o[r] = a, n.apply(this, o);
        }, i);
        this._scheduledEvents.push(s);
      };
    }
    unsync() {
      return this._scheduledEvents.forEach((e) => this.context.transport.clear(e)), this._scheduledEvents = [], this._synced && (this._synced = false, this.triggerAttack = this._original_triggerAttack, this.triggerRelease = this._original_triggerRelease, this.context.transport.off("stop", this._syncedRelease), this.context.transport.off("pause", this._syncedRelease), this.context.transport.off("loopEnd", this._syncedRelease)), this;
    }
    triggerAttackRelease(e, r, n, o) {
      let i = this.toSeconds(n), s = this.toSeconds(r);
      return this.triggerAttack(e, i, o), this.triggerRelease(i + s), this;
    }
    dispose() {
      return super.dispose(), this._volume.dispose(), this.unsync(), this._scheduledEvents = [], this;
    }
  };
  var rr = class t extends mr {
    constructor() {
      let e = b(t.getDefaults(), arguments);
      super(e), this.portamento = e.portamento, this.onsilence = e.onsilence;
    }
    static getDefaults() {
      return Object.assign(mr.getDefaults(), { detune: 0, onsilence: Z, portamento: 0 });
    }
    triggerAttack(e, r, n = 1) {
      this.log("triggerAttack", e, r, n);
      let o = this.toSeconds(r);
      return this._triggerEnvelopeAttack(o, n), this.setNote(e, o), this;
    }
    triggerRelease(e) {
      this.log("triggerRelease", e);
      let r = this.toSeconds(e);
      return this._triggerEnvelopeRelease(r), this;
    }
    setNote(e, r) {
      let n = this.toSeconds(r), o = e instanceof zt ? e.toFrequency() : e;
      if (this.portamento > 0 && this.getLevelAtTime(n) > 0.05) {
        let i = this.toSeconds(this.portamento);
        this.frequency.exponentialRampTo(o, i, n);
      } else this.frequency.setValueAtTime(o, n);
      return this;
    }
  };
  Pt([tr(0)], rr.prototype, "portamento", void 0);
  var Js = class t extends Gt {
    constructor() {
      super(b(t.getDefaults(), arguments, ["attack", "decay", "sustain", "release"])), this.name = "AmplitudeEnvelope", this._gainNode = new X({ context: this.context, gain: 0 }), this.output = this._gainNode, this.input = this._gainNode, this._sig.connect(this._gainNode.gain), this.output = this._gainNode, this.input = this._gainNode;
    }
    dispose() {
      return super.dispose(), this._gainNode.dispose(), this;
    }
  };
  var on = class t extends rr {
    constructor() {
      let e = b(t.getDefaults(), arguments);
      super(e), this.name = "Synth", this.oscillator = new ki(Object.assign({ context: this.context, detune: e.detune, onstop: () => this.onsilence(this) }, e.oscillator)), this.frequency = this.oscillator.frequency, this.detune = this.oscillator.detune, this.envelope = new Js(Object.assign({ context: this.context }, e.envelope)), this.oscillator.chain(this.envelope, this.output), z(this, ["oscillator", "frequency", "detune", "envelope"]);
    }
    static getDefaults() {
      return Object.assign(rr.getDefaults(), { envelope: Object.assign(en(Gt.getDefaults(), Object.keys(L.getDefaults())), { attack: 5e-3, decay: 0.1, release: 1, sustain: 0.3 }), oscillator: Object.assign(en(ki.getDefaults(), [...Object.keys(ye.getDefaults()), "frequency", "detune"]), { type: "triangle" }) });
    }
    _triggerEnvelopeAttack(e, r) {
      if (this.envelope.triggerAttack(e, r), this.oscillator.start(e), this.envelope.sustain === 0) {
        let n = this.toSeconds(this.envelope.attack), o = this.toSeconds(this.envelope.decay);
        this.oscillator.stop(e + n + o);
      }
    }
    _triggerEnvelopeRelease(e) {
      this.envelope.triggerRelease(e), this.oscillator.stop(e + this.toSeconds(this.envelope.release));
    }
    getLevelAtTime(e) {
      return e = this.toSeconds(e), this.envelope.getValueAtTime(e);
    }
    dispose() {
      return super.dispose(), this.oscillator.dispose(), this.envelope.dispose(), this;
    }
  };
  var Ei = class t extends on {
    constructor() {
      let e = b(t.getDefaults(), arguments);
      super(e), this.name = "MembraneSynth", this.portamento = 0, this.pitchDecay = e.pitchDecay, this.octaves = e.octaves, z(this, ["oscillator", "envelope"]);
    }
    static getDefaults() {
      return Or(rr.getDefaults(), on.getDefaults(), { envelope: { attack: 1e-3, attackCurve: "exponential", decay: 0.4, release: 1.4, sustain: 0.01 }, octaves: 10, oscillator: { type: "sine" }, pitchDecay: 0.05 });
    }
    setNote(e, r) {
      let n = this.toSeconds(r), o = this.toFrequency(e instanceof zt ? e.toFrequency() : e), i = o * this.octaves;
      return this.oscillator.frequency.setValueAtTime(i, n), this.oscillator.frequency.exponentialRampToValueAtTime(o, n + this.toSeconds(this.pitchDecay)), this;
    }
    dispose() {
      return super.dispose(), this;
    }
  };
  Pt([zp(0)], Ei.prototype, "octaves", void 0);
  Pt([tr(0)], Ei.prototype, "pitchDecay", void 0);
  var hA = /* @__PURE__ */ new Set();
  function ta(t) {
    hA.add(t);
  }
  function Gp(t, e) {
    let r = `registerProcessor("${t}", ${e})`;
    hA.add(r);
  }
  var dM = `
	/**
	 * The base AudioWorkletProcessor for use in Tone.js. Works with the {@link ToneAudioWorklet}. 
	 */
	class ToneAudioWorkletProcessor extends AudioWorkletProcessor {

		constructor(options) {
			
			super(options);
			/**
			 * If the processor was disposed or not. Keep alive until it's disposed.
			 */
			this.disposed = false;
		   	/** 
			 * The number of samples in the processing block
			 */
			this.blockSize = 128;
			/**
			 * the sample rate
			 */
			this.sampleRate = sampleRate;

			this.port.onmessage = (event) => {
				// when it receives a dispose 
				if (event.data === "dispose") {
					this.disposed = true;
				}
			};
		}
	}
`;
  ta(dM);
  var gM = `
	/**
	 * Abstract class for a single input/output processor. 
	 * has a 'generate' function which processes one sample at a time
	 */
	class SingleIOProcessor extends ToneAudioWorkletProcessor {

		constructor(options) {
			super(Object.assign(options, {
				numberOfInputs: 1,
				numberOfOutputs: 1
			}));
			/**
			 * Holds the name of the parameter and a single value of that
			 * parameter at the current sample
			 * @type { [name: string]: number }
			 */
			this.params = {}
		}

		/**
		 * Generate an output sample from the input sample and parameters
		 * @abstract
		 * @param input number
		 * @param channel number
		 * @param parameters { [name: string]: number }
		 * @returns number
		 */
		generate(){}

		/**
		 * Update the private params object with the 
		 * values of the parameters at the given index
		 * @param parameters { [name: string]: Float32Array },
		 * @param index number
		 */
		updateParams(parameters, index) {
			for (const paramName in parameters) {
				const param = parameters[paramName];
				if (param.length > 1) {
					this.params[paramName] = parameters[paramName][index];
				} else {
					this.params[paramName] = parameters[paramName][0];
				}
			}
		}

		/**
		 * Process a single frame of the audio
		 * @param inputs Float32Array[][]
		 * @param outputs Float32Array[][]
		 */
		process(inputs, outputs, parameters) {
			const input = inputs[0];
			const output = outputs[0];
			// get the parameter values
			const channelCount = Math.max(input && input.length || 0, output.length);
			for (let sample = 0; sample < this.blockSize; sample++) {
				this.updateParams(parameters, sample);
				for (let channel = 0; channel < channelCount; channel++) {
					const inputSample = input && input.length ? input[channel][sample] : 0;
					output[channel][sample] = this.generate(inputSample, channel, this.params);
				}
			}
			return !this.disposed;
		}
	};
`;
  ta(gM);
  var xM = `
	/**
	 * A multichannel buffer for use within an AudioWorkletProcessor as a delay line
	 */
	class DelayLine {
		
		constructor(size, channels) {
			this.buffer = [];
			this.writeHead = []
			this.size = size;

			// create the empty channels
			for (let i = 0; i < channels; i++) {
				this.buffer[i] = new Float32Array(this.size);
				this.writeHead[i] = 0;
			}
		}

		/**
		 * Push a value onto the end
		 * @param channel number
		 * @param value number
		 */
		push(channel, value) {
			this.writeHead[channel] += 1;
			if (this.writeHead[channel] > this.size) {
				this.writeHead[channel] = 0;
			}
			this.buffer[channel][this.writeHead[channel]] = value;
		}

		/**
		 * Get the recorded value of the channel given the delay
		 * @param channel number
		 * @param delay number delay samples
		 */
		get(channel, delay) {
			let readHead = this.writeHead[channel] - Math.floor(delay);
			if (readHead < 0) {
				readHead += this.size;
			}
			return this.buffer[channel][readHead];
		}
	}
`;
  ta(xM);
  var fA = "feedback-comb-filter", yM = `
	class FeedbackCombFilterWorklet extends SingleIOProcessor {

		constructor(options) {
			super(options);
			this.delayLine = new DelayLine(this.sampleRate, options.channelCount || 2);
		}

		static get parameterDescriptors() {
			return [{
				name: "delayTime",
				defaultValue: 0.1,
				minValue: 0,
				maxValue: 1,
				automationRate: "k-rate"
			}, {
				name: "feedback",
				defaultValue: 0.5,
				minValue: 0,
				maxValue: 0.9999,
				automationRate: "k-rate"
			}];
		}

		generate(input, channel, parameters) {
			const delayedSample = this.delayLine.get(channel, parameters.delayTime * this.sampleRate);
			this.delayLine.push(channel, input + delayedSample * parameters.feedback);
			return delayedSample;
		}
	}
`;
  Gp(fA, yM);
  var Xl = class t extends mr {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["voice", "options"]);
      super(e), this.name = "PolySynth", this._availableVoices = [], this._activeVoices = [], this._voices = [], this._gcTimeout = -1, this._averageActiveVoices = 0, this._syncedRelease = (o) => this.releaseAll(o), U(!Ot(e.voice), "DEPRECATED: The polyphony count is no longer the first argument.");
      let r = e.voice.getDefaults();
      this.options = Object.assign(r, e.options), this.voice = e.voice, this.maxPolyphony = e.maxPolyphony, this._dummyVoice = this._getNextAvailableVoice();
      let n = this._voices.indexOf(this._dummyVoice);
      this._voices.splice(n, 1), this._gcTimeout = this.context.setInterval(this._collectGarbage.bind(this), 1);
    }
    static getDefaults() {
      return Object.assign(mr.getDefaults(), { maxPolyphony: 32, options: {}, voice: on });
    }
    get activeVoices() {
      return this._activeVoices.length;
    }
    _makeVoiceAvailable(e) {
      this._availableVoices.push(e);
      let r = this._activeVoices.findIndex((n) => n.voice === e);
      this._activeVoices.splice(r, 1);
    }
    _getNextAvailableVoice() {
      if (this._availableVoices.length) return this._availableVoices.shift();
      if (this._voices.length < this.maxPolyphony) {
        let e = new this.voice(Object.assign(this.options, { context: this.context, onsilence: this._makeVoiceAvailable.bind(this) }));
        return U(e instanceof rr, "Voice must extend Monophonic class"), e.connect(this.output), this._voices.push(e), e;
      } else vi("Max polyphony exceeded. Note dropped.");
    }
    _collectGarbage() {
      if (this._averageActiveVoices = Math.max(this._averageActiveVoices * 0.95, this.activeVoices), this._availableVoices.length && this._voices.length > Math.ceil(this._averageActiveVoices + 1)) {
        let e = this._availableVoices.shift(), r = this._voices.indexOf(e);
        this._voices.splice(r, 1), this.context.isOffline || e.dispose();
      }
    }
    _triggerAttack(e, r, n) {
      e.forEach((o) => {
        let i = new zl(this.context, o).toMidi(), s = this._getNextAvailableVoice();
        s && (s.triggerAttack(o, r, n), this._activeVoices.push({ midi: i, voice: s, released: false }), this.log("triggerAttack", o, r));
      });
    }
    _triggerRelease(e, r) {
      e.forEach((n) => {
        let o = new zl(this.context, n).toMidi(), i = this._activeVoices.find(({ midi: s, released: a }) => s === o && !a);
        i && (i.voice.triggerRelease(r), i.released = true, this.log("triggerRelease", n, r));
      });
    }
    _scheduleEvent(e, r, n, o) {
      U(!this.disposed, "Synth was already disposed"), n <= this.now() ? e === "attack" ? this._triggerAttack(r, n, o) : this._triggerRelease(r, n) : this.context.setTimeout(() => {
        this.disposed || this._scheduleEvent(e, r, n, o);
      }, n - this.now());
    }
    triggerAttack(e, r, n) {
      Array.isArray(e) || (e = [e]);
      let o = this.toSeconds(r);
      return this._scheduleEvent("attack", e, o, n), this;
    }
    triggerRelease(e, r) {
      Array.isArray(e) || (e = [e]);
      let n = this.toSeconds(r);
      return this._scheduleEvent("release", e, n), this;
    }
    triggerAttackRelease(e, r, n, o) {
      let i = this.toSeconds(n);
      if (this.triggerAttack(e, i, o), Fe(r)) {
        U(Fe(e), "If the duration is an array, the notes must also be an array"), e = e;
        for (let s = 0; s < e.length; s++) {
          let a = r[Math.min(s, r.length - 1)], l = this.toSeconds(a);
          U(l > 0, "The duration must be greater than 0"), this.triggerRelease(e[s], i + l);
        }
      } else {
        let s = this.toSeconds(r);
        U(s > 0, "The duration must be greater than 0"), this.triggerRelease(e, i + s);
      }
      return this;
    }
    sync() {
      return this._syncState() && (this._syncMethod("triggerAttack", 1), this._syncMethod("triggerRelease", 1), this.context.transport.on("stop", this._syncedRelease), this.context.transport.on("pause", this._syncedRelease), this.context.transport.on("loopEnd", this._syncedRelease)), this;
    }
    set(e) {
      let r = en(e, ["onsilence", "context"]);
      return this.options = Or(this.options, r), this._voices.forEach((n) => n.set(r)), this._dummyVoice.set(r), this;
    }
    get() {
      return this._dummyVoice.get();
    }
    releaseAll(e) {
      let r = this.toSeconds(e);
      return this._activeVoices.forEach(({ voice: n }) => {
        n.triggerRelease(r);
      }), this;
    }
    dispose() {
      return super.dispose(), this._dummyVoice.dispose(), this._voices.forEach((e) => e.dispose()), this._activeVoices = [], this._availableVoices = [], this.context.clearInterval(this._gcTimeout), this;
    }
  };
  var Hp = class t extends mr {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["urls", "onload", "baseUrl"], "urls");
      super(e), this.name = "Sampler", this._activeSources = /* @__PURE__ */ new Map();
      let r = {};
      Object.keys(e.urls).forEach((n) => {
        let o = parseInt(n, 10);
        if (U(Ll(n) || Ot(o) && isFinite(o), `url key is neither a note or midi pitch: ${n}`), Ll(n)) {
          let i = new zt(this.context, n).toMidi();
          r[i] = e.urls[n];
        } else Ot(o) && isFinite(o) && (r[o] = e.urls[o]);
      }), this._buffers = new Ys({ urls: r, onload: e.onload, baseUrl: e.baseUrl, onerror: e.onerror }), this.attack = e.attack, this.release = e.release, this.curve = e.curve, this._buffers.loaded && Promise.resolve().then(e.onload);
    }
    static getDefaults() {
      return Object.assign(mr.getDefaults(), { attack: 0, baseUrl: "", curve: "exponential", onload: Z, onerror: Z, release: 0.1, urls: {} });
    }
    _findClosest(e) {
      let n = 0;
      for (; n < 96; ) {
        if (this._buffers.has(e + n)) return -n;
        if (this._buffers.has(e - n)) return n;
        n++;
      }
      throw new Error(`No available buffers for note: ${e}`);
    }
    triggerAttack(e, r, n = 1) {
      return this.log("triggerAttack", e, r, n), Array.isArray(e) || (e = [e]), e.forEach((o) => {
        let i = Ng(new zt(this.context, o).toFrequency()), s = Math.round(i), a = i - s, l = this._findClosest(s), u = s - l, c = this._buffers.get(u), p = Ai(l + a), h = new $n({ url: c, context: this.context, curve: this.curve, fadeIn: this.attack, fadeOut: this.release, playbackRate: p }).connect(this.output);
        h.start(r, 0, c.duration / p, n), Fe(this._activeSources.get(s)) || this._activeSources.set(s, []), this._activeSources.get(s).push(h), h.onended = () => {
          if (this._activeSources && this._activeSources.has(s)) {
            let f = this._activeSources.get(s), m = f.indexOf(h);
            m !== -1 && f.splice(m, 1);
          }
        };
      }), this;
    }
    triggerRelease(e, r) {
      return this.log("triggerRelease", e, r), Array.isArray(e) || (e = [e]), e.forEach((n) => {
        let o = new zt(this.context, n).toMidi();
        if (this._activeSources.has(o) && this._activeSources.get(o).length) {
          let i = this._activeSources.get(o);
          r = this.toSeconds(r), i.forEach((s) => {
            s.stop(r);
          }), this._activeSources.set(o, []);
        }
      }), this;
    }
    releaseAll(e) {
      let r = this.toSeconds(e);
      return this._activeSources.forEach((n) => {
        for (; n.length; ) n.shift().stop(r);
      }), this;
    }
    sync() {
      return this._syncState() && (this._syncMethod("triggerAttack", 1), this._syncMethod("triggerRelease", 1)), this;
    }
    triggerAttackRelease(e, r, n, o = 1) {
      let i = this.toSeconds(n);
      return this.triggerAttack(e, i, o), Fe(r) ? (U(Fe(e), "notes must be an array when duration is array"), e.forEach((s, a) => {
        let l = r[Math.min(a, r.length - 1)];
        this.triggerRelease(s, i + this.toSeconds(l));
      })) : this.triggerRelease(e, i + this.toSeconds(r)), this;
    }
    add(e, r, n) {
      if (U(Ll(e) || isFinite(e), `note must be a pitch or midi: ${e}`), Ll(e)) {
        let o = new zt(this.context, e).toMidi();
        this._buffers.add(o, r, n);
      } else this._buffers.add(e, r, n);
      return this;
    }
    get loaded() {
      return this._buffers.loaded;
    }
    dispose() {
      return super.dispose(), this._buffers.dispose(), this._activeSources.forEach((e) => {
        e.forEach((r) => r.dispose());
      }), this._activeSources.clear(), this;
    }
  };
  Pt([tr(0)], Hp.prototype, "attack", void 0);
  Pt([tr(0)], Hp.prototype, "release", void 0);
  var Yl = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["pan"]);
      super(e), this.name = "Panner", this._panner = this.context.createStereoPanner(), this.input = this._panner, this.output = this._panner, this.pan = new ie({ context: this.context, param: this._panner.pan, value: e.pan, minValue: -1, maxValue: 1 }), this._panner.channelCount = e.channelCount, this._panner.channelCountMode = "explicit", z(this, "pan");
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { pan: 0, channelCount: 1 });
    }
    dispose() {
      return super.dispose(), this._panner.disconnect(), this.pan.dispose(), this;
    }
  };
  var gA = "bit-crusher", CM = `
	class BitCrusherWorklet extends SingleIOProcessor {

		static get parameterDescriptors() {
			return [{
				name: "bits",
				defaultValue: 12,
				minValue: 1,
				maxValue: 16,
				automationRate: 'k-rate'
			}];
		}

		generate(input, _channel, parameters) {
			const step = Math.pow(0.5, parameters.bits - 1);
			const val = step * Math.floor(input / step + 0.5);
			return val;
		}
	}
`;
  Gp(gA, CM);
  var yhe = [1557 / 44100, 1617 / 44100, 1491 / 44100, 1422 / 44100, 1277 / 44100, 1356 / 44100, 1188 / 44100, 1116 / 44100];
  var khe = [1687 / 25e3, 1601 / 25e3, 2053 / 25e3, 2251 / 25e3];
  var ra = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["solo"]);
      super(e), this.name = "Solo", this.input = this.output = new X({ context: this.context }), t._allSolos.has(this.context) || t._allSolos.set(this.context, /* @__PURE__ */ new Set()), t._allSolos.get(this.context).add(this), this.solo = e.solo;
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { solo: false });
    }
    get solo() {
      return this._isSoloed();
    }
    set solo(e) {
      e ? this._addSolo() : this._removeSolo(), t._allSolos.get(this.context).forEach((r) => r._updateSolo());
    }
    get muted() {
      return this.input.gain.value === 0;
    }
    _addSolo() {
      t._soloed.has(this.context) || t._soloed.set(this.context, /* @__PURE__ */ new Set()), t._soloed.get(this.context).add(this);
    }
    _removeSolo() {
      t._soloed.has(this.context) && t._soloed.get(this.context).delete(this);
    }
    _isSoloed() {
      return t._soloed.has(this.context) && t._soloed.get(this.context).has(this);
    }
    _noSolos() {
      return !t._soloed.has(this.context) || t._soloed.has(this.context) && t._soloed.get(this.context).size === 0;
    }
    _updateSolo() {
      this._isSoloed() ? this.input.gain.value = 1 : this._noSolos() ? this.input.gain.value = 1 : this.input.gain.value = 0;
    }
    dispose() {
      return super.dispose(), t._allSolos.get(this.context).delete(this), this._removeSolo(), this;
    }
  };
  ra._allSolos = /* @__PURE__ */ new Map();
  ra._soloed = /* @__PURE__ */ new Map();
  var Qp = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["pan", "volume"]);
      super(e), this.name = "PanVol", this._panner = this.input = new Yl({ context: this.context, pan: e.pan, channelCount: e.channelCount }), this.pan = this._panner.pan, this._volume = this.output = new Mr({ context: this.context, volume: e.volume }), this.volume = this._volume.volume, this._panner.connect(this._volume), this.mute = e.mute, z(this, ["pan", "volume"]);
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { mute: false, pan: 0, volume: 0, channelCount: 1 });
    }
    get mute() {
      return this._volume.mute;
    }
    set mute(e) {
      this._volume.mute = e;
    }
    dispose() {
      return super.dispose(), this._panner.dispose(), this.pan.dispose(), this._volume.dispose(), this.volume.dispose(), this;
    }
  };
  var Lg = class t extends L {
    constructor() {
      let e = b(t.getDefaults(), arguments, ["volume", "pan"]);
      super(e), this.name = "Channel", this._solo = this.input = new ra({ solo: e.solo, context: this.context }), this._panVol = this.output = new Qp({ context: this.context, pan: e.pan, volume: e.volume, mute: e.mute, channelCount: e.channelCount }), this.pan = this._panVol.pan, this.volume = this._panVol.volume, this._solo.connect(this._panVol), z(this, ["pan", "volume"]);
    }
    static getDefaults() {
      return Object.assign(L.getDefaults(), { pan: 0, volume: 0, mute: false, solo: false, channelCount: 1 });
    }
    get solo() {
      return this._solo.solo;
    }
    set solo(e) {
      this._solo.solo = e;
    }
    get muted() {
      return this._solo.muted || this.mute;
    }
    get mute() {
      return this._panVol.mute;
    }
    set mute(e) {
      this._panVol.mute = e;
    }
    _getBus(e) {
      return t.buses.has(e) || t.buses.set(e, new X({ context: this.context })), t.buses.get(e);
    }
    send(e, r = 0) {
      let n = this._getBus(e), o = new X({ context: this.context, units: "decibels", gain: r });
      return this.connect(o), o.connect(n), o;
    }
    receive(e) {
      return this._getBus(e).connect(this), this;
    }
    dispose() {
      return super.dispose(), this._panVol.dispose(), this.pan.dispose(), this.volume.dispose(), this._solo.dispose(), this;
    }
  };
  Lg.buses = /* @__PURE__ */ new Map();
  function Kp() {
    return Ge().now();
  }
  var cxe = Ge().transport;
  var yA = Ge().destination, pxe = Ge().destination;
  var hxe = Ge().listener;
  var fxe = Ge().draw;
  var mxe = Ge();
  var Lu = se(Io(), 1), ln = se(xe(), 1);
  var SA = se(xe(), 1), na = (0, SA.createContext)({});
  var TA = se(xe(), 1);
  function oa(t) {
    let e = (0, TA.useRef)(null);
    return e.current === null && (e.current = t()), e.current;
  }
  var Jp = se(xe(), 1);
  var AA = typeof window < "u";
  var eh = AA ? Jp.useLayoutEffect : Jp.useEffect;
  var $x = se(Io(), 1), Rk = se(xe(), 1), Fu = se(xe(), 1);
  var CA = se(xe(), 1), Lo = (0, CA.createContext)(null);
  var Mk = se(Io(), 1);
  function bi(t, e) {
    t.indexOf(e) === -1 && t.push(e);
  }
  function Bo(t, e) {
    let r = t.indexOf(e);
    r > -1 && t.splice(r, 1);
  }
  var ft = (t, e, r) => r > e ? e : r < t ? t : r;
  var Yn = () => {
  }, Pr = () => {
  };
  var Ht = {};
  var Ql = (t) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(t);
  var Kl = (t) => typeof t == "object" && t !== null;
  var Zl = (t) => /^0[^.\s]+$/u.test(t);
  function Jl(t) {
    let e;
    return () => (e === void 0 && (e = t()), e);
  }
  var Le = (t) => t;
  var sn = (...t) => t.reduce((e, r) => (n) => r(e(n)));
  var Cn = (t, e, r) => {
    let n = e - t;
    return n ? (r - t) / n : 1;
  };
  var Qn = class {
    constructor() {
      this.subscriptions = [];
    }
    add(e) {
      return bi(this.subscriptions, e), () => Bo(this.subscriptions, e);
    }
    notify(e, r, n) {
      let o = this.subscriptions.length;
      if (o) if (o === 1) this.subscriptions[0](e, r, n);
      else for (let i = 0; i < o; i++) {
        let s = this.subscriptions[i];
        s && s(e, r, n);
      }
    }
    getSize() {
      return this.subscriptions.length;
    }
    clear() {
      this.subscriptions.length = 0;
    }
  };
  var Ze = (t) => t * 1e3, _t = (t) => t / 1e3;
  var eu = (t, e) => e ? t * (1e3 / e) : 0;
  var kA = (t, e, r) => (((1 - 3 * r + 3 * e) * t + (3 * r - 6 * e)) * t + 3 * e) * t, BM = 1e-7, jM = 12;
  function qM(t, e, r, n, o) {
    let i, s, a = 0;
    do
      s = e + (r - e) / 2, i = kA(s, n, o) - t, i > 0 ? r = s : e = s;
    while (Math.abs(i) > BM && ++a < jM);
    return s;
  }
  function jo(t, e, r, n) {
    if (t === e && r === n) return Le;
    let o = (i) => qM(i, 0, 1, t, r);
    return (i) => i === 0 || i === 1 ? i : kA(o(i), e, n);
  }
  var th = (t) => (e) => e <= 0.5 ? t(2 * e) / 2 : (2 - t(2 * (1 - e))) / 2;
  var rh = (t) => (e) => 1 - t(1 - e);
  var nh = jo(0.33, 1.53, 0.69, 0.99), ia = rh(nh), tu = th(ia);
  var ru = (t) => t >= 1 ? 1 : (t *= 2) < 1 ? 0.5 * ia(t) : 0.5 * (2 - Math.pow(2, -10 * (t - 1)));
  var nu = (t) => 1 - Math.sin(Math.acos(t)), ou = rh(nu), iu = th(nu);
  var Bg = jo(0.42, 0, 1, 1), jg = jo(0, 0, 0.58, 1), su = jo(0.42, 0, 0.58, 1);
  var qg = (t) => Array.isArray(t) && typeof t[0] != "number";
  var au = (t) => Array.isArray(t) && typeof t[0] == "number";
  var EA = { linear: Le, easeIn: Bg, easeInOut: su, easeOut: jg, circIn: nu, circInOut: iu, circOut: ou, backIn: ia, backInOut: tu, backOut: nh, anticipate: ru }, zM = (t) => typeof t == "string", oh = (t) => {
    if (au(t)) {
      Pr(t.length === 4, "Cubic bezier arrays must contain four numerical values.", "cubic-bezier-length");
      let [e, r, n, o] = t;
      return jo(e, r, n, o);
    } else if (zM(t)) return Pr(EA[t] !== void 0, `Invalid easing type '${t}'`, "invalid-easing-type"), EA[t];
    return t;
  };
  var lu = ["setup", "read", "resolveKeyframes", "preUpdate", "update", "preRender", "render", "postRender"];
  var dr = { value: null, addProjectionMetrics: null };
  function bA(t, e) {
    let r = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), o = false, i = false, s = /* @__PURE__ */ new WeakSet(), a = { delta: 0, timestamp: 0, isProcessing: false }, l = 0;
    function u(p) {
      s.has(p) && (c.schedule(p), t()), l++, p(a);
    }
    let c = { schedule: (p, h = false, f = false) => {
      let x = f && o ? r : n;
      return h && s.add(p), x.add(p), p;
    }, cancel: (p) => {
      n.delete(p), s.delete(p);
    }, process: (p) => {
      if (a = p, o) {
        i = true;
        return;
      }
      o = true;
      let h = r;
      r = n, n = h, r.forEach(u), e && dr.value && dr.value.frameloop[e].push(l), l = 0, r.clear(), o = false, i && (i = false, c.process(p));
    } };
    return c;
  }
  var WM = 40;
  function ih(t, e) {
    let r = false, n = true, o = { delta: 0, timestamp: 0, isProcessing: false }, i = () => r = true, s = lu.reduce((y, S) => (y[S] = bA(i, e ? S : void 0), y), {}), { setup: a, read: l, resolveKeyframes: u, preUpdate: c, update: p, preRender: h, render: f, postRender: m } = s, x = () => {
      let y = Ht.useManualTiming, S = y ? o.timestamp : performance.now();
      r = false, y || (o.delta = n ? 1e3 / 60 : Math.max(Math.min(S - o.timestamp, WM), 1)), o.timestamp = S, o.isProcessing = true, a.process(o), l.process(o), u.process(o), c.process(o), p.process(o), h.process(o), f.process(o), m.process(o), o.isProcessing = false, r && e && (n = false, t(x));
    }, _ = () => {
      r = true, n = true, o.isProcessing || t(x);
    };
    return { schedule: lu.reduce((y, S) => {
      let v = s[S];
      return y[S] = (T, A = false, w = false) => (r || _(), v.schedule(T, A, w)), y;
    }, {}), cancel: (y) => {
      for (let S = 0; S < lu.length; S++) s[lu[S]].cancel(y);
    }, state: o, steps: s };
  }
  var { schedule: ne, cancel: nr, state: He, steps: uu } = ih(typeof requestAnimationFrame < "u" ? requestAnimationFrame : Le, true);
  var sh;
  function UM() {
    sh = void 0;
  }
  var Be = { now: () => (sh === void 0 && Be.set(He.isProcessing || Ht.useManualTiming ? He.timestamp : performance.now()), sh), set: (t) => {
    sh = t, queueMicrotask(UM);
  } };
  var kn = { layout: 0, mainThread: 0, waapi: 0 };
  var NA = (t) => (e) => typeof e == "string" && e.startsWith(t), ah = NA("--"), GM = NA("var(--"), sa = (t) => GM(t) ? HM.test(t.split("/*")[0].trim()) : false, HM = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
  function zg(t) {
    return typeof t != "string" ? false : t.split("/*")[0].includes("var(--");
  }
  var En = { test: (t) => typeof t == "number", parse: parseFloat, transform: (t) => t }, Kn = { ...En, transform: (t) => ft(0, 1, t) }, cu = { ...En, default: 1 };
  var qo = (t) => Math.round(t * 1e5) / 1e5;
  var aa = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
  function OA(t) {
    return t == null;
  }
  var DA = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu;
  var la = (t, e) => (r) => !!(typeof r == "string" && DA.test(r) && r.startsWith(t) || e && !OA(r) && Object.prototype.hasOwnProperty.call(r, e)), lh = (t, e, r) => (n) => {
    if (typeof n != "string") return n;
    let [o, i, s, a] = n.match(aa);
    return { [t]: parseFloat(o), [e]: parseFloat(i), [r]: parseFloat(s), alpha: a !== void 0 ? parseFloat(a) : 1 };
  };
  var $M = (t) => ft(0, 255, t), Wg = { ...En, transform: (t) => Math.round($M(t)) }, bn = { test: la("rgb", "red"), parse: lh("red", "green", "blue"), transform: ({ red: t, green: e, blue: r, alpha: n = 1 }) => "rgba(" + Wg.transform(t) + ", " + Wg.transform(e) + ", " + Wg.transform(r) + ", " + qo(Kn.transform(n)) + ")" };
  function XM(t) {
    let e = "", r = "", n = "", o = "";
    return t.length > 5 ? (e = t.substring(1, 3), r = t.substring(3, 5), n = t.substring(5, 7), o = t.substring(7, 9)) : (e = t.substring(1, 2), r = t.substring(2, 3), n = t.substring(3, 4), o = t.substring(4, 5), e += e, r += r, n += n, o += o), { red: parseInt(e, 16), green: parseInt(r, 16), blue: parseInt(n, 16), alpha: o ? parseInt(o, 16) / 255 : 1 };
  }
  var pu = { test: la("#"), parse: XM, transform: bn.transform };
  var hu = (t) => ({ test: (e) => typeof e == "string" && e.endsWith(t) && e.split(" ").length === 1, parse: parseFloat, transform: (e) => `${e}${t}` }), Rr = hu("deg"), Rt = hu("%"), G = hu("px"), Ug = hu("vh"), Gg = hu("vw"), uh = { ...Rt, parse: (t) => Rt.parse(t) / 100, transform: (t) => Rt.transform(t * 100) };
  var zo = { test: la("hsl", "hue"), parse: lh("hue", "saturation", "lightness"), transform: ({ hue: t, saturation: e, lightness: r, alpha: n = 1 }) => "hsla(" + Math.round(t) + ", " + Rt.transform(qo(e)) + ", " + Rt.transform(qo(r)) + ", " + qo(Kn.transform(n)) + ")" };
  var Oe = { test: (t) => bn.test(t) || pu.test(t) || zo.test(t), parse: (t) => bn.test(t) ? bn.parse(t) : zo.test(t) ? zo.parse(t) : pu.parse(t), transform: (t) => typeof t == "string" ? t : t.hasOwnProperty("red") ? bn.transform(t) : zo.transform(t), getAnimatableNone: (t) => {
    let e = Oe.parse(t);
    return e.alpha = 0, Oe.transform(e);
  } };
  var MA = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
  function YM(t) {
    var e, r;
    return isNaN(t) && typeof t == "string" && (((e = t.match(aa)) == null ? void 0 : e.length) || 0) + (((r = t.match(MA)) == null ? void 0 : r.length) || 0) > 0;
  }
  var RA = "number", VA = "color", QM = "var", KM = "var(", PA = "${}", ZM = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
  function Wo(t) {
    let e = t.toString(), r = [], n = { color: [], number: [], var: [] }, o = [], i = 0, a = e.replace(ZM, (l) => (Oe.test(l) ? (n.color.push(i), o.push(VA), r.push(Oe.parse(l))) : l.startsWith(KM) ? (n.var.push(i), o.push(QM), r.push(l)) : (n.number.push(i), o.push(RA), r.push(parseFloat(l))), ++i, PA)).split(PA);
    return { values: r, split: a, indexes: n, types: o };
  }
  function JM(t) {
    return Wo(t).values;
  }
  function FA({ split: t, types: e }) {
    let r = t.length;
    return (n) => {
      let o = "";
      for (let i = 0; i < r; i++) if (o += t[i], n[i] !== void 0) {
        let s = e[i];
        s === RA ? o += qo(n[i]) : s === VA ? o += Oe.transform(n[i]) : o += n[i];
      }
      return o;
    };
  }
  function eP(t) {
    return FA(Wo(t));
  }
  var tP = (t) => typeof t == "number" ? 0 : Oe.test(t) ? Oe.getAnimatableNone(t) : t, rP = (t, e) => typeof t == "number" ? e != null && e.trim().endsWith("/") ? t : 0 : tP(t);
  function nP(t) {
    let e = Wo(t);
    return FA(e)(e.values.map((n, o) => rP(n, e.split[o])));
  }
  var mt = { test: YM, parse: JM, createTransformer: eP, getAnimatableNone: nP };
  function Hg(t, e, r) {
    return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? t + (e - t) * 6 * r : r < 1 / 2 ? e : r < 2 / 3 ? t + (e - t) * (2 / 3 - r) * 6 : t;
  }
  function IA({ hue: t, saturation: e, lightness: r, alpha: n }) {
    t /= 360, e /= 100, r /= 100;
    let o = 0, i = 0, s = 0;
    if (!e) o = i = s = r;
    else {
      let a = r < 0.5 ? r * (1 + e) : r + e - r * e, l = 2 * r - a;
      o = Hg(l, a, t + 1 / 3), i = Hg(l, a, t), s = Hg(l, a, t - 1 / 3);
    }
    return { red: Math.round(o * 255), green: Math.round(i * 255), blue: Math.round(s * 255), alpha: n };
  }
  function ua(t, e) {
    return (r) => r > 0 ? e : t;
  }
  var oe = (t, e, r) => t + (e - t) * r;
  var $g = (t, e, r) => {
    let n = t * t, o = r * (e * e - n) + n;
    return o < 0 ? 0 : Math.sqrt(o);
  }, oP = [pu, bn, zo], iP = (t) => oP.find((e) => e.test(t));
  function LA(t) {
    let e = iP(t);
    if (Yn(!!e, `'${t}' is not an animatable color. Use the equivalent color code instead.`, "color-not-animatable"), !e) return false;
    let r = e.parse(t);
    return e === zo && (r = IA(r)), r;
  }
  var Xg = (t, e) => {
    let r = LA(t), n = LA(e);
    if (!r || !n) return ua(t, e);
    let o = { ...r };
    return (i) => (o.red = $g(r.red, n.red, i), o.green = $g(r.green, n.green, i), o.blue = $g(r.blue, n.blue, i), o.alpha = oe(r.alpha, n.alpha, i), bn.transform(o));
  };
  var ch = /* @__PURE__ */ new Set(["none", "hidden"]);
  function BA(t, e) {
    return ch.has(t) ? (r) => r <= 0 ? t : e : (r) => r >= 1 ? e : t;
  }
  function sP(t, e) {
    return (r) => oe(t, e, r);
  }
  function ph(t) {
    return typeof t == "number" ? sP : typeof t == "string" ? sa(t) ? ua : Oe.test(t) ? Xg : uP : Array.isArray(t) ? jA : typeof t == "object" ? Oe.test(t) ? Xg : aP : ua;
  }
  function jA(t, e) {
    let r = [...t], n = r.length, o = t.map((i, s) => ph(i)(i, e[s]));
    return (i) => {
      for (let s = 0; s < n; s++) r[s] = o[s](i);
      return r;
    };
  }
  function aP(t, e) {
    let r = { ...t, ...e }, n = {};
    for (let o in r) t[o] !== void 0 && e[o] !== void 0 && (n[o] = ph(t[o])(t[o], e[o]));
    return (o) => {
      for (let i in n) r[i] = n[i](o);
      return r;
    };
  }
  function lP(t, e) {
    let r = [], n = { color: 0, var: 0, number: 0 };
    for (let o = 0; o < e.values.length; o++) {
      let i = e.types[o], s = t.indexes[i][n[i]], a = t.values[s] ?? 0;
      r[o] = a, n[i]++;
    }
    return r;
  }
  var uP = (t, e) => {
    let r = mt.createTransformer(e), n = Wo(t), o = Wo(e);
    return n.indexes.var.length === o.indexes.var.length && n.indexes.color.length === o.indexes.color.length && n.indexes.number.length >= o.indexes.number.length ? ch.has(t) && !o.values.length || ch.has(e) && !n.values.length ? BA(t, e) : sn(jA(lP(n, o), o.values), r) : (Yn(true, `Complex values '${t}' and '${e}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`, "complex-values-different"), ua(t, e));
  };
  function hh(t, e, r) {
    return typeof t == "number" && typeof e == "number" && typeof r == "number" ? oe(t, e, r) : ph(t)(t, e);
  }
  var qA = (t) => {
    let e = ({ timestamp: r }) => t(r);
    return { start: (r = true) => ne.update(e, r), stop: () => nr(e), now: () => He.isProcessing ? He.timestamp : Be.now() };
  };
  var fh = (t, e, r = 10) => {
    let n = "", o = Math.max(Math.round(e / r), 2);
    for (let i = 0; i < o; i++) n += Math.round(t(i / (o - 1)) * 1e4) / 1e4 + ", ";
    return `linear(${n.substring(0, n.length - 2)})`;
  };
  function ca(t) {
    let e = 0, r = 50, n = t.next(e);
    for (; !n.done && e < 2e4; ) e += r, n = t.next(e);
    return e >= 2e4 ? 1 / 0 : e;
  }
  function zA(t, e = 100, r) {
    let n = r({ ...t, keyframes: [0, e] }), o = Math.min(ca(n), 2e4);
    return { type: "keyframes", ease: (i) => n.next(o * i).value / e, duration: _t(o) };
  }
  var je = { stiffness: 100, damping: 10, mass: 1, velocity: 0, duration: 800, bounce: 0.3, visualDuration: 0.3, restSpeed: { granular: 0.01, default: 2 }, restDelta: { granular: 5e-3, default: 0.5 }, minDuration: 0.01, maxDuration: 10, minDamping: 0.05, maxDamping: 1 };
  function Kg(t, e) {
    return t * Math.sqrt(1 - e * e);
  }
  var cP = 12;
  function pP(t, e, r) {
    let n = r;
    for (let o = 1; o < cP; o++) n = n - t(n) / e(n);
    return n;
  }
  var Qg = 1e-3;
  function hP({ duration: t = je.duration, bounce: e = je.bounce, velocity: r = je.velocity, mass: n = je.mass }) {
    let o, i;
    Yn(t <= Ze(je.maxDuration), "Spring duration must be 10 seconds or less", "spring-duration-limit");
    let s = 1 - e;
    s = ft(je.minDamping, je.maxDamping, s), t = ft(je.minDuration, je.maxDuration, _t(t)), s < 1 ? (o = (u) => {
      let c = u * s, p = c * t, h = c - r, f = Kg(u, s), m = Math.exp(-p);
      return Qg - h / f * m;
    }, i = (u) => {
      let p = u * s * t, h = p * r + r, f = Math.pow(s, 2) * Math.pow(u, 2) * t, m = Math.exp(-p), x = Kg(Math.pow(u, 2), s);
      return (-o(u) + Qg > 0 ? -1 : 1) * ((h - f) * m) / x;
    }) : (o = (u) => {
      let c = Math.exp(-u * t), p = (u - r) * t + 1;
      return -Qg + c * p;
    }, i = (u) => {
      let c = Math.exp(-u * t), p = (r - u) * (t * t);
      return c * p;
    });
    let a = 5 / t, l = pP(o, i, a);
    if (t = Ze(t), isNaN(l)) return { stiffness: je.stiffness, damping: je.damping, duration: t };
    {
      let u = Math.pow(l, 2) * n;
      return { stiffness: u, damping: s * 2 * Math.sqrt(n * u), duration: t };
    }
  }
  var fP = ["duration", "bounce"], mP = ["stiffness", "damping", "mass"];
  function WA(t, e) {
    return e.some((r) => t[r] !== void 0);
  }
  function dP(t) {
    let e = { velocity: je.velocity, stiffness: je.stiffness, damping: je.damping, mass: je.mass, isResolvedFromDuration: false, ...t };
    if (!WA(t, mP) && WA(t, fP)) if (e.velocity = 0, t.visualDuration) {
      let r = t.visualDuration, n = 2 * Math.PI / (r * 1.2), o = n * n, i = 2 * ft(0.05, 1, 1 - (t.bounce || 0)) * Math.sqrt(o);
      e = { ...e, mass: je.mass, stiffness: o, damping: i };
    } else {
      let r = hP({ ...t, velocity: 0 });
      e = { ...e, ...r, mass: je.mass }, e.isResolvedFromDuration = true;
    }
    return e;
  }
  function pa(t = je.visualDuration, e = je.bounce) {
    let r = typeof t != "object" ? { visualDuration: t, keyframes: [0, 1], bounce: e } : t, { restSpeed: n, restDelta: o } = r, i = r.keyframes[0], s = r.keyframes[r.keyframes.length - 1], a = { done: false, value: i }, { stiffness: l, damping: u, mass: c, duration: p, velocity: h, isResolvedFromDuration: f } = dP({ ...r, velocity: -_t(r.velocity || 0) }), m = h || 0, x = u / (2 * Math.sqrt(l * c)), _ = s - i, d = _t(Math.sqrt(l / c)), g = Math.abs(_) < 5;
    n || (n = g ? je.restSpeed.granular : je.restSpeed.default), o || (o = g ? je.restDelta.granular : je.restDelta.default);
    let y, S, v, T, A, w;
    if (x < 1) v = Kg(d, x), T = (m + x * d * _) / v, y = (k) => {
      let D = Math.exp(-x * d * k);
      return s - D * (T * Math.sin(v * k) + _ * Math.cos(v * k));
    }, A = x * d * T + _ * v, w = x * d * _ - T * v, S = (k) => Math.exp(-x * d * k) * (A * Math.sin(v * k) + w * Math.cos(v * k));
    else if (x === 1) {
      y = (D) => s - Math.exp(-d * D) * (_ + (m + d * _) * D);
      let k = m + d * _;
      S = (D) => Math.exp(-d * D) * (d * k * D - m);
    } else {
      let k = d * Math.sqrt(x * x - 1);
      y = (B) => {
        let I = Math.exp(-x * d * B), C = Math.min(k * B, 300);
        return s - I * ((m + x * d * _) * Math.sinh(C) + k * _ * Math.cosh(C)) / k;
      };
      let D = (m + x * d * _) / k, M = x * d * D - _ * k, q = x * d * _ - D * k;
      S = (B) => {
        let I = Math.exp(-x * d * B), C = Math.min(k * B, 300);
        return I * (M * Math.sinh(C) + q * Math.cosh(C));
      };
    }
    let N = { calculatedDuration: f && p || null, velocity: (k) => Ze(S(k)), next: (k) => {
      if (!f && x < 1) {
        let M = Math.exp(-x * d * k), q = Math.sin(v * k), B = Math.cos(v * k), I = s - M * (T * q + _ * B), C = Ze(M * (A * q + w * B));
        return a.done = Math.abs(C) <= n && Math.abs(s - I) <= o, a.value = a.done ? s : I, a;
      }
      let D = y(k);
      if (f) a.done = k >= p;
      else {
        let M = Ze(S(k));
        a.done = Math.abs(M) <= n && Math.abs(s - D) <= o;
      }
      return a.value = a.done ? s : D, a;
    }, toString: () => {
      let k = Math.min(ca(N), 2e4), D = fh((M) => N.next(k * M).value, k, 30);
      return k + "ms " + D;
    }, toTransition: () => {
    } };
    return N;
  }
  pa.applyToOptions = (t) => {
    let e = zA(t, 100, pa);
    return t.ease = e.ease, t.duration = Ze(e.duration), t.type = "keyframes", t;
  };
  var gP = 5;
  function mh(t, e, r) {
    let n = Math.max(e - gP, 0);
    return eu(r - t(n), e - n);
  }
  function fu({ keyframes: t, velocity: e = 0, power: r = 0.8, timeConstant: n = 325, bounceDamping: o = 10, bounceStiffness: i = 500, modifyTarget: s, min: a, max: l, restDelta: u = 0.5, restSpeed: c }) {
    let p = t[0], h = { done: false, value: p }, f = (w) => a !== void 0 && w < a || l !== void 0 && w > l, m = (w) => a === void 0 ? l : l === void 0 || Math.abs(a - w) < Math.abs(l - w) ? a : l, x = r * e, _ = p + x, d = s === void 0 ? _ : s(_);
    d !== _ && (x = d - p);
    let g = (w) => -x * Math.exp(-w / n), y = (w) => d + g(w), S = (w) => {
      let N = g(w), k = y(w);
      h.done = Math.abs(N) <= u, h.value = h.done ? d : k;
    }, v, T, A = (w) => {
      f(h.value) && (v = w, T = pa({ keyframes: [h.value, m(h.value)], velocity: mh(y, w, h.value), damping: o, stiffness: i, restDelta: u, restSpeed: c }));
    };
    return A(0), { calculatedDuration: null, next: (w) => {
      let N = false;
      return !T && v === void 0 && (N = true, S(w), A(w)), v !== void 0 && w >= v ? T.next(w - v) : (!N && S(w), h);
    } };
  }
  function xP(t, e, r) {
    let n = [], o = r || Ht.mix || hh, i = t.length - 1;
    for (let s = 0; s < i; s++) {
      let a = o(t[s], t[s + 1]);
      if (e) {
        let l = Array.isArray(e) ? e[s] || Le : e;
        a = sn(l, a);
      }
      n.push(a);
    }
    return n;
  }
  function UA(t, e, { clamp: r = true, ease: n, mixer: o } = {}) {
    let i = t.length;
    if (Pr(i === e.length, "Both input and output ranges must be the same length", "range-length"), i === 1) return () => e[0];
    if (i === 2 && e[0] === e[1]) return () => e[1];
    let s = t[0] === t[1];
    t[0] > t[i - 1] && (t = [...t].reverse(), e = [...e].reverse());
    let a = xP(e, n, o), l = a.length, u = (c) => {
      if (s && c < t[0]) return e[0];
      let p = 0;
      if (l > 1) for (; p < t.length - 2 && !(c < t[p + 1]); p++) ;
      let h = Cn(t[p], t[p + 1], c);
      return a[p](h);
    };
    return r ? (c) => u(ft(t[0], t[i - 1], c)) : u;
  }
  function GA(t, e) {
    let r = t[t.length - 1];
    for (let n = 1; n <= e; n++) {
      let o = Cn(0, e, n);
      t.push(oe(r, 1, o));
    }
  }
  function HA(t) {
    let e = [0];
    return GA(e, t.length - 1), e;
  }
  function $A(t, e) {
    return t.map((r) => r * e);
  }
  function yP(t, e) {
    return t.map(() => e || su).splice(0, t.length - 1);
  }
  function Ni({ duration: t = 300, keyframes: e, times: r, ease: n = "easeInOut" }) {
    let o = qg(n) ? n.map(oh) : oh(n), i = { done: false, value: e[0] }, s = $A(r && r.length === e.length ? r : HA(e), t), a = UA(s, e, { ease: Array.isArray(o) ? o : yP(e, o) });
    return { calculatedDuration: t, next: (l) => (i.value = a(l), i.done = l >= t, i) };
  }
  var _P = (t) => t !== null;
  function Uo(t, { repeat: e, repeatType: r = "loop" }, n, o = 1) {
    let i = t.filter(_P), a = o < 0 || e && r !== "loop" && e % 2 === 1 ? 0 : i.length - 1;
    return !a || n === void 0 ? i[a] : n;
  }
  var vP = { decay: fu, inertia: fu, tween: Ni, keyframes: Ni, spring: pa };
  function dh(t) {
    typeof t.type == "string" && (t.type = vP[t.type]);
  }
  var Go = class {
    constructor() {
      this.updateFinished();
    }
    get finished() {
      return this._finished;
    }
    updateFinished() {
      this._finished = new Promise((e) => {
        this.resolve = e;
      });
    }
    notifyFinished() {
      this.resolve();
    }
    then(e, r) {
      return this.finished.then(e, r);
    }
  };
  var wP = (t) => t / 100, Zn = class extends Go {
    constructor(e) {
      super(), this.state = "idle", this.startTime = null, this.isStopped = false, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = { done: false, value: void 0 }, this.stop = () => {
        var n, o;
        let { motionValue: r } = this.options;
        r && r.updatedAt !== Be.now() && this.tick(Be.now()), this.isStopped = true, this.state !== "idle" && (this.teardown(), (o = (n = this.options).onStop) == null || o.call(n));
      }, kn.mainThread++, this.options = e, this.initAnimation(), this.play(), e.autoplay === false && this.pause();
    }
    initAnimation() {
      let { options: e } = this;
      dh(e);
      let { type: r = Ni, repeat: n = 0, repeatDelay: o = 0, repeatType: i, velocity: s = 0 } = e, { keyframes: a } = e, l = r || Ni;
      l !== Ni && typeof a[0] != "number" && (this.mixKeyframes = sn(wP, hh(a[0], a[1])), a = [0, 100]);
      let u = l({ ...e, keyframes: a });
      i === "mirror" && (this.mirroredGenerator = l({ ...e, keyframes: [...a].reverse(), velocity: -s })), u.calculatedDuration === null && (u.calculatedDuration = ca(u));
      let { calculatedDuration: c } = u;
      this.calculatedDuration = c, this.resolvedDuration = c + o, this.totalDuration = this.resolvedDuration * (n + 1) - o, this.generator = u;
    }
    updateTime(e) {
      let r = Math.round(e - this.startTime) * this.playbackSpeed;
      this.holdTime !== null ? this.currentTime = this.holdTime : this.currentTime = r;
    }
    tick(e, r = false) {
      let { generator: n, totalDuration: o, mixKeyframes: i, mirroredGenerator: s, resolvedDuration: a, calculatedDuration: l } = this;
      if (this.startTime === null) return n.next(0);
      let { delay: u = 0, keyframes: c, repeat: p, repeatType: h, repeatDelay: f, type: m, onUpdate: x, finalKeyframe: _ } = this.options;
      this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - o / this.speed, this.startTime)), r ? this.currentTime = e : this.updateTime(e);
      let d = this.currentTime - u * (this.playbackSpeed >= 0 ? 1 : -1), g = this.playbackSpeed >= 0 ? d < 0 : d > o;
      this.currentTime = Math.max(d, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = o);
      let y = this.currentTime, S = n;
      if (p) {
        let w = Math.min(this.currentTime, o) / a, N = Math.floor(w), k = w % 1;
        !k && w >= 1 && (k = 1), k === 1 && N--, N = Math.min(N, p + 1), !!(N % 2) && (h === "reverse" ? (k = 1 - k, f && (k -= f / a)) : h === "mirror" && (S = s)), y = ft(0, 1, k) * a;
      }
      let v;
      g ? (this.delayState.value = c[0], v = this.delayState) : v = S.next(y), i && !g && (v.value = i(v.value));
      let { done: T } = v;
      !g && l !== null && (T = this.playbackSpeed >= 0 ? this.currentTime >= o : this.currentTime <= 0);
      let A = this.holdTime === null && (this.state === "finished" || this.state === "running" && T);
      return A && m !== fu && (v.value = Uo(c, this.options, _, this.speed)), x && x(v.value), A && this.finish(), v;
    }
    then(e, r) {
      return this.finished.then(e, r);
    }
    get duration() {
      return _t(this.calculatedDuration);
    }
    get iterationDuration() {
      let { delay: e = 0 } = this.options || {};
      return this.duration + _t(e);
    }
    get time() {
      return _t(this.currentTime);
    }
    set time(e) {
      e = Ze(e), this.currentTime = e, this.startTime === null || this.holdTime !== null || this.playbackSpeed === 0 ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.playbackSpeed), this.driver ? this.driver.start(false) : (this.startTime = 0, this.state = "paused", this.holdTime = e, this.tick(e));
    }
    getGeneratorVelocity() {
      let e = this.currentTime;
      if (e <= 0) return this.options.velocity || 0;
      if (this.generator.velocity) return this.generator.velocity(e);
      let r = this.generator.next(e).value;
      return mh((n) => this.generator.next(n).value, e, r);
    }
    get speed() {
      return this.playbackSpeed;
    }
    set speed(e) {
      let r = this.playbackSpeed !== e;
      r && this.driver && this.updateTime(Be.now()), this.playbackSpeed = e, r && this.driver && (this.time = _t(this.currentTime));
    }
    play() {
      var o, i;
      if (this.isStopped) return;
      let { driver: e = qA, startTime: r } = this.options;
      this.driver || (this.driver = e((s) => this.tick(s))), (i = (o = this.options).onPlay) == null || i.call(o);
      let n = this.driver.now();
      this.state === "finished" ? (this.updateFinished(), this.startTime = n) : this.holdTime !== null ? this.startTime = n - this.holdTime : this.startTime || (this.startTime = r ?? n), this.state === "finished" && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start();
    }
    pause() {
      this.state = "paused", this.updateTime(Be.now()), this.holdTime = this.currentTime;
    }
    complete() {
      this.state !== "running" && this.play(), this.state = "finished", this.holdTime = null;
    }
    finish() {
      var e, r;
      this.notifyFinished(), this.teardown(), this.state = "finished", (r = (e = this.options).onComplete) == null || r.call(e);
    }
    cancel() {
      var e, r;
      this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), (r = (e = this.options).onCancel) == null || r.call(e);
    }
    teardown() {
      this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null, kn.mainThread--;
    }
    stopDriver() {
      this.driver && (this.driver.stop(), this.driver = void 0);
    }
    sample(e) {
      return this.startTime = 0, this.tick(e, true);
    }
    attachTimeline(e) {
      var r;
      return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), (r = this.driver) == null || r.stop(), e.observe(this);
    }
  };
  function XA(t) {
    for (let e = 1; e < t.length; e++) t[e] ?? (t[e] = t[e - 1]);
  }
  var Oi = (t) => t * 180 / Math.PI, Zg = (t) => {
    let e = Oi(Math.atan2(t[1], t[0]));
    return Jg(e);
  }, SP = { x: 4, y: 5, translateX: 4, translateY: 5, scaleX: 0, scaleY: 3, scale: (t) => (Math.abs(t[0]) + Math.abs(t[3])) / 2, rotate: Zg, rotateZ: Zg, skewX: (t) => Oi(Math.atan(t[1])), skewY: (t) => Oi(Math.atan(t[2])), skew: (t) => (Math.abs(t[1]) + Math.abs(t[2])) / 2 }, Jg = (t) => (t = t % 360, t < 0 && (t += 360), t), YA = Zg, QA = (t) => Math.sqrt(t[0] * t[0] + t[1] * t[1]), KA = (t) => Math.sqrt(t[4] * t[4] + t[5] * t[5]), TP = { x: 12, y: 13, z: 14, translateX: 12, translateY: 13, translateZ: 14, scaleX: QA, scaleY: KA, scale: (t) => (QA(t) + KA(t)) / 2, rotateX: (t) => Jg(Oi(Math.atan2(t[6], t[5]))), rotateY: (t) => Jg(Oi(Math.atan2(-t[2], t[0]))), rotateZ: YA, rotate: YA, skewX: (t) => Oi(Math.atan(t[4])), skewY: (t) => Oi(Math.atan(t[1])), skew: (t) => (Math.abs(t[1]) + Math.abs(t[4])) / 2 };
  function gh(t) {
    return t.includes("scale") ? 1 : 0;
  }
  function xh(t, e) {
    if (!t || t === "none") return gh(e);
    let r = t.match(/^matrix3d\(([-\d.e\s,]+)\)$/u), n, o;
    if (r) n = TP, o = r;
    else {
      let a = t.match(/^matrix\(([-\d.e\s,]+)\)$/u);
      n = SP, o = a;
    }
    if (!o) return gh(e);
    let i = n[e], s = o[1].split(",").map(AP);
    return typeof i == "function" ? i(s) : s[i];
  }
  var ZA = (t, e) => {
    let { transform: r = "none" } = getComputedStyle(t);
    return xh(r, e);
  };
  function AP(t) {
    return parseFloat(t.trim());
  }
  var Nn = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"], Vr = /* @__PURE__ */ new Set([...Nn, "pathRotation"]);
  var ex = (t) => t === En || t === G, CP = /* @__PURE__ */ new Set(["x", "y", "z"]), kP = Nn.filter((t) => !CP.has(t));
  function JA(t) {
    let e = [];
    return kP.forEach((r) => {
      let n = t.getValue(r);
      n !== void 0 && (e.push([r, n.get()]), n.set(r.startsWith("scale") ? 1 : 0));
    }), e;
  }
  var Jn = { width: ({ x: t }, { paddingLeft: e = "0", paddingRight: r = "0", boxSizing: n }) => {
    let o = t.max - t.min;
    return n === "border-box" ? o : o - parseFloat(e) - parseFloat(r);
  }, height: ({ y: t }, { paddingTop: e = "0", paddingBottom: r = "0", boxSizing: n }) => {
    let o = t.max - t.min;
    return n === "border-box" ? o : o - parseFloat(e) - parseFloat(r);
  }, top: (t, { top: e }) => parseFloat(e), left: (t, { left: e }) => parseFloat(e), bottom: ({ y: t }, { top: e }) => parseFloat(e) + (t.max - t.min), right: ({ x: t }, { left: e }) => parseFloat(e) + (t.max - t.min), x: (t, { transform: e }) => xh(e, "x"), y: (t, { transform: e }) => xh(e, "y") };
  Jn.translateX = Jn.x;
  Jn.translateY = Jn.y;
  var Di = /* @__PURE__ */ new Set(), tx = false, rx = false, nx = false;
  function eC() {
    if (rx) {
      let t = Array.from(Di).filter((n) => n.needsMeasurement), e = new Set(t.map((n) => n.element)), r = /* @__PURE__ */ new Map();
      e.forEach((n) => {
        let o = JA(n);
        o.length && (r.set(n, o), n.render());
      }), t.forEach((n) => n.measureInitialState()), e.forEach((n) => {
        n.render();
        let o = r.get(n);
        o && o.forEach(([i, s]) => {
          var a;
          (a = n.getValue(i)) == null || a.set(s);
        });
      }), t.forEach((n) => n.measureEndState()), t.forEach((n) => {
        n.suspendedScrollY !== void 0 && window.scrollTo(0, n.suspendedScrollY);
      });
    }
    rx = false, tx = false, Di.forEach((t) => t.complete(nx)), Di.clear();
  }
  function tC() {
    Di.forEach((t) => {
      t.readKeyframes(), t.needsMeasurement && (rx = true);
    });
  }
  function rC() {
    nx = true, tC(), eC(), nx = false;
  }
  var Ho = class {
    constructor(e, r, n, o, i, s = false) {
      this.state = "pending", this.isAsync = false, this.needsMeasurement = false, this.unresolvedKeyframes = [...e], this.onComplete = r, this.name = n, this.motionValue = o, this.element = i, this.isAsync = s;
    }
    scheduleResolve() {
      this.state = "scheduled", this.isAsync ? (Di.add(this), tx || (tx = true, ne.read(tC), ne.resolveKeyframes(eC))) : (this.readKeyframes(), this.complete());
    }
    readKeyframes() {
      let { unresolvedKeyframes: e, name: r, element: n, motionValue: o } = this;
      if (e[0] === null) {
        let i = o == null ? void 0 : o.get(), s = e[e.length - 1];
        if (i !== void 0) e[0] = i;
        else if (n && r) {
          let a = n.readValue(r, s);
          a != null && (e[0] = a);
        }
        e[0] === void 0 && (e[0] = s), o && i === void 0 && o.set(e[0]);
      }
      XA(e);
    }
    setFinalKeyframe() {
    }
    measureInitialState() {
    }
    renderEndStyles() {
    }
    measureEndState() {
    }
    complete(e = false) {
      this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e), Di.delete(this);
    }
    cancel() {
      this.state === "scheduled" && (Di.delete(this), this.state = "pending");
    }
    resume() {
      this.state === "pending" && this.scheduleResolve();
    }
  };
  var nC = (t) => t.startsWith("--");
  function yh(t, e, r) {
    nC(e) ? t.style.setProperty(e, r) : t.style[e] = r;
  }
  var oC = {};
  function _h(t, e) {
    let r = Jl(t);
    return () => oC[e] ?? r();
  }
  var iC = _h(() => window.ScrollTimeline !== void 0, "scrollTimeline");
  var vh = _h(() => {
    try {
      document.createElement("div").animate({ opacity: 0 }, { easing: "linear(0, 1)" });
    } catch {
      return false;
    }
    return true;
  }, "linearEasing");
  var Mi = ([t, e, r, n]) => `cubic-bezier(${t}, ${e}, ${r}, ${n})`;
  var ox = { linear: "linear", ease: "ease", easeIn: "ease-in", easeOut: "ease-out", easeInOut: "ease-in-out", circIn: Mi([0, 0.65, 0.55, 1]), circOut: Mi([0.55, 0, 1, 0.45]), backIn: Mi([0.31, 0.01, 0.66, -0.59]), backOut: Mi([0.33, 1.53, 0.69, 0.99]) };
  function ix(t, e) {
    if (t) return typeof t == "function" ? vh() ? fh(t, e) : "ease-out" : au(t) ? Mi(t) : Array.isArray(t) ? t.map((r) => ix(r, e) || ox.easeOut) : ox[t];
  }
  function sC(t, e, r, { delay: n = 0, duration: o = 300, repeat: i = 0, repeatType: s = "loop", ease: a = "easeOut", times: l } = {}, u = void 0) {
    let c = { [e]: r };
    l && (c.offset = l);
    let p = ix(a, o);
    Array.isArray(p) && (c.easing = p), dr.value && kn.waapi++;
    let h = { delay: n, duration: o, easing: Array.isArray(p) ? "linear" : p, fill: "both", iterations: i + 1, direction: s === "reverse" ? "alternate" : "normal" };
    u && (h.pseudoElement = u);
    let f = t.animate(c, h);
    return dr.value && f.finished.finally(() => {
      kn.waapi--;
    }), f;
  }
  function wh(t) {
    return typeof t == "function" && "applyToOptions" in t;
  }
  function aC({ type: t, ...e }) {
    return wh(t) && vh() ? t.applyToOptions(e) : (e.duration ?? (e.duration = 300), e.ease ?? (e.ease = "easeOut"), e);
  }
  var ha = class extends Go {
    constructor(e) {
      if (super(), this.finishedTime = null, this.isStopped = false, this.manualStartTime = null, !e) return;
      let { element: r, name: n, keyframes: o, pseudoElement: i, allowFlatten: s = false, finalKeyframe: a, onComplete: l } = e;
      this.isPseudoElement = !!i, this.allowFlatten = s, this.options = e, Pr(typeof e.type != "string", `Mini animate() doesn't support "type" as a string.`, "mini-spring");
      let u = aC(e);
      this.animation = sC(r, n, o, u, i), u.autoplay === false && this.animation.pause(), this.animation.onfinish = () => {
        if (this.finishedTime = this.time, !i) {
          let c = Uo(o, this.options, a, this.speed);
          this.updateMotionValue && this.updateMotionValue(c), yh(r, n, c), this.animation.cancel();
        }
        l == null || l(), this.notifyFinished();
      };
    }
    play() {
      this.isStopped || (this.manualStartTime = null, this.animation.play(), this.state === "finished" && this.updateFinished());
    }
    pause() {
      this.animation.pause();
    }
    complete() {
      var e, r;
      (r = (e = this.animation).finish) == null || r.call(e);
    }
    cancel() {
      try {
        this.animation.cancel();
      } catch {
      }
    }
    stop() {
      if (this.isStopped) return;
      this.isStopped = true;
      let { state: e } = this;
      e === "idle" || e === "finished" || (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel());
    }
    commitStyles() {
      var r, n, o;
      let e = (r = this.options) == null ? void 0 : r.element;
      !this.isPseudoElement && (e != null && e.isConnected) && ((o = (n = this.animation).commitStyles) == null || o.call(n));
    }
    get duration() {
      var r, n;
      let e = ((n = (r = this.animation.effect) == null ? void 0 : r.getComputedTiming) == null ? void 0 : n.call(r).duration) || 0;
      return _t(Number(e));
    }
    get iterationDuration() {
      let { delay: e = 0 } = this.options || {};
      return this.duration + _t(e);
    }
    get time() {
      return _t(Number(this.animation.currentTime) || 0);
    }
    set time(e) {
      let r = this.finishedTime !== null;
      this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = Ze(e), r && this.animation.pause();
    }
    get speed() {
      return this.animation.playbackRate;
    }
    set speed(e) {
      e < 0 && (this.finishedTime = null), this.animation.playbackRate = e;
    }
    get state() {
      return this.finishedTime !== null ? "finished" : this.animation.playState;
    }
    get startTime() {
      return this.manualStartTime ?? Number(this.animation.startTime);
    }
    set startTime(e) {
      this.manualStartTime = this.animation.startTime = e;
    }
    attachTimeline({ timeline: e, rangeStart: r, rangeEnd: n, observe: o }) {
      var i;
      return this.allowFlatten && ((i = this.animation.effect) == null || i.updateTiming({ easing: "linear" })), this.animation.onfinish = null, e && iC() ? (this.animation.timeline = e, r && (this.animation.rangeStart = r), n && (this.animation.rangeEnd = n), Le) : o(this);
    }
  };
  var lC = { anticipate: ru, backInOut: tu, circInOut: iu };
  function EP(t) {
    return t in lC;
  }
  function uC(t) {
    typeof t.ease == "string" && EP(t.ease) && (t.ease = lC[t.ease]);
  }
  var sx = 10, Sh = class extends ha {
    constructor(e) {
      uC(e), dh(e), super(e), e.startTime !== void 0 && e.autoplay !== false && (this.startTime = e.startTime), this.options = e;
    }
    updateMotionValue(e) {
      let { motionValue: r, onUpdate: n, onComplete: o, element: i, ...s } = this.options;
      if (!r) return;
      if (e !== void 0) {
        r.set(e);
        return;
      }
      let a = new Zn({ ...s, autoplay: false }), l = Math.max(sx, Be.now() - this.startTime), u = ft(0, sx, l - sx), c = a.sample(l).value, { name: p } = this.options;
      i && p && yh(i, p, c), r.setWithVelocity(a.sample(Math.max(0, l - u)).value, c, u), a.stop();
    }
  };
  var ax = (t, e) => e === "zIndex" ? false : !!(typeof t == "number" || Array.isArray(t) || typeof t == "string" && (mt.test(t) || t === "0") && !t.startsWith("url("));
  function bP(t) {
    let e = t[0];
    if (t.length === 1) return true;
    for (let r = 0; r < t.length; r++) if (t[r] !== e) return true;
  }
  function cC(t, e, r, n) {
    let o = t[0];
    if (o === null) return false;
    if (e === "display" || e === "visibility") return true;
    let i = t[t.length - 1], s = ax(o, e), a = ax(i, e);
    return Yn(s === a, `You are trying to animate ${e} from "${o}" to "${i}". "${s ? i : o}" is not an animatable value.`, "value-not-animatable"), !s || !a ? false : bP(t) || (r === "spring" || wh(r)) && n;
  }
  function mu(t) {
    t.duration = 0, t.type = "keyframes";
  }
  var Th = /* @__PURE__ */ new Set(["opacity", "clipPath", "filter", "transform"]);
  var NP = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;
  function pC(t) {
    for (let e = 0; e < t.length; e++) if (typeof t[e] == "string" && NP.test(t[e])) return true;
    return false;
  }
  var OP = /* @__PURE__ */ new Set(["color", "backgroundColor", "outlineColor", "fill", "stroke", "borderColor", "borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"]), DP = Jl(() => Object.hasOwnProperty.call(Element.prototype, "animate"));
  function hC(t) {
    var p;
    let { motionValue: e, name: r, repeatDelay: n, repeatType: o, damping: i, type: s, keyframes: a } = t;
    if (!(((p = e == null ? void 0 : e.owner) == null ? void 0 : p.current) instanceof HTMLElement)) return false;
    let { onUpdate: u, transformTemplate: c } = e.owner.getProps();
    return DP() && r && (Th.has(r) || OP.has(r) && pC(a)) && (r !== "transform" || !c) && !u && !n && o !== "mirror" && i !== 0 && s !== "inertia";
  }
  var MP = 40, Ah = class extends Go {
    constructor({ autoplay: e = true, delay: r = 0, type: n = "keyframes", repeat: o = 0, repeatDelay: i = 0, repeatType: s = "loop", keyframes: a, name: l, motionValue: u, element: c, ...p }) {
      var m;
      super(), this.stop = () => {
        var x, _;
        this._animation && (this._animation.stop(), (x = this.stopTimeline) == null || x.call(this)), (_ = this.keyframeResolver) == null || _.cancel();
      }, this.createdAt = Be.now();
      let h = { autoplay: e, delay: r, type: n, repeat: o, repeatDelay: i, repeatType: s, name: l, motionValue: u, element: c, ...p }, f = (c == null ? void 0 : c.KeyframeResolver) || Ho;
      this.keyframeResolver = new f(a, (x, _, d) => this.onKeyframesResolved(x, _, h, !d), l, u, c), (m = this.keyframeResolver) == null || m.scheduleResolve();
    }
    onKeyframesResolved(e, r, n, o) {
      var d, g;
      this.keyframeResolver = void 0;
      let { name: i, type: s, velocity: a, delay: l, isHandoff: u, onUpdate: c } = n;
      this.resolvedAt = Be.now();
      let p = true;
      cC(e, i, s, a) || (p = false, (Ht.instantAnimations || !l) && (c == null || c(Uo(e, n, r))), e[0] = e[e.length - 1], mu(n), n.repeat = 0);
      let f = { startTime: o ? this.resolvedAt ? this.resolvedAt - this.createdAt > MP ? this.resolvedAt : this.createdAt : this.createdAt : void 0, finalKeyframe: r, ...n, keyframes: e }, m = p && !u && hC(f), x = (g = (d = f.motionValue) == null ? void 0 : d.owner) == null ? void 0 : g.current, _;
      if (m) try {
        _ = new Sh({ ...f, element: x });
      } catch {
        _ = new Zn(f);
      }
      else _ = new Zn(f);
      _.finished.then(() => {
        this.notifyFinished();
      }).catch(Le), this.pendingTimeline && (this.stopTimeline = _.attachTimeline(this.pendingTimeline), this.pendingTimeline = void 0), this._animation = _;
    }
    get finished() {
      return this._animation ? this.animation.finished : this._finished;
    }
    then(e, r) {
      return this.finished.finally(e).then(() => {
      });
    }
    get animation() {
      var e;
      return this._animation || ((e = this.keyframeResolver) == null || e.resume(), rC()), this._animation;
    }
    get duration() {
      return this.animation.duration;
    }
    get iterationDuration() {
      return this.animation.iterationDuration;
    }
    get time() {
      return this.animation.time;
    }
    set time(e) {
      this.animation.time = e;
    }
    get speed() {
      return this.animation.speed;
    }
    get state() {
      return this.animation.state;
    }
    set speed(e) {
      this.animation.speed = e;
    }
    get startTime() {
      return this.animation.startTime;
    }
    attachTimeline(e) {
      return this._animation ? this.stopTimeline = this.animation.attachTimeline(e) : this.pendingTimeline = e, () => this.stop();
    }
    play() {
      this.animation.play();
    }
    pause() {
      this.animation.pause();
    }
    complete() {
      this.animation.complete();
    }
    cancel() {
      var e;
      this._animation && this.animation.cancel(), (e = this.keyframeResolver) == null || e.cancel();
    }
  };
  function Ch(t, e, r, n = 0, o = 1) {
    let i = Array.from(t).sort((u, c) => u.sortNodePosition(c)).indexOf(e), s = t.size, a = (s - 1) * n;
    return typeof r == "function" ? r(i, s) : o === 1 ? i * n : a - i * n;
  }
  var fC = 30, PP = (t) => !isNaN(parseFloat(t)), mC = { current: void 0 }, lx = class {
    constructor(e, r = {}) {
      this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (n) => {
        var i;
        let o = Be.now();
        if (this.updatedAt !== o && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(n), this.current !== this.prev && ((i = this.events.change) == null || i.notify(this.current), this.dependents)) for (let s of this.dependents) s.dirty();
      }, this.hasAnimated = false, this.setCurrent(e), this.owner = r.owner;
    }
    setCurrent(e) {
      this.current = e, this.updatedAt = Be.now(), this.canTrackVelocity === null && e !== void 0 && (this.canTrackVelocity = PP(this.current));
    }
    setPrevFrameValue(e = this.current) {
      this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt;
    }
    onChange(e) {
      return this.on("change", e);
    }
    on(e, r) {
      this.events[e] || (this.events[e] = new Qn());
      let n = this.events[e].add(r);
      return e === "change" ? () => {
        n(), ne.read(() => {
          this.events.change.getSize() || this.stop();
        });
      } : n;
    }
    clearListeners() {
      for (let e in this.events) this.events[e].clear();
    }
    attach(e, r) {
      this.passiveEffect = e, this.stopPassiveEffect = r;
    }
    set(e) {
      this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e);
    }
    setWithVelocity(e, r, n) {
      this.set(r), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - n;
    }
    jump(e, r = true) {
      this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, r && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
    }
    dirty() {
      var e;
      (e = this.events.change) == null || e.notify(this.current);
    }
    addDependent(e) {
      this.dependents || (this.dependents = /* @__PURE__ */ new Set()), this.dependents.add(e);
    }
    removeDependent(e) {
      this.dependents && this.dependents.delete(e);
    }
    get() {
      return mC.current && mC.current.push(this), this.current;
    }
    getPrevious() {
      return this.prev;
    }
    getVelocity() {
      let e = Be.now();
      if (!this.canTrackVelocity || this.prevFrameValue === void 0 || e - this.updatedAt > fC) return 0;
      let r = Math.min(this.updatedAt - this.prevUpdatedAt, fC);
      return eu(parseFloat(this.current) - parseFloat(this.prevFrameValue), r);
    }
    start(e) {
      return this.stop(), new Promise((r) => {
        this.hasAnimated = true, this.animation = e(r), this.events.animationStart && this.events.animationStart.notify();
      }).then(() => {
        this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation();
      });
    }
    stop() {
      this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation();
    }
    isAnimating() {
      return !!this.animation;
    }
    clearAnimation() {
      delete this.animation;
    }
    destroy() {
      var e, r;
      (e = this.dependents) == null || e.clear(), (r = this.events.destroy) == null || r.notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect();
    }
  };
  function an(t, e) {
    return new lx(t, e);
  }
  function kh(t, e) {
    if (t != null && t.inherit && e) {
      let { inherit: r, ...n } = t;
      return { ...e, ...n };
    }
    return t;
  }
  function fa(t, e) {
    let r = (t == null ? void 0 : t[e]) ?? (t == null ? void 0 : t.default) ?? t;
    return r !== t ? kh(r, t) : r;
  }
  var RP = { type: "spring", stiffness: 500, damping: 25, restSpeed: 10 }, VP = (t) => ({ type: "spring", stiffness: 550, damping: t === 0 ? 2 * Math.sqrt(550) : 30, restSpeed: 10 }), FP = { type: "keyframes", duration: 0.8 }, IP = { type: "keyframes", ease: [0.25, 0.1, 0.35, 1], duration: 0.3 }, dC = (t, { keyframes: e }) => e.length > 2 ? FP : Vr.has(t) ? t.startsWith("scale") ? VP(e[1]) : RP : IP;
  var LP = /* @__PURE__ */ new Set(["when", "delay", "delayChildren", "staggerChildren", "staggerDirection", "repeat", "repeatType", "repeatDelay", "from", "elapsed"]);
  function gC(t) {
    for (let e in t) if (!LP.has(e)) return true;
    return false;
  }
  var Pi = (t, e, r, n = {}, o, i) => (s) => {
    let a = fa(n, t) || {}, l = a.delay || n.delay || 0, { elapsed: u = 0 } = n;
    u = u - Ze(l);
    let c = { keyframes: Array.isArray(r) ? r : [null, r], ease: "easeOut", velocity: e.getVelocity(), ...a, delay: -u, onUpdate: (h) => {
      e.set(h), a.onUpdate && a.onUpdate(h);
    }, onComplete: () => {
      s(), a.onComplete && a.onComplete();
    }, name: t, motionValue: e, element: i ? void 0 : o };
    gC(a) || Object.assign(c, dC(t, c)), c.duration && (c.duration = Ze(c.duration)), c.repeatDelay && (c.repeatDelay = Ze(c.repeatDelay)), c.from !== void 0 && (c.keyframes[0] = c.from);
    let p = false;
    if ((c.type === false || c.duration === 0 && !c.repeatDelay) && (mu(c), c.delay === 0 && (p = true)), (Ht.instantAnimations || Ht.skipAnimations || o != null && o.shouldSkipAnimations || a.skipAnimations) && (p = true, mu(c), c.delay = 0), c.allowFlatten = !a.type && !a.ease, p && !i && e.get() !== void 0) {
      let h = Uo(c.keyframes, a);
      if (h !== void 0) {
        ne.update(() => {
          c.onUpdate(h), c.onComplete();
        });
        return;
      }
    }
    return a.isSync ? new Zn(c) : new Ah(c);
  };
  var BP = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
  function jP(t) {
    let e = BP.exec(t);
    if (!e) return [,];
    let [, r, n, o] = e;
    return [`--${r ?? n}`, o];
  }
  var qP = 4;
  function ux(t, e, r = 1) {
    Pr(r <= qP, `Max CSS variable fallback depth detected in property "${t}". This may indicate a circular fallback dependency.`, "max-css-var-depth");
    let [n, o] = jP(t);
    if (!n) return;
    let i = window.getComputedStyle(e).getPropertyValue(n);
    if (i) {
      let s = i.trim();
      return Ql(s) ? parseFloat(s) : s;
    }
    return sa(o) ? ux(o, e, r + 1) : o;
  }
  function xC(t) {
    let e = [{}, {}];
    return t == null || t.values.forEach((r, n) => {
      e[0][n] = r.get(), e[1][n] = r.getVelocity();
    }), e;
  }
  function Ri(t, e, r, n) {
    if (typeof e == "function") {
      let [o, i] = xC(n);
      e = e(r !== void 0 ? r : t.custom, o, i);
    }
    if (typeof e == "string" && (e = t.variants && t.variants[e]), typeof e == "function") {
      let [o, i] = xC(n);
      e = e(r !== void 0 ? r : t.custom, o, i);
    }
    return e;
  }
  function gr(t, e, r) {
    let n = t.getProps();
    return Ri(n, e, r !== void 0 ? r : n.custom, t);
  }
  var Eh = /* @__PURE__ */ new Set(["width", "height", "top", "left", "right", "bottom", ...Nn]);
  var du = (t) => Array.isArray(t);
  function zP(t, e, r) {
    t.hasValue(e) ? t.getValue(e).set(r) : t.addValue(e, an(r));
  }
  function WP(t) {
    return du(t) ? t[t.length - 1] || 0 : t;
  }
  function yC(t, e) {
    let r = gr(t, e), { transitionEnd: n = {}, transition: o = {}, ...i } = r || {};
    i = { ...i, ...n };
    for (let s in i) {
      let a = WP(i[s]);
      zP(t, s, a);
    }
  }
  var ve = (t) => !!(t && t.getVelocity);
  function _C(t) {
    return !!(ve(t) && t.add);
  }
  function ma(t, e) {
    let r = t.getValue("willChange");
    if (_C(r)) return r.add(e);
    if (!r && Ht.WillChange) {
      let n = new Ht.WillChange("auto");
      t.addValue("willChange", n), n.add(e);
    }
  }
  function da(t) {
    return t.replace(/([A-Z])/g, (e) => `-${e.toLowerCase()}`);
  }
  var vC = "framerAppearId", gu = "data-" + da(vC);
  function bh(t) {
    return t.props[gu];
  }
  function UP({ protectedKeys: t, needsAnimating: e }, r) {
    let n = t.hasOwnProperty(r) && e[r] !== true;
    return e[r] = false, n;
  }
  function Nh(t, e, { delay: r = 0, transitionOverride: n, type: o } = {}) {
    let { transition: i, transitionEnd: s, ...a } = e, l = t.getDefaultTransition();
    i = i ? kh(i, l) : l;
    let u = i == null ? void 0 : i.reduceMotion, c = i == null ? void 0 : i.skipAnimations;
    n && (i = n);
    let p = [], h = o && t.animationState && t.animationState.getState()[o], f = i == null ? void 0 : i.path;
    f && f.animateVisualElement(t, a, i, r, p);
    for (let m in a) {
      let x = t.getValue(m, t.latestValues[m] ?? null), _ = a[m];
      if (_ === void 0 || h && UP(h, m)) continue;
      let d = { delay: r, ...fa(i || {}, m) };
      c && (d.skipAnimations = true);
      let g = x.get();
      if (g !== void 0 && !x.isAnimating() && !Array.isArray(_) && _ === g && !d.velocity) {
        ne.update(() => x.set(_));
        continue;
      }
      let y = false;
      if (window.MotionHandoffAnimation) {
        let T = bh(t);
        if (T) {
          let A = window.MotionHandoffAnimation(T, m, ne);
          A !== null && (d.startTime = A, y = true);
        }
      }
      ma(t, m);
      let S = u ?? t.shouldReduceMotion;
      x.start(Pi(m, x, _, S && Eh.has(m) ? { type: false } : d, t, y));
      let v = x.animation;
      v && p.push(v);
    }
    if (s) {
      let m = () => ne.update(() => {
        s && yC(t, s);
      });
      p.length ? Promise.all(p).then(m) : m();
    }
    return p;
  }
  function Oh(t, e, r = {}) {
    var l;
    let n = gr(t, e, r.type === "exit" ? (l = t.presenceContext) == null ? void 0 : l.custom : void 0), { transition: o = t.getDefaultTransition() || {} } = n || {};
    r.transitionOverride && (o = r.transitionOverride);
    let i = n ? () => Promise.all(Nh(t, n, r)) : () => Promise.resolve(), s = t.variantChildren && t.variantChildren.size ? (u = 0) => {
      let { delayChildren: c = 0, staggerChildren: p, staggerDirection: h } = o;
      return GP(t, e, u, c, p, h, r);
    } : () => Promise.resolve(), { when: a } = o;
    if (a) {
      let [u, c] = a === "beforeChildren" ? [i, s] : [s, i];
      return u().then(() => c());
    } else return Promise.all([i(), s(r.delay)]);
  }
  function GP(t, e, r = 0, n = 0, o = 0, i = 1, s) {
    let a = [];
    for (let l of t.variantChildren) l.notify("AnimationStart", e), a.push(Oh(l, e, { ...s, delay: r + (typeof n == "function" ? 0 : n) + Ch(t.variantChildren, l, n, o, i) }).then(() => l.notify("AnimationComplete", e)));
    return Promise.all(a);
  }
  function wC(t, e, r = {}) {
    t.notify("AnimationStart", e);
    let n;
    if (Array.isArray(e)) {
      let o = e.map((i) => Oh(t, i, r));
      n = Promise.all(o);
    } else if (typeof e == "string") n = Oh(t, e, r);
    else {
      let o = typeof e == "function" ? gr(t, e, r.custom) : e;
      n = Promise.all(Nh(t, o, r));
    }
    return n.then(() => {
      t.notify("AnimationComplete", e);
    });
  }
  var SC = { test: (t) => t === "auto", parse: (t) => t };
  var Dh = (t) => (e) => e.test(t);
  var cx = [En, G, Rt, Rr, Gg, Ug, SC], px = (t) => cx.find(Dh(t));
  function TC(t) {
    return typeof t == "number" ? t === 0 : t !== null ? t === "none" || t === "0" || Zl(t) : true;
  }
  var HP = /* @__PURE__ */ new Set(["brightness", "contrast", "saturate", "opacity"]);
  function $P(t) {
    let [e, r] = t.slice(0, -1).split("(");
    if (e === "drop-shadow") return t;
    let [n] = r.match(aa) || [];
    if (!n) return t;
    let o = r.replace(n, ""), i = HP.has(e) ? 1 : 0;
    return n !== r && (i *= 100), e + "(" + i + o + ")";
  }
  var XP = /\b([a-z-]*)\(.*?\)/gu, xu = { ...mt, getAnimatableNone: (t) => {
    let e = t.match(XP);
    return e ? e.map($P).join(" ") : t;
  } };
  var yu = { ...mt, getAnimatableNone: (t) => {
    let e = mt.parse(t);
    return mt.createTransformer(t)(e.map((n) => typeof n == "number" ? 0 : typeof n == "object" ? { ...n, alpha: 1 } : n));
  } };
  var hx = { ...En, transform: Math.round };
  var AC = { rotate: Rr, pathRotation: Rr, rotateX: Rr, rotateY: Rr, rotateZ: Rr, scale: cu, scaleX: cu, scaleY: cu, scaleZ: cu, skew: Rr, skewX: Rr, skewY: Rr, distance: G, translateX: G, translateY: G, translateZ: G, x: G, y: G, z: G, perspective: G, transformPerspective: G, opacity: Kn, originX: uh, originY: uh, originZ: G };
  var Vi = { borderWidth: G, borderTopWidth: G, borderRightWidth: G, borderBottomWidth: G, borderLeftWidth: G, borderRadius: G, borderTopLeftRadius: G, borderTopRightRadius: G, borderBottomRightRadius: G, borderBottomLeftRadius: G, width: G, maxWidth: G, height: G, maxHeight: G, top: G, right: G, bottom: G, left: G, inset: G, insetBlock: G, insetBlockStart: G, insetBlockEnd: G, insetInline: G, insetInlineStart: G, insetInlineEnd: G, padding: G, paddingTop: G, paddingRight: G, paddingBottom: G, paddingLeft: G, paddingBlock: G, paddingBlockStart: G, paddingBlockEnd: G, paddingInline: G, paddingInlineStart: G, paddingInlineEnd: G, margin: G, marginTop: G, marginRight: G, marginBottom: G, marginLeft: G, marginBlock: G, marginBlockStart: G, marginBlockEnd: G, marginInline: G, marginInlineStart: G, marginInlineEnd: G, fontSize: G, backgroundPositionX: G, backgroundPositionY: G, ...AC, zIndex: hx, fillOpacity: Kn, strokeOpacity: Kn, numOctaves: hx };
  var YP = { ...Vi, color: Oe, backgroundColor: Oe, outlineColor: Oe, fill: Oe, stroke: Oe, borderColor: Oe, borderTopColor: Oe, borderRightColor: Oe, borderBottomColor: Oe, borderLeftColor: Oe, filter: xu, WebkitFilter: xu, mask: yu, WebkitMask: yu }, Mh = (t) => YP[t];
  var QP = /* @__PURE__ */ new Set([xu, yu]);
  function Ph(t, e) {
    let r = Mh(t);
    return QP.has(r) || (r = mt), r.getAnimatableNone ? r.getAnimatableNone(e) : void 0;
  }
  var KP = /* @__PURE__ */ new Set(["auto", "none", "0"]);
  function CC(t, e, r) {
    let n = 0, o;
    for (; n < t.length && !o; ) {
      let i = t[n];
      typeof i == "string" && !KP.has(i) && Wo(i).values.length && (o = t[n]), n++;
    }
    if (o && r) for (let i of e) t[i] = Ph(r, o);
  }
  var Rh = class extends Ho {
    constructor(e, r, n, o, i) {
      super(e, r, n, o, i, true);
    }
    readKeyframes() {
      let { unresolvedKeyframes: e, element: r, name: n } = this;
      if (!r || !r.current) return;
      super.readKeyframes();
      for (let c = 0; c < e.length; c++) {
        let p = e[c];
        if (typeof p == "string" && (p = p.trim(), sa(p))) {
          let h = ux(p, r.current);
          h !== void 0 && (e[c] = h), c === e.length - 1 && (this.finalKeyframe = p);
        }
      }
      if (this.resolveNoneKeyframes(), !Eh.has(n) || e.length !== 2) return;
      let [o, i] = e, s = px(o), a = px(i), l = zg(o), u = zg(i);
      if (l !== u && Jn[n]) {
        this.needsMeasurement = true;
        return;
      }
      if (s !== a) if (ex(s) && ex(a)) for (let c = 0; c < e.length; c++) {
        let p = e[c];
        typeof p == "string" && (e[c] = parseFloat(p));
      }
      else Jn[n] && (this.needsMeasurement = true);
    }
    resolveNoneKeyframes() {
      let { unresolvedKeyframes: e, name: r } = this, n = [];
      for (let o = 0; o < e.length; o++) (e[o] === null || TC(e[o])) && n.push(o);
      n.length && CC(e, n, r);
    }
    measureInitialState() {
      let { element: e, unresolvedKeyframes: r, name: n } = this;
      if (!e || !e.current) return;
      n === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = Jn[n](e.measureViewportBox(), window.getComputedStyle(e.current)), r[0] = this.measuredOrigin;
      let o = r[r.length - 1];
      o !== void 0 && e.getValue(n, o).jump(o, false);
    }
    measureEndState() {
      var a;
      let { element: e, name: r, unresolvedKeyframes: n } = this;
      if (!e || !e.current) return;
      let o = e.getValue(r);
      o && o.jump(this.measuredOrigin, false);
      let i = n.length - 1, s = n[i];
      n[i] = Jn[r](e.measureViewportBox(), window.getComputedStyle(e.current)), s !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = s), (a = this.removedTransforms) != null && a.length && this.removedTransforms.forEach(([l, u]) => {
        e.getValue(l).set(u);
      }), this.resolveNoneKeyframes();
    }
  };
  function Vh(t, e, r) {
    if (t == null) return [];
    if (t instanceof EventTarget) return [t];
    if (typeof t == "string") {
      let n = document;
      e && (n = e.current);
      let o = (r == null ? void 0 : r[t]) ?? n.querySelectorAll(t);
      return o ? Array.from(o) : [];
    }
    return Array.from(t).filter((n) => n != null);
  }
  var _u = (t, e) => e && typeof t == "number" ? e.transform(t) : t;
  function Fi(t) {
    return Kl(t) && "offsetHeight" in t && !("ownerSVGElement" in t);
  }
  var { schedule: Ii, cancel: ZP } = ih(queueMicrotask, false);
  var Fr = { x: false, y: false };
  function Fh() {
    return Fr.x || Fr.y;
  }
  function fx(t) {
    return t === "x" || t === "y" ? Fr[t] ? null : (Fr[t] = true, () => {
      Fr[t] = false;
    }) : Fr.x || Fr.y ? null : (Fr.x = Fr.y = true, () => {
      Fr.x = Fr.y = false;
    });
  }
  function Ih(t, e) {
    let r = Vh(t), n = new AbortController(), o = { passive: true, ...e, signal: n.signal };
    return [r, o, () => n.abort()];
  }
  function JP(t) {
    return !(t.pointerType === "touch" || Fh());
  }
  function mx(t, e, r = {}) {
    let [n, o, i] = Ih(t, r);
    return n.forEach((s) => {
      let a = false, l = false, u, c = () => {
        s.removeEventListener("pointerleave", m);
      }, p = (_) => {
        u && (u(_), u = void 0), c();
      }, h = (_) => {
        a = false, window.removeEventListener("pointerup", h), window.removeEventListener("pointercancel", h), l && (l = false, p(_));
      }, f = () => {
        a = true, window.addEventListener("pointerup", h, o), window.addEventListener("pointercancel", h, o);
      }, m = (_) => {
        if (_.pointerType !== "touch") {
          if (a) {
            l = true;
            return;
          }
          p(_);
        }
      }, x = (_) => {
        if (!JP(_)) return;
        l = false;
        let d = e(s, _);
        typeof d == "function" && (u = d, s.addEventListener("pointerleave", m, o));
      };
      s.addEventListener("pointerenter", x, o), s.addEventListener("pointerdown", f, o);
    }), i;
  }
  var dx = (t, e) => e ? t === e ? true : dx(t, e.parentElement) : false;
  var Li = (t) => t.pointerType === "mouse" ? typeof t.button != "number" || t.button <= 0 : t.isPrimary !== false;
  var eR = /* @__PURE__ */ new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);
  function gx(t) {
    return eR.has(t.tagName) || t.isContentEditable === true;
  }
  var tR = /* @__PURE__ */ new Set(["INPUT", "SELECT", "TEXTAREA"]);
  function xx(t) {
    return tR.has(t.tagName) || t.isContentEditable === true;
  }
  var ga = /* @__PURE__ */ new WeakSet();
  function kC(t) {
    return (e) => {
      e.key === "Enter" && t(e);
    };
  }
  function yx(t, e) {
    t.dispatchEvent(new PointerEvent("pointer" + e, { isPrimary: true, bubbles: true }));
  }
  var EC = (t, e) => {
    let r = t.currentTarget;
    if (!r) return;
    let n = kC(() => {
      if (ga.has(r)) return;
      yx(r, "down");
      let o = kC(() => {
        yx(r, "up");
      }), i = () => yx(r, "cancel");
      r.addEventListener("keyup", o, e), r.addEventListener("blur", i, e);
    });
    r.addEventListener("keydown", n, e), r.addEventListener("blur", () => r.removeEventListener("keydown", n), e);
  };
  function bC(t) {
    return Li(t) && !Fh();
  }
  var NC = /* @__PURE__ */ new WeakSet();
  function _x(t, e, r = {}) {
    let [n, o, i] = Ih(t, r), s = (a) => {
      let l = a.currentTarget;
      if (!bC(a) || NC.has(a)) return;
      ga.add(l), r.stopPropagation && NC.add(a);
      let u = e(l, a), c = (f, m) => {
        window.removeEventListener("pointerup", p), window.removeEventListener("pointercancel", h), ga.has(l) && ga.delete(l), bC(f) && typeof u == "function" && u(f, { success: m });
      }, p = (f) => {
        c(f, l === window || l === document || r.useGlobalTarget || dx(l, f.target));
      }, h = (f) => {
        c(f, false);
      };
      window.addEventListener("pointerup", p, o), window.addEventListener("pointercancel", h, o);
    };
    return n.forEach((a) => {
      (r.useGlobalTarget ? window : a).addEventListener("pointerdown", s, o), Fi(a) && (a.addEventListener("focus", (u) => EC(u, o)), !gx(a) && !a.hasAttribute("tabindex") && (a.tabIndex = 0));
    }), i;
  }
  function xa(t) {
    return Kl(t) && "ownerSVGElement" in t;
  }
  var Lh = /* @__PURE__ */ new WeakMap(), $o, OC = (t, e, r) => (n, o) => o && o[0] ? o[0][t + "Size"] : xa(n) && "getBBox" in n ? n.getBBox()[e] : n[r], rR = OC("inline", "width", "offsetWidth"), nR = OC("block", "height", "offsetHeight");
  function oR({ target: t, borderBoxSize: e }) {
    var r;
    (r = Lh.get(t)) == null || r.forEach((n) => {
      n(t, { get width() {
        return rR(t, e);
      }, get height() {
        return nR(t, e);
      } });
    });
  }
  function iR(t) {
    t.forEach(oR);
  }
  function sR() {
    typeof ResizeObserver > "u" || ($o = new ResizeObserver(iR));
  }
  function DC(t, e) {
    $o || sR();
    let r = Vh(t);
    return r.forEach((n) => {
      let o = Lh.get(n);
      o || (o = /* @__PURE__ */ new Set(), Lh.set(n, o)), o.add(e), $o == null || $o.observe(n);
    }), () => {
      r.forEach((n) => {
        let o = Lh.get(n);
        o == null || o.delete(e), o != null && o.size || $o == null || $o.unobserve(n);
      });
    };
  }
  var Bh = /* @__PURE__ */ new Set(), ya;
  function aR() {
    ya = () => {
      let t = { get width() {
        return window.innerWidth;
      }, get height() {
        return window.innerHeight;
      } };
      Bh.forEach((e) => e(t));
    }, window.addEventListener("resize", ya);
  }
  function MC(t) {
    return Bh.add(t), ya || aR(), () => {
      Bh.delete(t), !Bh.size && typeof ya == "function" && (window.removeEventListener("resize", ya), ya = void 0);
    };
  }
  function jh(t, e) {
    return typeof t == "function" ? MC(t) : DC(t, e);
  }
  function PC(t) {
    return xa(t) && t.tagName === "svg";
  }
  var lR = [...cx, Oe, mt], RC = (t) => lR.find(Dh(t));
  var vx = () => ({ translate: 0, scale: 1, origin: 0, originPoint: 0 }), Xo = () => ({ x: vx(), y: vx() }), wx = () => ({ min: 0, max: 0 }), De = () => ({ x: wx(), y: wx() });
  var VC = /* @__PURE__ */ new WeakMap();
  function eo(t) {
    return t !== null && typeof t == "object" && typeof t.start == "function";
  }
  function On(t) {
    return typeof t == "string" || Array.isArray(t);
  }
  var qh = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"], vu = ["initial", ...qh];
  function Yo(t) {
    return eo(t.animate) || vu.some((e) => On(t[e]));
  }
  function wu(t) {
    return !!(Yo(t) || t.variants);
  }
  function FC(t, e, r) {
    for (let n in e) {
      let o = e[n], i = r[n];
      if (ve(o)) t.addValue(n, o);
      else if (ve(i)) t.addValue(n, an(o, { owner: t }));
      else if (i !== o) if (t.hasValue(n)) {
        let s = t.getValue(n);
        s.liveStyle === true ? s.jump(o) : s.hasAnimated || s.set(o);
      } else {
        let s = t.getStaticValue(n);
        t.addValue(n, an(s !== void 0 ? s : o, { owner: t }));
      }
    }
    for (let n in r) e[n] === void 0 && t.removeValue(n);
    return e;
  }
  var Su = { current: null }, zh = { current: false };
  var uR = typeof window < "u";
  function IC() {
    if (zh.current = true, !!uR) if (window.matchMedia) {
      let t = window.matchMedia("(prefers-reduced-motion)"), e = () => Su.current = t.matches;
      t.addEventListener("change", e), e();
    } else Su.current = false;
  }
  var LC = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"], Wh = {};
  function Au(t) {
    Wh = t;
  }
  function Sx() {
    return Wh;
  }
  var Tu = class {
    scrapeMotionValuesFromProps(e, r, n) {
      return {};
    }
    constructor({ parent: e, props: r, presenceContext: n, reducedMotionConfig: o, skipAnimations: i, blockInitialAnimation: s, visualState: a }, l = {}) {
      this.current = null, this.children = /* @__PURE__ */ new Set(), this.isVariantNode = false, this.isControllingVariants = false, this.shouldReduceMotion = null, this.shouldSkipAnimations = false, this.values = /* @__PURE__ */ new Map(), this.KeyframeResolver = Ho, this.features = {}, this.valueSubscriptions = /* @__PURE__ */ new Map(), this.prevMotionValues = {}, this.hasBeenMounted = false, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
        this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection));
      }, this.renderScheduledAt = 0, this.scheduleRender = () => {
        let f = Be.now();
        this.renderScheduledAt < f && (this.renderScheduledAt = f, ne.render(this.render, false, true));
      };
      let { latestValues: u, renderState: c } = a;
      this.latestValues = u, this.baseTarget = { ...u }, this.initialValues = r.initial ? { ...u } : {}, this.renderState = c, this.parent = e, this.props = r, this.presenceContext = n, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = o, this.skipAnimationsConfig = i, this.options = l, this.blockInitialAnimation = !!s, this.isControllingVariants = Yo(r), this.isVariantNode = wu(r), this.isVariantNode && (this.variantChildren = /* @__PURE__ */ new Set()), this.manuallyAnimateOnMount = !!(e && e.current);
      let { willChange: p, ...h } = this.scrapeMotionValuesFromProps(r, {}, this);
      for (let f in h) {
        let m = h[f];
        u[f] !== void 0 && ve(m) && m.set(u[f]);
      }
    }
    mount(e) {
      var r, n;
      if (this.hasBeenMounted) for (let o in this.initialValues) (r = this.values.get(o)) == null || r.jump(this.initialValues[o]), this.latestValues[o] = this.initialValues[o];
      this.current = e, VC.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((o, i) => this.bindToMotionValue(i, o)), this.reducedMotionConfig === "never" ? this.shouldReduceMotion = false : this.reducedMotionConfig === "always" ? this.shouldReduceMotion = true : (zh.current || IC(), this.shouldReduceMotion = Su.current), this.shouldSkipAnimations = this.skipAnimationsConfig ?? false, (n = this.parent) == null || n.addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = true;
    }
    unmount() {
      var e;
      this.projection && this.projection.unmount(), nr(this.notifyUpdate), nr(this.render), this.valueSubscriptions.forEach((r) => r()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), (e = this.parent) == null || e.removeChild(this);
      for (let r in this.events) this.events[r].clear();
      for (let r in this.features) {
        let n = this.features[r];
        n && (n.unmount(), n.isMounted = false);
      }
      this.current = null;
    }
    addChild(e) {
      this.children.add(e), this.enteringChildren ?? (this.enteringChildren = /* @__PURE__ */ new Set()), this.enteringChildren.add(e);
    }
    removeChild(e) {
      this.children.delete(e), this.enteringChildren && this.enteringChildren.delete(e);
    }
    bindToMotionValue(e, r) {
      if (this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)(), r.accelerate && Th.has(e) && this.current instanceof HTMLElement) {
        let { factory: s, keyframes: a, times: l, ease: u, duration: c } = r.accelerate, p = new ha({ element: this.current, name: e, keyframes: a, times: l, ease: u, duration: Ze(c) }), h = s(p);
        this.valueSubscriptions.set(e, () => {
          h(), p.cancel();
        });
        return;
      }
      let n = Vr.has(e);
      n && this.onBindTransform && this.onBindTransform();
      let o = r.on("change", (s) => {
        this.latestValues[e] = s, this.props.onUpdate && ne.preRender(this.notifyUpdate), n && this.projection && (this.projection.isTransformDirty = true), this.scheduleRender();
      }), i;
      typeof window < "u" && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, e, r)), this.valueSubscriptions.set(e, () => {
        o(), i && i();
      });
    }
    sortNodePosition(e) {
      return !this.current || !this.sortInstanceNodePosition || this.type !== e.type ? 0 : this.sortInstanceNodePosition(this.current, e.current);
    }
    updateFeatures() {
      let e = "animation";
      for (e in Wh) {
        let r = Wh[e];
        if (!r) continue;
        let { isEnabled: n, Feature: o } = r;
        if (!this.features[e] && o && n(this.props) && (this.features[e] = new o(this)), this.features[e]) {
          let i = this.features[e];
          i.isMounted ? i.update() : (i.mount(), i.isMounted = true);
        }
      }
    }
    triggerBuild() {
      this.build(this.renderState, this.latestValues, this.props);
    }
    measureViewportBox() {
      return this.current ? this.measureInstanceViewportBox(this.current, this.props) : De();
    }
    getStaticValue(e) {
      return this.latestValues[e];
    }
    setStaticValue(e, r) {
      this.latestValues[e] = r;
    }
    update(e, r) {
      (e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = r;
      for (let n = 0; n < LC.length; n++) {
        let o = LC[n];
        this.propEventSubscriptions[o] && (this.propEventSubscriptions[o](), delete this.propEventSubscriptions[o]);
        let i = "on" + o, s = e[i];
        s && (this.propEventSubscriptions[o] = this.on(o, s));
      }
      this.prevMotionValues = FC(this, this.scrapeMotionValuesFromProps(e, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue();
    }
    getProps() {
      return this.props;
    }
    getVariant(e) {
      return this.props.variants ? this.props.variants[e] : void 0;
    }
    getDefaultTransition() {
      return this.props.transition;
    }
    getTransformPagePoint() {
      return this.props.transformPagePoint;
    }
    getClosestVariantNode() {
      return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0;
    }
    addVariantChild(e) {
      let r = this.getClosestVariantNode();
      if (r) return r.variantChildren && r.variantChildren.add(e), () => r.variantChildren.delete(e);
    }
    addValue(e, r) {
      let n = this.values.get(e);
      r !== n && (n && this.removeValue(e), this.bindToMotionValue(e, r), this.values.set(e, r), this.latestValues[e] = r.get());
    }
    removeValue(e) {
      this.values.delete(e);
      let r = this.valueSubscriptions.get(e);
      r && (r(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState);
    }
    hasValue(e) {
      return this.values.has(e);
    }
    getValue(e, r) {
      if (this.props.values && this.props.values[e]) return this.props.values[e];
      let n = this.values.get(e);
      return n === void 0 && r !== void 0 && (n = an(r === null ? void 0 : r, { owner: this }), this.addValue(e, n)), n;
    }
    readValue(e, r) {
      let n = this.latestValues[e] !== void 0 || !this.current ? this.latestValues[e] : this.getBaseTargetFromProps(this.props, e) ?? this.readValueFromInstance(this.current, e, this.options);
      return n != null && (typeof n == "string" && (Ql(n) || Zl(n)) ? n = parseFloat(n) : !RC(n) && mt.test(r) && (n = Ph(e, r)), this.setBaseTarget(e, ve(n) ? n.get() : n)), ve(n) ? n.get() : n;
    }
    setBaseTarget(e, r) {
      this.baseTarget[e] = r;
    }
    getBaseTarget(e) {
      var i;
      let { initial: r } = this.props, n;
      if (typeof r == "string" || typeof r == "object") {
        let s = Ri(this.props, r, (i = this.presenceContext) == null ? void 0 : i.custom);
        s && (n = s[e]);
      }
      if (r && n !== void 0) return n;
      let o = this.getBaseTargetFromProps(this.props, e);
      return o !== void 0 && !ve(o) ? o : this.initialValues[e] !== void 0 && n === void 0 ? void 0 : this.baseTarget[e];
    }
    on(e, r) {
      return this.events[e] || (this.events[e] = new Qn()), this.events[e].add(r);
    }
    notify(e, ...r) {
      this.events[e] && this.events[e].notify(...r);
    }
    scheduleRenderMicrotask() {
      Ii.render(this.render);
    }
  };
  var _a = class extends Tu {
    constructor() {
      super(...arguments), this.KeyframeResolver = Rh;
    }
    sortInstanceNodePosition(e, r) {
      return e.compareDocumentPosition(r) & 2 ? 1 : -1;
    }
    getBaseTargetFromProps(e, r) {
      let n = e.style;
      return n ? n[r] : void 0;
    }
    removeValueFromRenderState(e, { vars: r, style: n }) {
      delete r[e], delete n[e];
    }
    handleChildMotionValue() {
      this.childSubscription && (this.childSubscription(), delete this.childSubscription);
      let { children: e } = this.props;
      ve(e) && (this.childSubscription = e.on("change", (r) => {
        this.current && (this.current.textContent = `${r}`);
      }));
    }
  };
  var dt = class {
    constructor(e) {
      this.isMounted = false, this.node = e;
    }
    update() {
    }
  };
  function Cu({ top: t, left: e, right: r, bottom: n }) {
    return { x: { min: e, max: r }, y: { min: t, max: n } };
  }
  function Tx({ x: t, y: e }) {
    return { top: e.min, right: t.max, bottom: e.max, left: t.min };
  }
  function Ax(t, e) {
    if (!e) return t;
    let r = e({ x: t.left, y: t.top }), n = e({ x: t.right, y: t.bottom });
    return { top: r.y, left: r.x, bottom: n.y, right: n.x };
  }
  function Cx(t) {
    return t === void 0 || t === 1;
  }
  function Uh({ scale: t, scaleX: e, scaleY: r }) {
    return !Cx(t) || !Cx(e) || !Cx(r);
  }
  function to(t) {
    return Uh(t) || kx(t) || t.z || t.rotate || t.rotateX || t.rotateY || t.skewX || t.skewY;
  }
  function kx(t) {
    return BC(t.x) || BC(t.y);
  }
  function BC(t) {
    return t && t !== "0%";
  }
  function ku(t, e, r) {
    let n = t - r, o = e * n;
    return r + o;
  }
  function jC(t, e, r, n, o) {
    return o !== void 0 && (t = ku(t, o, n)), ku(t, r, n) + e;
  }
  function Ex(t, e = 0, r = 1, n, o) {
    t.min = jC(t.min, e, r, n, o), t.max = jC(t.max, e, r, n, o);
  }
  function bx(t, { x: e, y: r }) {
    Ex(t.x, e.translate, e.scale, e.originPoint), Ex(t.y, r.translate, r.scale, r.originPoint);
  }
  var qC = 0.999999999999, zC = 1.0000000000001;
  function GC(t, e, r, n = false) {
    var a;
    let o = r.length;
    if (!o) return;
    e.x = e.y = 1;
    let i, s;
    for (let l = 0; l < o; l++) {
      i = r[l], s = i.projectionDelta;
      let { visualElement: u } = i.options;
      u && u.props.style && u.props.style.display === "contents" || (n && i.options.layoutScroll && i.scroll && i !== i.root && (Ir(t.x, -i.scroll.offset.x), Ir(t.y, -i.scroll.offset.y)), s && (e.x *= s.x.scale, e.y *= s.y.scale, bx(t, s)), n && to(i.latestValues) && Eu(t, i.latestValues, (a = i.layout) == null ? void 0 : a.layoutBox));
    }
    e.x < zC && e.x > qC && (e.x = 1), e.y < zC && e.y > qC && (e.y = 1);
  }
  function Ir(t, e) {
    t.min += e, t.max += e;
  }
  function WC(t, e, r, n, o = 0.5) {
    let i = oe(t.min, t.max, o);
    Ex(t, e, r, i, n);
  }
  function UC(t, e) {
    return typeof t == "string" ? parseFloat(t) / 100 * (e.max - e.min) : t;
  }
  function Eu(t, e, r) {
    let n = r ?? t;
    WC(t.x, UC(e.x, n.x), e.scaleX, e.scale, e.originX), WC(t.y, UC(e.y, n.y), e.scaleY, e.scale, e.originY);
  }
  function Gh(t, e) {
    return Cu(Ax(t.getBoundingClientRect(), e));
  }
  function Nx(t, e, r) {
    let n = Gh(t, r), { scroll: o } = e;
    return o && (Ir(n.x, o.offset.x), Ir(n.y, o.offset.y)), n;
  }
  var cR = { x: "translateX", y: "translateY", z: "translateZ", transformPerspective: "perspective" }, pR = Nn.length;
  function HC(t, e, r) {
    let n = "", o = true;
    for (let s = 0; s < pR; s++) {
      let a = Nn[s], l = t[a];
      if (l === void 0) continue;
      let u = true;
      if (typeof l == "number") u = l === (a.startsWith("scale") ? 1 : 0);
      else {
        let c = parseFloat(l);
        u = a.startsWith("scale") ? c === 1 : c === 0;
      }
      if (!u || r) {
        let c = _u(l, Vi[a]);
        if (!u) {
          o = false;
          let p = cR[a] || a;
          n += `${p}(${c}) `;
        }
        r && (e[a] = c);
      }
    }
    let i = t.pathRotation;
    return i && (o = false, n += `rotate(${_u(i, Vi.pathRotation)}) `), n = n.trim(), r ? n = r(e, o ? "" : n) : o && (n = "none"), n;
  }
  function Bi(t, e, r) {
    let { style: n, vars: o, transformOrigin: i } = t, s = false, a = false;
    for (let l in e) {
      let u = e[l];
      if (Vr.has(l)) {
        s = true;
        continue;
      } else if (ah(l)) {
        o[l] = u;
        continue;
      } else {
        let c = _u(u, Vi[l]);
        l.startsWith("origin") ? (a = true, i[l] = c) : n[l] = c;
      }
    }
    if (e.transform || (s || r ? n.transform = HC(e, t.transform, r) : n.transform && (n.transform = "none")), a) {
      let { originX: l = "50%", originY: u = "50%", originZ: c = 0 } = i;
      n.transformOrigin = `${l} ${u} ${c}`;
    }
  }
  function Hh(t, { style: e, vars: r }, n, o) {
    let i = t.style, s;
    for (s in e) i[s] = e[s];
    o == null || o.applyProjectionStyles(i, n);
    for (s in r) i.setProperty(s, r[s]);
  }
  function $C(t, e) {
    return e.max === e.min ? 0 : t / (e.max - e.min) * 100;
  }
  var va = { correct: (t, e) => {
    if (!e.target) return t;
    if (typeof t == "string") if (G.test(t)) t = parseFloat(t);
    else return t;
    let r = $C(t, e.target.x), n = $C(t, e.target.y);
    return `${r}% ${n}%`;
  } };
  var XC = { correct: (t, { treeScale: e, projectionDelta: r }) => {
    let n = t, o = mt.parse(t);
    if (o.length > 5) return n;
    let i = mt.createTransformer(t), s = typeof o[0] != "number" ? 1 : 0, a = r.x.scale * e.x, l = r.y.scale * e.y;
    o[0 + s] /= a, o[1 + s] /= l;
    let u = oe(a, l, 0.5);
    return typeof o[2 + s] == "number" && (o[2 + s] /= u), typeof o[3 + s] == "number" && (o[3 + s] /= u), i(o);
  } };
  var bu = { borderRadius: { ...va, applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"] }, borderTopLeftRadius: va, borderTopRightRadius: va, borderBottomLeftRadius: va, borderBottomRightRadius: va, boxShadow: XC };
  function Nu(t, { layout: e, layoutId: r }) {
    return Vr.has(t) || t.startsWith("origin") || (e || r !== void 0) && (!!bu[t] || t === "opacity");
  }
  function ji(t, e, r) {
    var s;
    let n = t.style, o = e == null ? void 0 : e.style, i = {};
    if (!n) return i;
    for (let a in n) (ve(n[a]) || o && ve(o[a]) || Nu(a, t) || ((s = r == null ? void 0 : r.getValue(a)) == null ? void 0 : s.liveStyle) !== void 0) && (i[a] = n[a]);
    return i;
  }
  function hR(t) {
    return window.getComputedStyle(t);
  }
  var Ou = class extends _a {
    constructor() {
      super(...arguments), this.type = "html", this.renderInstance = Hh;
    }
    readValueFromInstance(e, r) {
      var n;
      if (Vr.has(r)) return (n = this.projection) != null && n.isProjecting ? gh(r) : ZA(e, r);
      {
        let o = hR(e), i = (ah(r) ? o.getPropertyValue(r) : o[r]) || 0;
        return typeof i == "string" ? i.trim() : i;
      }
    }
    measureInstanceViewportBox(e, { transformPagePoint: r }) {
      return Gh(e, r);
    }
    build(e, r, n) {
      Bi(e, r, n.transformTemplate);
    }
    scrapeMotionValuesFromProps(e, r, n) {
      return ji(e, r, n);
    }
  };
  var fR = { offset: "stroke-dashoffset", array: "stroke-dasharray" }, mR = { offset: "strokeDashoffset", array: "strokeDasharray" };
  function YC(t, e, r = 1, n = 0, o = true) {
    t.pathLength = 1;
    let i = o ? fR : mR;
    t[i.offset] = `${-n}`, t[i.array] = `${e} ${r}`;
  }
  var dR = ["offsetDistance", "offsetPath", "offsetRotate", "offsetAnchor"];
  function Du(t, { attrX: e, attrY: r, attrScale: n, pathLength: o, pathSpacing: i = 1, pathOffset: s = 0, ...a }, l, u, c) {
    if (Bi(t, a, u), l) {
      t.style.viewBox && (t.attrs.viewBox = t.style.viewBox);
      return;
    }
    t.attrs = t.style, t.style = {};
    let { attrs: p, style: h } = t;
    p.transform && (h.transform = p.transform, delete p.transform), (h.transform || p.transformOrigin) && (h.transformOrigin = p.transformOrigin ?? "50% 50%", delete p.transformOrigin), h.transform && (h.transformBox = (c == null ? void 0 : c.transformBox) ?? "fill-box", delete p.transformBox);
    for (let f of dR) p[f] !== void 0 && (h[f] = p[f], delete p[f]);
    e !== void 0 && (p.x = e), r !== void 0 && (p.y = r), n !== void 0 && (p.scale = n), o !== void 0 && YC(p, o, i, s, false);
  }
  var $h = /* @__PURE__ */ new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);
  var Mu = (t) => typeof t == "string" && t.toLowerCase() === "svg";
  function QC(t, e, r, n) {
    Hh(t, e, void 0, n);
    for (let o in e.attrs) t.setAttribute($h.has(o) ? o : da(o), e.attrs[o]);
  }
  function Pu(t, e, r) {
    let n = ji(t, e, r);
    for (let o in t) if (ve(t[o]) || ve(e[o])) {
      let i = Nn.indexOf(o) !== -1 ? "attr" + o.charAt(0).toUpperCase() + o.substring(1) : o;
      n[i] = t[o];
    }
    return n;
  }
  var Ru = class extends _a {
    constructor() {
      super(...arguments), this.type = "svg", this.isSVGTag = false, this.measureInstanceViewportBox = De;
    }
    getBaseTargetFromProps(e, r) {
      return e[r];
    }
    readValueFromInstance(e, r) {
      if (Vr.has(r)) {
        let n = Mh(r);
        return n && n.default || 0;
      }
      return r = $h.has(r) ? r : da(r), e.getAttribute(r);
    }
    scrapeMotionValuesFromProps(e, r, n) {
      return Pu(e, r, n);
    }
    build(e, r, n) {
      Du(e, r, this.isSVGTag, n.transformTemplate, n.style);
    }
    renderInstance(e, r, n, o) {
      QC(e, r, n, o);
    }
    mount(e) {
      this.isSVGTag = Mu(e.tagName), super.mount(e);
    }
  };
  var gR = vu.length;
  function Ox(t) {
    if (!t) return;
    if (!t.isControllingVariants) {
      let r = t.parent ? Ox(t.parent) || {} : {};
      return t.props.initial !== void 0 && (r.initial = t.props.initial), r;
    }
    let e = {};
    for (let r = 0; r < gR; r++) {
      let n = vu[r], o = t.props[n];
      (On(o) || o === false) && (e[n] = o);
    }
    return e;
  }
  function Dx(t, e) {
    if (!Array.isArray(e)) return false;
    let r = e.length;
    if (r !== t.length) return false;
    for (let n = 0; n < r; n++) if (e[n] !== t[n]) return false;
    return true;
  }
  var xR = [...qh].reverse(), yR = qh.length;
  function _R(t) {
    return (e) => Promise.all(e.map(({ animation: r, options: n }) => wC(t, r, n)));
  }
  function Mx(t) {
    let e = _R(t), r = KC(), n = true, o = false, i = (u) => (c, p) => {
      var f;
      let h = gr(t, p, u === "exit" ? (f = t.presenceContext) == null ? void 0 : f.custom : void 0);
      if (h) {
        let { transition: m, transitionEnd: x, ..._ } = h;
        c = { ...c, ..._, ...x };
      }
      return c;
    };
    function s(u) {
      e = u(t);
    }
    function a(u) {
      let { props: c } = t, p = Ox(t.parent) || {}, h = [], f = /* @__PURE__ */ new Set(), m = {}, x = 1 / 0;
      for (let d = 0; d < yR; d++) {
        let g = xR[d], y = r[g], S = c[g] !== void 0 ? c[g] : p[g], v = On(S), T = g === u ? y.isActive : null;
        T === false && (x = d);
        let A = S === p[g] && S !== c[g] && v;
        if (A && (n || o) && t.manuallyAnimateOnMount && (A = false), y.protectedKeys = { ...m }, !y.isActive && T === null || !S && !y.prevProp || eo(S) || typeof S == "boolean") continue;
        if (g === "exit" && y.isActive && T !== true) {
          y.prevResolvedValues && (m = { ...m, ...y.prevResolvedValues });
          continue;
        }
        let w = ZC(y.prevProp, S), N = w || g === u && y.isActive && !A && v || d > x && v, k = false, D = Array.isArray(S) ? S : [S], M = D.reduce(i(g), {});
        T === false && (M = {});
        let { prevResolvedValues: q = {} } = y, B = { ...q, ...M }, I = (O) => {
          N = true, f.has(O) && (k = true, f.delete(O)), y.needsAnimating[O] = true;
          let R = t.getValue(O);
          R && (R.liveStyle = false);
        };
        for (let O in B) {
          let R = M[O], P = q[O];
          if (m.hasOwnProperty(O)) continue;
          let V = false;
          du(R) && du(P) ? V = !Dx(R, P) || w : V = R !== P, V ? R != null ? I(O) : f.add(O) : R !== void 0 && f.has(O) ? I(O) : y.protectedKeys[O] = true;
        }
        y.prevProp = S, y.prevResolvedValues = M, y.isActive && (m = { ...m, ...M }), (n || o) && t.blockInitialAnimation && (N = false);
        let C = A && w;
        N && (!C || k) && h.push(...D.map((O) => {
          let R = { type: g };
          if (typeof O == "string" && (n || o) && !C && t.manuallyAnimateOnMount && t.parent) {
            let { parent: P } = t, V = gr(P, O);
            if (P.enteringChildren && V) {
              let { delayChildren: te } = V.transition || {};
              R.delay = Ch(P.enteringChildren, t, te);
            }
          }
          return { animation: O, options: R };
        }));
      }
      if (f.size) {
        let d = {};
        if (typeof c.initial != "boolean") {
          let g = gr(t, Array.isArray(c.initial) ? c.initial[0] : c.initial);
          g && g.transition && (d.transition = g.transition);
        }
        f.forEach((g) => {
          let y = t.getBaseTarget(g), S = t.getValue(g);
          S && (S.liveStyle = true), d[g] = y ?? null;
        }), h.push({ animation: d });
      }
      let _ = !!h.length;
      return n && (c.initial === false || c.initial === c.animate) && !t.manuallyAnimateOnMount && (_ = false), n = false, o = false, _ ? e(h) : Promise.resolve();
    }
    function l(u, c) {
      var h;
      if (r[u].isActive === c) return Promise.resolve();
      (h = t.variantChildren) == null || h.forEach((f) => {
        var m;
        return (m = f.animationState) == null ? void 0 : m.setActive(u, c);
      }), r[u].isActive = c;
      let p = a(u);
      for (let f in r) r[f].protectedKeys = {};
      return p;
    }
    return { animateChanges: a, setActive: l, setAnimateFunction: s, getState: () => r, reset: () => {
      r = KC(), o = true;
    } };
  }
  function ZC(t, e) {
    return typeof e == "string" ? e !== t : Array.isArray(e) ? !Dx(e, t) : false;
  }
  function qi(t = false) {
    return { isActive: t, protectedKeys: {}, needsAnimating: {}, prevResolvedValues: {} };
  }
  function KC() {
    return { animate: qi(true), whileInView: qi(), whileHover: qi(), whileTap: qi(), whileDrag: qi(), whileFocus: qi(), exit: qi() };
  }
  function Xh(t, e) {
    t.min = e.min, t.max = e.max;
  }
  function Lr(t, e) {
    Xh(t.x, e.x), Xh(t.y, e.y);
  }
  function Px(t, e) {
    t.translate = e.translate, t.scale = e.scale, t.originPoint = e.originPoint, t.origin = e.origin;
  }
  var JC = 1e-4, vR = 1 - JC, wR = 1 + JC, ek = 0.01, SR = 0 - ek, TR = 0 + ek;
  function it(t) {
    return t.max - t.min;
  }
  function Ix(t, e, r) {
    return Math.abs(t - e) <= r;
  }
  function Rx(t, e, r, n = 0.5) {
    t.origin = n, t.originPoint = oe(e.min, e.max, t.origin), t.scale = it(r) / it(e), t.translate = oe(r.min, r.max, t.origin) - t.originPoint, (t.scale >= vR && t.scale <= wR || isNaN(t.scale)) && (t.scale = 1), (t.translate >= SR && t.translate <= TR || isNaN(t.translate)) && (t.translate = 0);
  }
  function zi(t, e, r, n) {
    Rx(t.x, e.x, r.x, n ? n.originX : void 0), Rx(t.y, e.y, r.y, n ? n.originY : void 0);
  }
  function Vx(t, e, r, n = 0) {
    let o = n ? oe(r.min, r.max, n) : r.min;
    t.min = o + e.min, t.max = t.min + it(e);
  }
  function Lx(t, e, r, n) {
    Vx(t.x, e.x, r.x, n == null ? void 0 : n.x), Vx(t.y, e.y, r.y, n == null ? void 0 : n.y);
  }
  function Fx(t, e, r, n = 0) {
    let o = n ? oe(r.min, r.max, n) : r.min;
    t.min = e.min - o, t.max = t.min + it(e);
  }
  function wa(t, e, r, n) {
    Fx(t.x, e.x, r.x, n == null ? void 0 : n.x), Fx(t.y, e.y, r.y, n == null ? void 0 : n.y);
  }
  function tk(t, e, r, n, o) {
    return t -= e, t = ku(t, 1 / r, n), o !== void 0 && (t = ku(t, 1 / o, n)), t;
  }
  function AR(t, e = 0, r = 1, n = 0.5, o, i = t, s = t) {
    if (Rt.test(e) && (e = parseFloat(e), e = oe(s.min, s.max, e / 100) - s.min), typeof e != "number") return;
    let a = oe(i.min, i.max, n);
    t === i && (a -= e), t.min = tk(t.min, e, r, a, o), t.max = tk(t.max, e, r, a, o);
  }
  function rk(t, e, [r, n, o], i, s) {
    AR(t, e[r], e[n], e[o], e.scale, i, s);
  }
  var CR = ["x", "scaleX", "originX"], kR = ["y", "scaleY", "originY"];
  function Bx(t, e, r, n) {
    rk(t.x, e, CR, r ? r.x : void 0, n ? n.x : void 0), rk(t.y, e, kR, r ? r.y : void 0, n ? n.y : void 0);
  }
  function nk(t) {
    return t.translate === 0 && t.scale === 1;
  }
  function jx(t) {
    return nk(t.x) && nk(t.y);
  }
  function ok(t, e) {
    return t.min === e.min && t.max === e.max;
  }
  function sk(t, e) {
    return ok(t.x, e.x) && ok(t.y, e.y);
  }
  function ik(t, e) {
    return Math.round(t.min) === Math.round(e.min) && Math.round(t.max) === Math.round(e.max);
  }
  function qx(t, e) {
    return ik(t.x, e.x) && ik(t.y, e.y);
  }
  function zx(t) {
    return it(t.x) / it(t.y);
  }
  function Wx(t, e) {
    return t.translate === e.translate && t.scale === e.scale && t.originPoint === e.originPoint;
  }
  function xr(t) {
    return [t("x"), t("y")];
  }
  function ak(t, e, r) {
    let n = "", o = t.x.translate / e.x, i = t.y.translate / e.y, s = (r == null ? void 0 : r.z) || 0;
    if ((o || i || s) && (n = `translate3d(${o}px, ${i}px, ${s}px) `), (e.x !== 1 || e.y !== 1) && (n += `scale(${1 / e.x}, ${1 / e.y}) `), r) {
      let { transformPerspective: u, rotate: c, pathRotation: p, rotateX: h, rotateY: f, skewX: m, skewY: x } = r;
      u && (n = `perspective(${u}px) ${n}`), c && (n += `rotate(${c}deg) `), p && (n += `rotate(${p}deg) `), h && (n += `rotateX(${h}deg) `), f && (n += `rotateY(${f}deg) `), m && (n += `skewX(${m}deg) `), x && (n += `skewY(${x}deg) `);
    }
    let a = t.x.scale * e.x, l = t.y.scale * e.y;
    return (a !== 1 || l !== 1) && (n += `scale(${a}, ${l})`), n || "none";
  }
  var pk = ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"], ER = pk.length, lk = (t) => typeof t == "string" ? parseFloat(t) : t, uk = (t) => typeof t == "number" || G.test(t);
  function hk(t, e, r, n, o, i) {
    o ? (t.opacity = oe(0, r.opacity ?? 1, bR(n)), t.opacityExit = oe(e.opacity ?? 1, 0, NR(n))) : i && (t.opacity = oe(e.opacity ?? 1, r.opacity ?? 1, n));
    for (let s = 0; s < ER; s++) {
      let a = pk[s], l = ck(e, a), u = ck(r, a);
      if (l === void 0 && u === void 0) continue;
      l || (l = 0), u || (u = 0), l === 0 || u === 0 || uk(l) === uk(u) ? (t[a] = Math.max(oe(lk(l), lk(u), n), 0), (Rt.test(u) || Rt.test(l)) && (t[a] += "%")) : t[a] = u;
    }
    (e.rotate || r.rotate) && (t.rotate = oe(e.rotate || 0, r.rotate || 0, n));
  }
  function ck(t, e) {
    return t[e] !== void 0 ? t[e] : t.borderRadius;
  }
  var bR = fk(0, 0.5, ou), NR = fk(0.5, 0.95, Le);
  function fk(t, e, r) {
    return (n) => n < t ? 0 : n > e ? 1 : r(Cn(t, e, n));
  }
  function mk(t, e, r) {
    let n = ve(t) ? t : an(t);
    return n.start(Pi("", n, e, r)), n.animation;
  }
  function Dn(t, e, r, n = { passive: true }) {
    return t.addEventListener(e, r, n), () => t.removeEventListener(e, r);
  }
  var dk = (t, e) => t.depth - e.depth;
  var Yh = class {
    constructor() {
      this.children = [], this.isDirty = false;
    }
    add(e) {
      bi(this.children, e), this.isDirty = true;
    }
    remove(e) {
      Bo(this.children, e), this.isDirty = true;
    }
    forEach(e) {
      this.isDirty && this.children.sort(dk), this.isDirty = false, this.children.forEach(e);
    }
  };
  function gk(t, e) {
    let r = Be.now(), n = ({ timestamp: o }) => {
      let i = o - r;
      i >= e && (nr(n), t(i - e));
    };
    return ne.setup(n, true), () => nr(n);
  }
  function Wi(t) {
    return ve(t) ? t.get() : t;
  }
  var Qh = class {
    constructor() {
      this.members = [];
    }
    add(e) {
      bi(this.members, e);
      for (let r = this.members.length - 1; r >= 0; r--) {
        let n = this.members[r];
        if (n === e || n === this.lead || n === this.prevLead) continue;
        let o = n.instance;
        (!o || o.isConnected === false) && !n.snapshot && (Bo(this.members, n), n.unmount());
      }
      e.scheduleRender();
    }
    remove(e) {
      if (Bo(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
        let r = this.members[this.members.length - 1];
        r && this.promote(r);
      }
    }
    relegate(e) {
      var r;
      for (let n = this.members.indexOf(e) - 1; n >= 0; n--) {
        let o = this.members[n];
        if (o.isPresent !== false && ((r = o.instance) == null ? void 0 : r.isConnected) !== false) return this.promote(o), true;
      }
      return false;
    }
    promote(e, r) {
      var o;
      let n = this.lead;
      if (e !== n && (this.prevLead = n, this.lead = e, e.show(), n)) {
        n.updateSnapshot(), e.scheduleRender();
        let { layoutDependency: i } = n.options, { layoutDependency: s } = e.options;
        (i === void 0 || i !== s) && (e.resumeFrom = n, r && (n.preserveOpacity = true), n.snapshot && (e.snapshot = n.snapshot, e.snapshot.latestValues = n.animationValues || n.latestValues), (o = e.root) != null && o.isUpdating && (e.isLayoutDirty = true)), e.options.crossfade === false && n.hide();
      }
    }
    exitAnimationComplete() {
      this.members.forEach((e) => {
        var r, n, o, i, s;
        (n = (r = e.options).onExitComplete) == null || n.call(r), (s = (o = e.resumingFrom) == null ? void 0 : (i = o.options).onExitComplete) == null || s.call(i);
      });
    }
    scheduleRender() {
      this.members.forEach((e) => e.instance && e.scheduleRender(false));
    }
    removeLeadSnapshot() {
      var e;
      (e = this.lead) != null && e.snapshot && (this.lead.snapshot = void 0);
    }
  };
  var Ui = { hasAnimatedSinceResize: true, hasEverUpdated: false };
  var Gi = { nodes: 0, calculatedTargetDeltas: 0, calculatedProjections: 0 }, Ux = ["", "X", "Y", "Z"], OR = 1e3, DR = 0;
  function Gx(t, e, r, n) {
    let { latestValues: o } = e;
    o[t] && (r[t] = o[t], e.setStaticValue(t, 0), n && (n[t] = 0));
  }
  function Ck(t) {
    if (t.hasCheckedOptimisedAppear = true, t.root === t) return;
    let { visualElement: e } = t.options;
    if (!e) return;
    let r = bh(e);
    if (window.MotionHasOptimisedAnimation(r, "transform")) {
      let { layout: o, layoutId: i } = t.options;
      window.MotionCancelOptimisedAnimation(r, "transform", ne, !(o || i));
    }
    let { parent: n } = t;
    n && !n.hasCheckedOptimisedAppear && Ck(n);
  }
  function Kh({ attachResizeListener: t, defaultParent: e, measureScroll: r, checkIsScrollRoot: n, resetTransform: o }) {
    return class {
      constructor(s = {}, a = e == null ? void 0 : e()) {
        this.id = DR++, this.animationId = 0, this.animationCommitId = 0, this.children = /* @__PURE__ */ new Set(), this.options = {}, this.isTreeAnimating = false, this.isAnimationBlocked = false, this.isLayoutDirty = false, this.isProjectionDirty = false, this.isSharedProjectionDirty = false, this.isTransformDirty = false, this.updateManuallyBlocked = false, this.updateBlockedByResize = false, this.isUpdating = false, this.isSVG = false, this.needsReset = false, this.shouldResetTransform = false, this.hasCheckedOptimisedAppear = false, this.treeScale = { x: 1, y: 1 }, this.eventHandlers = /* @__PURE__ */ new Map(), this.hasTreeAnimated = false, this.layoutVersion = 0, this.updateScheduled = false, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = false, this.checkUpdateFailed = () => {
          this.isUpdating && (this.isUpdating = false, this.clearAllSnapshots());
        }, this.updateProjection = () => {
          this.projectionUpdateScheduled = false, dr.value && (Gi.nodes = Gi.calculatedTargetDeltas = Gi.calculatedProjections = 0), this.nodes.forEach(RR), this.nodes.forEach(jR), this.nodes.forEach(qR), this.nodes.forEach(VR), dr.addProjectionMetrics && dr.addProjectionMetrics(Gi);
        }, this.resolvedRelativeTargetAt = 0, this.linkedParentVersion = 0, this.hasProjected = false, this.isVisible = true, this.animationProgress = 0, this.sharedNodes = /* @__PURE__ */ new Map(), this.latestValues = s, this.root = a ? a.root || a : this, this.path = a ? [...a.path, a] : [], this.parent = a, this.depth = a ? a.depth + 1 : 0;
        for (let l = 0; l < this.path.length; l++) this.path[l].shouldResetTransform = true;
        this.root === this && (this.nodes = new Yh());
      }
      addEventListener(s, a) {
        return this.eventHandlers.has(s) || this.eventHandlers.set(s, new Qn()), this.eventHandlers.get(s).add(a);
      }
      notifyListeners(s, ...a) {
        let l = this.eventHandlers.get(s);
        l && l.notify(...a);
      }
      hasListeners(s) {
        return this.eventHandlers.has(s);
      }
      mount(s) {
        if (this.instance) return;
        this.isSVG = xa(s) && !PC(s), this.instance = s;
        let { layoutId: a, layout: l, visualElement: u } = this.options;
        if (u && !u.current && u.mount(s), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (l || a) && (this.isLayoutDirty = true), t) {
          let c, p = 0, h = () => this.root.updateBlockedByResize = false;
          ne.read(() => {
            p = window.innerWidth;
          }), t(s, () => {
            let f = window.innerWidth;
            f !== p && (p = f, this.root.updateBlockedByResize = true, c && c(), c = gk(h, 250), Ui.hasAnimatedSinceResize && (Ui.hasAnimatedSinceResize = false, this.nodes.forEach(_k)));
          });
        }
        a && this.root.registerSharedNode(a, this), this.options.animate !== false && u && (a || l) && this.addEventListener("didUpdate", ({ delta: c, hasLayoutChanged: p, hasRelativeLayoutChanged: h, layout: f }) => {
          if (this.isTreeAnimationBlocked()) {
            this.target = void 0, this.relativeTarget = void 0;
            return;
          }
          let m = this.options.transition || u.getDefaultTransition() || HR, { onLayoutAnimationStart: x, onLayoutAnimationComplete: _ } = u.getProps(), d = !this.targetLayout || !qx(this.targetLayout, f), g = !p && h;
          if (this.options.layoutRoot || this.resumeFrom || g || p && (d || !this.currentAnimation)) {
            this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
            let y = { ...fa(m, "layout"), onPlay: x, onComplete: _ };
            (u.shouldReduceMotion || this.options.layoutRoot) && (y.delay = 0, y.type = false), this.startAnimation(y), this.setAnimationOrigin(c, g, y.path);
          } else p || _k(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
          this.targetLayout = f;
        });
      }
      unmount() {
        this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
        let s = this.getStack();
        s && s.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), nr(this.updateProjection);
      }
      blockUpdate() {
        this.updateManuallyBlocked = true;
      }
      unblockUpdate() {
        this.updateManuallyBlocked = false;
      }
      isUpdateBlocked() {
        return this.updateManuallyBlocked || this.updateBlockedByResize;
      }
      isTreeAnimationBlocked() {
        return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || false;
      }
      startUpdate() {
        this.isUpdateBlocked() || (this.isUpdating = true, this.nodes && this.nodes.forEach(zR), this.animationId++);
      }
      getTransformTemplate() {
        let { visualElement: s } = this.options;
        return s && s.getProps().transformTemplate;
      }
      willUpdate(s = true) {
        if (this.root.hasTreeAnimated = true, this.root.isUpdateBlocked()) {
          this.options.onExitComplete && this.options.onExitComplete();
          return;
        }
        if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && Ck(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
        this.isLayoutDirty = true;
        for (let c = 0; c < this.path.length; c++) {
          let p = this.path[c];
          p.shouldResetTransform = true, (typeof p.latestValues.x == "string" || typeof p.latestValues.y == "string") && (p.isLayoutDirty = true), p.updateScroll("snapshot"), p.options.layoutRoot && p.willUpdate(false);
        }
        let { layoutId: a, layout: l } = this.options;
        if (a === void 0 && !l) return;
        let u = this.getTransformTemplate();
        this.prevTransformTemplateValue = u ? u(this.latestValues, "") : void 0, this.updateSnapshot(), s && this.notifyListeners("willUpdate");
      }
      update() {
        if (this.updateScheduled = false, this.isUpdateBlocked()) {
          let l = this.updateBlockedByResize;
          this.unblockUpdate(), this.updateBlockedByResize = false, this.clearAllSnapshots(), l && this.nodes.forEach(IR), this.nodes.forEach(xk);
          return;
        }
        if (this.animationId <= this.animationCommitId) {
          this.nodes.forEach(yk);
          return;
        }
        this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = false, this.nodes.forEach(LR), this.nodes.forEach(BR), this.nodes.forEach(MR), this.nodes.forEach(PR)) : this.nodes.forEach(yk), this.clearAllSnapshots();
        let a = Be.now();
        He.delta = ft(0, 1e3 / 60, a - He.timestamp), He.timestamp = a, He.isProcessing = true, uu.update.process(He), uu.preRender.process(He), uu.render.process(He), He.isProcessing = false;
      }
      didUpdate() {
        this.updateScheduled || (this.updateScheduled = true, Ii.read(this.scheduleUpdate));
      }
      clearAllSnapshots() {
        this.nodes.forEach(FR), this.sharedNodes.forEach(WR);
      }
      scheduleUpdateProjection() {
        this.projectionUpdateScheduled || (this.projectionUpdateScheduled = true, ne.preRender(this.updateProjection, false, true));
      }
      scheduleCheckAfterUnmount() {
        ne.postRender(() => {
          this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed();
        });
      }
      updateSnapshot() {
        this.snapshot || !this.instance || (this.snapshot = this.measure(), this.snapshot && !it(this.snapshot.measuredBox.x) && !it(this.snapshot.measuredBox.y) && (this.snapshot = void 0));
      }
      updateLayout() {
        if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
        if (this.resumeFrom && !this.resumeFrom.instance) for (let l = 0; l < this.path.length; l++) this.path[l].updateScroll();
        let s = this.layout;
        this.layout = this.measure(false), this.layoutVersion++, this.layoutCorrected || (this.layoutCorrected = De()), this.isLayoutDirty = false, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
        let { visualElement: a } = this.options;
        a && a.notify("LayoutMeasure", this.layout.layoutBox, s ? s.layoutBox : void 0);
      }
      updateScroll(s = "measure") {
        let a = !!(this.options.layoutScroll && this.instance);
        if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === s && (a = false), a && this.instance) {
          let l = n(this.instance);
          this.scroll = { animationId: this.root.animationId, phase: s, isRoot: l, offset: r(this.instance), wasRoot: this.scroll ? this.scroll.isRoot : l };
        }
      }
      resetTransform() {
        if (!o) return;
        let s = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout, a = this.projectionDelta && !jx(this.projectionDelta), l = this.getTransformTemplate(), u = l ? l(this.latestValues, "") : void 0, c = u !== this.prevTransformTemplateValue;
        s && this.instance && (a || to(this.latestValues) || c) && (o(this.instance, u), this.shouldResetTransform = false, this.scheduleRender());
      }
      measure(s = true) {
        let a = this.measurePageBox(), l = this.removeElementScroll(a);
        return s && (l = this.removeTransform(l)), $R(l), { animationId: this.root.animationId, measuredBox: a, layoutBox: l, latestValues: {}, source: this.id };
      }
      measurePageBox() {
        var u;
        let { visualElement: s } = this.options;
        if (!s) return De();
        let a = s.measureViewportBox();
        if (!(((u = this.scroll) == null ? void 0 : u.wasRoot) || this.path.some(XR))) {
          let { scroll: c } = this.root;
          c && (Ir(a.x, c.offset.x), Ir(a.y, c.offset.y));
        }
        return a;
      }
      removeElementScroll(s) {
        var l;
        let a = De();
        if (Lr(a, s), (l = this.scroll) != null && l.wasRoot) return a;
        for (let u = 0; u < this.path.length; u++) {
          let c = this.path[u], { scroll: p, options: h } = c;
          c !== this.root && p && h.layoutScroll && (p.wasRoot && Lr(a, s), Ir(a.x, p.offset.x), Ir(a.y, p.offset.y));
        }
        return a;
      }
      applyTransform(s, a = false, l) {
        var c, p;
        let u = l || De();
        Lr(u, s);
        for (let h = 0; h < this.path.length; h++) {
          let f = this.path[h];
          !a && f.options.layoutScroll && f.scroll && f !== f.root && (Ir(u.x, -f.scroll.offset.x), Ir(u.y, -f.scroll.offset.y)), to(f.latestValues) && Eu(u, f.latestValues, (c = f.layout) == null ? void 0 : c.layoutBox);
        }
        return to(this.latestValues) && Eu(u, this.latestValues, (p = this.layout) == null ? void 0 : p.layoutBox), u;
      }
      removeTransform(s) {
        var l;
        let a = De();
        Lr(a, s);
        for (let u = 0; u < this.path.length; u++) {
          let c = this.path[u];
          if (!to(c.latestValues)) continue;
          let p;
          c.instance && (Uh(c.latestValues) && c.updateSnapshot(), p = De(), Lr(p, c.measurePageBox())), Bx(a, c.latestValues, (l = c.snapshot) == null ? void 0 : l.layoutBox, p);
        }
        return to(this.latestValues) && Bx(a, this.latestValues), a;
      }
      setTargetDelta(s) {
        this.targetDelta = s, this.root.scheduleUpdateProjection(), this.isProjectionDirty = true;
      }
      setOptions(s) {
        this.options = { ...this.options, ...s, crossfade: s.crossfade !== void 0 ? s.crossfade : true };
      }
      clearMeasurements() {
        this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = false;
      }
      forceRelativeParentToResolveTarget() {
        this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== He.timestamp && this.relativeParent.resolveTargetDelta(true);
      }
      resolveTargetDelta(s = false) {
        var f;
        let a = this.getLead();
        this.isProjectionDirty || (this.isProjectionDirty = a.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = a.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = a.isSharedProjectionDirty);
        let l = !!this.resumingFrom || this !== a;
        if (!(s || l && this.isSharedProjectionDirty || this.isProjectionDirty || (f = this.parent) != null && f.isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
        let { layout: c, layoutId: p } = this.options;
        if (!this.layout || !(c || p)) return;
        this.resolvedRelativeTargetAt = He.timestamp;
        let h = this.getClosestProjectingParent();
        h && this.linkedParentVersion !== h.layoutVersion && !h.options.layoutRoot && this.removeRelativeTarget(), !this.targetDelta && !this.relativeTarget && (this.options.layoutAnchor !== false && h && h.layout ? this.createRelativeTarget(h, this.layout.layoutBox, h.layout.layoutBox) : this.removeRelativeTarget()), !(!this.relativeTarget && !this.targetDelta) && (this.target || (this.target = De(), this.targetWithTransforms = De()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), Lx(this.target, this.relativeTarget, this.relativeParent.target, this.options.layoutAnchor || void 0)) : this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, false, this.target) : Lr(this.target, this.layout.layoutBox), bx(this.target, this.targetDelta)) : Lr(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = false, this.options.layoutAnchor !== false && h && !!h.resumingFrom == !!this.resumingFrom && !h.options.layoutScroll && h.target && this.animationProgress !== 1 ? this.createRelativeTarget(h, this.target, h.target) : this.relativeParent = this.relativeTarget = void 0), dr.value && Gi.calculatedTargetDeltas++);
      }
      getClosestProjectingParent() {
        if (!(!this.parent || Uh(this.parent.latestValues) || kx(this.parent.latestValues))) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent();
      }
      isProjecting() {
        return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout);
      }
      createRelativeTarget(s, a, l) {
        this.relativeParent = s, this.linkedParentVersion = s.layoutVersion, this.forceRelativeParentToResolveTarget(), this.relativeTarget = De(), this.relativeTargetOrigin = De(), wa(this.relativeTargetOrigin, a, l, this.options.layoutAnchor || void 0), Lr(this.relativeTarget, this.relativeTargetOrigin);
      }
      removeRelativeTarget() {
        this.relativeParent = this.relativeTarget = void 0;
      }
      calcProjection() {
        var m;
        let s = this.getLead(), a = !!this.resumingFrom || this !== s, l = true;
        if ((this.isProjectionDirty || (m = this.parent) != null && m.isProjectionDirty) && (l = false), a && (this.isSharedProjectionDirty || this.isTransformDirty) && (l = false), this.resolvedRelativeTargetAt === He.timestamp && (l = false), l) return;
        let { layout: u, layoutId: c } = this.options;
        if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(u || c)) return;
        Lr(this.layoutCorrected, this.layout.layoutBox);
        let p = this.treeScale.x, h = this.treeScale.y;
        GC(this.layoutCorrected, this.treeScale, this.path, a), s.layout && !s.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (s.target = s.layout.layoutBox, s.targetWithTransforms = De());
        let { target: f } = s;
        if (!f) {
          this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
          return;
        }
        !this.projectionDelta || !this.prevProjectionDelta ? this.createProjectionDeltas() : (Px(this.prevProjectionDelta.x, this.projectionDelta.x), Px(this.prevProjectionDelta.y, this.projectionDelta.y)), zi(this.projectionDelta, this.layoutCorrected, f, this.latestValues), (this.treeScale.x !== p || this.treeScale.y !== h || !Wx(this.projectionDelta.x, this.prevProjectionDelta.x) || !Wx(this.projectionDelta.y, this.prevProjectionDelta.y)) && (this.hasProjected = true, this.scheduleRender(), this.notifyListeners("projectionUpdate", f)), dr.value && Gi.calculatedProjections++;
      }
      hide() {
        this.isVisible = false;
      }
      show() {
        this.isVisible = true;
      }
      scheduleRender(s = true) {
        var a;
        if ((a = this.options.visualElement) == null || a.scheduleRender(), s) {
          let l = this.getStack();
          l && l.scheduleRender();
        }
        this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0);
      }
      createProjectionDeltas() {
        this.prevProjectionDelta = Xo(), this.projectionDelta = Xo(), this.projectionDeltaWithTransform = Xo();
      }
      setAnimationOrigin(s, a = false, l) {
        let u = this.snapshot, c = u ? u.latestValues : {}, p = { ...this.latestValues }, h = Xo();
        (!this.relativeParent || !this.relativeParent.options.layoutRoot) && (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !a;
        let f = De(), m = u ? u.source : void 0, x = this.layout ? this.layout.source : void 0, _ = m !== x, d = this.getStack(), g = !d || d.members.length <= 1, y = !!(_ && !g && this.options.crossfade === true && !this.path.some(GR));
        this.animationProgress = 0;
        let S, v = l == null ? void 0 : l.interpolateProjection(s);
        this.mixTargetDelta = (T) => {
          let A = T / 1e3, w = v == null ? void 0 : v(A);
          w ? (h.x.translate = w.x, h.x.scale = oe(s.x.scale, 1, A), h.x.origin = s.x.origin, h.x.originPoint = s.x.originPoint, h.y.translate = w.y, h.y.scale = oe(s.y.scale, 1, A), h.y.origin = s.y.origin, h.y.originPoint = s.y.originPoint) : (vk(h.x, s.x, A), vk(h.y, s.y, A)), this.setTargetDelta(h), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (wa(f, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), UR(this.relativeTarget, this.relativeTargetOrigin, f, A), S && sk(this.relativeTarget, S) && (this.isProjectionDirty = false), S || (S = De()), Lr(S, this.relativeTarget)), _ && (this.animationValues = p, hk(p, c, this.latestValues, A, y, g)), w && w.rotate !== void 0 && (this.animationValues || (this.animationValues = p), this.animationValues.pathRotation = w.rotate), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = A;
        }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
      }
      startAnimation(s) {
        var a, l, u;
        this.notifyListeners("animationStart"), (a = this.currentAnimation) == null || a.stop(), (u = (l = this.resumingFrom) == null ? void 0 : l.currentAnimation) == null || u.stop(), this.pendingAnimation && (nr(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = ne.update(() => {
          Ui.hasAnimatedSinceResize = true, kn.layout++, this.motionValue || (this.motionValue = an(0)), this.motionValue.jump(0, false), this.currentAnimation = mk(this.motionValue, [0, 1e3], { ...s, velocity: 0, isSync: true, onUpdate: (c) => {
            this.mixTargetDelta(c), s.onUpdate && s.onUpdate(c);
          }, onStop: () => {
            kn.layout--;
          }, onComplete: () => {
            kn.layout--, s.onComplete && s.onComplete(), this.completeAnimation();
          } }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0;
        });
      }
      completeAnimation() {
        this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
        let s = this.getStack();
        s && s.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete");
      }
      finishAnimation() {
        this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(OR), this.currentAnimation.stop()), this.completeAnimation();
      }
      applyTransformsToTarget() {
        let s = this.getLead(), { targetWithTransforms: a, target: l, layout: u, latestValues: c } = s;
        if (!(!a || !l || !u)) {
          if (this !== s && this.layout && u && kk(this.options.animationType, this.layout.layoutBox, u.layoutBox)) {
            l = this.target || De();
            let p = it(this.layout.layoutBox.x);
            l.x.min = s.target.x.min, l.x.max = l.x.min + p;
            let h = it(this.layout.layoutBox.y);
            l.y.min = s.target.y.min, l.y.max = l.y.min + h;
          }
          Lr(a, l), Eu(a, c), zi(this.projectionDeltaWithTransform, this.layoutCorrected, a, c);
        }
      }
      registerSharedNode(s, a) {
        this.sharedNodes.has(s) || this.sharedNodes.set(s, new Qh()), this.sharedNodes.get(s).add(a);
        let u = a.options.initialPromotionConfig;
        a.promote({ transition: u ? u.transition : void 0, preserveFollowOpacity: u && u.shouldPreserveFollowOpacity ? u.shouldPreserveFollowOpacity(a) : void 0 });
      }
      isLead() {
        let s = this.getStack();
        return s ? s.lead === this : true;
      }
      getLead() {
        var a;
        let { layoutId: s } = this.options;
        return s ? ((a = this.getStack()) == null ? void 0 : a.lead) || this : this;
      }
      getPrevLead() {
        var a;
        let { layoutId: s } = this.options;
        return s ? (a = this.getStack()) == null ? void 0 : a.prevLead : void 0;
      }
      getStack() {
        let { layoutId: s } = this.options;
        if (s) return this.root.sharedNodes.get(s);
      }
      promote({ needsReset: s, transition: a, preserveFollowOpacity: l } = {}) {
        let u = this.getStack();
        u && u.promote(this, l), s && (this.projectionDelta = void 0, this.needsReset = true), a && this.setOptions({ transition: a });
      }
      relegate() {
        let s = this.getStack();
        return s ? s.relegate(this) : false;
      }
      resetSkewAndRotation() {
        let { visualElement: s } = this.options;
        if (!s) return;
        let a = false, { latestValues: l } = s;
        if ((l.z || l.rotate || l.rotateX || l.rotateY || l.rotateZ || l.skewX || l.skewY) && (a = true), !a) return;
        let u = {};
        l.z && Gx("z", s, u, this.animationValues);
        for (let c = 0; c < Ux.length; c++) Gx(`rotate${Ux[c]}`, s, u, this.animationValues), Gx(`skew${Ux[c]}`, s, u, this.animationValues);
        s.render();
        for (let c in u) s.setStaticValue(c, u[c]), this.animationValues && (this.animationValues[c] = u[c]);
        s.scheduleRender();
      }
      applyProjectionStyles(s, a) {
        if (!this.instance || this.isSVG) return;
        if (!this.isVisible) {
          s.visibility = "hidden";
          return;
        }
        let l = this.getTransformTemplate();
        if (this.needsReset) {
          this.needsReset = false, s.visibility = "", s.opacity = "", s.pointerEvents = Wi(a == null ? void 0 : a.pointerEvents) || "", s.transform = l ? l(this.latestValues, "") : "none";
          return;
        }
        let u = this.getLead();
        if (!this.projectionDelta || !this.layout || !u.target) {
          this.options.layoutId && (s.opacity = this.latestValues.opacity !== void 0 ? this.latestValues.opacity : 1, s.pointerEvents = Wi(a == null ? void 0 : a.pointerEvents) || ""), this.hasProjected && !to(this.latestValues) && (s.transform = l ? l({}, "") : "none", this.hasProjected = false);
          return;
        }
        s.visibility = "";
        let c = u.animationValues || u.latestValues;
        this.applyTransformsToTarget();
        let p = ak(this.projectionDeltaWithTransform, this.treeScale, c);
        l && (p = l(c, p)), s.transform = p;
        let { x: h, y: f } = this.projectionDelta;
        s.transformOrigin = `${h.origin * 100}% ${f.origin * 100}% 0`, u.animationValues ? s.opacity = u === this ? c.opacity ?? this.latestValues.opacity ?? 1 : this.preserveOpacity ? this.latestValues.opacity : c.opacityExit : s.opacity = u === this ? c.opacity !== void 0 ? c.opacity : "" : c.opacityExit !== void 0 ? c.opacityExit : 0;
        for (let m in bu) {
          if (c[m] === void 0) continue;
          let { correct: x, applyTo: _, isCSSVariable: d } = bu[m], g = p === "none" ? c[m] : x(c[m], u);
          if (_) {
            let y = _.length;
            for (let S = 0; S < y; S++) s[_[S]] = g;
          } else d ? this.options.visualElement.renderState.vars[m] = g : s[m] = g;
        }
        this.options.layoutId && (s.pointerEvents = u === this ? Wi(a == null ? void 0 : a.pointerEvents) || "" : "none");
      }
      clearSnapshot() {
        this.resumeFrom = this.snapshot = void 0;
      }
      resetTree() {
        this.root.nodes.forEach((s) => {
          var a;
          return (a = s.currentAnimation) == null ? void 0 : a.stop();
        }), this.root.nodes.forEach(xk), this.root.sharedNodes.clear();
      }
    };
  }
  function MR(t) {
    t.updateLayout();
  }
  function PR(t) {
    var r;
    let e = ((r = t.resumeFrom) == null ? void 0 : r.snapshot) || t.snapshot;
    if (t.isLead() && t.layout && e && t.hasListeners("didUpdate")) {
      let { layoutBox: n, measuredBox: o } = t.layout, { animationType: i } = t.options, s = e.source !== t.layout.source;
      if (i === "size") xr((p) => {
        let h = s ? e.measuredBox[p] : e.layoutBox[p], f = it(h);
        h.min = n[p].min, h.max = h.min + f;
      });
      else if (i === "x" || i === "y") {
        let p = i === "x" ? "y" : "x";
        Xh(s ? e.measuredBox[p] : e.layoutBox[p], n[p]);
      } else kk(i, e.layoutBox, n) && xr((p) => {
        let h = s ? e.measuredBox[p] : e.layoutBox[p], f = it(n[p]);
        h.max = h.min + f, t.relativeTarget && !t.currentAnimation && (t.isProjectionDirty = true, t.relativeTarget[p].max = t.relativeTarget[p].min + f);
      });
      let a = Xo();
      zi(a, n, e.layoutBox);
      let l = Xo();
      s ? zi(l, t.applyTransform(o, true), e.measuredBox) : zi(l, n, e.layoutBox);
      let u = !jx(a), c = false;
      if (!t.resumeFrom) {
        let p = t.getClosestProjectingParent();
        if (p && !p.resumeFrom) {
          let { snapshot: h, layout: f } = p;
          if (h && f) {
            let m = t.options.layoutAnchor || void 0, x = De();
            wa(x, e.layoutBox, h.layoutBox, m);
            let _ = De();
            wa(_, n, f.layoutBox, m), qx(x, _) || (c = true), p.options.layoutRoot && (t.relativeTarget = _, t.relativeTargetOrigin = x, t.relativeParent = p);
          }
        }
      }
      t.notifyListeners("didUpdate", { layout: n, snapshot: e, delta: l, layoutDelta: a, hasLayoutChanged: u, hasRelativeLayoutChanged: c });
    } else if (t.isLead()) {
      let { onExitComplete: n } = t.options;
      n && n();
    }
    t.options.transition = void 0;
  }
  function RR(t) {
    dr.value && Gi.nodes++, t.parent && (t.isProjecting() || (t.isProjectionDirty = t.parent.isProjectionDirty), t.isSharedProjectionDirty || (t.isSharedProjectionDirty = !!(t.isProjectionDirty || t.parent.isProjectionDirty || t.parent.isSharedProjectionDirty)), t.isTransformDirty || (t.isTransformDirty = t.parent.isTransformDirty));
  }
  function VR(t) {
    t.isProjectionDirty = t.isSharedProjectionDirty = t.isTransformDirty = false;
  }
  function FR(t) {
    t.clearSnapshot();
  }
  function xk(t) {
    t.clearMeasurements();
  }
  function IR(t) {
    t.isLayoutDirty = true, t.updateLayout();
  }
  function yk(t) {
    t.isLayoutDirty = false;
  }
  function LR(t) {
    t.isAnimationBlocked && t.layout && !t.isLayoutDirty && (t.snapshot = t.layout, t.isLayoutDirty = true);
  }
  function BR(t) {
    let { visualElement: e } = t.options;
    e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), t.resetTransform();
  }
  function _k(t) {
    t.finishAnimation(), t.targetDelta = t.relativeTarget = t.target = void 0, t.isProjectionDirty = true;
  }
  function jR(t) {
    t.resolveTargetDelta();
  }
  function qR(t) {
    t.calcProjection();
  }
  function zR(t) {
    t.resetSkewAndRotation();
  }
  function WR(t) {
    t.removeLeadSnapshot();
  }
  function vk(t, e, r) {
    t.translate = oe(e.translate, 0, r), t.scale = oe(e.scale, 1, r), t.origin = e.origin, t.originPoint = e.originPoint;
  }
  function wk(t, e, r, n) {
    t.min = oe(e.min, r.min, n), t.max = oe(e.max, r.max, n);
  }
  function UR(t, e, r, n) {
    wk(t.x, e.x, r.x, n), wk(t.y, e.y, r.y, n);
  }
  function GR(t) {
    return t.animationValues && t.animationValues.opacityExit !== void 0;
  }
  var HR = { duration: 0.45, ease: [0.4, 0, 0.1, 1] }, Sk = (t) => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(t), Tk = Sk("applewebkit/") && !Sk("chrome/") ? Math.round : Le;
  function Ak(t) {
    t.min = Tk(t.min), t.max = Tk(t.max);
  }
  function $R(t) {
    Ak(t.x), Ak(t.y);
  }
  function kk(t, e, r) {
    return t === "position" || t === "preserve-aspect" && !Ix(zx(e), zx(r), 0.2);
  }
  function XR(t) {
    var e;
    return t !== t.root && ((e = t.scroll) == null ? void 0 : e.wasRoot);
  }
  var Ek = Kh({ attachResizeListener: (t, e) => Dn(t, "resize", e), measureScroll: () => {
    var t, e;
    return { x: document.documentElement.scrollLeft || ((t = document.body) == null ? void 0 : t.scrollLeft) || 0, y: document.documentElement.scrollTop || ((e = document.body) == null ? void 0 : e.scrollTop) || 0 };
  }, checkIsScrollRoot: () => true });
  var Zh = { current: void 0 }, Vu = Kh({ measureScroll: (t) => ({ x: t.scrollLeft, y: t.scrollTop }), defaultParent: () => {
    if (!Zh.current) {
      let t = new Ek({});
      t.mount(window), t.setOptions({ layoutScroll: true }), Zh.current = t;
    }
    return Zh.current;
  }, resetTransform: (t, e) => {
    t.style.transform = e !== void 0 ? e : "none";
  }, checkIsScrollRoot: (t) => window.getComputedStyle(t).position === "fixed" });
  var Jh = se(xe(), 1), ro = se(xe(), 1);
  var bk = se(xe(), 1), Sa = (0, bk.createContext)({ transformPagePoint: (t) => t, isStatic: false, reducedMotion: "never" });
  var Ok = se(xe(), 1);
  function Nk(t, e) {
    if (typeof t == "function") return t(e);
    t != null && (t.current = e);
  }
  function YR(...t) {
    return (e) => {
      let r = false, n = t.map((o) => {
        let i = Nk(o, e);
        return !r && typeof i == "function" && (r = true), i;
      });
      if (r) return () => {
        for (let o = 0; o < n.length; o++) {
          let i = n[o];
          typeof i == "function" ? i() : Nk(t[o], null);
        }
      };
    };
  }
  function Dk(...t) {
    return Ok.useCallback(YR(...t), t);
  }
  var Hx = class extends Jh.Component {
    getSnapshotBeforeUpdate(e) {
      let r = this.props.childRef.current;
      if (Fi(r) && e.isPresent && !this.props.isPresent && this.props.pop !== false) {
        let n = r.offsetParent, o = Fi(n) && n.offsetWidth || 0, i = Fi(n) && n.offsetHeight || 0, s = getComputedStyle(r), a = this.props.sizeRef.current;
        a.height = parseFloat(s.height), a.width = parseFloat(s.width), a.top = r.offsetTop, a.left = r.offsetLeft, a.right = o - a.width - a.left, a.bottom = i - a.height - a.top, a.direction = s.direction;
      }
      return null;
    }
    componentDidUpdate() {
    }
    render() {
      return this.props.children;
    }
  };
  function Pk({ children: t, isPresent: e, anchorX: r, anchorY: n, root: o, pop: i }) {
    var h;
    let s = (0, ro.useId)(), a = (0, ro.useRef)(null), l = (0, ro.useRef)({ width: 0, height: 0, top: 0, left: 0, right: 0, bottom: 0, direction: "ltr" }), { nonce: u } = (0, ro.useContext)(Sa), c = ((h = t.props) == null ? void 0 : h.ref) ?? (t == null ? void 0 : t.ref), p = Dk(a, c);
    return (0, ro.useInsertionEffect)(() => {
      let { width: f, height: m, top: x, left: _, right: d, bottom: g, direction: y } = l.current;
      if (e || i === false || !a.current || !f || !m) return;
      let S = y === "rtl", v = r === "left" ? S ? `right: ${d}` : `left: ${_}` : S ? `left: ${_}` : `right: ${d}`, T = n === "bottom" ? `bottom: ${g}` : `top: ${x}`;
      a.current.dataset.motionPopId = s;
      let A = document.createElement("style");
      u && (A.nonce = u);
      let w = o ?? document.head;
      return w.appendChild(A), A.sheet && A.sheet.insertRule(`
          [data-motion-pop-id="${s}"] {
            position: absolute !important;
            width: ${f}px !important;
            height: ${m}px !important;
            ${v}px !important;
            ${T}px !important;
          }
        `), () => {
        var N;
        (N = a.current) == null || N.removeAttribute("data-motion-pop-id"), w.contains(A) && w.removeChild(A);
      };
    }, [e]), (0, Mk.jsx)(Hx, { isPresent: e, childRef: a, sizeRef: l, pop: i, children: i === false ? t : Jh.cloneElement(t, { ref: p }) });
  }
  var Vk = ({ children: t, initial: e, isPresent: r, onExitComplete: n, custom: o, presenceAffectsLayout: i, mode: s, anchorX: a, anchorY: l, root: u }) => {
    let c = oa(QR), p = (0, Fu.useId)(), h = true, f = (0, Fu.useMemo)(() => (h = false, { id: p, initial: e, isPresent: r, custom: o, onExitComplete: (m) => {
      c.set(m, true);
      for (let x of c.values()) if (!x) return;
      n && n();
    }, register: (m) => (c.set(m, false), () => c.delete(m)) }), [r, c, n]);
    return i && h && (f = { ...f }), (0, Fu.useMemo)(() => {
      c.forEach((m, x) => c.set(x, false));
    }, [r]), Rk.useEffect(() => {
      !r && !c.size && n && n();
    }, [r]), t = (0, $x.jsx)(Pk, { pop: s === "popLayout", isPresent: r, anchorX: a, anchorY: l, root: u, children: t }), (0, $x.jsx)(Lo.Provider, { value: f, children: t });
  };
  function QR() {
    return /* @__PURE__ */ new Map();
  }
  var Qo = se(xe(), 1);
  function ef(t = true) {
    let e = (0, Qo.useContext)(Lo);
    if (e === null) return [true, null];
    let { isPresent: r, onExitComplete: n, register: o } = e, i = (0, Qo.useId)();
    (0, Qo.useEffect)(() => {
      if (t) return o(i);
    }, [t]);
    let s = (0, Qo.useCallback)(() => t && n && n(i), [i, n, t]);
    return !r && n ? [false, s] : [true];
  }
  var tf = se(xe(), 1), Iu = (t) => t.key || "";
  function Xx(t) {
    let e = [];
    return tf.Children.forEach(t, (r) => {
      (0, tf.isValidElement)(r) && e.push(r);
    }), e;
  }
  var Yx = ({ children: t, custom: e, initial: r = true, onExitComplete: n, presenceAffectsLayout: o = true, mode: i = "sync", propagate: s = false, anchorX: a = "left", anchorY: l = "top", root: u }) => {
    let [c, p] = ef(s), h = (0, ln.useMemo)(() => Xx(t), [t]), f = s && !c ? [] : h.map(Iu), m = (0, ln.useRef)(true), x = (0, ln.useRef)(h), _ = oa(() => /* @__PURE__ */ new Map()), d = (0, ln.useRef)(/* @__PURE__ */ new Set()), [g, y] = (0, ln.useState)(h), [S, v] = (0, ln.useState)(h);
    eh(() => {
      m.current = false, x.current = h;
      for (let w = 0; w < S.length; w++) {
        let N = Iu(S[w]);
        f.includes(N) ? (_.delete(N), d.current.delete(N)) : _.get(N) !== true && _.set(N, false);
      }
    }, [S, f.length, f.join("-")]);
    let T = [];
    if (h !== g) {
      let w = [...h];
      for (let N = 0; N < S.length; N++) {
        let k = S[N], D = Iu(k);
        f.includes(D) || (w.splice(N, 0, k), T.push(k));
      }
      return i === "wait" && T.length && (w = T), v(Xx(w)), y(h), null;
    }
    let { forceRender: A } = (0, ln.useContext)(na);
    return (0, Lu.jsx)(Lu.Fragment, { children: S.map((w) => {
      let N = Iu(w), k = s && !c ? false : h === S || f.includes(N), D = () => {
        if (d.current.has(N)) return;
        if (_.has(N)) d.current.add(N), _.set(N, true);
        else return;
        let M = true;
        _.forEach((q) => {
          q || (M = false);
        }), M && (A == null || A(), v(x.current), s && (p == null || p()), n && n());
      };
      return (0, Lu.jsx)(Vk, { isPresent: k, initial: !m.current || r ? void 0 : false, custom: e, presenceAffectsLayout: o, mode: i, root: u, onExitComplete: k ? void 0 : D, anchorX: a, anchorY: l, children: w }, N);
    }) });
  };
  var Fk = se(xe(), 1), rf = (0, Fk.createContext)({ strict: false });
  var Ik = { animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"], exit: ["exit"], drag: ["drag", "dragControls"], focus: ["whileFocus"], hover: ["whileHover", "onHoverStart", "onHoverEnd"], tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"], pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"], inView: ["whileInView", "onViewportEnter", "onViewportLeave"], layout: ["layout", "layoutId"] }, Lk = false;
  function KR() {
    if (Lk) return;
    let t = {};
    for (let e in Ik) t[e] = { isEnabled: (r) => Ik[e].some((n) => !!r[n]) };
    Au(t), Lk = true;
  }
  function nf() {
    return KR(), Sx();
  }
  function Bk(t) {
    let e = nf();
    for (let r in t) e[r] = { ...e[r], ...t[r] };
    Au(e);
  }
  var ZR = /* @__PURE__ */ new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "propagate", "ignoreStrict", "viewport"]);
  function Bu(t) {
    return t.startsWith("while") || t.startsWith("drag") && t !== "draggable" || t.startsWith("layout") || t.startsWith("onTap") || t.startsWith("onPan") || t.startsWith("onLayout") || ZR.has(t);
  }
  var jk = (t) => !Bu(t);
  function JR(t) {
    typeof t == "function" && (jk = (e) => e.startsWith("on") ? !Bu(e) : t(e));
  }
  try {
    JR(sy("@emotion/is-prop-valid").default);
  } catch {
  }
  function qk(t, e, r) {
    let n = {};
    for (let o in t) o === "values" && typeof t.values == "object" || ve(t[o]) || (jk(o) || r === true && Bu(o) || !e && !Bu(o) || t.draggable && o.startsWith("onDrag")) && (n[o] = t[o]);
    return n;
  }
  var uf = se(Io(), 1);
  var ka = se(xe(), 1);
  var zk = se(xe(), 1), Ko = (0, zk.createContext)({});
  var of = se(xe(), 1);
  function Wk(t, e) {
    if (Yo(t)) {
      let { initial: r, animate: n } = t;
      return { initial: r === false || On(r) ? r : void 0, animate: On(n) ? n : void 0 };
    }
    return t.inherit !== false ? e : {};
  }
  function Gk(t) {
    let { initial: e, animate: r } = Wk(t, (0, of.useContext)(Ko));
    return (0, of.useMemo)(() => ({ initial: e, animate: r }), [Uk(e), Uk(r)]);
  }
  function Uk(t) {
    return Array.isArray(t) ? t.join(" ") : t;
  }
  var Ca = se(xe(), 1);
  var Hk = se(xe(), 1);
  var Ta = () => ({ style: {}, transform: {}, transformOrigin: {}, vars: {} });
  function Qx(t, e, r) {
    for (let n in e) !ve(e[n]) && !Nu(n, r) && (t[n] = e[n]);
  }
  function eV({ transformTemplate: t }, e) {
    return (0, Hk.useMemo)(() => {
      let r = Ta();
      return Bi(r, e, t), Object.assign({}, r.vars, r.style);
    }, [e]);
  }
  function tV(t, e) {
    let r = t.style || {}, n = {};
    return Qx(n, r, t), Object.assign(n, eV(t, e)), n;
  }
  function $k(t, e) {
    let r = {}, n = tV(t, e);
    return t.drag && t.dragListener !== false && (r.draggable = false, n.userSelect = n.WebkitUserSelect = n.WebkitTouchCallout = "none", n.touchAction = t.drag === true ? "none" : `pan-${t.drag === "x" ? "y" : "x"}`), t.tabIndex === void 0 && (t.onTap || t.onTapStart || t.whileTap) && (r.tabIndex = 0), r.style = n, r;
  }
  var Xk = se(xe(), 1);
  var sf = () => ({ ...Ta(), attrs: {} });
  function Yk(t, e, r, n) {
    let o = (0, Xk.useMemo)(() => {
      let i = sf();
      return Du(i, e, Mu(n), t.transformTemplate, t.style), { ...i.attrs, style: { ...i.style } };
    }, [e]);
    if (t.style) {
      let i = {};
      Qx(i, t.style, t), o.style = { ...i, ...o.style };
    }
    return o;
  }
  var Qk = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];
  function Aa(t) {
    return typeof t != "string" || t.includes("-") ? false : !!(Qk.indexOf(t) > -1 || /[A-Z]/u.test(t));
  }
  function Kk(t, e, r, { latestValues: n }, o, i = false, s) {
    let l = (s ?? Aa(t) ? Yk : $k)(e, n, o, t), u = qk(e, typeof t == "string", i), c = t !== Ca.Fragment ? { ...u, ...l, ref: r } : {}, { children: p } = e, h = (0, Ca.useMemo)(() => ve(p) ? p.get() : p, [p]);
    return (0, Ca.createElement)(t, { ...c, children: h });
  }
  var Kx = se(xe(), 1);
  function rV({ scrapeMotionValuesFromProps: t, createRenderState: e }, r, n, o) {
    return { latestValues: nV(r, n, o, t), renderState: e() };
  }
  function nV(t, e, r, n) {
    let o = {}, i = n(t, {});
    for (let h in i) o[h] = Wi(i[h]);
    let { initial: s, animate: a } = t, l = Yo(t), u = wu(t);
    e && u && !l && t.inherit !== false && (s === void 0 && (s = e.initial), a === void 0 && (a = e.animate));
    let c = r ? r.initial === false : false;
    c = c || s === false;
    let p = c ? a : s;
    if (p && typeof p != "boolean" && !eo(p)) {
      let h = Array.isArray(p) ? p : [p];
      for (let f = 0; f < h.length; f++) {
        let m = Ri(t, h[f]);
        if (m) {
          let { transitionEnd: x, transition: _, ...d } = m;
          for (let g in d) {
            let y = d[g];
            if (Array.isArray(y)) {
              let S = c ? y.length - 1 : 0;
              y = y[S];
            }
            y !== null && (o[g] = y);
          }
          for (let g in x) o[g] = x[g];
        }
      }
    }
    return o;
  }
  var af = (t) => (e, r) => {
    let n = (0, Kx.useContext)(Ko), o = (0, Kx.useContext)(Lo), i = () => rV(t, e, n, o);
    return r ? i() : oa(i);
  };
  var Zk = af({ scrapeMotionValuesFromProps: ji, createRenderState: Ta });
  var Jk = af({ scrapeMotionValuesFromProps: Pu, createRenderState: sf });
  var eE = Symbol.for("motionComponentSymbol");
  var Hi = se(xe(), 1);
  function tE(t, e, r) {
    let n = (0, Hi.useRef)(r);
    (0, Hi.useInsertionEffect)(() => {
      n.current = r;
    });
    let o = (0, Hi.useRef)(null);
    return (0, Hi.useCallback)((i) => {
      var a;
      i && ((a = t.onMount) == null || a.call(t, i)), e && (i ? e.mount(i) : e.unmount());
      let s = n.current;
      if (typeof s == "function") if (i) {
        let l = s(i);
        typeof l == "function" && (o.current = l);
      } else o.current ? (o.current(), o.current = null) : s(i);
      else s && (s.current = i);
    }, [e]);
  }
  var $t = se(xe(), 1);
  var rE = se(xe(), 1), lf = (0, rE.createContext)({});
  function Zo(t) {
    return t && typeof t == "object" && Object.prototype.hasOwnProperty.call(t, "current");
  }
  function nE(t, e, r, n, o, i) {
    var y, S;
    let { visualElement: s } = (0, $t.useContext)(Ko), a = (0, $t.useContext)(rf), l = (0, $t.useContext)(Lo), u = (0, $t.useContext)(Sa), c = u.reducedMotion, p = u.skipAnimations, h = (0, $t.useRef)(null), f = (0, $t.useRef)(false);
    n = n || a.renderer, !h.current && n && (h.current = n(t, { visualState: e, parent: s, props: r, presenceContext: l, blockInitialAnimation: l ? l.initial === false : false, reducedMotionConfig: c, skipAnimations: p, isSVG: i }), f.current && h.current && (h.current.manuallyAnimateOnMount = true));
    let m = h.current, x = (0, $t.useContext)(lf);
    m && !m.projection && o && (m.type === "html" || m.type === "svg") && oV(h.current, r, o, x);
    let _ = (0, $t.useRef)(false);
    (0, $t.useInsertionEffect)(() => {
      m && _.current && m.update(r, l);
    });
    let d = r[gu], g = (0, $t.useRef)(!!d && typeof window < "u" && !((y = window.MotionHandoffIsComplete) != null && y.call(window, d)) && ((S = window.MotionHasOptimisedAnimation) == null ? void 0 : S.call(window, d)));
    return eh(() => {
      f.current = true, m && (_.current = true, window.MotionIsMounted = true, m.updateFeatures(), m.scheduleRenderMicrotask(), g.current && m.animationState && m.animationState.animateChanges());
    }), (0, $t.useEffect)(() => {
      m && (!g.current && m.animationState && m.animationState.animateChanges(), g.current && (queueMicrotask(() => {
        var v;
        (v = window.MotionHandoffMarkAsComplete) == null || v.call(window, d);
      }), g.current = false), m.enteringChildren = void 0);
    }), m;
  }
  function oV(t, e, r, n) {
    let { layoutId: o, layout: i, drag: s, dragConstraints: a, layoutScroll: l, layoutRoot: u, layoutAnchor: c, layoutCrossfade: p } = e;
    t.projection = new r(t.latestValues, e["data-framer-portal-id"] ? void 0 : oE(t.parent)), t.projection.setOptions({ layoutId: o, layout: i, alwaysMeasureLayout: !!s || a && Zo(a), visualElement: t, animationType: typeof i == "string" ? i : "both", initialPromotionConfig: n, crossfade: p, layoutScroll: l, layoutRoot: u, layoutAnchor: c });
  }
  function oE(t) {
    if (t) return t.options.allowProjection !== false ? t.projection : oE(t.parent);
  }
  function cf(t, { forwardMotionProps: e = false, type: r } = {}, n, o) {
    n && Bk(n);
    let i = r ? r === "svg" : Aa(t), s = i ? Jk : Zk;
    function a(u, c) {
      let p, h = { ...(0, ka.useContext)(Sa), ...u, layoutId: iV(u) }, { isStatic: f } = h, m = Gk(u), x = s(u, f);
      if (!f && typeof window < "u") {
        sV(h, n);
        let _ = aV(h);
        p = _.MeasureLayout, m.visualElement = nE(t, x, h, o, _.ProjectionNode, i);
      }
      return (0, uf.jsxs)(Ko.Provider, { value: m, children: [p && m.visualElement ? (0, uf.jsx)(p, { visualElement: m.visualElement, ...h }) : null, Kk(t, u, tE(x, m.visualElement, c), x, f, e, i)] });
    }
    a.displayName = `motion.${typeof t == "string" ? t : `create(${t.displayName ?? t.name ?? ""})`}`;
    let l = (0, ka.forwardRef)(a);
    return l[eE] = t, l;
  }
  function iV({ layoutId: t }) {
    let e = (0, ka.useContext)(na).id;
    return e && t !== void 0 ? e + "-" + t : t;
  }
  function sV(t, e) {
    let r = (0, ka.useContext)(rf).strict;
  }
  function aV(t) {
    let e = nf(), { drag: r, layout: n } = e;
    if (!r && !n) return {};
    let o = { ...r, ...n };
    return { MeasureLayout: r != null && r.isEnabled(t) || n != null && n.isEnabled(t) ? o.MeasureLayout : void 0, ProjectionNode: o.ProjectionNode };
  }
  function iE(t, e) {
    if (typeof Proxy > "u") return cf;
    let r = /* @__PURE__ */ new Map(), n = (i, s) => cf(i, s, t, e), o = (i, s) => n(i, s);
    return new Proxy(o, { get: (i, s) => s === "create" ? n : (r.has(s) || r.set(s, cf(s, void 0, t, e)), r.get(s)) });
  }
  var sE = se(xe(), 1);
  var aE = (t, e) => e.isSVG ?? Aa(t) ? new Ru(e) : new Ou(e, { allowProjection: t !== sE.Fragment });
  var pf = class extends dt {
    constructor(e) {
      super(e), e.animationState || (e.animationState = Mx(e));
    }
    updateAnimationControlsSubscription() {
      let { animate: e } = this.node.getProps();
      eo(e) && (this.unmountControls = e.subscribe(this.node));
    }
    mount() {
      this.updateAnimationControlsSubscription();
    }
    update() {
      let { animate: e } = this.node.getProps(), { animate: r } = this.node.prevProps || {};
      e !== r && this.updateAnimationControlsSubscription();
    }
    unmount() {
      var e;
      this.node.animationState.reset(), (e = this.unmountControls) == null || e.call(this);
    }
  };
  var lV = 0, hf = class extends dt {
    constructor() {
      super(...arguments), this.id = lV++, this.isExitComplete = false;
    }
    update() {
      var i;
      if (!this.node.presenceContext) return;
      let { isPresent: e, onExitComplete: r } = this.node.presenceContext, { isPresent: n } = this.node.prevPresenceContext || {};
      if (!this.node.animationState || e === n) return;
      if (e && n === false) {
        if (this.isExitComplete) {
          let { initial: s, custom: a } = this.node.getProps();
          if (typeof s == "string" || typeof s == "object" && s !== null && !Array.isArray(s)) {
            let l = gr(this.node, s, a);
            if (l) {
              let { transition: u, transitionEnd: c, ...p } = l;
              for (let h in p) (i = this.node.getValue(h)) == null || i.jump(p[h]);
            }
          }
          this.node.animationState.reset(), this.node.animationState.animateChanges();
        } else this.node.animationState.setActive("exit", false);
        this.isExitComplete = false;
        return;
      }
      let o = this.node.animationState.setActive("exit", !e);
      r && !e && o.then(() => {
        this.isExitComplete = true, r(this.id);
      });
    }
    mount() {
      let { register: e, onExitComplete: r } = this.node.presenceContext || {};
      r && r(this.id), e && (this.unmount = e(this.id));
    }
    unmount() {
    }
  };
  var lE = { animation: { Feature: pf }, exit: { Feature: hf } };
  function no(t) {
    return { point: { x: t.pageX, y: t.pageY } };
  }
  var uE = (t) => (e) => Li(e) && t(e, no(e));
  function Jo(t, e, r, n) {
    return Dn(t, e, uE(r), n);
  }
  var ff = ({ current: t }) => t ? t.ownerDocument.defaultView : null;
  var cE = (t, e) => Math.abs(t - e);
  function pE(t, e) {
    let r = cE(t.x, e.x), n = cE(t.y, e.y);
    return Math.sqrt(r ** 2 + n ** 2);
  }
  var hE = /* @__PURE__ */ new Set(["auto", "scroll"]), Ea = class {
    constructor(e, r, { transformPagePoint: n, contextWindow: o = window, dragSnapToOrigin: i = false, distanceThreshold: s = 3, element: a } = {}) {
      if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = /* @__PURE__ */ new Map(), this.removeScrollListeners = null, this.onElementScroll = (f) => {
        this.handleScroll(f.target);
      }, this.onWindowScroll = () => {
        this.handleScroll(window);
      }, this.updatePoint = () => {
        if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
        this.lastRawMoveEventInfo && (this.lastMoveEventInfo = mf(this.lastRawMoveEventInfo, this.transformPagePoint));
        let f = Zx(this.lastMoveEventInfo, this.history), m = this.startEvent !== null, x = pE(f.offset, { x: 0, y: 0 }) >= this.distanceThreshold;
        if (!m && !x) return;
        let { point: _ } = f, { timestamp: d } = He;
        this.history.push({ ..._, timestamp: d });
        let { onStart: g, onMove: y } = this.handlers;
        m || (g && g(this.lastMoveEvent, f), this.startEvent = this.lastMoveEvent), y && y(this.lastMoveEvent, f);
      }, this.handlePointerMove = (f, m) => {
        this.lastMoveEvent = f, this.lastRawMoveEventInfo = m, this.lastMoveEventInfo = mf(m, this.transformPagePoint), ne.update(this.updatePoint, true);
      }, this.handlePointerUp = (f, m) => {
        this.end();
        let { onEnd: x, onSessionEnd: _, resumeAnimation: d } = this.handlers;
        if ((this.dragSnapToOrigin || !this.startEvent) && d && d(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
        let g = Zx(f.type === "pointercancel" ? this.lastMoveEventInfo : mf(m, this.transformPagePoint), this.history);
        this.startEvent && x && x(f, g), _ && _(f, g);
      }, !Li(e)) return;
      this.dragSnapToOrigin = i, this.handlers = r, this.transformPagePoint = n, this.distanceThreshold = s, this.contextWindow = o || window;
      let l = no(e), u = mf(l, this.transformPagePoint), { point: c } = u, { timestamp: p } = He;
      this.history = [{ ...c, timestamp: p }];
      let { onSessionStart: h } = r;
      h && h(e, Zx(u, this.history)), this.removeListeners = sn(Jo(this.contextWindow, "pointermove", this.handlePointerMove), Jo(this.contextWindow, "pointerup", this.handlePointerUp), Jo(this.contextWindow, "pointercancel", this.handlePointerUp)), a && this.startScrollTracking(a);
    }
    startScrollTracking(e) {
      let r = e.parentElement;
      for (; r; ) {
        let n = getComputedStyle(r);
        (hE.has(n.overflowX) || hE.has(n.overflowY)) && this.scrollPositions.set(r, { x: r.scrollLeft, y: r.scrollTop }), r = r.parentElement;
      }
      this.scrollPositions.set(window, { x: window.scrollX, y: window.scrollY }), window.addEventListener("scroll", this.onElementScroll, { capture: true }), window.addEventListener("scroll", this.onWindowScroll), this.removeScrollListeners = () => {
        window.removeEventListener("scroll", this.onElementScroll, { capture: true }), window.removeEventListener("scroll", this.onWindowScroll);
      };
    }
    handleScroll(e) {
      let r = this.scrollPositions.get(e);
      if (!r) return;
      let n = e === window, o = n ? { x: window.scrollX, y: window.scrollY } : { x: e.scrollLeft, y: e.scrollTop }, i = { x: o.x - r.x, y: o.y - r.y };
      i.x === 0 && i.y === 0 || (n ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += i.x, this.lastMoveEventInfo.point.y += i.y) : this.history.length > 0 && (this.history[0].x -= i.x, this.history[0].y -= i.y), this.scrollPositions.set(e, o), ne.update(this.updatePoint, true));
    }
    updateHandlers(e) {
      this.handlers = e;
    }
    end() {
      this.removeListeners && this.removeListeners(), this.removeScrollListeners && this.removeScrollListeners(), this.scrollPositions.clear(), nr(this.updatePoint);
    }
  };
  function mf(t, e) {
    return e ? { point: e(t.point) } : t;
  }
  function fE(t, e) {
    return { x: t.x - e.x, y: t.y - e.y };
  }
  function Zx({ point: t }, e) {
    return { point: t, delta: fE(t, mE(e)), offset: fE(t, uV(e)), velocity: cV(e, 0.1) };
  }
  function uV(t) {
    return t[0];
  }
  function mE(t) {
    return t[t.length - 1];
  }
  function cV(t, e) {
    if (t.length < 2) return { x: 0, y: 0 };
    let r = t.length - 1, n = null, o = mE(t);
    for (; r >= 0 && (n = t[r], !(o.timestamp - n.timestamp > Ze(e))); ) r--;
    if (!n) return { x: 0, y: 0 };
    n === t[0] && t.length > 2 && o.timestamp - n.timestamp > Ze(e) * 2 && (n = t[1]);
    let i = _t(o.timestamp - n.timestamp);
    if (i === 0) return { x: 0, y: 0 };
    let s = { x: (o.x - n.x) / i, y: (o.y - n.y) / i };
    return s.x === 1 / 0 && (s.x = 0), s.y === 1 / 0 && (s.y = 0), s;
  }
  function _E(t, { min: e, max: r }, n) {
    return e !== void 0 && t < e ? t = n ? oe(e, t, n.min) : Math.max(t, e) : r !== void 0 && t > r && (t = n ? oe(r, t, n.max) : Math.min(t, r)), t;
  }
  function dE(t, e, r) {
    return { min: e !== void 0 ? t.min + e : void 0, max: r !== void 0 ? t.max + r - (t.max - t.min) : void 0 };
  }
  function vE(t, { top: e, left: r, bottom: n, right: o }) {
    return { x: dE(t.x, r, o), y: dE(t.y, e, n) };
  }
  function gE(t, e) {
    let r = e.min - t.min, n = e.max - t.max;
    return e.max - e.min < t.max - t.min && ([r, n] = [n, r]), { min: r, max: n };
  }
  function wE(t, e) {
    return { x: gE(t.x, e.x), y: gE(t.y, e.y) };
  }
  function SE(t, e) {
    let r = 0.5, n = it(t), o = it(e);
    return o > n ? r = Cn(e.min, e.max - n, t.min) : n > o && (r = Cn(t.min, t.max - o, e.min)), ft(0, 1, r);
  }
  function TE(t, e) {
    let r = {};
    return e.min !== void 0 && (r.min = e.min - t.min), e.max !== void 0 && (r.max = e.max - t.min), r;
  }
  var df = 0.35;
  function AE(t = df) {
    return t === false ? t = 0 : t === true && (t = df), { x: xE(t, "left", "right"), y: xE(t, "top", "bottom") };
  }
  function xE(t, e, r) {
    return { min: yE(t, e), max: yE(t, r) };
  }
  function yE(t, e) {
    return typeof t == "number" ? t : t[e] || 0;
  }
  var pV = /* @__PURE__ */ new WeakMap(), xf = class {
    constructor(e) {
      this.openDragLock = null, this.isDragging = false, this.currentDirection = null, this.originPoint = { x: 0, y: 0 }, this.constraints = false, this.hasMutatedConstraints = false, this.elastic = De(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = e;
    }
    start(e, { snapToCursor: r = false, distanceThreshold: n } = {}) {
      let { presenceContext: o } = this.visualElement;
      if (o && o.isPresent === false) return;
      let i = (p) => {
        r && this.snapToCursor(no(p).point), this.stopAnimation();
      }, s = (p, h) => {
        let { drag: f, dragPropagation: m, onDragStart: x } = this.getProps();
        if (f && !m && (this.openDragLock && this.openDragLock(), this.openDragLock = fx(f), !this.openDragLock)) return;
        this.latestPointerEvent = p, this.latestPanInfo = h, this.isDragging = true, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = true, this.visualElement.projection.target = void 0), xr((d) => {
          let g = this.getAxisMotionValue(d).get() || 0;
          if (Rt.test(g)) {
            let { projection: y } = this.visualElement;
            if (y && y.layout) {
              let S = y.layout.layoutBox[d];
              S && (g = it(S) * (parseFloat(g) / 100));
            }
          }
          this.originPoint[d] = g;
        }), x && ne.update(() => x(p, h), false, true), ma(this.visualElement, "transform");
        let { animationState: _ } = this.visualElement;
        _ && _.setActive("whileDrag", true);
      }, a = (p, h) => {
        this.latestPointerEvent = p, this.latestPanInfo = h;
        let { dragPropagation: f, dragDirectionLock: m, onDirectionLock: x, onDrag: _ } = this.getProps();
        if (!f && !this.openDragLock) return;
        let { offset: d } = h;
        if (m && this.currentDirection === null) {
          this.currentDirection = fV(d), this.currentDirection !== null && x && x(this.currentDirection);
          return;
        }
        this.updateAxis("x", h.point, d), this.updateAxis("y", h.point, d), this.visualElement.render(), _ && ne.update(() => _(p, h), false, true);
      }, l = (p, h) => {
        this.latestPointerEvent = p, this.latestPanInfo = h, this.stop(p, h), this.latestPointerEvent = null, this.latestPanInfo = null;
      }, u = () => {
        let { dragSnapToOrigin: p } = this.getProps();
        (p || this.constraints) && this.startAnimation({ x: 0, y: 0 });
      }, { dragSnapToOrigin: c } = this.getProps();
      this.panSession = new Ea(e, { onSessionStart: i, onStart: s, onMove: a, onSessionEnd: l, resumeAnimation: u }, { transformPagePoint: this.visualElement.getTransformPagePoint(), dragSnapToOrigin: c, distanceThreshold: n, contextWindow: ff(this.visualElement), element: this.visualElement.current });
    }
    stop(e, r) {
      let n = e || this.latestPointerEvent, o = r || this.latestPanInfo, i = this.isDragging;
      if (this.cancel(), !i || !o || !n) return;
      let { velocity: s } = o;
      this.startAnimation(s);
      let { onDragEnd: a } = this.getProps();
      a && ne.postRender(() => a(n, o));
    }
    cancel() {
      this.isDragging = false;
      let { projection: e, animationState: r } = this.visualElement;
      e && (e.isAnimationBlocked = false), this.endPanSession();
      let { dragPropagation: n } = this.getProps();
      !n && this.openDragLock && (this.openDragLock(), this.openDragLock = null), r && r.setActive("whileDrag", false);
    }
    endPanSession() {
      this.panSession && this.panSession.end(), this.panSession = void 0;
    }
    updateAxis(e, r, n) {
      let { drag: o } = this.getProps();
      if (!n || !gf(e, o, this.currentDirection)) return;
      let i = this.getAxisMotionValue(e), s = this.originPoint[e] + n[e];
      this.constraints && this.constraints[e] && (s = _E(s, this.constraints[e], this.elastic[e])), i.set(s);
    }
    resolveConstraints() {
      var i;
      let { dragConstraints: e, dragElastic: r } = this.getProps(), n = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(false) : (i = this.visualElement.projection) == null ? void 0 : i.layout, o = this.constraints;
      e && Zo(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && n ? this.constraints = vE(n.layoutBox, e) : this.constraints = false, this.elastic = AE(r), o !== this.constraints && !Zo(e) && n && this.constraints && !this.hasMutatedConstraints && xr((s) => {
        this.constraints !== false && this.getAxisMotionValue(s) && (this.constraints[s] = TE(n.layoutBox[s], this.constraints[s]));
      });
    }
    resolveRefConstraints() {
      let { dragConstraints: e, onMeasureDragConstraints: r } = this.getProps();
      if (!e || !Zo(e)) return false;
      let n = e.current;
      Pr(n !== null, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.", "drag-constraints-ref");
      let { projection: o } = this.visualElement;
      if (!o || !o.layout) return false;
      o.root && (o.root.scroll = void 0, o.root.updateScroll());
      let i = Nx(n, o.root, this.visualElement.getTransformPagePoint()), s = wE(o.layout.layoutBox, i);
      if (r) {
        let a = r(Tx(s));
        this.hasMutatedConstraints = !!a, a && (s = Cu(a));
      }
      return s;
    }
    startAnimation(e) {
      let { drag: r, dragMomentum: n, dragElastic: o, dragTransition: i, dragSnapToOrigin: s, onDragTransitionEnd: a } = this.getProps(), l = this.constraints || {}, u = xr((c) => {
        if (!gf(c, r, this.currentDirection)) return;
        let p = l && l[c] || {};
        (s === true || s === c) && (p = { min: 0, max: 0 });
        let h = o ? 200 : 1e6, f = o ? 40 : 1e7, m = { type: "inertia", velocity: n ? e[c] : 0, bounceStiffness: h, bounceDamping: f, timeConstant: 750, restDelta: 1, restSpeed: 10, ...i, ...p };
        return this.startAxisValueAnimation(c, m);
      });
      return Promise.all(u).then(a);
    }
    startAxisValueAnimation(e, r) {
      let n = this.getAxisMotionValue(e);
      return ma(this.visualElement, e), n.start(Pi(e, n, 0, r, this.visualElement, false));
    }
    stopAnimation() {
      xr((e) => this.getAxisMotionValue(e).stop());
    }
    getAxisMotionValue(e) {
      let r = `_drag${e.toUpperCase()}`, o = this.visualElement.getProps()[r];
      return o || this.visualElement.getValue(e, this.visualElement.latestValues[e] ?? 0);
    }
    snapToCursor(e) {
      xr((r) => {
        let { drag: n } = this.getProps();
        if (!gf(r, n, this.currentDirection)) return;
        let { projection: o } = this.visualElement, i = this.getAxisMotionValue(r);
        if (o && o.layout) {
          let { min: s, max: a } = o.layout.layoutBox[r], l = i.get() || 0;
          i.set(e[r] - oe(s, a, 0.5) + l);
        }
      });
    }
    scalePositionWithinConstraints() {
      if (!this.visualElement.current) return;
      let { drag: e, dragConstraints: r } = this.getProps(), { projection: n } = this.visualElement;
      if (!Zo(r) || !n || !this.constraints) return;
      this.stopAnimation();
      let o = { x: 0, y: 0 };
      xr((s) => {
        let a = this.getAxisMotionValue(s);
        if (a && this.constraints !== false) {
          let l = a.get();
          o[s] = SE({ min: l, max: l }, this.constraints[s]);
        }
      });
      let { transformTemplate: i } = this.visualElement.getProps();
      this.visualElement.current.style.transform = i ? i({}, "") : "none", n.root && n.root.updateScroll(), n.updateLayout(), this.constraints = false, this.resolveConstraints(), xr((s) => {
        if (!gf(s, e, null)) return;
        let a = this.getAxisMotionValue(s), { min: l, max: u } = this.constraints[s];
        a.set(oe(l, u, o[s]));
      }), this.visualElement.render();
    }
    addListeners() {
      if (!this.visualElement.current) return;
      pV.set(this.visualElement, this);
      let e = this.visualElement.current, r = Jo(e, "pointerdown", (u) => {
        let { drag: c, dragListener: p = true } = this.getProps(), h = u.target, f = h !== e && xx(h);
        c && p && !f && this.start(u);
      }), n, o = () => {
        let { dragConstraints: u } = this.getProps();
        Zo(u) && u.current && (this.constraints = this.resolveRefConstraints(), n || (n = hV(e, u.current, () => this.scalePositionWithinConstraints())));
      }, { projection: i } = this.visualElement, s = i.addEventListener("measure", o);
      i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), ne.read(o);
      let a = Dn(window, "resize", () => this.scalePositionWithinConstraints()), l = i.addEventListener("didUpdate", ({ delta: u, hasLayoutChanged: c }) => {
        this.isDragging && c && (xr((p) => {
          let h = this.getAxisMotionValue(p);
          h && (this.originPoint[p] += u[p].translate, h.set(h.get() + u[p].translate));
        }), this.visualElement.render());
      });
      return () => {
        a(), r(), s(), l && l(), n && n();
      };
    }
    getProps() {
      let e = this.visualElement.getProps(), { drag: r = false, dragDirectionLock: n = false, dragPropagation: o = false, dragConstraints: i = false, dragElastic: s = df, dragMomentum: a = true } = e;
      return { ...e, drag: r, dragDirectionLock: n, dragPropagation: o, dragConstraints: i, dragElastic: s, dragMomentum: a };
    }
  };
  function CE(t) {
    let e = true;
    return () => {
      if (e) {
        e = false;
        return;
      }
      t();
    };
  }
  function hV(t, e, r) {
    let n = jh(t, CE(r)), o = jh(e, CE(r));
    return () => {
      n(), o();
    };
  }
  function gf(t, e, r) {
    return (e === true || e === t) && (r === null || r === t);
  }
  function fV(t, e = 10) {
    let r = null;
    return Math.abs(t.y) > e ? r = "y" : Math.abs(t.x) > e && (r = "x"), r;
  }
  var yf = class extends dt {
    constructor(e) {
      super(e), this.removeGroupControls = Le, this.removeListeners = Le, this.controls = new xf(e);
    }
    mount() {
      let { dragControls: e } = this.node.getProps();
      e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || Le;
    }
    update() {
      let { dragControls: e } = this.node.getProps(), { dragControls: r } = this.node.prevProps || {};
      e !== r && (this.removeGroupControls(), e && (this.removeGroupControls = e.subscribe(this.controls)));
    }
    unmount() {
      this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession();
    }
  };
  var Jx = (t) => (e, r) => {
    t && ne.update(() => t(e, r), false, true);
  }, _f = class extends dt {
    constructor() {
      super(...arguments), this.removePointerDownListener = Le;
    }
    onPointerDown(e) {
      this.session = new Ea(e, this.createPanHandlers(), { transformPagePoint: this.node.getTransformPagePoint(), contextWindow: ff(this.node) });
    }
    createPanHandlers() {
      let { onPanSessionStart: e, onPanStart: r, onPan: n, onPanEnd: o } = this.node.getProps();
      return { onSessionStart: Jx(e), onStart: Jx(r), onMove: Jx(n), onEnd: (i, s) => {
        delete this.session, o && ne.postRender(() => o(i, s));
      } };
    }
    mount() {
      this.removePointerDownListener = Jo(this.node.current, "pointerdown", (e) => this.onPointerDown(e));
    }
    update() {
      this.session && this.session.updateHandlers(this.createPanHandlers());
    }
    unmount() {
      this.removePointerDownListener(), this.session && this.session.end();
    }
  };
  var kE = se(Io(), 1);
  var ju = se(xe(), 1);
  var ey = false, ty = class extends ju.Component {
    componentDidMount() {
      let { visualElement: e, layoutGroup: r, switchLayoutGroup: n, layoutId: o } = this.props, { projection: i } = e;
      i && (r.group && r.group.add(i), n && n.register && o && n.register(i), ey && i.root.didUpdate(), i.addEventListener("animationComplete", () => {
        this.safeToRemove();
      }), i.setOptions({ ...i.options, layoutDependency: this.props.layoutDependency, onExitComplete: () => this.safeToRemove() })), Ui.hasEverUpdated = true;
    }
    getSnapshotBeforeUpdate(e) {
      let { layoutDependency: r, visualElement: n, drag: o, isPresent: i } = this.props, { projection: s } = n;
      return s && (s.isPresent = i, e.layoutDependency !== r && s.setOptions({ ...s.options, layoutDependency: r }), ey = true, o || e.layoutDependency !== r || r === void 0 || e.isPresent !== i ? s.willUpdate() : this.safeToRemove(), e.isPresent !== i && (i ? s.promote() : s.relegate() || ne.postRender(() => {
        let a = s.getStack();
        (!a || !a.members.length) && this.safeToRemove();
      }))), null;
    }
    componentDidUpdate() {
      let { visualElement: e, layoutAnchor: r } = this.props, { projection: n } = e;
      n && (n.options.layoutAnchor = r, n.root.didUpdate(), Ii.postRender(() => {
        !n.currentAnimation && n.isLead() && this.safeToRemove();
      }));
    }
    componentWillUnmount() {
      let { visualElement: e, layoutGroup: r, switchLayoutGroup: n } = this.props, { projection: o } = e;
      ey = true, o && (o.scheduleCheckAfterUnmount(), r && r.group && r.group.remove(o), n && n.deregister && n.deregister(o));
    }
    safeToRemove() {
      let { safeToRemove: e } = this.props;
      e && e();
    }
    render() {
      return null;
    }
  };
  function vf(t) {
    let [e, r] = ef(), n = (0, ju.useContext)(na);
    return (0, kE.jsx)(ty, { ...t, layoutGroup: n, switchLayoutGroup: (0, ju.useContext)(lf), isPresent: e, safeToRemove: r });
  }
  var EE = { pan: { Feature: _f }, drag: { Feature: yf, ProjectionNode: Vu, MeasureLayout: vf } };
  function bE(t, e, r) {
    let { props: n } = t;
    t.animationState && n.whileHover && t.animationState.setActive("whileHover", r === "Start");
    let o = "onHover" + r, i = n[o];
    i && ne.postRender(() => i(e, no(e)));
  }
  var wf = class extends dt {
    mount() {
      let { current: e } = this.node;
      e && (this.unmount = mx(e, (r, n) => (bE(this.node, n, "Start"), (o) => bE(this.node, o, "End"))));
    }
    unmount() {
    }
  };
  var Sf = class extends dt {
    constructor() {
      super(...arguments), this.isActive = false;
    }
    onFocus() {
      let e = false;
      try {
        e = this.node.current.matches(":focus-visible");
      } catch {
        e = true;
      }
      !e || !this.node.animationState || (this.node.animationState.setActive("whileFocus", true), this.isActive = true);
    }
    onBlur() {
      !this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", false), this.isActive = false);
    }
    mount() {
      this.unmount = sn(Dn(this.node.current, "focus", () => this.onFocus()), Dn(this.node.current, "blur", () => this.onBlur()));
    }
    unmount() {
    }
  };
  function NE(t, e, r) {
    let { props: n } = t;
    if (t.current instanceof HTMLButtonElement && t.current.disabled) return;
    t.animationState && n.whileTap && t.animationState.setActive("whileTap", r === "Start");
    let o = "onTap" + (r === "End" ? "" : r), i = n[o];
    i && ne.postRender(() => i(e, no(e)));
  }
  var Tf = class extends dt {
    mount() {
      let { current: e } = this.node;
      if (!e) return;
      let { globalTapTarget: r, propagate: n } = this.node.props;
      this.unmount = _x(e, (o, i) => (NE(this.node, i, "Start"), (s, { success: a }) => NE(this.node, s, a ? "End" : "Cancel")), { useGlobalTarget: r, stopPropagation: (n == null ? void 0 : n.tap) === false });
    }
    unmount() {
    }
  };
  var ny = /* @__PURE__ */ new WeakMap(), ry = /* @__PURE__ */ new WeakMap(), mV = (t) => {
    let e = ny.get(t.target);
    e && e(t);
  }, dV = (t) => {
    t.forEach(mV);
  };
  function gV({ root: t, ...e }) {
    let r = t || document;
    ry.has(r) || ry.set(r, {});
    let n = ry.get(r), o = JSON.stringify(e);
    return n[o] || (n[o] = new IntersectionObserver(dV, { root: t, ...e })), n[o];
  }
  function OE(t, e, r) {
    let n = gV(e);
    return ny.set(t, r), n.observe(t), () => {
      ny.delete(t), n.unobserve(t);
    };
  }
  var xV = { some: 0, all: 1 }, Af = class extends dt {
    constructor() {
      super(...arguments), this.hasEnteredView = false, this.isInView = false;
    }
    startObserver() {
      var l;
      (l = this.stopObserver) == null || l.call(this);
      let { viewport: e = {} } = this.node.getProps(), { root: r, margin: n, amount: o = "some", once: i } = e, s = { root: r ? r.current : void 0, rootMargin: n, threshold: typeof o == "number" ? o : xV[o] }, a = (u) => {
        let { isIntersecting: c } = u;
        if (this.isInView === c || (this.isInView = c, i && !c && this.hasEnteredView)) return;
        c && (this.hasEnteredView = true), this.node.animationState && this.node.animationState.setActive("whileInView", c);
        let { onViewportEnter: p, onViewportLeave: h } = this.node.getProps(), f = c ? p : h;
        f && f(u);
      };
      this.stopObserver = OE(this.node.current, s, a);
    }
    mount() {
      this.startObserver();
    }
    update() {
      if (typeof IntersectionObserver > "u") return;
      let { props: e, prevProps: r } = this.node;
      ["amount", "margin", "root"].some(yV(e, r)) && this.startObserver();
    }
    unmount() {
      var e;
      (e = this.stopObserver) == null || e.call(this), this.hasEnteredView = false, this.isInView = false;
    }
  };
  function yV({ viewport: t = {} }, { viewport: e = {} } = {}) {
    return (r) => t[r] !== e[r];
  }
  var DE = { inView: { Feature: Af }, tap: { Feature: Tf }, focus: { Feature: Sf }, hover: { Feature: wf } };
  var ME = { layout: { ProjectionNode: Vu, MeasureLayout: vf } };
  var PE = { ...lE, ...DE, ...EE, ...ME };
  var oy = iE(PE, aE);
  var qe = se(Io()), _V = () => (0, qe.jsx)("style", { children: `
    @font-face {
      font-family: 'Bangers';
      src: url('./assets/fonts/bangers/Bangers-Regular.woff2') format('woff2');
      font-weight: 400;
      font-style: normal;
      font-display: swap;
    }
    :root {
      --font-display: -apple-system, "Helvetica Neue", "PingFang SC", system-ui, sans-serif;
      --font-body:    -apple-system, "Helvetica Neue", "PingFang SC", system-ui, sans-serif;
      --font-mono:    ui-monospace, Menlo, monospace;
      --color-bg:     #f5f4ef;
      --color-player: #303936;
      --color-enemy:  #b66f68;
    }
    html, body, #root { width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; background: var(--color-bg); font-family: var(--font-body); }
    * { box-sizing: border-box; touch-action: none; user-select: none; -webkit-user-drag: none; }
    button { font-family: var(--font-body); }
  ` });
  function vV(t) {
    let e = {};
    return (t.tweaks || []).forEach((r) => {
      e[r.id] = r.value;
    }), (t.texts || []).forEach((r) => {
      e[r.id] = r.value;
    }), (t.images || []).forEach((r) => {
      e[r.id] = r.path;
    }), (t.mentions || []).forEach((r) => {
      e[r.id] = r.path != null && r.path !== "" ? r.path : r.value;
    }), (t.motions || []).forEach((r) => {
      !r || !r.id || (r.base_path != null && r.base_path !== "" && (e[r.id] = r.base_path, e[r.id + "_BASE"] = r.base_path), r.frame_count != null && (e[r.id + "_COUNT"] = r.frame_count));
    }), e;
  }
  function wV() {
    let t = typeof window < "u" && typeof window.tt < "u" && typeof window.tt.playableRecordingSubmission == "function", [e, r] = (0, ge.useState)(false);
    (0, ge.useEffect)(() => {
      let o = () => r(false), i = () => {
        document.visibilityState === "visible" && o();
      };
      return document.addEventListener("visibilitychange", i), window.addEventListener("pageshow", o), () => {
        document.removeEventListener("visibilitychange", i), window.removeEventListener("pageshow", o);
      };
    }, []);
    let n = (0, ge.useCallback)(() => {
      e || !t || (r(true), window.tt.playableRecordingSubmission({ success() {
      }, fail(o) {
        console.error("[post_my_play] playableRecordingSubmission failed", o && (o.errMsg || o.message)), r(false);
      }, complete() {
      } }));
    }, [e, t]);
    return { canSubmit: t, submitting: e, submitRecording: n };
  }
  var SV = ({ cfg: t }) => {
    let e = (0, ge.useRef)(null), r = (0, ge.useRef)(null), n = (0, ge.useRef)(null), o = (0, ge.useRef)(null), i = (0, ge.useRef)(performance.now()), [s, a] = (0, ge.useState)("playing"), [l, u] = (0, ge.useState)(null), [c, p] = (0, ge.useState)({ current: 0, total: t.MAX_ENEMIES }), h = (0, ge.useRef)({
      entities: [],
      particles: [],
      enemySpawned: 0,
      playerTarget: null,
      dragging: false,
      gameState: "playing"
    }), f = (0, ge.useRef)(0), m = (0, ge.useRef)(0), x = (0, ge.useRef)({
      ready: false,
      synthShoot: null,
      synthHit: null,
      synthWin: null,
      synthLose: null,
      lastTime: {},
      lastShootReal: 0
    }), _ = async () => {
      if (!x.current.ready)
        try {
          await bg();
          let C = x.current;
          C.synthShoot = new Xl(on).toDestination(), C.synthShoot.volume.value = -12, C.synthHit = new Ei().toDestination(), C.synthHit.volume.value = -15, C.synthWin = new Xl(on).toDestination(), C.synthWin.volume.value = -8, C.synthLose = new Ei().toDestination(), C.synthLose.volume.value = -8, yA.volume.value = -5, C.ready = true;
        } catch (C) {
          console.warn("Audio init failed", C);
        }
    }, d = (0, ge.useCallback)((C) => {
      let E = x.current, O = Kp(), R = E.lastTime[C] || 0, P = O > R ? O : R + 1e-3;
      return E.lastTime[C] = P, P;
    }, []), g = (0, ge.useCallback)(() => {
      if (!x.current.ready) return;
      let C = Date.now();
      C - x.current.lastShootReal < 60 || (x.current.lastShootReal = C, x.current.synthShoot.triggerAttackRelease("G5", "32n", d("shoot")));
    }, [d]), y = (0, ge.useCallback)(() => {
      x.current.ready && x.current.synthWin.triggerAttackRelease(
        ["C4", "E4", "G4", "C5"],
        "2n",
        Kp()
      );
    }, []), S = (0, ge.useCallback)(() => {
      x.current.ready && x.current.synthLose.triggerAttackRelease("G2", "2n", Kp());
    }, []), v = (0, ge.useCallback)(() => {
      feedGate.current = false;
      setFeedStarted(false);
      if (h.current = {
        entities: [],
        particles: [],
        enemySpawned: 0,
        neutralTotal: 0,
        neutralCap: 9,
        neutralPending: 0,
        neutralNextAt: 0,
        playerTarget: null,
        dragging: false,
        gameState: "playing"
      }, e.current) {
        let C = e.current.clientWidth, E = e.current.clientHeight;
        for (let O = 0; O < 15; O++)
          h.current.entities.push({
            id: Math.random(),
            team: "player",
            x: C / 2 + (Math.random() - 0.5) * 80,
            y: E / 2 + 150 + (Math.random() - 0.5) * 80,
            r: 8,
            hp: 30,
            maxHp: 30,
            speed: t.PLAYER_SPEED || 0.12,
            atkDamage: 5,
            atkRange: 40,
            atkCooldown: 600,
            lastAtk: 0
          });
        h.current.neutralTotal = 3;
        h.current.entities.push(
          ...[
            [0.25, 0.56],
            [0.75, 0.47],
            [0.52, 0.33]
          ].map(([x2, y2]) => ({
            id: Math.random(),
            team: "player",
            x: C * x2,
            y: E * y2,
            r: 8,
            hp: 75,
            maxHp: 75,
            speed: 0,
            atkDamage: 0,
            atkRange: 0,
            atkCooldown: 600,
            lastAtk: 0,
            __neutralTroop: true,
            recruited: false
          }))
        );
      }
      a("playing"), u(null), p({ current: 0, total: t.MAX_ENEMIES }), f.current = 0, m.current = 0, i.current = performance.now();
    }, [t]);
    const [feedStarted, setFeedStarted] = (0, ge.useState)(false);
    const feedGate = (0, ge.useRef)(false);
    (0, ge.useEffect)(() => {
      v();
    }, [v]);
    let T = (0, ge.useCallback)(
      (C) => {
        let E = h.current;
        if (!e.current || E.gameState !== "playing") return;
        let O = e.current.clientWidth, R = e.current.clientHeight;
        if (f.current += C, E.enemySpawned < t.MAX_ENEMIES && f.current - m.current > t.ENEMY_SPAWN_INTERVAL) {
          m.current = f.current;
          for (let j = 0; j < 2 && !(E.enemySpawned >= t.MAX_ENEMIES); j++)
            E.entities.push({
              id: Math.random(),
              team: "enemy",
              x: Math.random() * O,
              y: -20,
              r: 8,
              hp: 20,
              maxHp: 20,
              speed: 0.08,
              atkDamage: 5,
              atkRange: 40,
              atkCooldown: 800,
              lastAtk: 0
            }), E.enemySpawned++;
        }
        let P = Date.now();
        for (let j of E.entities) {
          if (j.__neutralTroop && !j.recruited && E.entities.some(
            (K) => K.team === "player" && !K.__neutralTroop && K.hp > 0 && Math.hypot(K.x - j.x, K.y - j.y) <= 42
          )) {
            j.recruited = true;
            j.speed = t.PLAYER_SPEED || 0.12;
            j.atkDamage = 5;
            j.atkRange = 40;
            j.hp = j.maxHp;
            if (E.neutralTotal + E.neutralPending < E.neutralCap) {
              E.neutralPending++;
              if (!E.neutralNextAt) E.neutralNextAt = f.current + 4e3;
            }
          }
        }
        if (E.neutralPending > 0 && E.neutralTotal < E.neutralCap && f.current >= E.neutralNextAt && E.entities.filter((j) => j.__neutralTroop && !j.recruited && j.hp > 0).length < 3) {
          let spawn = null;
          for (let attempt = 0; attempt < 32; attempt++) {
            let x2 = 45 + Math.random() * Math.max(1, O - 90), y2 = 90 + Math.random() * Math.max(1, R - 150);
            if (!E.entities.some(
              (unit) => unit.hp > 0 && Math.hypot(unit.x - x2, unit.y - y2) < (unit.__neutralTroop && !unit.recruited ? 60 : unit.team === "player" ? 100 : 35)
            )) {
              spawn = { x: x2, y: y2 };
              break;
            }
          }
          if (spawn) {
            E.entities.push({
              id: Math.random(),
              team: "player",
              x: spawn.x,
              y: spawn.y,
              r: 8,
              hp: 75,
              maxHp: 75,
              speed: 0,
              atkDamage: 0,
              atkRange: 0,
              atkCooldown: 600,
              lastAtk: 0,
              __neutralTroop: true,
              recruited: false
            });
            E.neutralTotal++;
            E.neutralPending--;
            E.neutralNextAt = E.neutralPending ? f.current + 4e3 : 0;
          } else E.neutralNextAt = f.current + 500;
        }
        for (let j of E.entities) {
          if (j.hp <= 0 || j.__neutralTroop && !j.recruited) continue;
          let re = null, Y = 1 / 0;
          for (let K of E.entities)
            if (K.team !== j.team && K.hp > 0 && (!K.__neutralTroop || K.recruited)) {
              let ue = K.x - j.x, W = K.y - j.y, st = Math.sqrt(ue * ue + W * W);
              st < Y && (Y = st, re = K);
            }
          if (re && Y <= j.atkRange) {
            if (P - j.lastAtk > j.atkCooldown) {
              re.hp -= j.atkDamage, j.lastAtk = P;
              for (let K = 0; K < 3; K++)
                E.particles.push({
                  x: re.x,
                  y: re.y,
                  vx: (Math.random() - 0.5) * 0.6,
                  vy: (Math.random() - 0.5) * 0.6,
                  life: 300,
                  maxLife: 300,
                  color: "#ffaa00"
                });
              g();
            }
          } else if (j.team === "enemy" && re && (j.targetPos = { x: re.x, y: re.y }), j.team === "player" && E.playerTarget && (j.targetPos = E.playerTarget), j.targetPos) {
            let K = j.targetPos.x - j.x, ue = j.targetPos.y - j.y, W = Math.sqrt(K * K + ue * ue);
            W > j.speed * C ? (j.x += K / W * j.speed * C, j.y += ue / W * j.speed * C) : (j.x = j.targetPos.x, j.y = j.targetPos.y, j.team === "player" && (j.targetPos = null));
          }
          j.x = Math.max(j.r, Math.min(O - j.r, j.x)), j.y = Math.max(j.r, Math.min(R - j.r, j.y));
        }
        for (let j = 0; j < E.entities.length; j++)
          for (let re = j + 1; re < E.entities.length; re++) {
            let Y = E.entities[j], K = E.entities[re];
            if (Y.hp <= 0 || K.hp <= 0) continue;
            let ue = Y.x - K.x, W = Y.y - K.y, st = ue * ue + W * W, Je = Y.r + K.r;
            if (st < Je * Je && st > 1e-3) {
              let un = Math.sqrt(st), Br = (Je - un) * 0.5, qu = ue / un, zu = W / un;
              Y.x += qu * Br, Y.y += zu * Br, K.x -= qu * Br, K.y -= zu * Br;
            }
          }
        for (let j = E.particles.length - 1; j >= 0; j--) {
          let re = E.particles[j];
          re.x += re.vx * C, re.y += re.vy * C, re.life -= C, re.life <= 0 && E.particles.splice(j, 1);
        }
        E.entities = E.entities.filter((j) => j.hp > 0);
        let V = E.entities.filter(
          (j) => j.team === "player" && (!j.__neutralTroop || j.recruited)
        ).length, te = E.entities.filter((j) => j.team === "enemy").length;
        V === 0 ? (E.gameState = "over", S(), u("lose"), a("over")) : E.enemySpawned >= t.MAX_ENEMIES && te === 0 && (E.gameState = "over", y(), u("win"), a("over")), p((j) => {
          let re = E.enemySpawned - te;
          return j.current !== re ? { current: re, total: t.MAX_ENEMIES } : j;
        });
      },
      [t, g, y, S]
    ), A = (0, ge.useCallback)(() => {
      let C = n.current;
      if (!C || !e.current) return;
      let E = e.current.clientWidth, O = e.current.clientHeight;
      C.clearRect(0, 0, E, O);
      let R = h.current;
      R.playerTarget && (C.strokeStyle = "rgba(74,91,77,.35)", C.lineWidth = 2, C.beginPath(), C.arc(R.playerTarget.x, R.playerTarget.y, 14, 0, Math.PI * 2), C.stroke());
      for (let P of R.entities)
        if (C.fillStyle = P.__neutralTroop && !P.recruited ? "#c6ccc3" : P.team === "player" ? "#303936" : "#b66f68", C.beginPath(), C.arc(P.x, P.y, P.r, 0, Math.PI * 2), C.fill(), P.__neutralTroop && !P.recruited && (C.strokeStyle = "#9da79d", C.lineWidth = 1.5, C.stroke()), false, P.hp < P.maxHp) {
          let V = P.r * 2.5, te = 3, j = P.x - V / 2, re = P.y - P.r - 6;
          C.fillStyle = "rgba(0,0,0,0.4)", C.fillRect(j, re, V, te), C.fillStyle = P.team === "player" ? "#91a893" : "#b66f68", C.fillRect(j, re, V * (P.hp / P.maxHp), te);
        }
      for (let P of R.particles)
        C.fillStyle = P.color, C.globalAlpha = Math.max(0, P.life / P.maxLife), C.beginPath(), C.arc(P.x, P.y, 2, 0, Math.PI * 2), C.fill(), C.globalAlpha = 1;
    }, []), w = (0, ge.useCallback)(() => {
      o.current = requestAnimationFrame(w);
      let C = performance.now(), E = C - i.current;
      E > 100 && (E = 16), i.current = C, h.current.gameState === "playing" && (feedGate.current && T(E), A());
    }, [T, A]);
    (0, ge.useEffect)(() => {
      let C = new ResizeObserver((E) => {
        for (let O of E) {
          let { width: R, height: P } = O.contentRect, V = window.devicePixelRatio || 1;
          r.current && R > 0 && P > 0 && (r.current.width = R * V, r.current.height = P * V, r.current.style.width = R + "px", r.current.style.height = P + "px", n.current = r.current.getContext("2d"), n.current.scale(V, V));
        }
      });
      return e.current && C.observe(e.current), o.current = requestAnimationFrame(w), () => {
        C.disconnect(), cancelAnimationFrame(o.current);
      };
    }, [w]);
    let N = (C) => {
      if (!r.current) return;
      feedGate.current = true;
      setFeedStarted(true);
      let E = r.current.getBoundingClientRect();
      h.current.playerTarget = { x: C.clientX - E.left, y: C.clientY - E.top };
    }, k = (C) => {
      C.isPrimary !== false && (_(), s === "playing" && (h.current.dragging = true, C.currentTarget.setPointerCapture?.(C.pointerId), N(C)));
    }, D = (C) => {
      C.isPrimary === false || !h.current.dragging || s !== "playing" || N(C);
    }, M = (C) => {
      C.isPrimary !== false && (h.current.dragging = false, C.currentTarget.hasPointerCapture?.(C.pointerId) && C.currentTarget.releasePointerCapture(C.pointerId));
    }, { canSubmit: q, submitting: B, submitRecording: I } = wV();
    return (0, qe.jsxs)("div", {
      ref: e,
      style: {
        width: "100%",
        height: "100%",
        position: "relative",
        containerType: "size",
        background: "#f5f4ef",
        backgroundSize: "72px 72px,54px 54px,100% 100%"
      },
      children: [
        (0, qe.jsx)(_V, {}),
        !feedStarted && s === "playing" && (0, qe.jsx)("p", { className: "feed-first-action", style: { position: "absolute", top: "90px", left: 30, right: 30, zIndex: 12, margin: 0, fontSize: 18, lineHeight: 1.35, textAlign: "center", pointerEvents: "none", color: "#252627" }, children: "Drag to command troops" }),
        (0, qe.jsx)("canvas", {
          ref: r,
          style: {
            position: "relative",
            zIndex: 1,
            width: "100%",
            height: "100%",
            display: "block"
          },
          onPointerDown: k,
          onPointerMove: D,
          onPointerUp: M,
          onPointerCancel: M
        }),
        (0, qe.jsxs)("div", {
          style: {
            position: "absolute",
            zIndex: 2,
            top: "calc(30px + env(safe-area-inset-top, 0px))",
            left: "30px",
            right: "30px",
            pointerEvents: "none",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center"
          },
          children: [
            (0, qe.jsxs)("div", {
              style: {
                margin: "0 auto",
                minHeight: "44px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "transparent",
                borderRadius: "22px",
                padding: "8px 18px",
                fontFamily: "var(--font-mono)",
                color: "#252627",
                fontSize: "18px",
                fontWeight: 700,
                border: "0",
                boxShadow: "none"
              },
              "aria-label": "Enemies remaining " + Math.max(0, c.total - c.current),
              children: [(0, qe.jsx)("span", { style: { fontSize: 14, marginRight: 8 }, children: "Enemies" }), (0, qe.jsx)("span", { style: { fontSize: 28, lineHeight: 1.2 }, children: Math.max(0, c.total - c.current) })]
            })
          ]
        }),
        (0, qe.jsx)(Yx, {
          children: s === "over" && (0, qe.jsxs)(oy.div, {
            initial: { opacity: 0, scale: 0.95 },
            animate: { opacity: 1, scale: 1 },
            exit: { opacity: 0, scale: 0.95 },
            style: {
              position: "absolute",
              inset: 0,
              zIndex: 20,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "rgba(0,0,0,0.68)",
              backdropFilter: "blur(6px)",
              padding: "calc(40px + env(safe-area-inset-top, 0px)) 25px calc(40px + env(safe-area-inset-bottom, 0px))",
              boxSizing: "border-box"
            },
            children: [
              l === "lose" ? (0, qe.jsxs)("div", {
                style: {
                  width: "min(82%, 420px)",
                  padding: "clamp(24px, 7vw, 40px)",
                  background: "#f5f4ef",
                  borderRadius: "28px",
                  border: "2px solid rgba(239,68,68,.18)",
                  textAlign: "center",
                  marginBottom: "32px",
                  boxShadow: "0 24px 70px rgba(0,0,0,.28)"
                },
                children: [
                  (0, qe.jsx)("div", {
                    style: {
                      width: "72px",
                      height: "72px",
                      margin: "0 auto 18px",
                      borderRadius: "50%",
                      display: "grid",
                      placeItems: "center",
                      background: "rgba(239,68,68,.12)",
                      color: "#dc2626",
                      fontSize: "42px",
                      fontWeight: 900
                    },
                    children: "!"
                  }),
                  (0, qe.jsx)("h1", {
                    style: {
                      fontFamily: "var(--font-display)",
                      color: "#dc2626",
                      fontSize: "clamp(36px, 10vw, 48px)",
                      lineHeight: 1,
                      margin: 0
                    },
                    children: "DEFEATED"
                  }),
                  (0, qe.jsx)("p", {
                    style: {
                      fontFamily: "var(--font-body)",
                      color: "#475569",
                      fontSize: "18px",
                      lineHeight: 1.45,
                      margin: "14px 0 0"
                    },
                    children: "Your army was wiped out."
                  })
                ]
              }) : (0, qe.jsxs)("div", {
                style: {
                  width: "min(82%, 420px)",
                  padding: "clamp(24px, 7vw, 40px)",
                  background: "#f5f4ef",
                  borderRadius: "28px",
                  textAlign: "center",
                  marginBottom: "32px",
                  boxShadow: "0 24px 70px rgba(0,0,0,.28)"
                },
                children: [
                  (0, qe.jsx)("h1", {
                    style: {
                      fontFamily: "var(--font-display)",
                      color: "#2d82fe",
                      fontSize: "clamp(36px, 10vw, 48px)",
                      lineHeight: 1,
                      margin: 0
                    },
                    children: t.TXT_VICTORY
                  }),
                  (0, qe.jsx)("p", {
                    style: {
                      fontFamily: "var(--font-body)",
                      color: "#4a5568",
                      fontSize: "18px",
                      lineHeight: 1.45,
                      margin: "14px 0 0"
                    },
                    children: t.TXT_ALL_CLEARED
                  })
                ]
              }),
              (0, qe.jsxs)("div", {
                style: {
                  display: "flex",
                  gap: "16px",
                  flexWrap: "wrap",
                  justifyContent: "center",
                  width: "100%",
                  padding: "0 20px"
                },
                children: [
                  (0, qe.jsx)("button", {
                    onClick: v,
                    style: {
                      flex: "1 1 auto",
                      minWidth: "130px",
                      padding: "16px 20px",
                      fontFamily: "var(--font-body)",
                      fontSize: "18px",
                      fontWeight: "bold",
                      color: "white",
                      backgroundColor: "#2d82fe",
                      border: "none",
                      borderRadius: "32px",
                      cursor: "pointer",
                      boxShadow: "0 4px 12px rgba(45,130,254,0.3)"
                    },
                    children: t.TXT_TRY_AGAIN
                  }),
                  q && (0, qe.jsx)("button", {
                    onClick: I,
                    disabled: B,
                    style: {
                      flex: "1 1 auto",
                      minWidth: "130px",
                      padding: "16px 20px",
                      fontFamily: "var(--font-body)",
                      fontSize: "18px",
                      fontWeight: "bold",
                      color: "white",
                      backgroundColor: "#ff2d55",
                      border: "none",
                      borderRadius: "32px",
                      cursor: B ? "not-allowed" : "pointer",
                      opacity: B ? 0.6 : 1,
                      boxShadow: "0 4px 12px rgba(255,45,85,0.3)"
                    },
                    children: t.TXT_POST
                  })
                ]
              })
            ]
          })
        })
      ]
    });
  }, TV = () => {
    let [t, e] = (0, ge.useState)(null);
    return (0, ge.useEffect)(() => {
      let r = true;
      return (async () => {
        let n = { tweaks: [], texts: [], images: [] };
        try {
          let o = await fetch("./game.config.json", { cache: "no-store" });
          o.ok && (n = await o.json());
        } catch {
        }
        r && e(vV(n));
      })(), () => {
        r = false;
      };
    }, []), t ? (0, qe.jsx)(SV, { cfg: t }) : (0, qe.jsx)("div", { style: { width: "100%", height: "100%", background: "#f5f4ef" } });
  };
  (0, RE.createRoot)(document.getElementById("root")).render((0, qe.jsx)(TV, {}));
})();
(function() {
  "use strict";
  const script = document.currentScript;
  const selector = "#root canvas";
  const media = window.matchMedia?.("(prefers-reduced-motion: reduce)");
  let observer, animation, entered = false;
  function stop() {
    animation?.cancel();
    animation = null;
  }
  function enter() {
    if (entered || document.hidden) return;
    const subject = document.querySelector(selector);
    if (!subject || subject.closest('[hidden], [aria-hidden="true"]')) return;
    const computed = window.getComputedStyle(subject);
    if (computed.display === "none" || computed.visibility === "hidden") return;
    if (subject.tagName === "IMG" && !subject.complete) {
      subject.addEventListener("load", enter, { once: true });
      return;
    }
    entered = true;
    observer?.disconnect();
    if (media?.matches) return;
    const opacity = Number(window.getComputedStyle(subject).opacity) || 1;
    if (typeof subject.animate === "function") {
      animation = subject.animate([{ opacity: opacity * 0.76 }, { opacity }], { duration: 650, easing: "ease-out" });
      animation.onfinish = () => {
        animation = null;
      };
    }
  }
  observer = new MutationObserver(enter);
  observer.observe(document.body, { childList: true, subtree: true });
  enter();
  document.addEventListener("visibilitychange", () => {
    document.documentElement.toggleAttribute("data-feed-background", document.hidden);
    if (document.hidden) stop();
    else enter();
  });
  window.addEventListener("pagehide", () => {
    observer.disconnect();
    stop();
  });
  window.addEventListener("pageshow", () => {
    if (!entered) observer.observe(document.body, { childList: true, subtree: true });
    enter();
  });
  document.addEventListener("pointerdown", stop, { capture: true, passive: true });
  media?.addEventListener?.("change", () => {
    if (media.matches) stop();
  });
})();
