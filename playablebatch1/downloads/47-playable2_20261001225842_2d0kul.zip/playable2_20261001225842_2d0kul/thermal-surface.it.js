    (() => {
      const overlay = document.getElementById("thermal-overlay");
      const ctx = overlay.getContext("2d");
      const backdrop = document.createElement("canvas");
      const backdropCtx = backdrop.getContext("2d");
      const TAU = Math.PI * 2;
      const CELL = 6;
      const BRUSH_RADIUS = 78;
      const HEAT_DOTS = 5; // One controlled ball plus four mirrored balls.
      const COOL_PER_SECOND = 0.615;
      const heatColors = ["#4676bc", "#21abd2", "#f6e554", "#ffac2b", "#f66b50", "#eb308e"];
      let width = 0;
      let height = 0;
      let dpr = 1;
      let radius = 0;
      let columns = 0;
      let rows = 0;
      let heat = new Float32Array(0);
      let previewHeat = new Float32Array(0);
      let wasPreview = false;
      let point = null;
      let activePointer = null;
      let lastFrame = 0;
      const backgroundWaves = Array.from({ length: 7 }, (_, index) => ({
        y: (index + 0.65) / 7.5,
        amplitude: 8 + Math.random() * 22,
        wavelength: 120 + Math.random() * 190,
        secondary: 42 + Math.random() * 96,
        speed: (0.00008 + Math.random() * 0.0001) * (Math.random() < 0.5 ? -1 : 1),
        phase: Math.random() * TAU,
        alpha: 0.018 + Math.random() * 0.025,
        width: 0.7 + Math.random() * 1.25
      }));

      function noise(index) {
        const value = Math.sin(index * 127.1 + 78.233) * 43758.5453;
        return value - Math.floor(value);
      }

      function buildBackdrop() {
        backdrop.width = Math.ceil(width);
        backdrop.height = Math.ceil(height);
        const base = backdropCtx.createLinearGradient(0, 0, 0, height);
        base.addColorStop(0, "#79559f");
        base.addColorStop(0.58, "#865caa");
        base.addColorStop(1, "#7755a4");
        backdropCtx.fillStyle = base;
        backdropCtx.fillRect(0, 0, width, height);
        const ambientColors = ["#5198be", "#6a91c0", "#4da5c4", "#6780b7"];
        for (let row = 0; row < rows; row++) {
          for (let col = 0; col < columns; col++) {
            const index = row * columns + col;
            backdropCtx.fillStyle = ambientColors[Math.floor(noise(index + 19) * ambientColors.length)];
            backdropCtx.fillRect(col * CELL + 1, row * CELL + 1, CELL - 2, CELL - 2);
          }
        }
      }

      function resize() {
        width = window.innerWidth;
        height = window.innerHeight;
        dpr = Math.min(window.devicePixelRatio || 1, 3);
        radius = Math.max(40, Math.min(width / 2 - 28, height / 2 - 90));
        columns = Math.ceil(width / CELL);
        rows = Math.ceil(height / CELL);
        heat = new Float32Array(columns * rows);
        previewHeat = new Float32Array(columns * rows);
        overlay.width = Math.round(width * dpr);
        overlay.height = Math.round(height * dpr);
        overlay.style.width = width + "px";
        overlay.style.height = height + "px";
        ctx.imageSmoothingEnabled = false;
        buildBackdrop();
      }

      function constrainPoint(clientX, clientY) {
        return { x: clientX, y: clientY };
      }

      function rotatePoint(source, cx, cy, step) {
        const angle = step * TAU / HEAT_DOTS;
        const dx = source.x - cx;
        const dy = source.y - cy;
        return {
          x: cx + dx * Math.cos(angle) - dy * Math.sin(angle),
          y: cy + dx * Math.sin(angle) + dy * Math.cos(angle)
        };
      }

      function depositAt(x, y, target = heat) {
        const minCol = Math.max(0, Math.floor((x - BRUSH_RADIUS) / CELL));
        const maxCol = Math.min(columns - 1, Math.ceil((x + BRUSH_RADIUS) / CELL));
        const minRow = Math.max(0, Math.floor((y - BRUSH_RADIUS) / CELL));
        const maxRow = Math.min(rows - 1, Math.ceil((y + BRUSH_RADIUS) / CELL));
        const radiusSquared = BRUSH_RADIUS * BRUSH_RADIUS;
        for (let row = minRow; row <= maxRow; row++) {
          for (let col = minCol; col <= maxCol; col++) {
            const dx = col * CELL + CELL / 2 - x;
            const dy = row * CELL + CELL / 2 - y;
            const distanceSquared = dx * dx + dy * dy;
            if (distanceSquared >= radiusSquared) continue;
            const strength = Math.pow(1 - distanceSquared / radiusSquared, 1.25);
            const index = row * columns + col;
            target[index] = Math.max(target[index], strength);
          }
        }
      }

      function paintBetween(from, to) {
        const cx = width / 2;
        const cy = height / 2;
        const distance = from ? Math.hypot(to.x - from.x, to.y - from.y) : 0;
        const steps = Math.max(1, Math.ceil(distance / (CELL * 1.4)));
        for (let sample = 0; sample <= steps; sample++) {
          const amount = sample / steps;
          const source = from
            ? { x: from.x + (to.x - from.x) * amount, y: from.y + (to.y - from.y) * amount }
            : to;
          for (let step = 0; step < HEAT_DOTS; step++) {
            const reflected = rotatePoint(source, cx, cy, step);
            depositAt(reflected.x, reflected.y);
          }
        }
        point = to;
      }

      function render(now) {
        requestAnimationFrame(render);
        if(document.hidden){lastFrame=0;return;}
        if (lastFrame && now - lastFrame < 30) return;
        const elapsed = lastFrame ? Math.min(8, (now - lastFrame) / 1000) : 0;
        lastFrame = now;
        const preview=window.PlayableBatch4Preview?.active, reduced=window.PlayableBatch4Preview?.reduced;
        if(preview!==wasPreview){previewHeat.fill(0);wasPreview=preview;}
        if(preview){
          const source=window.PlayablePreviewModels.heatPose(reduced?0:window.PlayableBatch4Preview.elapsed(now),width,height,radius);
          for(let step=0;step<HEAT_DOTS;step++){const p=rotatePoint(source,width/2,height/2,step);depositAt(p.x,p.y,previewHeat);}
        }
        const visibleHeat=preview?previewHeat:heat;
        if(preview&&reduced)now=0;
        if (activePointer !== null && point) {
          for (let step = 0; step < HEAT_DOTS; step++) {
            const reflected = rotatePoint(point, width / 2, height / 2, step);
            depositAt(reflected.x, reflected.y);
          }
        }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.drawImage(backdrop, 0, 0, width, height);
        ctx.save();
        ctx.globalCompositeOperation = "screen";
        ctx.lineCap = "round";
        for (const wave of backgroundWaves) {
          ctx.strokeStyle = `rgba(116, 231, 239, ${wave.alpha})`;
          ctx.lineWidth = wave.width;
          ctx.beginPath();
          for (let x = -12; x <= width + 12; x += 7) {
            const y = height * wave.y
              + Math.sin(x / wave.wavelength * TAU + now * wave.speed + wave.phase) * wave.amplitude
              + Math.sin(x / wave.secondary * TAU - now * wave.speed * 0.58 + wave.phase * 1.7) * wave.amplitude * 0.28;
            if (x === -12) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
        }
        ctx.restore();
        const cellsByColor = heatColors.map(() => []);
        for (let index = 0; index < visibleHeat.length; index++) {
          const value = visibleHeat[index] = Math.max(0, visibleHeat[index] - elapsed * COOL_PER_SECOND);
          if (value < 0.08) continue;
          const patterned = value + (noise(index + 827) - 0.5) * 0.12;
          const band = patterned > 0.76 ? 5 : patterned > 0.6 ? 4 : patterned > 0.43 ? 3 : patterned > 0.23 ? 2 : patterned > 0.13 ? 1 : 0;
          cellsByColor[band].push(index);
        }
        for (let band = 0; band < heatColors.length; band++) {
          ctx.fillStyle = heatColors[band];
          ctx.beginPath();
          for (const index of cellsByColor[band]) {
            const col = index % columns;
            const row = Math.floor(index / columns);
            ctx.rect(col * CELL + 0.65, row * CELL + 0.65, CELL - 1.3, CELL - 1.3);
          }
          ctx.fill();
        }
      }

      function attachInput() {
        const inputCanvas = document.querySelector("#root canvas");
        if (!inputCanvas) return requestAnimationFrame(attachInput);
        inputCanvas.addEventListener("pointerdown", event => {
          if (event.isPrimary === false) return;
          event.preventDefault();
          activePointer = event.pointerId;
          inputCanvas.setPointerCapture?.(event.pointerId);
          paintBetween(null, constrainPoint(event.clientX, event.clientY));
        });
        inputCanvas.addEventListener("pointermove", event => {
          if (event.pointerId === activePointer) {
            event.preventDefault();
            paintBetween(point, constrainPoint(event.clientX, event.clientY));
          }
        });
        const release = event => {
          if (event.pointerId === activePointer) {
            activePointer = null;
            point = null;
          }
        };
        inputCanvas.addEventListener("pointerup", release);
        inputCanvas.addEventListener("pointercancel", release);
        inputCanvas.addEventListener("lostpointercapture", release);
        inputCanvas.addEventListener("keydown", event => {
          const move = { ArrowLeft: [-14, 0], ArrowRight: [14, 0], ArrowUp: [0, -14], ArrowDown: [0, 14] }[event.key];
          if (!move) return;
          event.preventDefault();
          const from = point || { x: width / 2 + 40, y: height / 2 };
          paintBetween(from, constrainPoint(from.x + move[0], from.y + move[1]));
        });

        const heading = document.querySelector("#root .heading");
        if (heading) heading.textContent = "THERMAL MIRROR";
      }

      window.addEventListener("resize", resize, { passive: true });
      resize();
      attachInput();
      requestAnimationFrame(render);
    })();
