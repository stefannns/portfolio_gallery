document.documentElement.lang = "it";
// Editable Batch 2 game. Rebuild using the platform app/h5_build/build.js.
const PACKAGE_CONFIG_FALLBACK = {
  "tweaks": [{
    "id": "BRUSH_1",
    "kind": "number",
    "label": "Brush size one",
    "value": 7,
    "default": 7,
    "min": 4,
    "max": 32,
    "step": 1
  }, {
    "id": "BRUSH_2",
    "kind": "number",
    "label": "Brush size two",
    "value": 10,
    "default": 10,
    "min": 4,
    "max": 32,
    "step": 1
  }, {
    "id": "BRUSH_3",
    "kind": "number",
    "label": "Brush size three",
    "value": 14,
    "default": 14,
    "min": 4,
    "max": 32,
    "step": 1
  }, {
    "id": "BRUSH_4",
    "kind": "number",
    "label": "Brush size four",
    "value": 20,
    "default": 20,
    "min": 4,
    "max": 32,
    "step": 1
  }, {
    "id": "BRUSH_5",
    "kind": "number",
    "label": "Brush size five",
    "value": 27,
    "default": 27,
    "min": 4,
    "max": 32,
    "step": 1
  }, {
    "id": "INK_FADE_MS",
    "kind": "number",
    "label": "Cover recovery time",
    "value": 3000,
    "default": 3000,
    "min": 2500,
    "max": 12000,
    "step": 100
  }, {
    "id": "INK_STEP",
    "kind": "number",
    "label": "Word spacing",
    "value": 15,
    "default": 15,
    "min": 6,
    "max": 30,
    "step": 1
  }, {
    "id": "ACCENT_RATE",
    "kind": "number",
    "label": "Accent rhythm",
    "value": 6,
    "default": 6,
    "min": 3,
    "max": 12,
    "step": 1
  }],
  "texts": [{
    "id": "GAME_TITLE",
    "label": "Title",
    "value": "Parole sul foglio",
    "default": "Parole sul foglio",
    "max_length": 30
  }, {
    "id": "DRAW_HINT",
    "label": "Drawing hint",
    "value": "Passa per svelare le parole",
    "default": "Passa per svelare le parole",
    "max_length": 30
  }, {
    "id": "CLEAR_CANVAS",
    "label": "Clear canvas label",
    "value": "Cancella il foglio",
    "default": "Cancella il foglio",
    "max_length": 30
  }, {
    "id": "BRUSH_LABEL_1",
    "label": "Fine brush label",
    "value": "Pennello sottile",
    "default": "Pennello sottile",
    "max_length": 30
  }, {
    "id": "BRUSH_LABEL_2",
    "label": "Small brush label",
    "value": "Pennello piccolo",
    "default": "Pennello piccolo",
    "max_length": 30
  }, {
    "id": "BRUSH_LABEL_3",
    "label": "Medium brush label",
    "value": "Pennello medio",
    "default": "Pennello medio",
    "max_length": 30
  }, {
    "id": "BRUSH_LABEL_4",
    "label": "Large brush label",
    "value": "Pennello grande",
    "default": "Pennello grande",
    "max_length": 30
  }, {
    "id": "BRUSH_LABEL_5",
    "label": "Wide brush label",
    "value": "Pennello largo",
    "default": "Pennello largo",
    "max_length": 30
  }, {
    "id": "POEM_1",
    "label": "Poem line one",
    "value": "fai spazio alla quiete",
    "default": "fai spazio alla quiete",
    "max_length": 40
  }, {
    "id": "POEM_2",
    "label": "Poem line two",
    "value": "una piccola luce diventa un sentiero",
    "default": "una piccola luce diventa un sentiero",
    "max_length": 40
  }, {
    "id": "POEM_3",
    "label": "Poem line three",
    "value": "custodisci questo istante",
    "default": "custodisci questo istante",
    "max_length": 40
  }, {
    "id": "POEM_4",
    "label": "Poem line four",
    "value": "la mano ricorda il cielo",
    "default": "la mano ricorda il cielo",
    "max_length": 40
  }, {
    "id": "POEM_5",
    "label": "Poem line five",
    "value": "ricomincia con un gesto lieve",
    "default": "ricomincia con un gesto lieve",
    "max_length": 40
  }, {
    "id": "POEM_6",
    "label": "Poem line six",
    "value": "ciò che svanisce lascia una traccia",
    "default": "ciò che svanisce lascia una traccia",
    "max_length": 40
  }],
  "images": [],
  "config_version": "2.0",
  "playable": {
    "post_id": "109025442493025995",
    "version_id": "109025442492874407",
    "runtime_target": "h5",
    "h5_playstyle_type": "general_game",
    "content_locale": "it",
    "min_capability_level": 1,
    "full_capability_level": 1
  }
};
const PACKAGE_HTML_STYLES = "html,body,#root{width:100%;height:100%;margin:0;overflow:hidden}body{background:#050607}";

/* BATCH2_IDLE_20261102 */
/* Game-owned, silent demonstration clock. Never dispatches gameplay input. */
(() => {
  'use strict';

  if (window.PlayableIdlePreview) return;
  const query = new URLSearchParams(location.search);
  const hosted = query.get('feedReview') === '1' || query.get('host') === 'fyp';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let preview = hosted,
    elapsed = 0,
    last = performance.now();
  const listeners = new Set();
  const sync = () => {
    const html = document.documentElement;
    html.dataset.batch2Idle = String(preview);
    html.dataset.batch2IdlePaused = String(document.hidden);
    html.dataset.batch2IdleReduced = String(reduced.matches);
    if (!preview) for (const node of document.querySelectorAll('[data-idle-preview]')) node.dataset.idlePreview = 'off';
    last = performance.now();
    for (const fn of listeners) fn(preview && !document.hidden);
  };
  const clock = () => {
    const now = performance.now();
    if (preview && !document.hidden && !reduced.matches) elapsed += Math.min(64, Math.max(0, now - last));
    last = now;
    return reduced.matches ? 1600 : elapsed;
  };
  const clamp = (n, a = 0, b = 1) => Math.max(a, Math.min(b, n));
  const ease = t => (t = clamp(t), t * t * (3 - 2 * t));
  const trace = (ctx, points, progress = 1) => {
    if (!points.length) return;
    const distances = points.slice(1).map((p, i) => Math.hypot(p.x - points[i].x, p.y - points[i].y));
    let left = distances.reduce((a, b) => a + b, 0) * clamp(progress);
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      const p = points[i - 1],
        q = points[i],
        d = distances[i - 1];
      const t = Math.min(1, left / Math.max(.01, d));
      ctx.lineTo(p.x + (q.x - p.x) * t, p.y + (q.y - p.y) * t);
      left -= d;
      if (left <= 0) break;
    }
    ctx.stroke();
  };
  const onPath = (points, progress) => {
    const lengths = points.slice(1).map((p, i) => Math.hypot(p.x - points[i].x, p.y - points[i].y));
    let distance = lengths.reduce((a, b) => a + b, 0) * clamp(progress);
    for (let i = 1; i < points.length; i++) {
      const a = points[i - 1],
        b = points[i],
        length = lengths[i - 1];
      if (distance <= length || i === points.length - 1) {
        const t = clamp(distance / Math.max(.01, length));
        return {
          x: a.x + (b.x - a.x) * t,
          y: a.y + (b.y - a.y) * t
        };
      }
      distance -= length;
    }
    return points[0];
  };
  const stamp = (canvas, kind, phase = clock()) => {
    if (!canvas) return;
    canvas.dataset.idlePreview = preview ? kind : 'off';
    canvas.dataset.idlePhase = String(Math.round(phase));
  };
  function ant(ctx, w, h, image) {
    const t = clock() / 1000,
      p = t % 5.4 / 5.4;
    const cx = w * .5,
      cy = h * .51,
      rx = Math.min(w * .29, 105),
      ry = Math.min(h * .16, 78);
    const path = Array.from({
      length: 81
    }, (_, i) => ({
      x: cx + Math.cos(i / 80 * Math.PI * 2) * rx,
      y: cy + Math.sin(i / 80 * Math.PI * 2) * ry
    }));
    ctx.save();
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#242322';
    ctx.globalAlpha = p > .88 ? (1 - p) / .12 : 1;
    trace(ctx, path, ease(p / .48));
    const x = cx + Math.sin(t * 2.1) * rx * .63,
      y = cy + Math.sin(t * 2.8) * ry * .59;
    ctx.translate(x, y);
    ctx.rotate(Math.atan2(Math.cos(t * 2.8) * ry, Math.cos(t * 2.1) * rx) + Math.PI / 2);
    if (image?.complete && image.naturalWidth) ctx.drawImage(image, -17, -17, 34, 34);else {
      ctx.fillStyle = '#242322';
      for (const [y, r] of [[-7, 5], [0, 4], [7, 6]]) {
        ctx.beginPath();
        ctx.ellipse(0, y, r, r * 1.2, 0, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
    stamp(ctx.canvas, 'ant-loop');
  }
  function army(state, w, h) {
    const t = clock() / 1000;
    const players = state.entities.filter(e => e.team === 'player'),
      cx = players.reduce((n, e) => n + e.x, 0) / Math.max(1, players.length),
      cy = players.reduce((n, e) => n + e.y, 0) / Math.max(1, players.length);
    return {
      ...state,
      particles: [],
      playerTarget: {
        x: w * (.5 + Math.sin(t * .8) * .18),
        y: h * (.43 + Math.cos(t * .8) * .04)
      },
      entities: state.entities.map((entity, i) => ({
        ...entity,
        x: entity.team === 'player' ? w * (.5 + Math.sin(t * .8) * .14) + (entity.x - cx) * .7 : entity.x + Math.sin(t * 1.5 + i * .7) * 8,
        y: entity.team === 'player' ? h * (.57 + Math.cos(t * .8) * .04) + (entity.y - cy) * .7 : entity.y + Math.cos(t * 1.5 + i * .7) * 8
      }))
    };
  }
  function blade(ctx, w, h, top, bottom) {
    const t = clock() / 1000,
      p = t % 5.8 / 5.8,
      cx = w / 2,
      cy = (top + bottom) / 2;
    const points = [[-.22, .16], [-.11, .02], [.04, .04], [.17, -.17], [.24, -.11]].map(([x, y]) => ({
      x: cx + x * w,
      y: cy + y * (bottom - top)
    }));
    ctx.save();
    ctx.strokeStyle = '#303936';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.globalAlpha = p > .9 ? (1 - p) / .1 : 1;
    if (p < .5) trace(ctx, points, ease(p / .45));else {
      ctx.translate(cx, cy);
      ctx.rotate((p - .5) * Math.PI * 3.4);
      trace(ctx, points.map(v => ({
        x: v.x - cx,
        y: v.y - cy
      })));
      ctx.fillStyle = '#303936';
      ctx.beginPath();
      ctx.arc(0, 0, 11, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
    stamp(ctx.canvas, 'draw-and-spin-blade');
  }
  function roadPose(key) {
    const t = clock() / 1000,
      offset = key === 'player' ? 0 : key === 'copL' ? 1.3 : 2.2;
    const q = t * .75 - offset,
      x = 375 + Math.sin(q) * 130,
      y = key === 'player' ? 800 : 1040 + (key === 'copR' ? 60 : 0);
    return {
      x: x + (key === 'copL' ? -85 : key === 'copR' ? 85 : 0),
      y: y + Math.cos(q) * 28,
      angle: -Math.PI / 2 + Math.cos(q) * .18
    };
  }
  function road(ctx) {
    const p = roadPose('player');
    ctx.save();
    ctx.strokeStyle = '#ffffff88';
    ctx.setLineDash([11, 12]);
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.bezierCurveTo(p.x + 100, p.y - 100, 340, p.y - 220, 420, p.y - 340);
    ctx.stroke();
    ctx.restore();
    stamp(ctx.canvas, 'escape-route');
  }
  function route(start, end, circles, w) {
    const nodes = [start, end];
    for (const circle of circles) for (let i = 0; i < 12; i++) {
      const a = i * Math.PI / 6,
        r = circle.circleRadius + 16;
      const p = {
        x: circle.position.x + Math.cos(a) * r,
        y: circle.position.y + Math.sin(a) * r
      };
      if (p.x > 15 && p.x < w - 15) nodes.push(p);
    }
    const distance = nodes.map(() => Infinity),
      previous = nodes.map(() => -1),
      visited = new Set();
    distance[0] = 0;
    const clear = (a, b) => circles.every(c => {
      const dx = b.x - a.x,
        dy = b.y - a.y,
        t = clamp(((c.position.x - a.x) * dx + (c.position.y - a.y) * dy) / Math.max(.01, dx * dx + dy * dy));
      return Math.hypot(a.x + dx * t - c.position.x, a.y + dy * t - c.position.y) > c.circleRadius + 7;
    });
    for (let pass = 0; pass < nodes.length; pass++) {
      let k = -1;
      for (let j = 0; j < nodes.length; j++) if (!visited.has(j) && (k < 0 || distance[j] < distance[k])) k = j;
      if (k < 0 || !Number.isFinite(distance[k])) break;
      if (k === 1) break;
      visited.add(k);
      for (let j = 0; j < nodes.length; j++) {
        if (visited.has(j) || !clear(nodes[k], nodes[j])) continue;
        const d = distance[k] + Math.hypot(nodes[k].x - nodes[j].x, nodes[k].y - nodes[j].y);
        if (d < distance[j]) {
          distance[j] = d;
          previous[j] = k;
        }
      }
    }
    if (previous[1] < 0) return [start, {
      x: 20,
      y: start.y + 24
    }, {
      x: 20,
      y: end.y - 28
    }, end];
    const path = [];
    for (let k = 1; k >= 0; k = previous[k]) {
      path.unshift(nodes[k]);
      if (k === 0) break;
    }
    return path;
  }
  let sodaCache = null;
  function soda(ctx, source, cup, cupW, cupH, bodies, w) {
    if (!source || !cup) return;
    const t = clock() / 1000,
      p = t % 5.6;
    const circles = bodies.filter(b => b.label === 'obstacle'),
      key = JSON.stringify([source, cup, w, circles.map(c => [c.position.x, c.position.y, c.circleRadius])]);
    if (sodaCache?.key !== key) sodaCache = {
      key,
      points: route({
        x: source.x,
        y: source.y + 21
      }, {
        x: cup.x,
        y: cup.y - cupH * .42
      }, circles, w)
    };
    const points = sodaCache.points;
    ctx.save();
    ctx.strokeStyle = '#242322';
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.globalAlpha = p > 5 ? (5.6 - p) / .6 : 1;
    trace(ctx, points, ease(p / 1.7));
    if (p > 1.4 && p < 5) {
      for (let i = 0; i < 15; i++) {
        const q = (p - 1.4) * .65 - i * .067;
        if (q < 0 || q > 1) continue;
        const at = onPath(points, q);
        ctx.fillStyle = '#59c6b1';
        ctx.strokeStyle = '#242322';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(at.x, at.y, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
    }
    ctx.restore();
    stamp(ctx.canvas, 'guided-soda-route');
  }
  const style = document.createElement('style');
  style.dataset.batch2IdleStyle = '';
  style.textContent = `
    html[data-batch2-idle=true] .idle-memory-deck{display:block}
    .idle-memory-deck{position:absolute;inset:0;display:none;overflow:hidden;pointer-events:none}
    .idle-memory-deck img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;opacity:0;animation:idle-memory-photo 7.2s linear infinite}
    .idle-memory-deck img:nth-child(2){animation-delay:-4.8s}.idle-memory-deck img:nth-child(3){animation-delay:-2.4s}
    .idle-clean-tool{display:none;position:absolute;z-index:5;left:var(--idle-clean-x,25%);top:var(--idle-clean-y,54%);width:76px;height:95px;pointer-events:none;transform:translate(-50%,-35%)}
    .idle-clean-tool>span{display:none;width:100%;height:100%}.idle-clean-tool img{width:100%;height:100%;object-fit:contain}
    html[data-batch2-idle=true] .idle-clean-tool{display:block}
    [data-idle-clean-tool=spray] .idle-clean-spray,[data-idle-clean-tool=brush] .idle-clean-brush,[data-idle-clean-tool=rinse] .idle-clean-rinse{display:block}
    html[data-batch2-idle=true] .video-window>img{visibility:hidden}
    @keyframes idle-memory-photo{0%,29%{opacity:1;transform:scale(1)}33%,96%{opacity:0;transform:scale(1.035)}100%{opacity:1;transform:scale(1)}}
    html[data-batch2-idle=true] .tool-swing{animation:idle-tool-hit 2.6s ease-in-out infinite!important;transform-origin:70% 75%}
    html[data-batch2-idle=true] .target-art{animation:idle-stick-react 2.6s ease-in-out infinite!important;transform-origin:50% 75%}
    @keyframes idle-tool-hit{0%,32%,100%{transform:translate(10px,5px) rotate(-25deg)}46%{transform:translate(-30px,-8px) rotate(-64deg)}55%,70%{transform:translate(6px,7px) rotate(-20deg)}}
    @keyframes idle-stick-react{0%,45%,72%,100%{transform:rotate(0) scale(1)}50%{transform:translate(-4px,2px) rotate(-3deg) scale(1.025,.97)}60%{transform:rotate(1.5deg) scale(.99,1.01)}}
    html[data-batch2-idle-paused=true] :is(.idle-memory-deck img,.tool-swing,.target-art){animation-play-state:paused!important}
    html[data-batch2-idle-reduced=true] :is(.idle-memory-deck img,.tool-swing,.target-art){animation:none!important}
    html[data-batch2-idle-reduced=true] .idle-memory-deck img:first-child{opacity:1}
  `;
  document.head.append(style);
  window.PlayableIdlePreview = Object.freeze({
    get active() {
      return preview && !document.hidden;
    },
    get preview() {
      return preview;
    },
    get reduced() {
      return reduced.matches;
    },
    get seconds() {
      return clock() / 1000;
    },
    clock,
    ease,
    clamp,
    stamp,
    trace,
    onPath,
    ant,
    army,
    blade,
    road,
    roadPose,
    soda,
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    }
  });
  addEventListener('message', event => {
    if (parent === window || event.source !== parent || event.origin !== location.origin || event.data?.type !== 'playable-active') return;
    const next = event.data.active !== true;
    if (next !== preview) {
      preview = next;
      elapsed = 0;
    }
    sync();
  });
  document.addEventListener('visibilitychange', sync);
  reduced.addEventListener?.('change', sync);
  addEventListener('pagehide', () => {
    preview = false;
    sync();
    listeners.clear();
  }, {
    once: true
  });
  sync();
})();
import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';

// This bridge belongs to the game; it does not reproduce host UI or gradients.
const feedSession = (() => {
  const embedded = window.parent !== window && new URLSearchParams(location.search).get('feedReview') === '1';
  let active = !embedded;
  const listeners = new Set();
  const update = () => {
    document.documentElement.dataset.feedPreview = String(!active);
    for (const callback of listeners) callback(active && !document.hidden);
  };
  window.addEventListener('message', event => {
    if (!embedded || event.source !== parent || event.origin !== location.origin || event.data?.type !== 'playable-active') return;
    active = event.data.active === true;
    update();
  });
  document.addEventListener('visibilitychange', update);
  update();
  return {
    get active() {
      return active && !document.hidden;
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    }
  };
})();
const reducedMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
function useFeedActive() {
  const [active, setActive] = React.useState(feedSession.active);
  React.useEffect(() => feedSession.subscribe(setActive), []);
  return active;
}
function BatchPolish() {
  const active = useFeedActive();
  return <>
    <style>{POLISH_CSS}</style>
    {!active && [80, 81, 84].includes(GAME_NUMBER) && <div className={'preview-example example-' + GAME_NUMBER} aria-hidden="true">
      {GAME_NUMBER === 80 && <svg viewBox="0 0 320 220"><defs><radialGradient id="soft-example" cx=".35" cy=".2" r=".9"><stop stopColor="#ffe4bd" /><stop offset="1" stopColor="#f3ad97" /></radialGradient></defs><path className="example-blob" d="M78 61C112 16 184 23 192 66C206 88 248 75 249 113C251 162 200 176 165 166C117 195 69 166 80 124C40 101 47 78 78 61Z" fill="url(#soft-example)" stroke="#d99485" strokeWidth="2" /><g className="example-eyes"><ellipse cx="136" cy="91" rx="11" ry="14" fill="white" /><ellipse cx="168" cy="91" rx="11" ry="14" fill="white" /><circle cx="139" cy="94" r="5" fill="#443c39" /><circle cx="171" cy="94" r="5" fill="#443c39" /></g></svg>}
      {GAME_NUMBER === 81 && <svg viewBox="0 0 320 220"><path className="example-noodle" d="M65 145C44 109 84 61 115 88S139 171 187 151S250 80 263 126" fill="none" stroke="#e4d3ed" strokeWidth="29" strokeLinecap="round" /><path className="example-noodle" d="M65 145C44 109 84 61 115 88S139 171 187 151S250 80 263 126" fill="none" stroke="#3e3b42" strokeWidth="13" strokeLinecap="round" /><circle cx="129" cy="103" r="6" fill="white" /><circle cx="144" cy="111" r="6" fill="white" /><circle cx="130" cy="104" r="2.4" /><circle cx="145" cy="112" r="2.4" /><path d="M115 151q-5 17-15 11M186 160q5 18 15 9" fill="none" stroke="#3e3b42" strokeWidth="3" strokeLinecap="round" /></svg>}
      {GAME_NUMBER === 84 && <div className="example-poem">una piccola linea diventa un pensiero<br />le parole vagano sul foglio<br /><em>piano</em> si apre un piccolo mondo<br />ogni segno è un momento<br />e ogni momento può ricominciare</div>}
    </div>}
  </>;
}
const BASE_CSS = `
button { touch-action: manipulation; }
button:focus-visible { outline: 3px solid #3c8ddd; outline-offset: 3px; }
@keyframes batchBreathe { 0%,100% { opacity:.72; } 50% { opacity:1; } }
.preview-example { position:fixed; z-index:2; pointer-events:none; width:min(80%,340px); left:50%; top:35%; transform:translateX(-50%); }
.preview-example svg { width:100%; height:auto; overflow:visible; }
.example-blob { transform-origin:50% 60%; animation:exampleSquish 3.8s ease-in-out infinite; }
.example-noodle { transform-origin:50% 70%; animation:exampleWiggle 3.6s ease-in-out infinite; }
.example-poem { padding:20px; color:#44444c; font:15px/1.8 ui-monospace,monospace; clip-path:ellipse(49% 47% at 50% 50%); animation:exampleInk 5s ease-in-out infinite; }
.example-poem em { color:#ad7397; font-style:normal; }
@keyframes exampleSquish { 0%,100% {transform:scale(1,1) rotate(-3deg)} 40% {transform:scale(1.06,.94) rotate(2deg)} 70% {transform:scale(.96,1.04) rotate(-1deg)} }
@keyframes exampleWiggle { 0%,100% { transform:rotate(-3deg) translateY(0); } 50% { transform:rotate(3deg) translateY(-5px); } }
@keyframes exampleInk { 0%,100% {opacity:.25;clip-path:ellipse(23% 35% at 32% 50%)} 45%,70% {opacity:.9;clip-path:ellipse(49% 47% at 50% 50%)} }
@media (prefers-reduced-motion:reduce) { *,*::before,*::after { animation:none!important; transition:none!important; } }
`;
const GAME_NUMBER = 84;
const POLISH_CSS = "";
const DEFAULTS = {
  BRUSH_1: 7,
  BRUSH_2: 10,
  BRUSH_3: 14,
  BRUSH_4: 20,
  BRUSH_5: 27,
  INK_FADE_MS: 3000,
  INK_STEP: 15,
  ACCENT_RATE: 6,
  GAME_TITLE: "Parole sul foglio",
  DRAW_HINT: "Passa per svelare le parole",
  CLEAR_CANVAS: "Cancella il foglio",
  BRUSH_LABEL_1: "Pennello sottile",
  BRUSH_LABEL_2: "Pennello piccolo",
  BRUSH_LABEL_3: "Pennello medio",
  BRUSH_LABEL_4: "Pennello grande",
  BRUSH_LABEL_5: "Pennello largo",
  POEM_1: "fai spazio alla quiete",
  POEM_2: "una piccola luce diventa un sentiero",
  POEM_3: "custodisci questo istante",
  POEM_4: "la mano ricorda il cielo",
  POEM_5: "ricomincia con un gesto lieve",
  POEM_6: "ciò che svanisce lascia una traccia"
};
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
function letterLifetime(duration, random = Math.random) {
  return duration * (.18 + .82 * random());
}
function refreshGlyph(glyph, now, duration, random = Math.random) {
  // Roll once per fresh reveal, so position never determines recovery order.
  // Holding/rebrushing an exposed letter extends that same deadline without
  // rerolling it on every frame and making the character flicker.
  if (glyph.until <= now || !glyph.lifetime) glyph.lifetime = letterLifetime(duration, random);
  glyph.until = now + glyph.lifetime;
}
function glyphHit(glyph, a, b, r, width, height) {
  const ax = a.x * width,
    ay = a.y * height,
    dx = (b.x - a.x) * width,
    dy = (b.y - a.y) * height,
    cx = glyph.x + glyph.w / 2,
    cy = glyph.y + glyph.h * .55,
    t = clamp(((cx - ax) * dx + (cy - ay) * dy) / (dx * dx + dy * dy || 1), 0, 1);
  return Math.hypot(cx - ax - t * dx, cy - ay - t * dy) <= r * width + glyph.w * .35;
}
function App() {
  const active = useFeedActive(),
    [cfg, setCfg] = useState(DEFAULTS),
    [brush, setBrush] = useState(2),
    [guide, setGuide] = useState(true);
  const canvasRef = useRef(null),
    layers = useRef(null),
    pointer = useRef(null),
    clock = useRef({
      value: 0,
      last: 0
    }),
    cfgRef = useRef(cfg),
    brushRef = useRef(2),
    activeRef = useRef(active),
    audio = useRef(null),
    samples = useRef(new Map());
  cfgRef.current = cfg;
  activeRef.current = active;
  brushRef.current = brush;
  useEffect(() => {
    let alive = true;
    fetch('./game.config.json').then(r => r.json()).then(raw => {
      if (alive) setCfg({
        ...DEFAULTS,
        ...Object.fromEntries([...raw.texts, ...raw.tweaks].map(x => [x.id, x.value]))
      });
    }).catch(() => {});
    return () => {
      alive = false;
    };
  }, []);
  const sound = kind => {
    if (!feedSession.active) return;
    const paths = {
      clear: './assets/sfx_paper_clear.mp3',
      tap: './assets/sfx_paper_tap.mp3',
      brush: './assets/sfx_paper_brush.mp3'
    };
    playPackageSound('word-' + kind, paths[kind]);
  };
  useEffect(() => () => {
    try {
      audio.current?.close();
    } catch {}
  }, []);
  useEffect(() => {
    clock.current.last = performance.now();
    pointer.current = null;
  }, [active]);
  useEffect(() => {
    const pause = () => {
      clock.current.last = performance.now();
      pointer.current = null;
    };
    document.addEventListener('visibilitychange', pause);
    return () => document.removeEventListener('visibilitychange', pause);
  }, []);
  const paintSegment = (a, b, r, now) => {
    const l = layers.current;
    if (!l) return;
    const duration = Math.max(500, Number(cfgRef.current.INK_FADE_MS) || 3000);
    for (const glyph of l.glyphs) if (glyphHit(glyph, a, b, r, l.width, l.height)) refreshGlyph(glyph, now, duration);
  };
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const build = () => {
      const rect = canvas.getBoundingClientRect(),
        width = rect.width,
        height = rect.height,
        dpr = Math.min(devicePixelRatio || 1, 2),
        old = layers.current;
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      const ctx = canvas.getContext('2d'),
        fontSize = clamp(width * .029, 10, 13),
        lineHeight = fontSize * 1.4,
        margin = 25;
      const font = `500 ${fontSize}px ui-monospace,Menlo,monospace`;
      ctx.font = font;
      const words = Array.from({
        length: 6
      }, (_, i) => String(cfgRef.current['POEM_' + (i + 1)] || '')).join('. ').split(/\s+/).filter(Boolean);
      const spacing = Math.max(3, Number(cfgRef.current.INK_STEP) * .3),
        accent = Math.max(3, Number(cfgRef.current.ACCENT_RATE)),
        layout = [],
        glyphs = [];
      let x = margin,
        y = 30,
        index = 0;
      while (y < height - 112 && words.length) {
        const word = words[index % words.length],
          wordWidth = ctx.measureText(word).width;
        if (x + wordWidth > width - margin) {
          x = margin;
          y += lineHeight;
          if (y >= height - 112) break;
        }
        const color = index % accent === 0 ? ['#b98b9c', '#9b92b7', '#91a98d'][Math.floor(index / accent) % 3] : '#3b3c41';
        layout.push(word + ':' + Math.round(x) + ':' + Math.round(y));
        let letterX = x;
        for (const char of word) {
          const w = ctx.measureText(char).width,
            i = glyphs.length;
          glyphs.push({
            char,
            x: letterX,
            y,
            w,
            h: fontSize,
            color,
            index: i,
            until: old?.glyphs[i]?.until || 0,
            lifetime: old?.glyphs[i]?.lifetime || 0,
            demoBorn: -1,
            demoLifetime: 0
          });
          letterX += w;
        }
        x += wordWidth + spacing;
        index++;
      }
      // The preview brushes open these same stationary letters. It has its own
      // illustrative timing and never changes the player's recovery deadlines.
      for (let i = 0; i < 36; i++) {
        const p = t => ({
          x: .16 + t * .68,
          y: .48 + Math.sin(t * 4) * .08
        });
        for (const glyph of glyphs) if (glyphHit(glyph, p(i / 36), p((i + 1) / 36), .095, width, height)) glyph.demoBorn = i / 36 * 1800;
      }
      let hash = 2166136261;
      for (const char of layout.join('|')) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
      canvas.dataset.textLayout = String(hash >>> 0);
      canvas.dataset.recoveryMode = 'letter-by-letter';
      canvas.dataset.recoveryOrder = 'random';
      layers.current = {
        glyphs,
        width,
        height,
        dpr,
        font,
        demoCycle: -1
      };
    };
    const observer = new ResizeObserver(build);
    observer.observe(canvas);
    build();
    document.fonts?.ready.then(() => {
      if (canvasRef.current === canvas) build();
    });
    let raf = 0;
    const frame = now => {
      const time = clock.current,
        last = time.last || now;
      time.last = now;
      if (activeRef.current && !document.hidden) time.value += Math.max(0, now - last);else pointer.current = null;
      const l = layers.current;
      if (l) {
        const duration = Math.max(500, Number(cfgRef.current.INK_FADE_MS) || 3000),
          pen = pointer.current;
        if (activeRef.current && pen && time.value - pen.lastStamp > 90) {
          paintSegment(pen.last, pen.last, pen.r, time.value);
          pen.lastStamp = time.value;
        }
        const ctx = canvas.getContext('2d');
        ctx.setTransform(l.dpr, 0, 0, l.dpr, 0, 0);
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, l.width, l.height);
        ctx.font = l.font;
        ctx.textBaseline = 'top';
        const idleTime = window.PlayableIdlePreview.clock(),
          previewTime = reducedMotionQuery.matches ? 1800 : idleTime % (duration + 2000),
          previewCycle = reducedMotionQuery.matches ? 0 : Math.floor(idleTime / (duration + 2000));
        let visible = 0;
        if (!activeRef.current && l.demoCycle !== previewCycle) {
          l.demoCycle = previewCycle;
          for (const glyph of l.glyphs) glyph.demoLifetime = letterLifetime(duration);
        }
        for (const glyph of l.glyphs) {
          const shown = activeRef.current ? glyph.until > time.value : glyph.demoBorn >= 0 && previewTime >= glyph.demoBorn && previewTime < glyph.demoBorn + glyph.demoLifetime;
          if (!shown) continue;
          // Each character stays fully opaque until its own deadline, then
          // disappears in one frame. There is no opacity or mask interpolation.
          ctx.fillStyle = glyph.color;
          ctx.fillText(glyph.char, glyph.x, glyph.y);
          visible++;
        }
        if (window.PlayableIdlePreview.active) {
          const p = Math.min(1, previewTime / 1800),
            x = (.16 + p * .68) * l.width,
            y = (.48 + Math.sin(p * 4) * .08) * l.height;
          ctx.save();
          ctx.globalAlpha = previewTime < 1950 ? .55 : 0;
          ctx.strokeStyle = '#9b92b7';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(x, y, 14, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
          window.PlayableIdlePreview.stamp(canvas, 'brush-open-letters');
        }
        canvas.dataset.visibleLetters = String(visible);
        canvas.dataset.revealOpacity = visible ? '1' : '0';
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      layers.current = null;
    };
  }, [cfg]);
  const pointFor = event => {
    const rect = canvasRef.current.getBoundingClientRect();
    return {
      x: clamp((event.clientX - rect.left) / rect.width, 0, 1),
      y: clamp((event.clientY - rect.top) / rect.height, 0, 1)
    };
  };
  const start = event => {
    if (!activeRef.current || pointer.current || event.isPrimary === false || event.pointerType === 'mouse' && event.button !== 0) return;
    const point = pointFor(event);
    const width = canvasRef.current.getBoundingClientRect().width;
    const size = Number(cfgRef.current['BRUSH_' + (brushRef.current + 1)]) || 14;
    const radius = size * 1.7 / width;
    const now = clock.current.value;
    pointer.current = {
      id: event.pointerId,
      last: point,
      r: radius,
      lastStamp: now
    };
    paintSegment(point, point, radius, now);
    setGuide(false);
    event.currentTarget.setPointerCapture(event.pointerId);
    sound('brush');
  };
  const move = event => {
    const pen = pointer.current;
    if (!pen || pen.id !== event.pointerId) return;
    const point = pointFor(event);
    const layer = layers.current;
    if (!layer) return;
    const distance = Math.hypot((point.x - pen.last.x) * layer.width, (point.y - pen.last.y) * layer.height);
    if (distance < 1) return;
    const now = clock.current.value;
    paintSegment(pen.last, point, pen.r, now);
    pen.last = point;
    pen.lastStamp = now;
  };
  const end = event => {
    if (pointer.current?.id === event.pointerId) pointer.current = null;
  };
  const clear = () => {
    if (layers.current) layers.current.glyphs.forEach(g => {
      g.until = 0;
    });
    pointer.current = null;
    setGuide(true);
    sound('clear');
  };
  return <main className="word-reveal" aria-label={cfg.GAME_TITLE}>
    <canvas ref={canvasRef} aria-label="Lettere già scritte nascoste sotto una copertura. Passa per svelarle: scompariranno una alla volta." onPointerDown={start} onPointerMove={move} onPointerUp={end} onPointerCancel={end} onLostPointerCapture={end} />
    {guide && <p className="reveal-guide">{cfg.DRAW_HINT}</p>}
    <nav className="reveal-toolbar" aria-label="Comandi del pennello">
      {Array.from({
        length: 5
      }, (_, i) => <button key={i} className={i === brush ? 'selected' : ''} aria-label={cfg['BRUSH_LABEL_' + (i + 1)]} aria-pressed={i === brush} onClick={() => {
        setBrush(i);
        sound('tap');
      }}><span style={{
          fontSize: Math.min(32, 16 + i * 4)
        }}>✦</span></button>)}
      <button aria-label={cfg.CLEAR_CANVAS} onClick={clear}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 7h12M9 7V4h6v3M7 7l1 13h8l1-13M10 10v6m4-6v6" /></svg></button>
    </nav>
    <style>{BASE_CSS + CSS}</style>
  </main>;
}
const CSS = `
@font-face{font-family:Poppins;src:url('./assets/fonts/poppins/Poppins-Regular.woff2') format('woff2');font-weight:400;font-display:swap}@font-face{font-family:Poppins;src:url('./assets/fonts/poppins/Poppins-Bold.woff2') format('woff2');font-weight:700;font-display:swap}
*{box-sizing:border-box}html,body,#root{width:100%;height:100%;margin:0;overflow:hidden}body{background:#fff;font-family:Poppins,system-ui,sans-serif;-webkit-tap-highlight-color:transparent}button{font:inherit;cursor:pointer;border:0;touch-action:manipulation}.word-reveal{position:relative;width:100%;height:100%;overflow:hidden;background:#fff}.word-reveal canvas{display:block;width:100%;height:100%;touch-action:none;user-select:none;cursor:crosshair}.reveal-guide{position:absolute;top:24%;left:30px;right:30px;transform:translateY(-50%);margin:0;text-align:center;font-size:18px;font-weight:700;line-height:1.3;color:#49454f;pointer-events:none;animation:batchBreathe 2.6s ease-in-out infinite}.reveal-toolbar{position:absolute;bottom:50px;left:30px;right:30px;display:flex;align-items:center;min-height:48px;padding:2px 3px;gap:1px;background:#ffffffed;border:1px solid #e9e7ec;border-radius:28px}.reveal-toolbar button{flex:1;min-width:0;height:46px;padding:0;background:transparent;color:#aaa6ad;border-radius:23px;display:grid;place-items:center}.reveal-toolbar button.selected{color:#cd8a79;background:#fff2ed}.reveal-toolbar button:active{transform:scale(.94)}.reveal-toolbar svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}[data-feed-preview=true] .reveal-toolbar{visibility:hidden}`;
createRoot(document.getElementById('root')).render(<><style>{PACKAGE_HTML_STYLES}</style>{<App />}</>);

/* Decorative CTA breathing only. No positions, inputs, clocks or game state. */
(() => {
  const selectors = [".reveal-guide"],
    copy = new Set(["Passa per svelare le parole"].map(s => s.replace(/\s+/g, ' ').trim().toLowerCase()));
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)'),
    running = new Map();
  let queued = false,
    visible = true;
  const action = /^(?:(?:tap|drag|hold|swipe|draw|use|press|click|release|brush|pull|touch|pinch|rub|move|trace)\b|spray\s*[→-]|tocca\b|trascina\b|tieni\b|scorri\b|disegna\b|premi\b|点击|轻触|滑动|按住|拖动|长按|双击)/i;
  function scan() {
    queued = false;
    for (const [el, a] of running) if (!el.isConnected) {
      a.cancel();
      running.delete(el);
    }
    if (motion.matches) {
      for (const a of running.values()) a.cancel();
      running.clear();
      return;
    }
    const targets = new Set();
    for (const selector of selectors) {
      try {
        document.querySelectorAll(selector).forEach(el => targets.add(el));
      } catch {}
    }
    for (const el of document.querySelectorAll('p,span,div,label,text')) {
      if (el.children.length || el.closest('button,a,input,select,textarea,[role="button"]')) continue;
      const text = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (text.length >= 5 && text.length <= 140 && (copy.has(text.toLowerCase()) || !selectors.length && action.test(text))) targets.add(el);
    }
    for (const el of targets) {
      if (running.has(el) || typeof el.animate !== 'function') continue;
      if ([...targets].some(child => child !== el && el.contains(child))) continue;
      const style = getComputedStyle(el);
      if (/breath/i.test(style.animationName)) continue;
      const base = style.filter.replace(/opacity\([^)]*\)/g, '').replace(/^none$/, '').trim(),
        filter = v => (base ? base + ' ' : '') + 'opacity(' + v + ')';
      const a = el.animate([{
        filter: filter(1)
      }, {
        filter: filter(.65)
      }, {
        filter: filter(1)
      }], {
        duration: 2400,
        iterations: Infinity,
        easing: 'ease-in-out'
      });
      running.set(el, a);
      if (document.hidden || !visible) a.pause();
    }
  }
  const schedule = () => {
    if (!queued) {
      queued = true;
      requestAnimationFrame(scan);
    }
  };
  const pause = () => {
    for (const a of running.values()) document.hidden || !visible ? a.pause() : a.play();
  };
  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });
  const intersection = typeof IntersectionObserver === 'function' ? new IntersectionObserver(entries => {
    visible = entries.some(e => e.isIntersecting);
    pause();
  }) : null;
  if (document.body) intersection?.observe(document.body);else document.addEventListener('DOMContentLoaded', () => intersection?.observe(document.body), {
    once: true
  });
  document.addEventListener('visibilitychange', pause);
  motion.addEventListener?.('change', schedule);
  schedule();
  window.addEventListener('pagehide', () => {
    observer.disconnect();
    intersection?.disconnect();
    for (const a of running.values()) a.cancel();
    running.clear();
  }, {
    once: true
  });
})();
function playPackageSound(key, soundPath, minGapMs = 90) {
  if (!soundPath || document.hidden || !window.SFX) return;
  window.SFX.register({
    [key]: soundPath
  });
  window.SFX.unlock();
  window.SFX.play(key, {
    minGapMs
  });
}
